#ifndef CONNECTION_H
#define CONNECTION_H

#include <QtGui>
#include <QtSql>

<<<<<<< HEAD:connection.h
=======
<<<<<<< HEAD:connection.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:connection.h
static void connectionParametrs(QString& host, int& port, QString& dataBaseName,
                  QString& userName, QString& password)
{
    QFile *file = new QFile("preferences.xml");
    if (!file->open(QFile::ReadOnly | QFile::Text)) {
        return;
    }

    QXmlStreamReader xmlReader(file);
    xmlReader.readNext();
    xmlReader.readNext();
    xmlReader.readNext();
    xmlReader.readNext();
    host = xmlReader.readElementText();
    xmlReader.readNext();
    xmlReader.readNext();
    dataBaseName = xmlReader.readElementText();
    xmlReader.readNext();
    xmlReader.readNext();
    userName = xmlReader.readElementText();
    xmlReader.readNext();
    xmlReader.readNext();
    password = xmlReader.readElementText();
    xmlReader.readNext();
    xmlReader.readNext();
    port = xmlReader.readElementText().toInt();

    file->close();
}

static bool createConnection()
{

    QString host = "localhost", dataBaseName = "halturka",
            userName = "postgres", password = "1";

    int port = 5432;
    connectionParametrs(host, port, dataBaseName, userName, password);

    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");
    db.setHostName(host);
    db.setDatabaseName(dataBaseName);
    db.setUserName(userName);
    db.setPassword(password);
    db.setPort(port);
<<<<<<< HEAD:connection.h
=======
=======
//! [0]
static bool createConnection()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");
    db.setHostName("localhost");
    db.setDatabaseName("halturka");
    db.setUserName("postgres");
    db.setPassword("1");
    db.setPort(5432);
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:connection.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:connection.h

    if (!db.open()) {
        QMessageBox::warning(0, QObject::tr("Database Error"),
                             db.lastError().text());
        return false;
    }
    return true;

}
<<<<<<< HEAD:connection.h
=======
<<<<<<< HEAD:connection.h
=======
//! [0]
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:connection.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:connection.h

#endif // CONNECTION_H
