/********************************************************************************
** Form generated from reading UI file 'paymentform.ui'
**
** Created: Mon Mar 29 10:53:20 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAYMENTFORM_H
#define UI_PAYMENTFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QDialog>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PaymentDialog
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *firstButton;
    QPushButton *previousButton;
    QPushButton *nextButton;
    QPushButton *lastButton;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *workLabel;
    QComboBox *workComboBox;
    QLabel *dateLabel;
    QDateEdit *dateEdit;
    QLabel *customerLabel;
    QComboBox *customerComboBox;
    QLabel *priceLabel;
    QLineEdit *priceEdit;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QPushButton *closeButton;

    void setupUi(QDialog *PaymentDialog)
    {
        if (PaymentDialog->objectName().isEmpty())
            PaymentDialog->setObjectName(QString::fromUtf8("PaymentDialog"));
        PaymentDialog->setWindowModality(Qt::NonModal);
        PaymentDialog->resize(495, 245);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/payment.png"), QSize(), QIcon::Normal, QIcon::Off);
        PaymentDialog->setWindowIcon(icon);
        PaymentDialog->setSizeGripEnabled(false);
        PaymentDialog->setModal(false);
        horizontalLayoutWidget = new QWidget(PaymentDialog);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 470, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        firstButton = new QPushButton(horizontalLayoutWidget);
        firstButton->setObjectName(QString::fromUtf8("firstButton"));

        horizontalLayout->addWidget(firstButton);

        previousButton = new QPushButton(horizontalLayoutWidget);
        previousButton->setObjectName(QString::fromUtf8("previousButton"));

        horizontalLayout->addWidget(previousButton);

        nextButton = new QPushButton(horizontalLayoutWidget);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));

        horizontalLayout->addWidget(nextButton);

        lastButton = new QPushButton(horizontalLayoutWidget);
        lastButton->setObjectName(QString::fromUtf8("lastButton"));

        horizontalLayout->addWidget(lastButton);

        formLayoutWidget_2 = new QWidget(PaymentDialog);
        formLayoutWidget_2->setObjectName(QString::fromUtf8("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(50, 50, 401, 141));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        formLayout_2->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        workLabel = new QLabel(formLayoutWidget_2);
        workLabel->setObjectName(QString::fromUtf8("workLabel"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, workLabel);

        workComboBox = new QComboBox(formLayoutWidget_2);
        workComboBox->setObjectName(QString::fromUtf8("workComboBox"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, workComboBox);

        dateLabel = new QLabel(formLayoutWidget_2);
        dateLabel->setObjectName(QString::fromUtf8("dateLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, dateLabel);

        dateEdit = new QDateEdit(formLayoutWidget_2);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setCalendarPopup(true);

        formLayout_2->setWidget(1, QFormLayout::FieldRole, dateEdit);

        customerLabel = new QLabel(formLayoutWidget_2);
        customerLabel->setObjectName(QString::fromUtf8("customerLabel"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, customerLabel);

        customerComboBox = new QComboBox(formLayoutWidget_2);
        customerComboBox->setObjectName(QString::fromUtf8("customerComboBox"));
        customerComboBox->setEnabled(false);

        formLayout_2->setWidget(2, QFormLayout::FieldRole, customerComboBox);

        priceLabel = new QLabel(formLayoutWidget_2);
        priceLabel->setObjectName(QString::fromUtf8("priceLabel"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, priceLabel);

        priceEdit = new QLineEdit(formLayoutWidget_2);
        priceEdit->setObjectName(QString::fromUtf8("priceEdit"));
        priceEdit->setEnabled(false);

        formLayout_2->setWidget(3, QFormLayout::FieldRole, priceEdit);

        horizontalLayoutWidget_2 = new QWidget(PaymentDialog);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(220, 200, 269, 31));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        addButton = new QPushButton(horizontalLayoutWidget_2);
        addButton->setObjectName(QString::fromUtf8("addButton"));

        horizontalLayout_2->addWidget(addButton);

        deleteButton = new QPushButton(horizontalLayoutWidget_2);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));

        horizontalLayout_2->addWidget(deleteButton);

        closeButton = new QPushButton(horizontalLayoutWidget_2);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));

        horizontalLayout_2->addWidget(closeButton);

        horizontalLayoutWidget->raise();
        formLayoutWidget_2->raise();
        horizontalLayoutWidget_2->raise();
        workLabel->raise();
        workComboBox->raise();

        retranslateUi(PaymentDialog);

        QMetaObject::connectSlotsByName(PaymentDialog);
    } // setupUi

    void retranslateUi(QDialog *PaymentDialog)
    {
        PaymentDialog->setWindowTitle(QApplication::translate("PaymentDialog", "Edit Payments", 0, QApplication::UnicodeUTF8));
        firstButton->setText(QApplication::translate("PaymentDialog", "<< &First", 0, QApplication::UnicodeUTF8));
        previousButton->setText(QApplication::translate("PaymentDialog", "< &Previous", 0, QApplication::UnicodeUTF8));
        nextButton->setText(QApplication::translate("PaymentDialog", "&Next >", 0, QApplication::UnicodeUTF8));
        lastButton->setText(QApplication::translate("PaymentDialog", "&Last >>", 0, QApplication::UnicodeUTF8));
        workLabel->setText(QApplication::translate("PaymentDialog", "Work:", 0, QApplication::UnicodeUTF8));
        dateLabel->setText(QApplication::translate("PaymentDialog", "Date:", 0, QApplication::UnicodeUTF8));
        customerLabel->setText(QApplication::translate("PaymentDialog", "Customer:", 0, QApplication::UnicodeUTF8));
        priceLabel->setText(QApplication::translate("PaymentDialog", "Price:", 0, QApplication::UnicodeUTF8));
        addButton->setText(QApplication::translate("PaymentDialog", "&Add", 0, QApplication::UnicodeUTF8));
        deleteButton->setText(QApplication::translate("PaymentDialog", "&Delete", 0, QApplication::UnicodeUTF8));
        closeButton->setText(QApplication::translate("PaymentDialog", "&Close", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class PaymentDialog: public Ui_PaymentDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAYMENTFORM_H
