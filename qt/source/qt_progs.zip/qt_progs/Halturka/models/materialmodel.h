#ifndef MATERIALMODEL_H
#define MATERIALMODEL_H

enum {
    Material_Material_id = 0,
    Material_Work_id = 1,
    Material_Name = 2,
    Material_Count = 3,
    Material_Price = 4,
};

#endif // MATERIALMODEL_H
