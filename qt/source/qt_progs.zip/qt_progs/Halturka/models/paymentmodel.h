#ifndef PAYMENTMODEL_H
#define PAYMENTMODEL_H

#include <QWidget>

<<<<<<< HEAD:models/paymentmodel.h
=======
<<<<<<< HEAD:models/paymentmodel.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:models/paymentmodel.h
class QSqlRelationalTableModel;
class QPushButton;
class QTableView;
class QDialogButtonBox;
class QSplitter;
class QLabel;
<<<<<<< HEAD:models/paymentmodel.h
=======
=======
class QSqlTableModel;
class QPushButton;
class QTableView;
class QDialogButtonBox;
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:models/paymentmodel.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:models/paymentmodel.h

enum {
    Payment_Payment_id = 0,
    Payment_Customer_id = 1,
    Payment_Worker_id = 2,
    Payment_Work_id = 3,
<<<<<<< HEAD:models/paymentmodel.h
    Payment_Date = 4,
    Payment_Price = 5
=======
<<<<<<< HEAD:models/paymentmodel.h
    Payment_Date = 4,
    Payment_Price = 5
=======
    Payment_Date = 4
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:models/paymentmodel.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:models/paymentmodel.h
};

class PaymentModel : public QWidget
{
    Q_OBJECT

public:
    PaymentModel();

private slots:
    void deleteRecord();
    void editRecords();
<<<<<<< HEAD:models/paymentmodel.h
    void updateWorkerView();
    void workerEditRecords();
=======
<<<<<<< HEAD:models/paymentmodel.h
    void updateWorkerView();
    void workerEditRecords();
=======
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:models/paymentmodel.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:models/paymentmodel.h

private:
    QSize sizeHint() const;
    QPushButton *deleteButton;
    QPushButton *editButton;
<<<<<<< HEAD:models/paymentmodel.h
=======
<<<<<<< HEAD:models/paymentmodel.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:models/paymentmodel.h
    QPushButton *workerEditButton;
    QTableView *view;
    QTableView *workerView;
    QSqlRelationalTableModel *model;
    QSqlRelationalTableModel *workerModel;
    QDialogButtonBox *buttonBox;
    QDialogButtonBox *workerButtonBox;
    QWidget *panel;
    QWidget *workerPanel;
    QSplitter *splitter;
    QLabel *workerLabel;
<<<<<<< HEAD:models/paymentmodel.h
=======
=======
    QTableView *view;
    QSqlTableModel *model;
    QDialogButtonBox *buttonBox;
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:models/paymentmodel.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:models/paymentmodel.h
    void initializeModel();
    void createView();
    void createButtons();
};

#endif // PAYMENTMODEL_H
