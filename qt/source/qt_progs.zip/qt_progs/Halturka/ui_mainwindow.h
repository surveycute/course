/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
<<<<<<< HEAD:ui_mainwindow.h
** Created: Mon Mar 29 10:53:20 2010
=======
** Created: Sun Mar 21 23:23:11 2010
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMdiArea>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
<<<<<<< HEAD:ui_mainwindow.h
=======
#include <QtGui/QStatusBar>
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionExit;
    QAction *actionCustomers;
    QAction *actionWorks;
    QAction *actionWorkers;
    QAction *actionPayments;
<<<<<<< HEAD:ui_mainwindow.h
    QAction *aboutAction;
    QAction *aboutQtAction;
    QAction *closeAction;
    QAction *closeAllAction;
    QAction *tileAction;
    QAction *cascadeAction;
    QAction *nextAction;
    QAction *previousAction;
    QAction *actionPreferences;
    QAction *actionStatistic;
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QMdiArea *mdiArea;
    QMenuBar *menubar;
    QMenu *menu_File;
    QMenu *menu_Work;
    QMenu *menu_Settings;
    QMenu *menu_Help;
<<<<<<< HEAD:ui_mainwindow.h
    QMenu *menu_Window;
=======
    QStatusBar *statusbar;
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(700, 500);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/logotip.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExit->setIcon(icon1);
        actionExit->setMenuRole(QAction::NoRole);
        actionExit->setSoftKeyRole(QAction::NoSoftKey);
        actionExit->setIconVisibleInMenu(true);
        actionCustomers = new QAction(MainWindow);
        actionCustomers->setObjectName(QString::fromUtf8("actionCustomers"));
        actionCustomers->setCheckable(false);
        actionCustomers->setChecked(false);
        actionCustomers->setEnabled(true);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/customer.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCustomers->setIcon(icon2);
        actionCustomers->setIconVisibleInMenu(true);
        actionWorks = new QAction(MainWindow);
        actionWorks->setObjectName(QString::fromUtf8("actionWorks"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/work.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionWorks->setIcon(icon3);
        actionWorks->setIconVisibleInMenu(true);
        actionWorkers = new QAction(MainWindow);
        actionWorkers->setObjectName(QString::fromUtf8("actionWorkers"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/images/worker.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionWorkers->setIcon(icon4);
        actionWorkers->setIconVisibleInMenu(true);
        actionPayments = new QAction(MainWindow);
        actionPayments->setObjectName(QString::fromUtf8("actionPayments"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/images/payment.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPayments->setIcon(icon5);
        actionPayments->setIconVisibleInMenu(true);
<<<<<<< HEAD:ui_mainwindow.h
        aboutAction = new QAction(MainWindow);
        aboutAction->setObjectName(QString::fromUtf8("aboutAction"));
        aboutQtAction = new QAction(MainWindow);
        aboutQtAction->setObjectName(QString::fromUtf8("aboutQtAction"));
        closeAction = new QAction(MainWindow);
        closeAction->setObjectName(QString::fromUtf8("closeAction"));
        closeAllAction = new QAction(MainWindow);
        closeAllAction->setObjectName(QString::fromUtf8("closeAllAction"));
        tileAction = new QAction(MainWindow);
        tileAction->setObjectName(QString::fromUtf8("tileAction"));
        cascadeAction = new QAction(MainWindow);
        cascadeAction->setObjectName(QString::fromUtf8("cascadeAction"));
        nextAction = new QAction(MainWindow);
        nextAction->setObjectName(QString::fromUtf8("nextAction"));
        previousAction = new QAction(MainWindow);
        previousAction->setObjectName(QString::fromUtf8("previousAction"));
        actionPreferences = new QAction(MainWindow);
        actionPreferences->setObjectName(QString::fromUtf8("actionPreferences"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/images/preferences.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPreferences->setIcon(icon6);
        actionPreferences->setIconVisibleInMenu(true);
        actionStatistic = new QAction(MainWindow);
        actionStatistic->setObjectName(QString::fromUtf8("actionStatistic"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/images/statistic.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionStatistic->setIcon(icon7);
        actionStatistic->setIconVisibleInMenu(true);
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        mdiArea = new QMdiArea(centralwidget);
        mdiArea->setObjectName(QString::fromUtf8("mdiArea"));

        horizontalLayout->addWidget(mdiArea);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 700, 25));
        menu_File = new QMenu(menubar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        menu_Work = new QMenu(menubar);
        menu_Work->setObjectName(QString::fromUtf8("menu_Work"));
        menu_Settings = new QMenu(menubar);
        menu_Settings->setObjectName(QString::fromUtf8("menu_Settings"));
        menu_Help = new QMenu(menubar);
        menu_Help->setObjectName(QString::fromUtf8("menu_Help"));
<<<<<<< HEAD:ui_mainwindow.h
        menu_Window = new QMenu(menubar);
        menu_Window->setObjectName(QString::fromUtf8("menu_Window"));
        MainWindow->setMenuBar(menubar);
=======
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        toolBar->setInputMethodHints(Qt::ImhExclusiveInputMask);
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        menubar->addAction(menu_File->menuAction());
        menubar->addAction(menu_Work->menuAction());
<<<<<<< HEAD:ui_mainwindow.h
        menubar->addAction(menu_Window->menuAction());
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
        menubar->addAction(menu_Settings->menuAction());
        menubar->addAction(menu_Help->menuAction());
        menu_File->addAction(actionExit);
        menu_Work->addAction(actionCustomers);
        menu_Work->addAction(actionWorkers);
        menu_Work->addAction(actionWorks);
        menu_Work->addAction(actionPayments);
<<<<<<< HEAD:ui_mainwindow.h
        menu_Settings->addAction(actionPreferences);
        menu_Help->addAction(aboutAction);
        menu_Help->addAction(aboutQtAction);
        menu_Window->addAction(closeAction);
        menu_Window->addAction(closeAllAction);
        menu_Window->addSeparator();
        menu_Window->addAction(tileAction);
        menu_Window->addAction(cascadeAction);
        menu_Window->addSeparator();
        menu_Window->addAction(nextAction);
        menu_Window->addAction(previousAction);
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
        toolBar->addAction(actionCustomers);
        toolBar->addAction(actionWorkers);
        toolBar->addAction(actionWorks);
        toolBar->addAction(actionPayments);
<<<<<<< HEAD:ui_mainwindow.h
        toolBar->addAction(actionStatistic);
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
        toolBar->addSeparator();
        toolBar->addAction(actionExit);

        retranslateUi(MainWindow);
        QObject::connect(actionExit, SIGNAL(activated()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Halturka", 0, QApplication::UnicodeUTF8));
        actionExit->setText(QApplication::translate("MainWindow", "E&xit", 0, QApplication::UnicodeUTF8));
        actionExit->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", 0, QApplication::UnicodeUTF8));
        actionCustomers->setText(QApplication::translate("MainWindow", "C&ustomers", 0, QApplication::UnicodeUTF8));
        actionCustomers->setShortcut(QApplication::translate("MainWindow", "Ctrl+U", 0, QApplication::UnicodeUTF8));
        actionWorks->setText(QApplication::translate("MainWindow", "Wo&rks", 0, QApplication::UnicodeUTF8));
        actionWorks->setShortcut(QApplication::translate("MainWindow", "Ctrl+R", 0, QApplication::UnicodeUTF8));
        actionWorkers->setText(QApplication::translate("MainWindow", "W&orkers", 0, QApplication::UnicodeUTF8));
        actionWorkers->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        actionPayments->setText(QApplication::translate("MainWindow", "P&ayments", 0, QApplication::UnicodeUTF8));
        actionPayments->setShortcut(QApplication::translate("MainWindow", "Ctrl+A", 0, QApplication::UnicodeUTF8));
<<<<<<< HEAD:ui_mainwindow.h
        aboutAction->setText(QApplication::translate("MainWindow", "&About", 0, QApplication::UnicodeUTF8));
        aboutQtAction->setText(QApplication::translate("MainWindow", "About &Qt", 0, QApplication::UnicodeUTF8));
        closeAction->setText(QApplication::translate("MainWindow", "&Close", 0, QApplication::UnicodeUTF8));
        closeAllAction->setText(QApplication::translate("MainWindow", "Close &All", 0, QApplication::UnicodeUTF8));
        tileAction->setText(QApplication::translate("MainWindow", "&Tile", 0, QApplication::UnicodeUTF8));
        cascadeAction->setText(QApplication::translate("MainWindow", "&Cascade", 0, QApplication::UnicodeUTF8));
        nextAction->setText(QApplication::translate("MainWindow", "Ne&xt", 0, QApplication::UnicodeUTF8));
        previousAction->setText(QApplication::translate("MainWindow", "Pre&vious", 0, QApplication::UnicodeUTF8));
        actionPreferences->setText(QApplication::translate("MainWindow", "Preferences...", 0, QApplication::UnicodeUTF8));
        actionStatistic->setText(QApplication::translate("MainWindow", "Statistic", 0, QApplication::UnicodeUTF8));
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
        menu_File->setTitle(QApplication::translate("MainWindow", "&File", 0, QApplication::UnicodeUTF8));
        menu_Work->setTitle(QApplication::translate("MainWindow", "&Work", 0, QApplication::UnicodeUTF8));
        menu_Settings->setTitle(QApplication::translate("MainWindow", "&Settings", 0, QApplication::UnicodeUTF8));
        menu_Help->setTitle(QApplication::translate("MainWindow", "&Help", 0, QApplication::UnicodeUTF8));
<<<<<<< HEAD:ui_mainwindow.h
        menu_Window->setTitle(QApplication::translate("MainWindow", "&Window", 0, QApplication::UnicodeUTF8));
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_mainwindow.h
        toolBar->setWindowTitle(QApplication::translate("MainWindow", "toolBar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
