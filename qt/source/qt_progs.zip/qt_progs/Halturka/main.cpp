#include <QtGui/QApplication>

#include "connection.h"
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

<<<<<<< HEAD:main.cpp
    createConnection();
=======
<<<<<<< HEAD:main.cpp
    createConnection();
=======
    if (!createConnection())
        return 1;
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:main.cpp
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:main.cpp

    MainWindow w;
#if defined(Q_WS_S60) || defined(Q_WS_MAEMO_5)
    w.showMaximized();
#else
    w.show();
#endif
    return a.exec();

}
