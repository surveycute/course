/********************************************************************************
** Form generated from reading UI file 'paymentworkerform.ui'
**
** Created: Mon Mar 29 10:53:20 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAYMENTWORKERFORM_H
#define UI_PAYMENTWORKERFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QDialog>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PaymentWorkerDialog
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *firstButton;
    QPushButton *previousButton;
    QPushButton *nextButton;
    QPushButton *lastButton;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *workerLabel;
    QComboBox *workerComboBox;
    QLabel *dateLabel;
    QDateEdit *dateEdit;
    QLabel *priceLabel;
    QLineEdit *priceEdit;
    QLabel *workLabel;
    QComboBox *workComboBox;
    QPushButton *closeButton;

    void setupUi(QDialog *PaymentWorkerDialog)
    {
        if (PaymentWorkerDialog->objectName().isEmpty())
            PaymentWorkerDialog->setObjectName(QString::fromUtf8("PaymentWorkerDialog"));
        PaymentWorkerDialog->setWindowModality(Qt::NonModal);
        PaymentWorkerDialog->resize(495, 245);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/payment.png"), QSize(), QIcon::Normal, QIcon::Off);
        PaymentWorkerDialog->setWindowIcon(icon);
        PaymentWorkerDialog->setSizeGripEnabled(false);
        PaymentWorkerDialog->setModal(false);
        horizontalLayoutWidget = new QWidget(PaymentWorkerDialog);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 470, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        firstButton = new QPushButton(horizontalLayoutWidget);
        firstButton->setObjectName(QString::fromUtf8("firstButton"));

        horizontalLayout->addWidget(firstButton);

        previousButton = new QPushButton(horizontalLayoutWidget);
        previousButton->setObjectName(QString::fromUtf8("previousButton"));

        horizontalLayout->addWidget(previousButton);

        nextButton = new QPushButton(horizontalLayoutWidget);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));

        horizontalLayout->addWidget(nextButton);

        lastButton = new QPushButton(horizontalLayoutWidget);
        lastButton->setObjectName(QString::fromUtf8("lastButton"));

        horizontalLayout->addWidget(lastButton);

        formLayoutWidget_2 = new QWidget(PaymentWorkerDialog);
        formLayoutWidget_2->setObjectName(QString::fromUtf8("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(50, 50, 401, 141));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        formLayout_2->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        workerLabel = new QLabel(formLayoutWidget_2);
        workerLabel->setObjectName(QString::fromUtf8("workerLabel"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, workerLabel);

        workerComboBox = new QComboBox(formLayoutWidget_2);
        workerComboBox->setObjectName(QString::fromUtf8("workerComboBox"));
        workerComboBox->setEnabled(false);

        formLayout_2->setWidget(0, QFormLayout::FieldRole, workerComboBox);

        dateLabel = new QLabel(formLayoutWidget_2);
        dateLabel->setObjectName(QString::fromUtf8("dateLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, dateLabel);

        dateEdit = new QDateEdit(formLayoutWidget_2);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setCalendarPopup(true);

        formLayout_2->setWidget(1, QFormLayout::FieldRole, dateEdit);

        priceLabel = new QLabel(formLayoutWidget_2);
        priceLabel->setObjectName(QString::fromUtf8("priceLabel"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, priceLabel);

        priceEdit = new QLineEdit(formLayoutWidget_2);
        priceEdit->setObjectName(QString::fromUtf8("priceEdit"));
        priceEdit->setEnabled(true);

        formLayout_2->setWidget(2, QFormLayout::FieldRole, priceEdit);

        workLabel = new QLabel(formLayoutWidget_2);
        workLabel->setObjectName(QString::fromUtf8("workLabel"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, workLabel);

        workComboBox = new QComboBox(formLayoutWidget_2);
        workComboBox->setObjectName(QString::fromUtf8("workComboBox"));
        workComboBox->setEnabled(false);

        formLayout_2->setWidget(3, QFormLayout::FieldRole, workComboBox);

        closeButton = new QPushButton(PaymentWorkerDialog);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));
        closeButton->setGeometry(QRect(390, 200, 89, 27));

        retranslateUi(PaymentWorkerDialog);

        QMetaObject::connectSlotsByName(PaymentWorkerDialog);
    } // setupUi

    void retranslateUi(QDialog *PaymentWorkerDialog)
    {
        PaymentWorkerDialog->setWindowTitle(QApplication::translate("PaymentWorkerDialog", "Edit Worker Payments", 0, QApplication::UnicodeUTF8));
        firstButton->setText(QApplication::translate("PaymentWorkerDialog", "<< &First", 0, QApplication::UnicodeUTF8));
        previousButton->setText(QApplication::translate("PaymentWorkerDialog", "< &Previous", 0, QApplication::UnicodeUTF8));
        nextButton->setText(QApplication::translate("PaymentWorkerDialog", "&Next >", 0, QApplication::UnicodeUTF8));
        lastButton->setText(QApplication::translate("PaymentWorkerDialog", "&Last >>", 0, QApplication::UnicodeUTF8));
        workerLabel->setText(QApplication::translate("PaymentWorkerDialog", "Worker:", 0, QApplication::UnicodeUTF8));
        dateLabel->setText(QApplication::translate("PaymentWorkerDialog", "Date:", 0, QApplication::UnicodeUTF8));
        priceLabel->setText(QApplication::translate("PaymentWorkerDialog", "Price:", 0, QApplication::UnicodeUTF8));
        workLabel->setText(QApplication::translate("PaymentWorkerDialog", "Work:", 0, QApplication::UnicodeUTF8));
        closeButton->setText(QApplication::translate("PaymentWorkerDialog", "&Close", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class PaymentWorkerDialog: public Ui_PaymentWorkerDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAYMENTWORKERFORM_H
