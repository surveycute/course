/********************************************************************************
** Form generated from reading UI file 'customerform.ui'
**
<<<<<<< HEAD:ui_customerform.h
** Created: Mon Mar 29 10:53:20 2010
=======
** Created: Sun Mar 21 23:23:11 2010
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_customerform.h
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUSTOMERFORM_H
#define UI_CUSTOMERFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CustomerDialog
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *firstButton;
    QPushButton *previousButton;
    QPushButton *nextButton;
    QPushButton *lastButton;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QPushButton *closeButton;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *nameLabel;
    QLineEdit *nameEdit;
    QLabel *surnameLabel;
    QLineEdit *surnameEdit;
    QLabel *emailLabel;
    QLineEdit *emailEdit;
    QLabel *addressLabel;
    QLineEdit *addressEdit;
    QLabel *phoneLabel;
    QLineEdit *phoneEdit;

    void setupUi(QDialog *CustomerDialog)
    {
        if (CustomerDialog->objectName().isEmpty())
            CustomerDialog->setObjectName(QString::fromUtf8("CustomerDialog"));
        CustomerDialog->setWindowModality(Qt::NonModal);
        CustomerDialog->resize(487, 257);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/customer.png"), QSize(), QIcon::Normal, QIcon::Off);
        CustomerDialog->setWindowIcon(icon);
        CustomerDialog->setSizeGripEnabled(false);
        CustomerDialog->setModal(false);
        horizontalLayoutWidget = new QWidget(CustomerDialog);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 470, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        firstButton = new QPushButton(horizontalLayoutWidget);
        firstButton->setObjectName(QString::fromUtf8("firstButton"));

        horizontalLayout->addWidget(firstButton);

        previousButton = new QPushButton(horizontalLayoutWidget);
        previousButton->setObjectName(QString::fromUtf8("previousButton"));

        horizontalLayout->addWidget(previousButton);

        nextButton = new QPushButton(horizontalLayoutWidget);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));

        horizontalLayout->addWidget(nextButton);

        lastButton = new QPushButton(horizontalLayoutWidget);
        lastButton->setObjectName(QString::fromUtf8("lastButton"));

        horizontalLayout->addWidget(lastButton);

        horizontalLayoutWidget_2 = new QWidget(CustomerDialog);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(210, 220, 269, 31));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        addButton = new QPushButton(horizontalLayoutWidget_2);
        addButton->setObjectName(QString::fromUtf8("addButton"));

        horizontalLayout_2->addWidget(addButton);

        deleteButton = new QPushButton(horizontalLayoutWidget_2);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));

        horizontalLayout_2->addWidget(deleteButton);

        closeButton = new QPushButton(horizontalLayoutWidget_2);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));

        horizontalLayout_2->addWidget(closeButton);

        formLayoutWidget_2 = new QWidget(CustomerDialog);
        formLayoutWidget_2->setObjectName(QString::fromUtf8("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(50, 50, 401, 161));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        nameLabel = new QLabel(formLayoutWidget_2);
        nameLabel->setObjectName(QString::fromUtf8("nameLabel"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, nameLabel);

        nameEdit = new QLineEdit(formLayoutWidget_2);
        nameEdit->setObjectName(QString::fromUtf8("nameEdit"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, nameEdit);

        surnameLabel = new QLabel(formLayoutWidget_2);
        surnameLabel->setObjectName(QString::fromUtf8("surnameLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, surnameLabel);

        surnameEdit = new QLineEdit(formLayoutWidget_2);
        surnameEdit->setObjectName(QString::fromUtf8("surnameEdit"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, surnameEdit);

        emailLabel = new QLabel(formLayoutWidget_2);
        emailLabel->setObjectName(QString::fromUtf8("emailLabel"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, emailLabel);

        emailEdit = new QLineEdit(formLayoutWidget_2);
        emailEdit->setObjectName(QString::fromUtf8("emailEdit"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, emailEdit);

        addressLabel = new QLabel(formLayoutWidget_2);
        addressLabel->setObjectName(QString::fromUtf8("addressLabel"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, addressLabel);

        addressEdit = new QLineEdit(formLayoutWidget_2);
        addressEdit->setObjectName(QString::fromUtf8("addressEdit"));

        formLayout_2->setWidget(3, QFormLayout::FieldRole, addressEdit);

        phoneLabel = new QLabel(formLayoutWidget_2);
        phoneLabel->setObjectName(QString::fromUtf8("phoneLabel"));

        formLayout_2->setWidget(4, QFormLayout::LabelRole, phoneLabel);

        phoneEdit = new QLineEdit(formLayoutWidget_2);
        phoneEdit->setObjectName(QString::fromUtf8("phoneEdit"));

        formLayout_2->setWidget(4, QFormLayout::FieldRole, phoneEdit);


        retranslateUi(CustomerDialog);

        QMetaObject::connectSlotsByName(CustomerDialog);
    } // setupUi

    void retranslateUi(QDialog *CustomerDialog)
    {
        CustomerDialog->setWindowTitle(QApplication::translate("CustomerDialog", "Edit Customers", 0, QApplication::UnicodeUTF8));
        firstButton->setText(QApplication::translate("CustomerDialog", "<< &First", 0, QApplication::UnicodeUTF8));
        previousButton->setText(QApplication::translate("CustomerDialog", "< &Previous", 0, QApplication::UnicodeUTF8));
        nextButton->setText(QApplication::translate("CustomerDialog", "&Next >", 0, QApplication::UnicodeUTF8));
        lastButton->setText(QApplication::translate("CustomerDialog", "&Last >>", 0, QApplication::UnicodeUTF8));
        addButton->setText(QApplication::translate("CustomerDialog", "&Add", 0, QApplication::UnicodeUTF8));
        deleteButton->setText(QApplication::translate("CustomerDialog", "&Delete", 0, QApplication::UnicodeUTF8));
        closeButton->setText(QApplication::translate("CustomerDialog", "&Close", 0, QApplication::UnicodeUTF8));
        nameLabel->setText(QApplication::translate("CustomerDialog", "Name:", 0, QApplication::UnicodeUTF8));
        surnameLabel->setText(QApplication::translate("CustomerDialog", "Surname:", 0, QApplication::UnicodeUTF8));
        emailLabel->setText(QApplication::translate("CustomerDialog", "Email:", 0, QApplication::UnicodeUTF8));
        emailEdit->setText(QString());
        addressLabel->setText(QApplication::translate("CustomerDialog", "Address:", 0, QApplication::UnicodeUTF8));
        phoneLabel->setText(QApplication::translate("CustomerDialog", "Phone:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CustomerDialog: public Ui_CustomerDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUSTOMERFORM_H
