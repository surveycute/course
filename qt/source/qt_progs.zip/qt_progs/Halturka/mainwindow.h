#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMdiSubWindow>
#include <QMdiArea>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void changeEvent(QEvent *e);

private slots:
    void openModelCustomer();
    void openModelWorker();
    void openModelWork();
    void openModelPayment();
<<<<<<< HEAD:mainwindow.h
    void openModelStatistik();
    void about();
    void preferenceDialog();
=======
<<<<<<< HEAD:mainwindow.h
    void openModelStatistik();
    void about();
    void preferenceDialog();
=======
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:mainwindow.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:mainwindow.h

private:
    Ui::MainWindow *ui;
    QMdiSubWindow *subWindowCustomer;
    QMdiSubWindow *subWindowWorker;
    QMdiSubWindow *subWindowWork;
    QMdiSubWindow *subWindowPayment;
<<<<<<< HEAD:mainwindow.h
    QMdiSubWindow *subWindowStatistik;
    void customize();
=======
<<<<<<< HEAD:mainwindow.h
    QMdiSubWindow *subWindowStatistik;
    void customize();
=======
>>>>>>> 71d516d443934cc1380d5bdfe34cf5e3fa2503b4:mainwindow.h
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:mainwindow.h
};

#endif // MAINWINDOW_H
