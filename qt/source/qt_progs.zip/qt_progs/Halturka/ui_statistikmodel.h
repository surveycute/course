/********************************************************************************
** Form generated from reading UI file 'statistikmodel.ui'
**
** Created: Mon Mar 29 10:53:20 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIKMODEL_H
#define UI_STATISTIKMODEL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StatistikModel
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *emailLabel;
    QComboBox *emailComboBox;
    QPushButton *emailButton;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *dateLabel;
    QDateEdit *dateStartEdit;
    QDateEdit *dateFinishEdit;
    QPushButton *dateButton;
    QWidget *horizontalLayoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *groupByLabel;
    QPushButton *worksCountButton;
    QWidget *horizontalLayoutWidget_4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *countLabel;
    QComboBox *workComboBox;
    QPushButton *workCountButton;
    QWidget *horizontalLayoutWidget_5;
    QHBoxLayout *horizontalLayout_5;
    QLabel *anyLabel;
    QPushButton *allButton;
    QWidget *horizontalLayoutWidget_6;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label;
    QPushButton *immediatelyButton;
    QWidget *horizontalLayoutWidget_7;
    QHBoxLayout *horizontalLayout_7;
    QLabel *unionLabel;
    QPushButton *unionButton;
    QWidget *horizontalLayoutWidget_8;
    QHBoxLayout *horizontalLayout_8;
    QLabel *updateLabel;
    QPushButton *updateButton;
    QComboBox *workIdComboBox;

    void setupUi(QWidget *StatistikModel)
    {
        if (StatistikModel->objectName().isEmpty())
            StatistikModel->setObjectName(QString::fromUtf8("StatistikModel"));
        StatistikModel->resize(660, 341);
        StatistikModel->setMinimumSize(QSize(660, 341));
        horizontalLayoutWidget = new QWidget(StatistikModel);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 429, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        emailLabel = new QLabel(horizontalLayoutWidget);
        emailLabel->setObjectName(QString::fromUtf8("emailLabel"));

        horizontalLayout->addWidget(emailLabel);

        emailComboBox = new QComboBox(horizontalLayoutWidget);
        emailComboBox->setObjectName(QString::fromUtf8("emailComboBox"));

        horizontalLayout->addWidget(emailComboBox);

        emailButton = new QPushButton(horizontalLayoutWidget);
        emailButton->setObjectName(QString::fromUtf8("emailButton"));

        horizontalLayout->addWidget(emailButton);

        horizontalLayoutWidget_2 = new QWidget(StatistikModel);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(10, 50, 646, 31));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        dateLabel = new QLabel(horizontalLayoutWidget_2);
        dateLabel->setObjectName(QString::fromUtf8("dateLabel"));

        horizontalLayout_2->addWidget(dateLabel);

        dateStartEdit = new QDateEdit(horizontalLayoutWidget_2);
        dateStartEdit->setObjectName(QString::fromUtf8("dateStartEdit"));
        dateStartEdit->setCalendarPopup(true);

        horizontalLayout_2->addWidget(dateStartEdit);

        dateFinishEdit = new QDateEdit(horizontalLayoutWidget_2);
        dateFinishEdit->setObjectName(QString::fromUtf8("dateFinishEdit"));
        dateFinishEdit->setCalendarPopup(true);

        horizontalLayout_2->addWidget(dateFinishEdit);

        dateButton = new QPushButton(horizontalLayoutWidget_2);
        dateButton->setObjectName(QString::fromUtf8("dateButton"));

        horizontalLayout_2->addWidget(dateButton);

        horizontalLayoutWidget_3 = new QWidget(StatistikModel);
        horizontalLayoutWidget_3->setObjectName(QString::fromUtf8("horizontalLayoutWidget_3"));
        horizontalLayoutWidget_3->setGeometry(QRect(10, 130, 327, 31));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget_3);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        groupByLabel = new QLabel(horizontalLayoutWidget_3);
        groupByLabel->setObjectName(QString::fromUtf8("groupByLabel"));

        horizontalLayout_3->addWidget(groupByLabel);

        worksCountButton = new QPushButton(horizontalLayoutWidget_3);
        worksCountButton->setObjectName(QString::fromUtf8("worksCountButton"));

        horizontalLayout_3->addWidget(worksCountButton);

        horizontalLayoutWidget_4 = new QWidget(StatistikModel);
        horizontalLayoutWidget_4->setObjectName(QString::fromUtf8("horizontalLayoutWidget_4"));
        horizontalLayoutWidget_4->setGeometry(QRect(10, 90, 411, 31));
        horizontalLayout_4 = new QHBoxLayout(horizontalLayoutWidget_4);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        countLabel = new QLabel(horizontalLayoutWidget_4);
        countLabel->setObjectName(QString::fromUtf8("countLabel"));

        horizontalLayout_4->addWidget(countLabel);

        workComboBox = new QComboBox(horizontalLayoutWidget_4);
        workComboBox->setObjectName(QString::fromUtf8("workComboBox"));

        horizontalLayout_4->addWidget(workComboBox);

        workCountButton = new QPushButton(horizontalLayoutWidget_4);
        workCountButton->setObjectName(QString::fromUtf8("workCountButton"));

        horizontalLayout_4->addWidget(workCountButton);

        horizontalLayoutWidget_5 = new QWidget(StatistikModel);
        horizontalLayoutWidget_5->setObjectName(QString::fromUtf8("horizontalLayoutWidget_5"));
        horizontalLayoutWidget_5->setGeometry(QRect(10, 170, 241, 31));
        horizontalLayout_5 = new QHBoxLayout(horizontalLayoutWidget_5);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        anyLabel = new QLabel(horizontalLayoutWidget_5);
        anyLabel->setObjectName(QString::fromUtf8("anyLabel"));

        horizontalLayout_5->addWidget(anyLabel);

        allButton = new QPushButton(horizontalLayoutWidget_5);
        allButton->setObjectName(QString::fromUtf8("allButton"));

        horizontalLayout_5->addWidget(allButton);

        horizontalLayoutWidget_6 = new QWidget(StatistikModel);
        horizontalLayoutWidget_6->setObjectName(QString::fromUtf8("horizontalLayoutWidget_6"));
        horizontalLayoutWidget_6->setGeometry(QRect(10, 210, 353, 31));
        horizontalLayout_6 = new QHBoxLayout(horizontalLayoutWidget_6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget_6);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_6->addWidget(label);

        immediatelyButton = new QPushButton(horizontalLayoutWidget_6);
        immediatelyButton->setObjectName(QString::fromUtf8("immediatelyButton"));

        horizontalLayout_6->addWidget(immediatelyButton);

        horizontalLayoutWidget_7 = new QWidget(StatistikModel);
        horizontalLayoutWidget_7->setObjectName(QString::fromUtf8("horizontalLayoutWidget_7"));
        horizontalLayoutWidget_7->setGeometry(QRect(10, 250, 319, 31));
        horizontalLayout_7 = new QHBoxLayout(horizontalLayoutWidget_7);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        unionLabel = new QLabel(horizontalLayoutWidget_7);
        unionLabel->setObjectName(QString::fromUtf8("unionLabel"));

        horizontalLayout_7->addWidget(unionLabel);

        unionButton = new QPushButton(horizontalLayoutWidget_7);
        unionButton->setObjectName(QString::fromUtf8("unionButton"));

        horizontalLayout_7->addWidget(unionButton);

        horizontalLayoutWidget_8 = new QWidget(StatistikModel);
        horizontalLayoutWidget_8->setObjectName(QString::fromUtf8("horizontalLayoutWidget_8"));
        horizontalLayoutWidget_8->setGeometry(QRect(10, 290, 599, 31));
        horizontalLayout_8 = new QHBoxLayout(horizontalLayoutWidget_8);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        updateLabel = new QLabel(horizontalLayoutWidget_8);
        updateLabel->setObjectName(QString::fromUtf8("updateLabel"));

        horizontalLayout_8->addWidget(updateLabel);

        updateButton = new QPushButton(horizontalLayoutWidget_8);
        updateButton->setObjectName(QString::fromUtf8("updateButton"));

        horizontalLayout_8->addWidget(updateButton);

        workIdComboBox = new QComboBox(StatistikModel);
        workIdComboBox->setObjectName(QString::fromUtf8("workIdComboBox"));
        workIdComboBox->setEnabled(false);
        workIdComboBox->setGeometry(QRect(470, 90, 85, 27));

        retranslateUi(StatistikModel);

        QMetaObject::connectSlotsByName(StatistikModel);
    } // setupUi

    void retranslateUi(QWidget *StatistikModel)
    {
        StatistikModel->setWindowTitle(QApplication::translate("StatistikModel", "Statistik", 0, QApplication::UnicodeUTF8));
        emailLabel->setText(QApplication::translate("StatistikModel", "Select customers that have email:", 0, QApplication::UnicodeUTF8));
        emailComboBox->clear();
        emailComboBox->insertItems(0, QStringList()
         << QApplication::translate("StatistikModel", "gmail.com", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("StatistikModel", "rambler.ru", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("StatistikModel", "mail.ru", 0, QApplication::UnicodeUTF8)
        );
        emailButton->setText(QApplication::translate("StatistikModel", "Select", 0, QApplication::UnicodeUTF8));
        dateLabel->setText(QApplication::translate("StatistikModel", "Select customers payments that payed between dates:", 0, QApplication::UnicodeUTF8));
        dateButton->setText(QApplication::translate("StatistikModel", "Select", 0, QApplication::UnicodeUTF8));
        groupByLabel->setText(QApplication::translate("StatistikModel", "Select number of workers on works:", 0, QApplication::UnicodeUTF8));
        worksCountButton->setText(QApplication::translate("StatistikModel", "Select", 0, QApplication::UnicodeUTF8));
        countLabel->setText(QApplication::translate("StatistikModel", "Select number of workers on work:", 0, QApplication::UnicodeUTF8));
        workCountButton->setText(QApplication::translate("StatistikModel", "Select", 0, QApplication::UnicodeUTF8));
        anyLabel->setText(QApplication::translate("StatistikModel", "Is all work status true:", 0, QApplication::UnicodeUTF8));
        allButton->setText(QApplication::translate("StatistikModel", "Select", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("StatistikModel", "What works were not paid immediately:", 0, QApplication::UnicodeUTF8));
        immediatelyButton->setText(QApplication::translate("StatistikModel", "Select", 0, QApplication::UnicodeUTF8));
        unionLabel->setText(QApplication::translate("StatistikModel", "Show customer and worker table:", 0, QApplication::UnicodeUTF8));
        unionButton->setText(QApplication::translate("StatistikModel", "Select", 0, QApplication::UnicodeUTF8));
        updateLabel->setText(QApplication::translate("StatistikModel", "Update the status of work to True but if it was performed on the worker's pay:", 0, QApplication::UnicodeUTF8));
        updateButton->setText(QApplication::translate("StatistikModel", "Update", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class StatistikModel: public Ui_StatistikModel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIKMODEL_H
