/********************************************************************************
** Form generated from reading UI file 'workform.ui'
**
<<<<<<< HEAD:ui_workform.h
** Created: Mon Mar 29 10:53:20 2010
=======
** Created: Sun Mar 21 23:23:11 2010
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WORKFORM_H
#define UI_WORKFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QDialog>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_WorkDialog
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *firstButton;
    QPushButton *previousButton;
    QPushButton *nextButton;
    QPushButton *lastButton;
    QWidget *formLayoutWidget_2;
    QFormLayout *formLayout_2;
    QLabel *nameLabel;
    QLineEdit *nameEdit;
<<<<<<< HEAD:ui_workform.h
    QLabel *statusLabel;
    QCheckBox *statusCheckBox;
    QLabel *dateStartLabel;
    QDateEdit *dateStartEdit;
    QLabel *dateFinishLabel;
    QDateEdit *dateFinishEdit;
    QLabel *priceLabel;
    QLineEdit *priceEdit;
    QLabel *customerLabel;
    QComboBox *customerComboBox;
=======
    QLabel *customerLabel;
    QLabel *statusLabel;
    QLabel *dateStartLabel;
    QLabel *dateFinishLabel;
    QLabel *priceLabel;
    QLineEdit *priceEdit;
    QComboBox *customerComboBox;
    QCheckBox *statusCheckBox;
    QDateEdit *dateStartEdit;
    QDateEdit *dateFinishEdit;
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QPushButton *closeButton;

    void setupUi(QDialog *WorkDialog)
    {
        if (WorkDialog->objectName().isEmpty())
            WorkDialog->setObjectName(QString::fromUtf8("WorkDialog"));
        WorkDialog->setWindowModality(Qt::NonModal);
        WorkDialog->resize(495, 292);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/work.png"), QSize(), QIcon::Normal, QIcon::Off);
        WorkDialog->setWindowIcon(icon);
        WorkDialog->setSizeGripEnabled(false);
        WorkDialog->setModal(false);
        horizontalLayoutWidget = new QWidget(WorkDialog);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(10, 10, 470, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        firstButton = new QPushButton(horizontalLayoutWidget);
        firstButton->setObjectName(QString::fromUtf8("firstButton"));

        horizontalLayout->addWidget(firstButton);

        previousButton = new QPushButton(horizontalLayoutWidget);
        previousButton->setObjectName(QString::fromUtf8("previousButton"));

        horizontalLayout->addWidget(previousButton);

        nextButton = new QPushButton(horizontalLayoutWidget);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));

        horizontalLayout->addWidget(nextButton);

        lastButton = new QPushButton(horizontalLayoutWidget);
        lastButton->setObjectName(QString::fromUtf8("lastButton"));

        horizontalLayout->addWidget(lastButton);

        formLayoutWidget_2 = new QWidget(WorkDialog);
        formLayoutWidget_2->setObjectName(QString::fromUtf8("formLayoutWidget_2"));
        formLayoutWidget_2->setGeometry(QRect(50, 50, 401, 191));
        formLayout_2 = new QFormLayout(formLayoutWidget_2);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
<<<<<<< HEAD:ui_workform.h
        formLayout_2->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        nameLabel = new QLabel(formLayoutWidget_2);
        nameLabel->setObjectName(QString::fromUtf8("nameLabel"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, nameLabel);

        nameEdit = new QLineEdit(formLayoutWidget_2);
        nameEdit->setObjectName(QString::fromUtf8("nameEdit"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, nameEdit);

<<<<<<< HEAD:ui_workform.h
=======
        customerLabel = new QLabel(formLayoutWidget_2);
        customerLabel->setObjectName(QString::fromUtf8("customerLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, customerLabel);

>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        statusLabel = new QLabel(formLayoutWidget_2);
        statusLabel->setObjectName(QString::fromUtf8("statusLabel"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, statusLabel);

<<<<<<< HEAD:ui_workform.h
        statusCheckBox = new QCheckBox(formLayoutWidget_2);
        statusCheckBox->setObjectName(QString::fromUtf8("statusCheckBox"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, statusCheckBox);

=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        dateStartLabel = new QLabel(formLayoutWidget_2);
        dateStartLabel->setObjectName(QString::fromUtf8("dateStartLabel"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, dateStartLabel);

<<<<<<< HEAD:ui_workform.h
        dateStartEdit = new QDateEdit(formLayoutWidget_2);
        dateStartEdit->setObjectName(QString::fromUtf8("dateStartEdit"));
        dateStartEdit->setCalendarPopup(true);

        formLayout_2->setWidget(3, QFormLayout::FieldRole, dateStartEdit);

=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        dateFinishLabel = new QLabel(formLayoutWidget_2);
        dateFinishLabel->setObjectName(QString::fromUtf8("dateFinishLabel"));

        formLayout_2->setWidget(4, QFormLayout::LabelRole, dateFinishLabel);

<<<<<<< HEAD:ui_workform.h
        dateFinishEdit = new QDateEdit(formLayoutWidget_2);
        dateFinishEdit->setObjectName(QString::fromUtf8("dateFinishEdit"));
        dateFinishEdit->setCalendarPopup(true);

        formLayout_2->setWidget(4, QFormLayout::FieldRole, dateFinishEdit);

=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        priceLabel = new QLabel(formLayoutWidget_2);
        priceLabel->setObjectName(QString::fromUtf8("priceLabel"));

        formLayout_2->setWidget(5, QFormLayout::LabelRole, priceLabel);

        priceEdit = new QLineEdit(formLayoutWidget_2);
        priceEdit->setObjectName(QString::fromUtf8("priceEdit"));

        formLayout_2->setWidget(5, QFormLayout::FieldRole, priceEdit);

<<<<<<< HEAD:ui_workform.h
        customerLabel = new QLabel(formLayoutWidget_2);
        customerLabel->setObjectName(QString::fromUtf8("customerLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, customerLabel);

=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        customerComboBox = new QComboBox(formLayoutWidget_2);
        customerComboBox->setObjectName(QString::fromUtf8("customerComboBox"));

        formLayout_2->setWidget(1, QFormLayout::FieldRole, customerComboBox);

<<<<<<< HEAD:ui_workform.h
=======
        statusCheckBox = new QCheckBox(formLayoutWidget_2);
        statusCheckBox->setObjectName(QString::fromUtf8("statusCheckBox"));

        formLayout_2->setWidget(2, QFormLayout::FieldRole, statusCheckBox);

        dateStartEdit = new QDateEdit(formLayoutWidget_2);
        dateStartEdit->setObjectName(QString::fromUtf8("dateStartEdit"));
        dateStartEdit->setCalendarPopup(true);

        formLayout_2->setWidget(3, QFormLayout::FieldRole, dateStartEdit);

        dateFinishEdit = new QDateEdit(formLayoutWidget_2);
        dateFinishEdit->setObjectName(QString::fromUtf8("dateFinishEdit"));
        dateFinishEdit->setCalendarPopup(true);

        formLayout_2->setWidget(4, QFormLayout::FieldRole, dateFinishEdit);

>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        horizontalLayoutWidget_2 = new QWidget(WorkDialog);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(210, 250, 269, 31));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        addButton = new QPushButton(horizontalLayoutWidget_2);
        addButton->setObjectName(QString::fromUtf8("addButton"));

        horizontalLayout_2->addWidget(addButton);

        deleteButton = new QPushButton(horizontalLayoutWidget_2);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));

        horizontalLayout_2->addWidget(deleteButton);

        closeButton = new QPushButton(horizontalLayoutWidget_2);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));

        horizontalLayout_2->addWidget(closeButton);

<<<<<<< HEAD:ui_workform.h
        horizontalLayoutWidget->raise();
        formLayoutWidget_2->raise();
        horizontalLayoutWidget_2->raise();
        customerComboBox->raise();
        customerLabel->raise();
        priceLabel->raise();
        priceEdit->raise();
=======
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h

        retranslateUi(WorkDialog);

        QMetaObject::connectSlotsByName(WorkDialog);
    } // setupUi

    void retranslateUi(QDialog *WorkDialog)
    {
        WorkDialog->setWindowTitle(QApplication::translate("WorkDialog", "Edit Works", 0, QApplication::UnicodeUTF8));
        firstButton->setText(QApplication::translate("WorkDialog", "<< &First", 0, QApplication::UnicodeUTF8));
        previousButton->setText(QApplication::translate("WorkDialog", "< &Previous", 0, QApplication::UnicodeUTF8));
        nextButton->setText(QApplication::translate("WorkDialog", "&Next >", 0, QApplication::UnicodeUTF8));
        lastButton->setText(QApplication::translate("WorkDialog", "&Last >>", 0, QApplication::UnicodeUTF8));
        nameLabel->setText(QApplication::translate("WorkDialog", "Name:", 0, QApplication::UnicodeUTF8));
<<<<<<< HEAD:ui_workform.h
        statusLabel->setText(QApplication::translate("WorkDialog", "Status:", 0, QApplication::UnicodeUTF8));
        statusCheckBox->setText(QApplication::translate("WorkDialog", "Completed", 0, QApplication::UnicodeUTF8));
        dateStartLabel->setText(QApplication::translate("WorkDialog", "Date start:", 0, QApplication::UnicodeUTF8));
        dateFinishLabel->setText(QApplication::translate("WorkDialog", "Date finish:", 0, QApplication::UnicodeUTF8));
        priceLabel->setText(QApplication::translate("WorkDialog", "Price:", 0, QApplication::UnicodeUTF8));
        customerLabel->setText(QApplication::translate("WorkDialog", "Customer:", 0, QApplication::UnicodeUTF8));
=======
        customerLabel->setText(QApplication::translate("WorkDialog", "Customer:", 0, QApplication::UnicodeUTF8));
        statusLabel->setText(QApplication::translate("WorkDialog", "Status:", 0, QApplication::UnicodeUTF8));
        dateStartLabel->setText(QApplication::translate("WorkDialog", "Date start:", 0, QApplication::UnicodeUTF8));
        dateFinishLabel->setText(QApplication::translate("WorkDialog", "Date finish:", 0, QApplication::UnicodeUTF8));
        priceLabel->setText(QApplication::translate("WorkDialog", "Price:", 0, QApplication::UnicodeUTF8));
        statusCheckBox->setText(QApplication::translate("WorkDialog", "Completed", 0, QApplication::UnicodeUTF8));
>>>>>>> e96f9ffaaf8998c9742c975f29f8f0f854367f8a:ui_workform.h
        addButton->setText(QApplication::translate("WorkDialog", "&Add", 0, QApplication::UnicodeUTF8));
        deleteButton->setText(QApplication::translate("WorkDialog", "&Delete", 0, QApplication::UnicodeUTF8));
        closeButton->setText(QApplication::translate("WorkDialog", "&Close", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class WorkDialog: public Ui_WorkDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WORKFORM_H
