
#include "QOpenCVWidget.h"
#include <QGraphicsEffect>
#include <QDir>
#include <CNN/cnn.h>
#include <QtConcurrentRun>

QPoint old_point;

// Constructor
QOpenCVWidget::QOpenCVWidget(QWidget *parent) : QWidget(parent) {
    layout = new QVBoxLayout;
    imagelabel = new QLabel;
    QImage dummy(100,100,QImage::Format_RGB32);
    image = dummy;
    layout->addWidget(imagelabel);
    for (int x = 0; x < 100; x ++) {
        for (int y =0; y < 100; y++) {
            image.setPixel(x,y,qRgb(x, y, y));
        }
    }
    imagelabel->setPixmap(QPixmap::fromImage(image));

    old_point.setX(999);
    old_point.setY(999);

    setLayout(layout);
}

QOpenCVWidget::~QOpenCVWidget(void) {
    
}

void QOpenCVWidget::putImage(IplImage *cvimage) {
    int cvIndex, cvLineStart;
    // switch between bit depths
    switch (cvimage->depth) {
        case IPL_DEPTH_8U:
            switch (cvimage->nChannels) {
                case 3:
                    if ( (cvimage->width != image.width()) || (cvimage->height != image.height()) ) {
                        QImage temp(cvimage->width, cvimage->height, QImage::Format_RGB32);
                        image = temp;
                    }
                    cvIndex = 0; cvLineStart = 0;
                    for (int y = 0; y < cvimage->height; y++) {
                        unsigned char red,green,blue;
                        cvIndex = cvLineStart;
                        for (int x = 0; x < cvimage->width; x++) {
                            // DO it
                            red = cvimage->imageData[cvIndex+2];
                            green = cvimage->imageData[cvIndex+1];
                            blue = cvimage->imageData[cvIndex+0];
                            
                            image.setPixel(x,y,qRgb(red, green, blue));
                            cvIndex += 3;
                        }
                        cvLineStart += cvimage->widthStep;                        
                    }
                    break;
                default:
                    printf("This number of channels is not supported\n");
                    break;
            }
            break;
        default:
            printf("This type of IplImage is not implemented in QOpenCVWidget\n");
            break;
    }

    image = image.scaled(image.width()/2, image.height()/2);

    if(old_point.x() != 999) {
         image = drawRect(image,old_point.x(),old_point.y(),120);
    }
    int secs = QTime::currentTime().second();
    if((secs%3) == 0) {

        QString net = QDir::currentPath() + "/BEST_edu.txt";
        //QString image_path = QDir::currentPath() + "/test.jpg";
        //image = image.scaled(image.width()/2, image.height()/2);
        QPoint point = CNN::find_face(image,net);
        //image = image.scaled(image.width()/6,image.height()/6);
        if(point.x() != 0) {
            image = drawRect(image,point.x(),point.y(),120);
            old_point.setX(point.x());
            old_point.setY(point.y());
        }
    }
    //image = skinFilter(image);
    //image = image.convertToFormat(QImage::Format_Mono,Qt::ThresholdDither);
    //image = toGrayscale(image);
    //image = toSobel(image);
    //image.invertPixels();
    //image = image.convertToFormat(QImage::Format_Mono,Qt::ThresholdDither);
    //QGraphicsEffect::
    //image.save("/home/anton/QtOpenCV/save.jpg");
    ///sleep(1);
    imagelabel->setPixmap(QPixmap::fromImage(image));
}

QImage QOpenCVWidget::drawRect(QImage &img, int width, int height, int length) {


    for(int i=0; i<length; i++) {

        img.setPixel(width+i,height,-1000);
        //img.setPixel(width+i,height+1,-1000);
        //img.setPixel(width+i,height+2,-1000);
        img.setPixel(width+i,height+3,-1000);

        img.setPixel(width+i,height+length,-1000);
        //img.setPixel(width+i,height+length+1,-1000);
        //img.setPixel(width+i,height+length+2,-1000);
        img.setPixel(width+i,height+length+3,-1000);

        img.setPixel(width,height+i,-1000);
        //img.setPixel(width+1,height+i,-1000);
        //img.setPixel(width+2,height+i,-1000);
        img.setPixel(width+3,height+i,-1000);

        img.setPixel(width+length,height+i,-1000);
        //img.setPixel(width+length+1,height+i,-1000);
        //img.setPixel(width+length+2,height+i,-1000);
        img.setPixel(width+length+3,height+i,-1000);
    }

    return img;

}

QImage QOpenCVWidget::skinFilter(QImage image) {

    for(int i=0; i<image.width(); i++) {
        for(int j=0; j<image.height(); j++) {

            if(!isSkin(image.pixel(i,j))) {
                image.setPixel(i,j,0);
            }

        }
    }

    return image;

}

bool QOpenCVWidget::isSkin(QColor color) {

    int r,g,b;
    color.getRgb(&r,&g,&b);

    if((r>95) && (g>40) && (b>20) && ((maxRgb(r,g,b) - minRgb(r,g,b)) > 15) && (qAbs(r-g) > 15) && (r>g) && (r>b) && ( ((r*100)/(r+g+b)) < 57 ) && ( ((g*100)/(r+g+b)) < 35 ) && ( ((b*100)/(r+g+b)) < 35 )) {
        return true;
    }

    return false;

}

int QOpenCVWidget::minRgb(int r, int g, int b) {
    int min = r;
    if(g<min) {
        min = g;
    }
    if(b<min) {
        min = b;
    }
    return min;
}

int QOpenCVWidget::maxRgb(int r, int g, int b) {
    int max = r;
    if(g>max) {
        max = g;
    }
    if(b>max) {
        max = b;
    }
    return max;
}

QImage QOpenCVWidget::toGrayscale(QImage img) {

    img = img.convertToFormat(QImage::Format_Indexed8);

    QVector<int> transform_table(img.numColors());

    for(int i=0; i<img.numColors() ;i++) {
        QRgb c1=img.color(i);
        int avg=qGray(c1);
        transform_table[i]=avg;
    }

    img.setNumColors(256);

    for(int i=0; i<256; i++) {
        img.setColor(i,qRgb(i,i,i));
    }

    for(int i=0; i<img.numBytes();i++) {
        img.bits()[i]=transform_table[img.bits()[i]];
    }

    return img;
}

QImage QOpenCVWidget::toSobel(QImage img) {

    int mask[3][3];
    mask[0][0]=1;  mask[1][0]=2;  mask[2][0]=1;
    mask[0][1]=0;  mask[1][1]=0;  mask[2][1]=0;
    mask[0][2]=-1; mask[1][2]=-2; mask[2][2]=-1;

    for(int i=1; i<img.width()-2; i++) {
        for(int j=1; j<img.height()-2; j++) {
            int c1 = 0;
            int c2 = 0;

            for(int k=0; k<3; k++) {
                for(int l=0; l<3; l++) {
                    QColor col = img.pixel(i+k,j+l);
                    int r,g,b;
                    col.getRgb(&r,&g,&b);
                    c1 = c1 + r * mask[k][l];
                    c2 = c2 + r * mask[l][k];
                }
                int c = sqrt(pow(c1,2) + pow(c2,2));
                if(c>255) {
                    c = 255;
                }
                c = round(c);
                img.setPixel(i,j,c);

            }

        }
    }

    return img;

}
