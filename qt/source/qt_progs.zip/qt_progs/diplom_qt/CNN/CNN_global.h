#ifndef CNN_GLOBAL_H
#define CNN_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(CNN_LIBRARY)
#  define CNNSHARED_EXPORT Q_DECL_EXPORT
#else
#  define CNNSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // CNN_GLOBAL_H
