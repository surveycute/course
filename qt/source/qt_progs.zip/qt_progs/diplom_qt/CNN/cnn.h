#ifndef CNN_H
#define CNN_H

#include "CNN_global.h"
#include <QVector>
#include <QList>
#include <qdebug.h>
#include <math.h>
#include <QTime>
#include <QFile>
#include <QString>
#include <QStringList>
#include <QImage>
#include <QColor>
#include <QDir>

typedef QVector<float> vfloat;
typedef QVector<QVector<float> > vfloat2d;
typedef QList<vfloat> list_vfloat;
typedef QList<vfloat2d> list_vfloat2d;
typedef QList<list_vfloat2d> list2d_vfloat2d;
typedef QVector<int> vint;
typedef QVector<vint> vint2d;
typedef QList<vint> list_vint;

/*
//вход
struct i_layer {
    vfloat2d image;
};

//сверточный слой
struct c_layer {
    //ядра (весовые матрицы)
    list_vfloat2d kernel;
    //карты признаков
    list_vfloat2d feature_map;
    //нейронные смещения
    vfloat biases;
};

//слой субдескретизации
struct s_layer {
    //веса
    vfloat weight;
    //карты признаков
    list_vfloat2d feature_map;
    //нейронные смещения
    vfloat biases;
};


//слой персептронов
struct n_layer {
    //кол-во нейронов в слое
    int num_neurons;
    //коэф. синаптических связей
    vfloat2d weight;
    //выход слоя
    vfloat output;

};
*/

//общий слой
struct layer {

    int type_layer;

    //тип #0 вход
    //входное изображение
    //vfloat2d image;

    //тип #1 свертка
    //ядра (весовые матрицы)
    list_vfloat2d c_kernel;
    //карты признаков
    list_vfloat2d c_feature_map;
    //нейронные смещения
    vfloat c_biases;

    //тип #2 субдескретизация
    //веса
    vfloat s_weight;
    //карты признаков
    list_vfloat2d s_feature_map;
    //нейронные смещения
    vfloat s_biases;

    //тип #3 слой персептронов
    //кол-во нейронов в слое
    int n_num_neurons;
    //коэф. синаптических связей
    vfloat2d n_weight;
    //выход слоя
    vfloat n_output;

    //тип #4 переходной слой субдескретизация-персептронный
    //кол-во нейронов в слое
    int sn_num_neurons;
    //коэф. синаптических связей
    list_vfloat2d sn_weight;
    //выход слоя
    vfloat sn_output;
    //смещения
    vfloat sn_biases;

};

/*
//слой нейросети
struct layer {
    //тип слоя
    int type_layer;
    //тип #0 вход нейросети
    i_layer input;
    //тип #1 слой свертки и субдескретизации
    c_layer conv_layer;
    s_layer subs_layer;
    n_layer neur_layer;
};*/

/*struct layer {

    list_vfloat2d feature_map;

};

struct cnn_data {
    int num_layers;
    vfloat2d &input;
    list2d_vfloat2d &list_kernels;
    list_vfloat &c_biases;
    list_vfloat &s_biases;
    list_vfloat &s_weights;
};*/

struct cnn_data {

    vfloat2d kernel1_1;
    vfloat2d kernel1_2;
    vfloat2d kernel1_3;
    vfloat2d kernel1_4;
    vfloat2d kernel1_5;

    float bias1_1;
    float bias1_2;
    float bias1_3;
    float bias1_4;
    float bias1_5;

    float weight2_1;
    float weight2_2;
    float weight2_3;
    float weight2_4;
    float weight2_5;

    float bias2_1;
    float bias2_2;
    float bias2_3;
    float bias2_4;
    float bias2_5;

    vfloat2d kernel3_1;
    vfloat2d kernel3_2;
    vfloat2d kernel3_3;
    vfloat2d kernel3_4;
    vfloat2d kernel3_5;
    vfloat2d kernel3_6;
    vfloat2d kernel3_7;
    vfloat2d kernel3_8;
    vfloat2d kernel3_9;
    vfloat2d kernel3_10;

    float bias3_1;
    float bias3_2;
    float bias3_3;
    float bias3_4;
    float bias3_5;
    float bias3_6;
    float bias3_7;
    float bias3_8;
    float bias3_9;
    float bias3_10;

    vfloat2d kernel3_11;
    vfloat2d kernel3_12;
    vfloat2d kernel3_13;
    vfloat2d kernel3_14;
    vfloat2d kernel3_15;
    vfloat2d kernel3_16;
    vfloat2d kernel3_17;
    vfloat2d kernel3_18;
    vfloat2d kernel3_19;
    vfloat2d kernel3_20;
    vfloat2d kernel3_21;
    vfloat2d kernel3_22;
    vfloat2d kernel3_23;
    vfloat2d kernel3_24;
    vfloat2d kernel3_25;
    vfloat2d kernel3_26;
    vfloat2d kernel3_27;
    vfloat2d kernel3_28;
    vfloat2d kernel3_29;
    vfloat2d kernel3_30;

    float bias3_11;
    float bias3_12;
    float bias3_13;
    float bias3_14;
    float bias3_15;
    float bias3_16;
    float bias3_17;
    float bias3_18;
    float bias3_19;
    float bias3_20;

    float weight4_1;
    float weight4_2;
    float weight4_3;
    float weight4_4;
    float weight4_5;
    float weight4_6;
    float weight4_7;
    float weight4_8;
    float weight4_9;
    float weight4_10;
    float weight4_11;
    float weight4_12;
    float weight4_13;
    float weight4_14;
    float weight4_15;
    float weight4_16;
    float weight4_17;
    float weight4_18;
    float weight4_19;
    float weight4_20;

    float bias4_1;
    float bias4_2;
    float bias4_3;
    float bias4_4;
    float bias4_5;
    float bias4_6;
    float bias4_7;
    float bias4_8;
    float bias4_9;
    float bias4_10;
    float bias4_11;
    float bias4_12;
    float bias4_13;
    float bias4_14;
    float bias4_15;
    float bias4_16;
    float bias4_17;
    float bias4_18;
    float bias4_19;
    float bias4_20;

    float bias5_1;
    float bias5_2;
    float bias5_3;
    float bias5_4;
    float bias5_5;
    float bias5_6;
    float bias5_7;
    float bias5_8;
    float bias5_9;
    float bias5_10;
    float bias5_11;
    float bias5_12;
    float bias5_13;
    float bias5_14;
    float bias5_15;
    float bias5_16;
    float bias5_17;
    float bias5_18;
    float bias5_19;
    float bias5_20;

    vfloat2d weight5_1;
    vfloat2d weight5_2;
    vfloat2d weight5_3;
    vfloat2d weight5_4;
    vfloat2d weight5_5;
    vfloat2d weight5_6;
    vfloat2d weight5_7;
    vfloat2d weight5_8;
    vfloat2d weight5_9;
    vfloat2d weight5_10;
    vfloat2d weight5_11;
    vfloat2d weight5_12;
    vfloat2d weight5_13;
    vfloat2d weight5_14;
    vfloat2d weight5_15;
    vfloat2d weight5_16;
    vfloat2d weight5_17;
    vfloat2d weight5_18;
    vfloat2d weight5_19;
    vfloat2d weight5_20;

    float weight6_1;
    float weight6_2;
    float weight6_3;
    float weight6_4;
    float weight6_5;
    float weight6_6;
    float weight6_7;
    float weight6_8;
    float weight6_9;
    float weight6_10;
    float weight6_11;
    float weight6_12;
    float weight6_13;
    float weight6_14;
    float weight6_15;
    float weight6_16;
    float weight6_17;
    float weight6_18;
    float weight6_19;
    float weight6_20;

    float bias6_1;

};

typedef QList<layer*> c_net;

class CNNSHARED_EXPORT CNN {
public:
    //функция свертки
    static vfloat2d convolution(vfloat2d &kernel, float bias, vfloat2d &input);
    //функция субдескретизации
    static vfloat2d subsampling(vfloat2d &input, float bias, float weight);
    //свертка + субдескретизация
    static vfloat2d conv_and_subs(vfloat2d &input, vfloat2d &c_kernel, float c_bias, float s_bias, float s_weight);
    //активационная функция - гиперболический тангенс
    static float activation(float value);
    //прямое распространение
    //static list_vfloat2d forward_propagate(cnn_data data);
    //задание размерности сети и ее компонентов
    static c_net create_net(int num_layers, vint &layers_type, vint &num_neurons, vint2d &kernels_size);
    static vfloat2d vfloat2d_create(const int M, const int N);
    static void start_net(vfloat2d &input, c_net &net);
    static float subs_to_neuron(vfloat2d &weight, vfloat2d &fmap, float bias);
    static vfloat2d sum_fmaps(vfloat2d &fmap1, vfloat2d &fmap2);
    static float convolution_net(vfloat2d &input, cnn_data &data);
    static cnn_data get_randon_data();
    static vfloat2d random_vfloat2d(int height, int width, float range_min, float range_max);
    static float random_float(float range_min, float range_max);
    static vfloat cnn_data_to_vfloat(cnn_data &data);
    static void append_vfloat2d(vfloat2d &kernel, vfloat &data);
    static vfloat2d append_data_to_vfloat2d(int kern_height, int kern_width, vfloat &data, int &counter);
    static cnn_data vfloat_to_cnn_data(vfloat &data);
    static void save_net(vfloat data, QString path_save);
    static vfloat load_net(QString path_load);
    static QStringList read_file(QString path);
    static QImage toGrayscale(QImage &img);

    static vfloat vfloat_sum(vfloat &vector1, vfloat &vector2);
    static cnn_data rga_train(list_vfloat2d &in, vfloat2d &target, vfloat2d &population, float rms_error, float blx_koef, int step, int max_step);
    static int best_chromosome(vfloat2d &outputs, vfloat &target);
    static vfloat2d random_blx(vfloat2d &population, double blx_koef);
    static vfloat2d tournament_selection(vfloat2d &population, vfloat &values);
    static vfloat calculate_fitness(vfloat2d &outputs, vfloat &target);
    static float vfloat_sum_elem(vfloat &vector);
    static vfloat vfloat_pow(vfloat &vector, double power);
    static vfloat vfloat_sub(vfloat &vector1, vfloat &vector2);
    static float fitness_neural(vfloat &output, vfloat &target);
    static float rand_A_B(int A, int B);
    static vfloat2d population_mutation(vfloat2d &population, int chance);
    static float random_mutation(float value);
    static vfloat blx_a_crossover(vfloat &chromosome1, vfloat &chromosome2, float A);
    static QImage toNeuro(QImage &img, int height, int width);
    static float min(float a, float b);
    static float max(float a, float b);
    static vfloat2d open_image(QImage &image);
    static cnn_data image_rga_train(QString faces_dir, QString no_faces_dir);
    static list_vfloat2d openFaces(QString open_directory);
    static QPoint find_face(QImage &image, QString &path_net);

};

#endif // CNN_H
