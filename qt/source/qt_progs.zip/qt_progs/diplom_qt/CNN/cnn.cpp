#include "cnn.h"
#include <QtConcurrentRun>

/*##### коды ошибок (функция свертки) #######################
##  1 - ядро пустое                                         #
##  2 - неверный размер ядра (должен быть кравдратным)      #
##  3 - входные значения пусты                              #
###########################################################*/

/*##### коды ошибок (функция субдескритезации) ##############
##  4 - входное значение пустое                             #
###########################################################*/

/*##### коды ошибок (задание размеров сети) #################
##  5 - не верный тип слоя                                  #
###########################################################*/

//функция свертки
vfloat2d CNN::convolution(vfloat2d &kernel, float bias, vfloat2d &input) {

    //проверяем ядро на пустоту
    if(kernel.empty()) {
        exit(1);
    }

    //проверяем размерность ядра
    if(kernel.size() != kernel.at(0).size()) {
        exit(2);
    }

    //проверяем входные значения на пустоту
    if(input.empty()) {
        exit(3);
    }

    //вычисление исходных размерностей
    //размерность ядра
    int kernel_size = kernel.size();
    //ширина входного слоя
    int input_width = input.at(0).size();
    //высота входного слоя
    int input_height = input.size();

    //вычисляем размер выходной плоскости
    //ширина выходной плоскости
    int out_width = input_width - kernel_size + 1;
    //высота выходной плоскости
    int out_height = input_height - kernel_size + 1;

    //создаем выходную плоскость
    vfloat2d output;
    for(int i=0; i<out_height; i++) {
        vfloat out_line;
        out_line.resize(out_width);
        output.append(out_line);
    }

    //выполняем свертку для каждого нейрона в плоскости
    for(int i=0; i<out_height; i++) {
        for(int j=0; j<out_width; j++) {

            for(int s=0; s<kernel_size; s++) {
                for(int t=0; t<kernel_size; t++) {

                    output[i][j] = output[i][j] + kernel[s][t] * input[i+s][j+t];

                }
            }

            output[i][j] = output[i][j] + bias;

        }
    }
    return output;

}

//функция субдескритезации
vfloat2d CNN::subsampling(vfloat2d &input, float bias, float weight) {

    //проверяем входную плоскость на пустоту
    if(input.empty()) {
        exit(4);
    }

    //задаем размеры выходной плоскости, в 2 раза меньше входной
    //ширина
    int out_width = input.at(0).size() / 2;
    //высота
    int out_height = input.size() / 2;

    //создаем выходную плоскость заданной размерностью
    vfloat2d output;
    for(int i=0; i<out_height; i++) {
        vfloat out_line;
        out_line.resize(out_width);
        output.append(out_line);
    }

    //вычисляем среднее 4-х входов, умножаем на синаптический коэффициент и прибавляем нейронное смещение
    for(int i=0; i<out_height; i++) {
        for(int j=0; j<out_width; j++) {

            output[i][j] = activation( ((input[2*i][2*j] + input[2*i+1][2*j] + input[2*i][2*j+1] + input[2*i+1][2*j+1]) / 4) * weight + bias);

        }
    }

    return output;

}

vfloat2d CNN::conv_and_subs(vfloat2d &input, vfloat2d &c_kernel, float c_bias, float s_bias, float s_weight) {

    vfloat2d output = convolution(c_kernel,c_bias,input);
    output = subsampling(output,s_bias,s_weight);

    return output;

}

float CNN::activation(float value) {
    return 1.7159 * tanh(0.6666 * value);
}


/*c_net CNN::create_net(int num_layers, vint &type_layers) {

    c_net convoluation_net;

    for(int i=0; i<num_layers; i++) {

        switch (type_layers.at(i)) {
        case 0:
            i_layer input;
            layer input_layer;
            input_layer.type_layer = 0;
            input_layer.input = input;
            convoluation_net.append(input_layer);
            break;
        case 1:
            c_layer conv;
            layer conv_layer;
            conv_layer.type_layer = 1;
            conv_layer.conv_layer = conv;
            convoluation_net.append(conv_layer);
            break;
        case 2:
            s_layer subs;
            layer subs_layer;
            subs_layer.type_layer = 2;
            subs_layer.subs_layer = subs;
            convoluation_net.append(subs_layer);
            break;
        case 3:
            n_layer neur;
            layer neur_layer;
            neur_layer.type_layer = 3;
            neur_layer.neur_layer = neur;
            convoluation_net.append(neur_layer);
            break;
        default:
            exit(5);
            break;
        }
    }

    return convoluation_net;

}
*/
/*
list_vfloat2d CNN::forward_propagate(cnn_data data) {

    c_net convoluation_net;
    //задаем вход
    layer input_layer;
    input_layer.feature_map.append(data.input);
    convoluation_net.append(input_layer);

    //расчитываем оставшиеся слои
    for(int i=1; i<data.num_layers; i++) {

        layer cs_layer;
        for(int j=0; j<data.list_kernels.at(i-1).size(); j++) {
            for(int k=0; k<convoluation_net.at(i-1).feature_map.size(); k++) {
                vfloat2d input = convoluation_net.at(i-1).feature_map.at(k);
                vfloat2d kernel = data.list_kernels.at(i-1).at(j);
                float c_bias = data.c_biases.at(i-1).at(j);
                float s_bias = data.s_biases.at(i-1).at(j);
                float s_weight = data.s_weights.at(i-1).at(j);
                vfloat2d feature_map = conv_and_subs(input,kernel,c_bias,s_bias,s_weight);
                cs_layer.feature_map.append(feature_map);
            }
        }
        convoluation_net.append(cs_layer);
    }

    return convoluation_net.last().feature_map;

}
*/


c_net CNN::create_net(int num_layers, vint &layers_type, vint &num_neurons, vint2d &kernels_size) {

    c_net convoluation_net;
    for(int i=0; i<num_layers; i++) {

        layer *temp_layer = new layer;
        temp_layer->type_layer = layers_type.at(i);

        if(layers_type.at(i) == 0) {

            temp_layer->s_feature_map.append(vfloat2d_create(kernels_size.at(i).at(0),kernels_size.at(i).at(1)));
            break;

        }

        if(layers_type.at(i) == 1) {

            temp_layer->c_biases.resize(num_neurons.at(i));
            for(int k=0; k<num_neurons.at(i); k++) {
                temp_layer->c_kernel.append(vfloat2d_create(kernels_size.at(i).at(0),kernels_size.at(i).at(1)));
                for(int j=0; j<convoluation_net.at(i-1)->s_feature_map.size(); j++) {
                    //вычисление исходных размерностей
                    //размерность ядра
                    int kernel_height = kernels_size.at(i).at(0);
                    int kernel_width = kernels_size.at(i).at(1);
                    //размерность входа
                    int input_height = convoluation_net.at(i-1)->s_feature_map.at(j).size();
                    int input_width = convoluation_net.at(i-1)->s_feature_map.at(j).at(0).size();

                    //вычисляем размер выходной плоскости
                    //ширина выходной плоскости
                    int out_width = input_width - kernel_width + 1;
                    //высота выходной плоскости
                    int out_height = input_height - kernel_height + 1;
                    temp_layer->c_feature_map.append( vfloat2d_create(out_height,out_width) );
                }
            }
            break;

        }

        if(layers_type.at(i) == 2) {

            temp_layer->s_weight.resize(num_neurons.at(i));
            temp_layer->s_biases.resize(num_neurons.at(i));
            for(int j=0; j<convoluation_net.at(i-1)->c_feature_map.size(); j++) {
                int f_map_height =  convoluation_net.at(i-1)->c_feature_map.at(j).size()/2;
                int f_map_width = convoluation_net.at(i-1)->c_feature_map.at(j).at(0).size()/2;
                temp_layer->s_feature_map.append( vfloat2d_create(f_map_height, f_map_width) );
            }
            break;

        }

        if(layers_type.at(i) == 3) {

            temp_layer->n_num_neurons = num_neurons.at(i);
            temp_layer->n_output.resize(num_neurons.at(i));
            vfloat2d n_weight = vfloat2d_create(num_neurons.at(i-1), num_neurons.at(i));
            temp_layer->n_weight = n_weight;
            break;
        }

        if(layers_type.at(i) == 4) {

            temp_layer->sn_num_neurons = num_neurons.at(i);
            temp_layer->n_output.resize(num_neurons.at(i));
            temp_layer->sn_biases.resize(num_neurons.at(i));
            for(int j=0; j<convoluation_net.at(i-1)->s_feature_map.size(); j++) {

                int fmap_height = convoluation_net.at(i-1)->s_feature_map.at(j).size();
                int fmap_width = convoluation_net.at(i-1)->s_feature_map.at(j).at(0).size();
                vfloat2d sn_weigt = vfloat2d_create(fmap_height*fmap_width, 1);
                temp_layer->sn_weight.append(sn_weigt);

            }
            break;

        }

        convoluation_net.append(temp_layer);

    }

    return convoluation_net;

}

vfloat2d CNN::vfloat2d_create(const int M, const int N) {
    vfloat2d vector;
    vector.resize(M);
    for(int i=0; i<M; i++) {
        vector[i].resize(N);
    }
    return vector;
}

void CNN::start_net(vfloat2d &input, c_net &net) {

    //net.at(0)->s_feature_map.at(0).resize(10);// = input;

}

float CNN::convolution_net(vfloat2d &input, cnn_data &data) {


    vfloat2d fmap1_1 = convolution(data.kernel1_1,data.bias1_1,input);
    vfloat2d fmap1_2 = convolution(data.kernel1_2,data.bias1_2,input);
    vfloat2d fmap1_3 = convolution(data.kernel1_3,data.bias1_3,input);
    vfloat2d fmap1_4 = convolution(data.kernel1_4,data.bias1_4,input);
    vfloat2d fmap1_5 = convolution(data.kernel1_5,data.bias1_5,input);



    vfloat2d fmap2_1 = subsampling(fmap1_1,data.bias2_1,data.weight2_1);
    vfloat2d fmap2_2 = subsampling(fmap1_2,data.bias2_2,data.weight2_2);
    vfloat2d fmap2_3 = subsampling(fmap1_3,data.bias2_3,data.weight2_3);
    vfloat2d fmap2_4 = subsampling(fmap1_4,data.bias2_4,data.weight2_4);
    vfloat2d fmap2_5 = subsampling(fmap1_5,data.bias2_5,data.weight2_5);



    vfloat2d fmap3_1 = convolution(data.kernel3_1,data.bias3_1,fmap2_1);
    vfloat2d fmap3_2 = convolution(data.kernel3_2,data.bias3_2,fmap2_2);
    vfloat2d fmap3_3 = convolution(data.kernel3_3,data.bias3_3,fmap2_3);
    vfloat2d fmap3_4 = convolution(data.kernel3_4,data.bias3_4,fmap2_4);
    vfloat2d fmap3_5 = convolution(data.kernel3_5,data.bias3_5,fmap2_5);
    vfloat2d fmap3_6 = convolution(data.kernel3_6,data.bias3_6,fmap2_1);
    vfloat2d fmap3_7 = convolution(data.kernel3_7,data.bias3_7,fmap2_2);
    vfloat2d fmap3_8 = convolution(data.kernel3_8,data.bias3_8,fmap2_3);
    vfloat2d fmap3_9 = convolution(data.kernel3_9,data.bias3_9,fmap2_4);
    vfloat2d fmap3_10 = convolution(data.kernel3_10,data.bias3_10,fmap2_5);



    vfloat2d temp_1 = convolution(data.kernel3_11,data.bias3_11,fmap2_1);
    vfloat2d temp_2 = convolution(data.kernel3_12,data.bias3_11,fmap2_2);
    vfloat2d temp_3 = convolution(data.kernel3_13,data.bias3_12,fmap2_1);
    vfloat2d temp_4 = convolution(data.kernel3_14,data.bias3_12,fmap2_3);
    vfloat2d temp_5 = convolution(data.kernel3_15,data.bias3_13,fmap2_1);
    vfloat2d temp_6 = convolution(data.kernel3_16,data.bias3_13,fmap2_4);
    vfloat2d temp_7 = convolution(data.kernel3_17,data.bias3_14,fmap2_1);
    vfloat2d temp_8 = convolution(data.kernel3_18,data.bias3_14,fmap2_5);
    vfloat2d temp_9 = convolution(data.kernel3_19,data.bias3_15,fmap2_2);
    vfloat2d temp_10 = convolution(data.kernel3_20,data.bias3_15,fmap2_3);
    vfloat2d temp_11 = convolution(data.kernel3_21,data.bias3_16,fmap2_2);
    vfloat2d temp_12 = convolution(data.kernel3_22,data.bias3_16,fmap2_4);
    vfloat2d temp_13 = convolution(data.kernel3_23,data.bias3_17,fmap2_2);
    vfloat2d temp_14 = convolution(data.kernel3_24,data.bias3_17,fmap2_5);
    vfloat2d temp_15 = convolution(data.kernel3_25,data.bias3_18,fmap2_3);
    vfloat2d temp_16 = convolution(data.kernel3_26,data.bias3_18,fmap2_4);
    vfloat2d temp_17 = convolution(data.kernel3_27,data.bias3_19,fmap2_3);
    vfloat2d temp_18 = convolution(data.kernel3_28,data.bias3_19,fmap2_5);
    vfloat2d temp_19 = convolution(data.kernel3_29,data.bias3_20,fmap2_4);
    vfloat2d temp_20 = convolution(data.kernel3_30,data.bias3_20,fmap2_5);

    vfloat2d fmap3_11 = sum_fmaps(temp_1,temp_2);
    vfloat2d fmap3_12 = sum_fmaps(temp_3,temp_4);
    vfloat2d fmap3_13 = sum_fmaps(temp_5,temp_6);
    vfloat2d fmap3_14 = sum_fmaps(temp_7,temp_8);
    vfloat2d fmap3_15 = sum_fmaps(temp_9,temp_10);
    vfloat2d fmap3_16 = sum_fmaps(temp_11,temp_12);
    vfloat2d fmap3_17 = sum_fmaps(temp_13,temp_14);
    vfloat2d fmap3_18 = sum_fmaps(temp_15,temp_16);
    vfloat2d fmap3_19 = sum_fmaps(temp_17,temp_18);
    vfloat2d fmap3_20 = sum_fmaps(temp_19,temp_20);


    vfloat2d fmap4_1 = subsampling(fmap3_1,data.bias4_1,data.weight4_1);
    vfloat2d fmap4_2 = subsampling(fmap3_2,data.bias4_2,data.weight4_2);
    vfloat2d fmap4_3 = subsampling(fmap3_3,data.bias4_3,data.weight4_3);
    vfloat2d fmap4_4 = subsampling(fmap3_4,data.bias4_4,data.weight4_4);
    vfloat2d fmap4_5 = subsampling(fmap3_5,data.bias4_5,data.weight4_5);
    vfloat2d fmap4_6 = subsampling(fmap3_6,data.bias4_6,data.weight4_6);
    vfloat2d fmap4_7 = subsampling(fmap3_7,data.bias4_7,data.weight4_7);
    vfloat2d fmap4_8 = subsampling(fmap3_8,data.bias4_8,data.weight4_8);
    vfloat2d fmap4_9 = subsampling(fmap3_9,data.bias4_9,data.weight4_9);
    vfloat2d fmap4_10 = subsampling(fmap3_10,data.bias4_10,data.weight4_10);
    vfloat2d fmap4_11 = subsampling(fmap3_11,data.bias4_11,data.weight4_11);
    vfloat2d fmap4_12 = subsampling(fmap3_12,data.bias4_12,data.weight4_12);
    vfloat2d fmap4_13 = subsampling(fmap3_13,data.bias4_13,data.weight4_13);
    vfloat2d fmap4_14 = subsampling(fmap3_14,data.bias4_14,data.weight4_14);
    vfloat2d fmap4_15 = subsampling(fmap3_15,data.bias4_15,data.weight4_15);
    vfloat2d fmap4_16 = subsampling(fmap3_16,data.bias4_16,data.weight4_16);
    vfloat2d fmap4_17 = subsampling(fmap3_17,data.bias4_17,data.weight4_17);
    vfloat2d fmap4_18 = subsampling(fmap3_18,data.bias4_18,data.weight4_18);
    vfloat2d fmap4_19 = subsampling(fmap3_19,data.bias4_19,data.weight4_19);
    vfloat2d fmap4_20 = subsampling(fmap3_20,data.bias4_20,data.weight4_20);




    float neuron_out5_1 = subs_to_neuron(data.weight5_1,fmap4_1,data.bias5_1);
    float neuron_out5_2 = subs_to_neuron(data.weight5_2,fmap4_2,data.bias5_2);
    float neuron_out5_3 = subs_to_neuron(data.weight5_3,fmap4_3,data.bias5_3);
    float neuron_out5_4 = subs_to_neuron(data.weight5_4,fmap4_4,data.bias5_4);
    float neuron_out5_5 = subs_to_neuron(data.weight5_5,fmap4_5,data.bias5_5);
    float neuron_out5_6 = subs_to_neuron(data.weight5_6,fmap4_6,data.bias5_6);
    float neuron_out5_7 = subs_to_neuron(data.weight5_7,fmap4_7,data.bias5_7);
    float neuron_out5_8 = subs_to_neuron(data.weight5_8,fmap4_8,data.bias5_8);
    float neuron_out5_9 = subs_to_neuron(data.weight5_9,fmap4_9,data.bias5_9);
    float neuron_out5_10 = subs_to_neuron(data.weight5_10,fmap4_10,data.bias5_10);
    float neuron_out5_11 = subs_to_neuron(data.weight5_11,fmap4_11,data.bias5_11);
    float neuron_out5_12 = subs_to_neuron(data.weight5_12,fmap4_12,data.bias5_12);
    float neuron_out5_13 = subs_to_neuron(data.weight5_13,fmap4_13,data.bias5_13);
    float neuron_out5_14 = subs_to_neuron(data.weight5_14,fmap4_14,data.bias5_14);
    float neuron_out5_15 = subs_to_neuron(data.weight5_15,fmap4_15,data.bias5_15);
    float neuron_out5_16 = subs_to_neuron(data.weight5_16,fmap4_16,data.bias5_16);
    float neuron_out5_17 = subs_to_neuron(data.weight5_17,fmap4_17,data.bias5_17);
    float neuron_out5_18 = subs_to_neuron(data.weight5_18,fmap4_18,data.bias5_18);
    float neuron_out5_19 = subs_to_neuron(data.weight5_19,fmap4_19,data.bias5_19);
    float neuron_out5_20 = subs_to_neuron(data.weight5_20,fmap4_20,data.bias5_20);



    float mul6_1 = data.weight6_1 * neuron_out5_1;
    float mul6_2 = data.weight6_2 * neuron_out5_2;
    float mul6_3 = data.weight6_3 * neuron_out5_3;
    float mul6_4 = data.weight6_4 * neuron_out5_4;
    float mul6_5 = data.weight6_5 * neuron_out5_5;
    float mul6_6 = data.weight6_6 * neuron_out5_6;
    float mul6_7 = data.weight6_7 * neuron_out5_7;
    float mul6_8 = data.weight6_8 * neuron_out5_8;
    float mul6_9 = data.weight6_9 * neuron_out5_9;
    float mul6_10 = data.weight6_10 * neuron_out5_10;
    float mul6_11 = data.weight6_11 * neuron_out5_11;
    float mul6_12 = data.weight6_12 * neuron_out5_12;
    float mul6_13 = data.weight6_13 * neuron_out5_13;
    float mul6_14 = data.weight6_14 * neuron_out5_14;
    float mul6_15 = data.weight6_15 * neuron_out5_15;
    float mul6_16 = data.weight6_16 * neuron_out5_16;
    float mul6_17 = data.weight6_17 * neuron_out5_17;
    float mul6_18 = data.weight6_18 * neuron_out5_18;
    float mul6_19 = data.weight6_19 * neuron_out5_19;
    float mul6_20 = data.weight6_20 * neuron_out5_20;

    float sum = mul6_1 + mul6_2 + mul6_3 + mul6_4 + mul6_5 + mul6_6 + mul6_7 + mul6_8 + mul6_9 + mul6_10 + mul6_11 + mul6_12 + mul6_13 + mul6_14 + mul6_15 + mul6_16 + mul6_17 + mul6_18 + mul6_19 + mul6_20;

    sum = activation(sum + data.bias6_1);

    return sum;

}

vfloat2d CNN::sum_fmaps(vfloat2d &fmap1, vfloat2d &fmap2) {

    vfloat2d ret_fmap;
    ret_fmap.resize(fmap1.size());
    for(int i=0; i<fmap1.size(); i++) {
        ret_fmap[i].resize(fmap1.at(i).size());
        for(int j=0; j<fmap1.at(0).size(); j++) {
            ret_fmap[i][j] = fmap1[i][j] + fmap2[i][j];
        }
    }

    return ret_fmap;

}


float CNN::subs_to_neuron(vfloat2d &weight, vfloat2d &fmap, float bias) {

    float sum;
    for(int i=0; i<weight.size(); i++) {
        for(int j=0; j<weight.at(0).size(); j++) {
            sum = sum + (weight[i][j] * fmap[i][j]);
        }
    }

    sum = activation(sum+bias);
    return sum;

}

cnn_data CNN::get_randon_data() {

    float range_min = -0.5;
    float range_max = 0.5;

    int kernel_1_size = 5;

    cnn_data data;

    data.kernel1_1 = random_vfloat2d(kernel_1_size,kernel_1_size,range_min,range_max);
    data.kernel1_2 = random_vfloat2d(kernel_1_size,kernel_1_size,range_min,range_max);
    data.kernel1_3 = random_vfloat2d(kernel_1_size,kernel_1_size,range_min,range_max);
    data.kernel1_4 = random_vfloat2d(kernel_1_size,kernel_1_size,range_min,range_max);
    data.kernel1_5 = random_vfloat2d(kernel_1_size,kernel_1_size,range_min,range_max);

    data.bias1_1 = random_float(range_min,range_max);
    data.bias1_2 = random_float(range_min,range_max);
    data.bias1_3 = random_float(range_min,range_max);
    data.bias1_4 = random_float(range_min,range_max);
    data.bias1_5 = random_float(range_min,range_max);

    data.weight2_1 = random_float(range_min,range_max);
    data.weight2_2 = random_float(range_min,range_max);
    data.weight2_3 = random_float(range_min,range_max);
    data.weight2_4 = random_float(range_min,range_max);
    data.weight2_5 = random_float(range_min,range_max);

    data.bias2_1 = random_float(range_min,range_max);
    data.bias2_2 = random_float(range_min,range_max);
    data.bias2_3 = random_float(range_min,range_max);
    data.bias2_4 = random_float(range_min,range_max);
    data.bias2_5 = random_float(range_min,range_max);

    int kernel_3_size = 3;
    data.kernel3_1 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_2 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_3 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_4 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_5 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_6 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_7 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_8 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_9 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_10 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);

    data.bias3_1 = random_float(range_min,range_max);
    data.bias3_2 = random_float(range_min,range_max);
    data.bias3_3 = random_float(range_min,range_max);
    data.bias3_4 = random_float(range_min,range_max);
    data.bias3_5 = random_float(range_min,range_max);
    data.bias3_6 = random_float(range_min,range_max);
    data.bias3_7 = random_float(range_min,range_max);
    data.bias3_8 = random_float(range_min,range_max);
    data.bias3_9 = random_float(range_min,range_max);
    data.bias3_10 = random_float(range_min,range_max);

    data.kernel3_11 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_12 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_13 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_14 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_15 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_16 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_17 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_18 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_19 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_20 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_21 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_22 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_23 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_24 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_25 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_26 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_27 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_28 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_29 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);
    data.kernel3_30 = random_vfloat2d(kernel_3_size,kernel_3_size,range_min,range_max);

    data.bias3_11 = random_float(range_min,range_max);
    data.bias3_12 = random_float(range_min,range_max);
    data.bias3_13 = random_float(range_min,range_max);
    data.bias3_14 = random_float(range_min,range_max);
    data.bias3_15 = random_float(range_min,range_max);
    data.bias3_16 = random_float(range_min,range_max);
    data.bias3_17 = random_float(range_min,range_max);
    data.bias3_18 = random_float(range_min,range_max);
    data.bias3_19 = random_float(range_min,range_max);
    data.bias3_20 = random_float(range_min,range_max);

    data.weight4_1 = random_float(range_min,range_max);
    data.weight4_2 = random_float(range_min,range_max);
    data.weight4_3 = random_float(range_min,range_max);
    data.weight4_4 = random_float(range_min,range_max);
    data.weight4_5 = random_float(range_min,range_max);
    data.weight4_6 = random_float(range_min,range_max);
    data.weight4_7 = random_float(range_min,range_max);
    data.weight4_8 = random_float(range_min,range_max);
    data.weight4_9 = random_float(range_min,range_max);
    data.weight4_10 = random_float(range_min,range_max);
    data.weight4_11 = random_float(range_min,range_max);
    data.weight4_12 = random_float(range_min,range_max);
    data.weight4_13 = random_float(range_min,range_max);
    data.weight4_14 = random_float(range_min,range_max);
    data.weight4_15 = random_float(range_min,range_max);
    data.weight4_16 = random_float(range_min,range_max);
    data.weight4_17 = random_float(range_min,range_max);
    data.weight4_18 = random_float(range_min,range_max);
    data.weight4_19 = random_float(range_min,range_max);
    data.weight4_20 = random_float(range_min,range_max);

    data.bias4_1 = random_float(range_min,range_max);
    data.bias4_2 = random_float(range_min,range_max);
    data.bias4_3 = random_float(range_min,range_max);
    data.bias4_4 = random_float(range_min,range_max);
    data.bias4_5 = random_float(range_min,range_max);
    data.bias4_6 = random_float(range_min,range_max);
    data.bias4_7 = random_float(range_min,range_max);
    data.bias4_8 = random_float(range_min,range_max);
    data.bias4_9 = random_float(range_min,range_max);
    data.bias4_10 = random_float(range_min,range_max);
    data.bias4_11 = random_float(range_min,range_max);
    data.bias4_12 = random_float(range_min,range_max);
    data.bias4_13 = random_float(range_min,range_max);
    data.bias4_14 = random_float(range_min,range_max);
    data.bias4_15 = random_float(range_min,range_max);
    data.bias4_16 = random_float(range_min,range_max);
    data.bias4_17 = random_float(range_min,range_max);
    data.bias4_18 = random_float(range_min,range_max);
    data.bias4_19 = random_float(range_min,range_max);
    data.bias4_20 = random_float(range_min,range_max);

    data.bias5_1 = random_float(range_min,range_max);
    data.bias5_2 = random_float(range_min,range_max);
    data.bias5_3 = random_float(range_min,range_max);
    data.bias5_4 = random_float(range_min,range_max);
    data.bias5_5 = random_float(range_min,range_max);
    data.bias5_6 = random_float(range_min,range_max);
    data.bias5_7 = random_float(range_min,range_max);
    data.bias5_8 = random_float(range_min,range_max);
    data.bias5_9 = random_float(range_min,range_max);
    data.bias5_10 = random_float(range_min,range_max);
    data.bias5_11 = random_float(range_min,range_max);
    data.bias5_12 = random_float(range_min,range_max);
    data.bias5_13 = random_float(range_min,range_max);
    data.bias5_14 = random_float(range_min,range_max);
    data.bias5_15 = random_float(range_min,range_max);
    data.bias5_16 = random_float(range_min,range_max);
    data.bias5_17 = random_float(range_min,range_max);
    data.bias5_18 = random_float(range_min,range_max);
    data.bias5_19 = random_float(range_min,range_max);
    data.bias5_20 = random_float(range_min,range_max);

    int weight_5_height = 6;
    int weight_5_width = 7;

    data.weight5_1 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_2 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_3 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_4 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_5 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_6 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_7 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_8 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_9 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_10 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_11 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_12 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_13 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_14 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_15 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_16 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_17 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_18 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_19 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);
    data.weight5_20 = random_vfloat2d(weight_5_height,weight_5_width,range_min,range_max);

    data.weight6_1 = random_float(range_min,range_max);
    data.weight6_2 = random_float(range_min,range_max);
    data.weight6_3 = random_float(range_min,range_max);
    data.weight6_4 = random_float(range_min,range_max);
    data.weight6_5 = random_float(range_min,range_max);
    data.weight6_6 = random_float(range_min,range_max);
    data.weight6_7 = random_float(range_min,range_max);
    data.weight6_8 = random_float(range_min,range_max);
    data.weight6_9 = random_float(range_min,range_max);
    data.weight6_10 = random_float(range_min,range_max);
    data.weight6_11 = random_float(range_min,range_max);
    data.weight6_12 = random_float(range_min,range_max);
    data.weight6_13 = random_float(range_min,range_max);
    data.weight6_14 = random_float(range_min,range_max);
    data.weight6_15 = random_float(range_min,range_max);
    data.weight6_16 = random_float(range_min,range_max);
    data.weight6_17 = random_float(range_min,range_max);
    data.weight6_18 = random_float(range_min,range_max);
    data.weight6_19 = random_float(range_min,range_max);
    data.weight6_20 = random_float(range_min,range_max);

    data.bias6_1 = random_float(range_min,range_max);

    return data;

}

vfloat2d CNN::random_vfloat2d(int height, int width, float range_min, float range_max) {

    vfloat2d ret_val;
    ret_val.resize(height);
    for(int i=0; i<ret_val.size(); i++) {
        ret_val[i].resize(width);
        for(int j=0; j<ret_val.at(i).size(); j++) {

            ret_val[i][j] = random_float(range_min,range_max);

        }
    }

    return ret_val;

}

float CNN::random_float(float range_min, float range_max) {
    float random_val = (float) qrand()/RAND_MAX;
    float ret_val = range_min + (range_max - range_min) * random_val;
    return ret_val;
}

vfloat CNN::cnn_data_to_vfloat(cnn_data &data) {

    vfloat new_data;

    append_vfloat2d(data.kernel1_1,new_data);
    append_vfloat2d(data.kernel1_2,new_data);
    append_vfloat2d(data.kernel1_3,new_data);
    append_vfloat2d(data.kernel1_4,new_data);
    append_vfloat2d(data.kernel1_5,new_data);

    new_data.append(data.bias1_1);
    new_data.append(data.bias1_2);
    new_data.append(data.bias1_3);
    new_data.append(data.bias1_4);
    new_data.append(data.bias1_5);

    new_data.append(data.weight2_1);
    new_data.append(data.weight2_2);
    new_data.append(data.weight2_3);
    new_data.append(data.weight2_4);
    new_data.append(data.weight2_5);

    new_data.append(data.bias2_1);
    new_data.append(data.bias2_2);
    new_data.append(data.bias2_3);
    new_data.append(data.bias2_4);
    new_data.append(data.bias2_5);

    append_vfloat2d(data.kernel3_1,new_data);
    append_vfloat2d(data.kernel3_2,new_data);
    append_vfloat2d(data.kernel3_3,new_data);
    append_vfloat2d(data.kernel3_4,new_data);
    append_vfloat2d(data.kernel3_5,new_data);
    append_vfloat2d(data.kernel3_6,new_data);
    append_vfloat2d(data.kernel3_7,new_data);
    append_vfloat2d(data.kernel3_8,new_data);
    append_vfloat2d(data.kernel3_9,new_data);
    append_vfloat2d(data.kernel3_10,new_data);

    new_data.append(data.bias3_1);
    new_data.append(data.bias3_2);
    new_data.append(data.bias3_3);
    new_data.append(data.bias3_4);
    new_data.append(data.bias3_5);
    new_data.append(data.bias3_6);
    new_data.append(data.bias3_7);
    new_data.append(data.bias3_8);
    new_data.append(data.bias3_9);
    new_data.append(data.bias3_10);

    append_vfloat2d(data.kernel3_11,new_data);
    append_vfloat2d(data.kernel3_12,new_data);
    append_vfloat2d(data.kernel3_13,new_data);
    append_vfloat2d(data.kernel3_14,new_data);
    append_vfloat2d(data.kernel3_15,new_data);
    append_vfloat2d(data.kernel3_16,new_data);
    append_vfloat2d(data.kernel3_17,new_data);
    append_vfloat2d(data.kernel3_18,new_data);
    append_vfloat2d(data.kernel3_19,new_data);
    append_vfloat2d(data.kernel3_20,new_data);
    append_vfloat2d(data.kernel3_21,new_data);
    append_vfloat2d(data.kernel3_22,new_data);
    append_vfloat2d(data.kernel3_23,new_data);
    append_vfloat2d(data.kernel3_24,new_data);
    append_vfloat2d(data.kernel3_25,new_data);
    append_vfloat2d(data.kernel3_26,new_data);
    append_vfloat2d(data.kernel3_27,new_data);
    append_vfloat2d(data.kernel3_28,new_data);
    append_vfloat2d(data.kernel3_29,new_data);
    append_vfloat2d(data.kernel3_30,new_data);

    new_data.append(data.bias3_11);
    new_data.append(data.bias3_12);
    new_data.append(data.bias3_13);
    new_data.append(data.bias3_14);
    new_data.append(data.bias3_15);
    new_data.append(data.bias3_16);
    new_data.append(data.bias3_17);
    new_data.append(data.bias3_18);
    new_data.append(data.bias3_19);
    new_data.append(data.bias3_20);

    new_data.append(data.weight4_1);
    new_data.append(data.weight4_2);
    new_data.append(data.weight4_3);
    new_data.append(data.weight4_4);
    new_data.append(data.weight4_5);
    new_data.append(data.weight4_6);
    new_data.append(data.weight4_7);
    new_data.append(data.weight4_8);
    new_data.append(data.weight4_9);
    new_data.append(data.weight4_10);
    new_data.append(data.weight4_11);
    new_data.append(data.weight4_12);
    new_data.append(data.weight4_13);
    new_data.append(data.weight4_14);
    new_data.append(data.weight4_15);
    new_data.append(data.weight4_16);
    new_data.append(data.weight4_17);
    new_data.append(data.weight4_18);
    new_data.append(data.weight4_19);
    new_data.append(data.weight4_20);

    new_data.append(data.bias4_1);
    new_data.append(data.bias4_2);
    new_data.append(data.bias4_3);
    new_data.append(data.bias4_4);
    new_data.append(data.bias4_5);
    new_data.append(data.bias4_6);
    new_data.append(data.bias4_7);
    new_data.append(data.bias4_8);
    new_data.append(data.bias4_9);
    new_data.append(data.bias4_10);
    new_data.append(data.bias4_11);
    new_data.append(data.bias4_12);
    new_data.append(data.bias4_13);
    new_data.append(data.bias4_14);
    new_data.append(data.bias4_15);
    new_data.append(data.bias4_16);
    new_data.append(data.bias4_17);
    new_data.append(data.bias4_18);
    new_data.append(data.bias4_19);
    new_data.append(data.bias4_20);

    new_data.append(data.bias5_1);
    new_data.append(data.bias5_2);
    new_data.append(data.bias5_3);
    new_data.append(data.bias5_4);
    new_data.append(data.bias5_5);
    new_data.append(data.bias5_6);
    new_data.append(data.bias5_7);
    new_data.append(data.bias5_8);
    new_data.append(data.bias5_9);
    new_data.append(data.bias5_10);
    new_data.append(data.bias5_11);
    new_data.append(data.bias5_12);
    new_data.append(data.bias5_13);
    new_data.append(data.bias5_14);
    new_data.append(data.bias5_15);
    new_data.append(data.bias5_16);
    new_data.append(data.bias5_17);
    new_data.append(data.bias5_18);
    new_data.append(data.bias5_19);
    new_data.append(data.bias5_20);

    append_vfloat2d(data.weight5_1,new_data);
    append_vfloat2d(data.weight5_2,new_data);
    append_vfloat2d(data.weight5_3,new_data);
    append_vfloat2d(data.weight5_4,new_data);
    append_vfloat2d(data.weight5_5,new_data);
    append_vfloat2d(data.weight5_6,new_data);
    append_vfloat2d(data.weight5_7,new_data);
    append_vfloat2d(data.weight5_8,new_data);
    append_vfloat2d(data.weight5_9,new_data);
    append_vfloat2d(data.weight5_10,new_data);
    append_vfloat2d(data.weight5_11,new_data);
    append_vfloat2d(data.weight5_12,new_data);
    append_vfloat2d(data.weight5_13,new_data);
    append_vfloat2d(data.weight5_14,new_data);
    append_vfloat2d(data.weight5_15,new_data);
    append_vfloat2d(data.weight5_16,new_data);
    append_vfloat2d(data.weight5_17,new_data);
    append_vfloat2d(data.weight5_18,new_data);
    append_vfloat2d(data.weight5_19,new_data);
    append_vfloat2d(data.weight5_20,new_data);

    new_data.append(data.weight6_1);
    new_data.append(data.weight6_2);
    new_data.append(data.weight6_3);
    new_data.append(data.weight6_4);
    new_data.append(data.weight6_5);
    new_data.append(data.weight6_6);
    new_data.append(data.weight6_7);
    new_data.append(data.weight6_8);
    new_data.append(data.weight6_9);
    new_data.append(data.weight6_10);
    new_data.append(data.weight6_11);
    new_data.append(data.weight6_12);
    new_data.append(data.weight6_13);
    new_data.append(data.weight6_14);
    new_data.append(data.weight6_15);
    new_data.append(data.weight6_16);
    new_data.append(data.weight6_17);
    new_data.append(data.weight6_18);
    new_data.append(data.weight6_19);
    new_data.append(data.weight6_20);

    new_data.append(data.bias6_1);

    return new_data;

}

void CNN::append_vfloat2d(vfloat2d &kernel, vfloat &data) {
    for(int i=0; i<kernel.size(); i++) {
        for(int j=0; j<kernel.at(i).size(); j++) {
            data.append(kernel[i][j]);
        }
    }
}

vfloat2d CNN::append_data_to_vfloat2d(int kern_height, int kern_width, vfloat &data, int &counter) {
    vfloat2d ret_val;
    ret_val.resize(kern_height);
    for(int i=0; i<kern_height; i++) {
        ret_val[i].resize(kern_width);
        for(int j=0; j<kern_width; j++) {
            //data.append(kernel[i][j]);
            ret_val[i][j] = data[counter];
            counter++;
        }
    }
    return ret_val;
}

cnn_data CNN::vfloat_to_cnn_data(vfloat &data) {

    int counter = 0;

    cnn_data new_data;

    int kernel_1_size = 5;

    new_data.kernel1_1 = append_data_to_vfloat2d(kernel_1_size,kernel_1_size,data,counter);
    new_data.kernel1_2 = append_data_to_vfloat2d(kernel_1_size,kernel_1_size,data,counter);
    new_data.kernel1_3 = append_data_to_vfloat2d(kernel_1_size,kernel_1_size,data,counter);
    new_data.kernel1_4 = append_data_to_vfloat2d(kernel_1_size,kernel_1_size,data,counter);
    new_data.kernel1_5 = append_data_to_vfloat2d(kernel_1_size,kernel_1_size,data,counter);

    new_data.bias1_1 = data[counter];
    counter++;
    new_data.bias1_2 = data[counter];
    counter++;
    new_data.bias1_3 = data[counter];
    counter++;
    new_data.bias1_4 = data[counter];
    counter++;
    new_data.bias1_5 = data[counter];
    counter++;

    new_data.weight2_1 = data[counter];
    counter++;
    new_data.weight2_2 = data[counter];
    counter++;
    new_data.weight2_3 = data[counter];
    counter++;
    new_data.weight2_4 = data[counter];
    counter++;
    new_data.weight2_5 = data[counter];
    counter++;

    new_data.bias2_1 = data[counter];
    counter++;
    new_data.bias2_2 = data[counter];
    counter++;
    new_data.bias2_3 = data[counter];
    counter++;
    new_data.bias2_4 = data[counter];
    counter++;
    new_data.bias2_5 = data[counter];
    counter++;

    int kernel_3_size = 3;
    new_data.kernel3_1 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_2 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_3 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_4 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_5 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_6 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_7 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_8 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_9 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_10 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);

    new_data.bias3_1 = data[counter];
    counter++;
    new_data.bias3_2 = data[counter];
    counter++;
    new_data.bias3_3 = data[counter];
    counter++;
    new_data.bias3_4 = data[counter];
    counter++;
    new_data.bias3_5 = data[counter];
    counter++;
    new_data.bias3_6 = data[counter];
    counter++;
    new_data.bias3_7 = data[counter];
    counter++;
    new_data.bias3_8 = data[counter];
    counter++;
    new_data.bias3_9 = data[counter];
    counter++;
    new_data.bias3_10 = data[counter];
    counter++;

    new_data.kernel3_11 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_12 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_13 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_14 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_15 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_16 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_17 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_18 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_19 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_20 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_21 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_22 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_23 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_24 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_25 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_26 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_27 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_28 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_29 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);
    new_data.kernel3_30 = append_data_to_vfloat2d(kernel_3_size,kernel_3_size,data,counter);

    new_data.bias3_11 = data[counter];
    counter++;
    new_data.bias3_12 = data[counter];
    counter++;
    new_data.bias3_13 = data[counter];
    counter++;
    new_data.bias3_14 = data[counter];
    counter++;
    new_data.bias3_15 = data[counter];
    counter++;
    new_data.bias3_16 = data[counter];
    counter++;
    new_data.bias3_17 = data[counter];
    counter++;
    new_data.bias3_18 = data[counter];
    counter++;
    new_data.bias3_19 = data[counter];
    counter++;
    new_data.bias3_20 = data[counter];
    counter++;

    new_data.weight4_1 = data[counter];
    counter++;
    new_data.weight4_2 = data[counter];
    counter++;
    new_data.weight4_3 = data[counter];
    counter++;
    new_data.weight4_4 = data[counter];
    counter++;
    new_data.weight4_5 = data[counter];
    counter++;
    new_data.weight4_6 = data[counter];
    counter++;
    new_data.weight4_7 = data[counter];
    counter++;
    new_data.weight4_8 = data[counter];
    counter++;
    new_data.weight4_9 = data[counter];
    counter++;
    new_data.weight4_10 = data[counter];
    counter++;
    new_data.weight4_11 = data[counter];
    counter++;
    new_data.weight4_12 = data[counter];
    counter++;
    new_data.weight4_13 = data[counter];
    counter++;
    new_data.weight4_14 = data[counter];
    counter++;
    new_data.weight4_15 = data[counter];
    counter++;
    new_data.weight4_16 = data[counter];
    counter++;
    new_data.weight4_17 = data[counter];
    counter++;
    new_data.weight4_18 = data[counter];
    counter++;
    new_data.weight4_19 = data[counter];
    counter++;
    new_data.weight4_20 = data[counter];
    counter++;

    new_data.bias4_1 = data[counter];
    counter++;
    new_data.bias4_2 = data[counter];
    counter++;
    new_data.bias4_3 = data[counter];
    counter++;
    new_data.bias4_4 = data[counter];
    counter++;
    new_data.bias4_5 = data[counter];
    counter++;
    new_data.bias4_6 = data[counter];
    counter++;
    new_data.bias4_7 = data[counter];
    counter++;
    new_data.bias4_8 = data[counter];
    counter++;
    new_data.bias4_9 = data[counter];
    counter++;
    new_data.bias4_10 = data[counter];
    counter++;
    new_data.bias4_11 = data[counter];
    counter++;
    new_data.bias4_12 = data[counter];
    counter++;
    new_data.bias4_13 = data[counter];
    counter++;
    new_data.bias4_14 = data[counter];
    counter++;
    new_data.bias4_15 = data[counter];
    counter++;
    new_data.bias4_16 = data[counter];
    counter++;
    new_data.bias4_17 = data[counter];
    counter++;
    new_data.bias4_18 = data[counter];
    counter++;
    new_data.bias4_19 = data[counter];
    counter++;
    new_data.bias4_20 = data[counter];
    counter++;

    new_data.bias5_1 = data[counter];
    counter++;
    new_data.bias5_2 = data[counter];
    counter++;
    new_data.bias5_3 = data[counter];
    counter++;
    new_data.bias5_4 = data[counter];
    counter++;
    new_data.bias5_5 = data[counter];
    counter++;
    new_data.bias5_6 = data[counter];
    counter++;
    new_data.bias5_7 = data[counter];
    counter++;
    new_data.bias5_8 = data[counter];
    counter++;
    new_data.bias5_9 = data[counter];
    counter++;
    new_data.bias5_10 = data[counter];
    counter++;
    new_data.bias5_11 = data[counter];
    counter++;
    new_data.bias5_12 = data[counter];
    counter++;
    new_data.bias5_13 = data[counter];
    counter++;
    new_data.bias5_14 = data[counter];
    counter++;
    new_data.bias5_15 = data[counter];
    counter++;
    new_data.bias5_16 = data[counter];
    counter++;
    new_data.bias5_17 = data[counter];
    counter++;
    new_data.bias5_18 = data[counter];
    counter++;
    new_data.bias5_19 = data[counter];
    counter++;
    new_data.bias5_20 = data[counter];
    counter++;

    int weight_5_height = 6;
    int weight_5_width = 7;

    new_data.weight5_1 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_2 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_3 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_4 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_5 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_6 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_7 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_8 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_9 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_10 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_11 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_12 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_13 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_14 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_15 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_16 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_17 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_18 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_19 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);
    new_data.weight5_20 = append_data_to_vfloat2d(weight_5_height,weight_5_width,data,counter);

    new_data.weight6_1 = data[counter];
    counter++;
    new_data.weight6_2 = data[counter];
    counter++;
    new_data.weight6_3 = data[counter];
    counter++;
    new_data.weight6_4 = data[counter];
    counter++;
    new_data.weight6_5 = data[counter];
    counter++;
    new_data.weight6_6 = data[counter];
    counter++;
    new_data.weight6_7 = data[counter];
    counter++;
    new_data.weight6_8 = data[counter];
    counter++;
    new_data.weight6_9 = data[counter];
    counter++;
    new_data.weight6_10 = data[counter];
    counter++;
    new_data.weight6_11 = data[counter];
    counter++;
    new_data.weight6_12 = data[counter];
    counter++;
    new_data.weight6_13 = data[counter];
    counter++;
    new_data.weight6_14 = data[counter];
    counter++;
    new_data.weight6_15 = data[counter];
    counter++;
    new_data.weight6_16 = data[counter];
    counter++;
    new_data.weight6_17 = data[counter];
    counter++;
    new_data.weight6_18 = data[counter];
    counter++;
    new_data.weight6_19 = data[counter];
    counter++;
    new_data.weight6_20 = data[counter];
    counter++;

    new_data.bias6_1 = data[counter];
    counter++;
    //qDebug()<<counter;

    return new_data;

}


void CNN::save_net(vfloat data, QString path_save) {

    QFile file(path_save);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    for(int i=0; i<data.size(); i++) {
        out<<QString::number(data[i])<<"|";
    }
    file.close();

}

vfloat CNN::load_net(QString path_load) {

    QStringList file = read_file(path_load);
    QString line = file.at(0);
    QStringList line_splitted = line.split("|");
    vfloat data;
    for(int i=0; i<line_splitted.size(); i++) {
        QString val = line_splitted.at(i);
        data.append(val.toFloat());
    }
    return data;

}

QStringList CNN::read_file(QString path) {
    QFile file(path);
    file.open(QIODevice::ReadOnly);
    QStringList StrList;
    while(!file.atEnd()) {
        StrList<<file.readLine();
    }
    file.close();
    return StrList;
}

vfloat2d CNN::open_image(QImage &image) {

    //qDebug()<<image.height();
    //qDebug()<<image.width();
    //exit(99);
    vfloat2d ret_val;
    ret_val.resize(image.height());
    for(int i=0; i<image.height(); i++) {
        ret_val[i].resize(image.width());
        for(int j=0; j<image.width(); j++) {
            QColor color = image.pixel(j,i);
            int r;
            color.getRgb(&r,&r,&r);

            float pix = (r/100)  - 1.275;
            //qDebug()<<pix;

            ret_val[i][j] = pix;

            /*if(image.pixel(j,i) == -1) {
                ret_val[i][j] = 0;
            } else {
                ret_val[i][j] = 1;
            }*/

        }
    }
    return ret_val;

}

QImage CNN::toGrayscale(QImage &img) {

    img = img.convertToFormat(QImage::Format_Indexed8);

    QVector<int> transform_table(img.numColors());

    for(int i=0; i<img.numColors() ;i++) {
        QRgb c1=img.color(i);
        int avg=qGray(c1);
        transform_table[i]=avg;
    }

    img.setNumColors(256);

    for(int i=0; i<256; i++) {
        img.setColor(i,qRgb(i,i,i));
    }

    for(int i=0; i<img.numBytes();i++) {
        img.bits()[i]=transform_table[img.bits()[i]];
    }

    return img;
}

QImage CNN::toNeuro(QImage &img, int height, int width) {

    img = toGrayscale(img);
    //img = img.convertToFormat(QImage::Format_MonoLSB, Qt::ThresholdDither);
    img = img.scaled(width,height);

    return img;

}

vfloat CNN::blx_a_crossover(vfloat &chromosome1, vfloat &chromosome2, float A) {
    if(chromosome1.size()!=chromosome2.size()) {
        qDebug()<<"Не совпадают размеры хромосом";
        exit(1);
    }

    vfloat new_chromosome(chromosome1.size());

    for(int i=0; i<new_chromosome.size(); i++) {
        float c_max = max(chromosome1[i],chromosome2[i]);
        float c_min = min(chromosome1[i],chromosome2[i]);
        float delta = c_max - c_min;
        float range_min = c_min - delta*A;
        float range_max = c_max + delta*A;
        new_chromosome[i] = random_float(range_min,range_max);
    }
    return new_chromosome;
}

float CNN::random_mutation(float value) {
    float range_min = value - value*0.2;
    float range_max = value + value*0.2;
    float ret_val = random_float(range_min,range_max);
    return ret_val;
}

vfloat2d CNN::population_mutation(vfloat2d &population, int chance) {


    for(int i=0; i<population.size(); i++) {
        int rand_val = rand_A_B(0,100-chance);
        if(rand_val == 0) {
            for(int j=0; j<population.at(i).size(); j++) {
                population[i][j] = random_mutation(population.at(i).at(j));
            }
        }
    }

    return population;

}

float CNN::rand_A_B(int A, int B) {
    return qrand()%(B-A+1)+A;
}

float CNN::fitness_neural(vfloat &output, vfloat &target) {
    if(output.size() != target.size()) {
        qDebug()<<"Несовпадение размеров выхода сети и требуемых выходов";
        exit(3);
    }
    vfloat sub = vfloat_sub(output,target);
    vfloat power = vfloat_pow(sub,2);
    float sum = vfloat_sum_elem(power);
    float fitness = sum/output.size();
    return fitness;
}

vfloat CNN::vfloat_sub(vfloat &vector1, vfloat &vector2) {
    if(vector1.size() != vector2.size()) {
        exit(9);
    }
    vfloat ret(vector1.size());
    for(int i=0; i<vector1.size(); i++) {
        ret[i] = vector1[i] - vector2[i];
    }
    return ret;
}

vfloat CNN::vfloat_pow(vfloat &vector, double power) {
    vfloat ret(vector.size());
    for(int i=0; i<vector.size(); i++) {
        ret[i] = pow(vector[i],power);
    }
    return ret;
}

float CNN::vfloat_sum_elem(vfloat &vector) {
    float sum;
    for(int i=0; i<vector.size(); i++) {
        sum = sum + vector[i];
    }
    return sum;
}

vfloat CNN::calculate_fitness(vfloat2d &outputs, vfloat &target) {
    vfloat ret_val;
    ret_val.resize(outputs.size());
    for(int i=0; i<outputs.size(); i++) {
        ret_val[i] = fitness_neural(outputs[i],target);
    }
    return ret_val;
}

vfloat2d CNN::tournament_selection(vfloat2d &population, vfloat &values) {
    int population_size = population.size();
    vfloat2d new_population;
    for(int i=0; i<population_size; i++) {
        int rand_ch1 = rand_A_B(0,population_size-1);
        int rand_ch2 = rand_A_B(0,population_size-1);
        if(values[rand_ch1] < values[rand_ch2]) {
            new_population.append(population[rand_ch1]);
        } else {
            new_population.append(population[rand_ch2]);
        }
    }

    return new_population;
}

vfloat2d CNN::random_blx(vfloat2d &population, double blx_koef) {
    int population_size = population.size();
    vfloat2d new_population;
    for(int i=0; i<population_size; i++) {
        int rand_ch1 = rand_A_B(0,population_size-1);
        int rand_ch2 = rand_A_B(0,population_size-1);
        new_population.append(blx_a_crossover(population[rand_ch1],population[rand_ch2],blx_koef));
    }
    return new_population;
}

int CNN::best_chromosome(vfloat2d &outputs, vfloat &target) {
    vfloat errors = calculate_fitness(outputs,target);
    float min = errors[0];
    int ret_val = 0;
    for(int i=0; i<errors.size(); i++) {
        if(errors[i]<=min) {
            ret_val = i;
        }
    }
    return ret_val;
}

cnn_data CNN::rga_train(list_vfloat2d &in, vfloat2d &target, vfloat2d &population, float rms_error, float blx_koef, int step, int max_step) {
    //qDebug()<<"train started";
    cnn_data ret_net;
    if(step<max_step) {
        float error = 0;
        vfloat all_errors(population.size());
        int best;

        for(int j=0; j<in.size(); j++) {
            //qDebug()<<"calc errors";
            vfloat2d outputs;
            for(int i=0; i<population.size(); i++) {
                cnn_data temp_net = vfloat_to_cnn_data(population[i]);

                float output = convolution_net(in[j],temp_net);

                //qDebug()<<"point";
                vfloat line;
                line.append(output);
                outputs.append(line);
            }
            //qDebug()<<"out end";
            best = best_chromosome(outputs,target[j]);
            //qDebug()<<"best end";
            //qDebug()<<outputs.at(best);

            vfloat errors = calculate_fitness(outputs,target[j]);
            //qDebug()<<"errors end";

            all_errors = vfloat_sum(all_errors,errors);
            error = error + vfloat_sum_elem(errors) / errors.size();

        }

        ret_net = vfloat_to_cnn_data(population[best]);
        if((step%10)==0) {
            save_net(population[best],QDir::currentPath() + "/NET.txt" + QString::number(step));

        }
        qDebug()<<"Error = "<<error<<"; On step: "<<step;

        if(error>rms_error) {

            vfloat2d new_population = tournament_selection(population,all_errors);//ТУРНИР
            //v2double new_population = neural_rga.roulette_wheel(population,errors);//РУЛЕТКА
            new_population = random_blx(new_population, blx_koef);
            new_population = population_mutation(new_population,20);
            step++;
            rga_train(in,target, new_population, rms_error, blx_koef,step,max_step);
        }
    }
    return ret_net;

}

vfloat CNN::vfloat_sum(vfloat &vector1, vfloat &vector2) {
    if(vector1.size() != vector2.size()) {
        exit(9);
    }
    vfloat ret(vector1.size());
    for(int i=0; i<vector1.size(); i++) {
        ret[i] = vector1[i] + vector2[i];
    }
    return ret;
}

float CNN::max(float a, float b) {
    if(a>b) {
        return a;
    } else {
        return b;
    }
}

float CNN::min(float a, float b) {
    if(a<b) {
        return a;
    } else {
        return b;
    }
}

cnn_data CNN::image_rga_train(QString faces_dir, QString no_faces_dir) {

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    float rms_error = 0.5;
    float blx_a_koef = 0.5;
    float rnd_start_range = -0.3;
    float rnd_end_range = 0.3;
    int populatin_size = 20;
    int chromosome_size = 1351;

    vfloat2d population;
    for(int i=0; i<populatin_size; i++) {
        vfloat chromosome(chromosome_size);
        for(int j=0; j<chromosome.size(); j++) {
            chromosome[j] = random_float(rnd_start_range,rnd_end_range);
        }
        population.append(chromosome);
    }

    list_vfloat2d faces_data = openFaces(faces_dir);

    vfloat2d faces_target;
    for(int i=0; i<faces_data.size(); i++) {
        vfloat target;
        //target.append(0.8);
        //target.append(0.2);
        target.append(1);
        faces_target.append(target);
    }

    list_vfloat2d no_faces_data = openFaces(no_faces_dir);

    vfloat2d no_faces_target;
    for(int i=0; i<no_faces_data.size(); i++) {
        vfloat target;
        //target.append(0.2);
        //target.append(0.8);
        target.append(-1);
        no_faces_target.append(target);
    }

    list_vfloat2d input_data;
    for(int i=0; i<faces_data.size(); i++) {
        input_data.append(faces_data.at(i));
    }
    for(int i=0; i<no_faces_data.size(); i++) {
        input_data.append(no_faces_data.at(i));
    }

    vfloat2d target_data;
    for(int i=0; i<faces_target.size(); i++) {
        target_data.append(faces_target.at(i));
    }
    for(int i=0; i<no_faces_target.size(); i++) {
        target_data.append(no_faces_target.at(i));
    }

    cnn_data net = rga_train(input_data,target_data,population,rms_error,blx_a_koef,0,300);

    return net;
}

list_vfloat2d CNN::openFaces(QString open_directory) {

    QDir dir(open_directory);
    QFileInfoList dirContent = dir.entryInfoList(QStringList() << "*.jpg", QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot);

    list_vfloat2d all_faces;

    for(int i=0; i<dirContent.length(); i++) {
        QImage face;
        face.load(dirContent.at(i).absoluteFilePath());

        face = toNeuro(face,32,36);

        vfloat2d one_face = open_image(face);

        all_faces.append(one_face);

    }
    qDebug()<<all_faces.size();

    return all_faces;
}

QPoint CNN::find_face(QImage &image, QString &path_net) {
    QPoint point;
    point.setX(0);
    point.setY(0);
    vfloat vfloat_data = load_net(path_net);
    cnn_data data = vfloat_to_cnn_data(vfloat_data);

    /*QImage image_old;
    image_old.load(image_path);*/


    //image = image.scaled(image.width()/6, image.height()/6);
    //image = skinFilter(image);
    //image = main_image.toNeuro(image,image.width(),image.height());

    int mask = 120;
   //image = image.scaled(image.height(),image.height());
   int step = 0;
   //while(mask <= image.width()) {

        for(int i=0; i<image.width()-mask; i=i+mask/4) {
            for(int j=0; j<image.height()-mask; j=j+mask/4) {

                QImage on_net = image.copy(i,j,mask,mask);
                on_net = toNeuro(on_net,32,36);
                //on_net = on_net.convertToFormat(QImage::Format_MonoLSB,Qt::ThresholdDither);
                //on_net = on_net.scaled(50,50);
                //on_net = nsf.my_filter(on_net);

                vfloat2d one_face = open_image(on_net);

                float output = QtConcurrent::run(convolution_net,one_face,data);
                //qDebug()<<output;
                //float output = -0.5;
                //if((out1[0]-out1[1])>0.15 && out1[0]>0.40 && out1[1]<0.35 && out1[1]>0.30 && out1[0]<0.50) {
                if(output>0.7) {
                    //qDebug()<<"I = "<<i<<";     J="<<j<<";      Out="<<output;

                    point.setX(i);
                    point.setY(j);

                    vfloat vfloat_data_2 = load_net(QDir::currentPath() + "/NET.txt100");
                    cnn_data data_2 = vfloat_to_cnn_data(vfloat_data_2);

                    vfloat2d one_face_2 = open_image(on_net);
                    float output_2 = QtConcurrent::run(convolution_net,one_face_2,data_2);
                    if(output_2>0.7) {
                        qDebug()<<"TRUE";
                    } else {
                        qDebug()<<"FALSE";
                    }


                    //QImage on_net_2 = image.copy(i,j,mask,mask);
                    //on_net.save(QDir::currentPath() + "/OK/out"+ QString::number(i) + QString::number(j) + "t" + QTime::currentTime().toString() + ".jpg");
                    //on_net_2.save(QDir::currentPath() + "/OK/outb"+ QString::number(i) + QString::number(j) +".jpg");
                    //qDebug()<<output;
                    return point;
                }
            }
        }
        //qDebug()<<"size = "<<image.width()<<" x "<<image.height();
        //image = image.scaled(image.width()*0.90, image.height()*0.90);
        //mask = mask * 1.2;
        //step = step+1;

    //}

   return point;

}
