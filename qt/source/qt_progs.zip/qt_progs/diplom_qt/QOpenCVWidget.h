
#ifndef QOPENCVWIDGET_H
#define QOPENCVWIDGET_H

#include <opencv/cv.h>
#include <QPixmap>
#include <QLabel>
#include <QWidget>
#include <QVBoxLayout>
#include <QImage>

class QOpenCVWidget : public QWidget {
    private:
        QLabel *imagelabel;
        QVBoxLayout *layout;
        
        QImage image;
        
    public:
        QOpenCVWidget(QWidget *parent = 0);
        ~QOpenCVWidget(void);
        void putImage(IplImage *);
        QImage drawRect(QImage &img, int width, int height, int length);
        bool isSkin(QColor color);
        QImage skinFilter(QImage image);
        int minRgb(int r, int g, int b);
        int maxRgb(int r, int g, int b);
        QImage toGrayscale(QImage img);
        QImage toSobel(QImage img);
}; 

#endif
