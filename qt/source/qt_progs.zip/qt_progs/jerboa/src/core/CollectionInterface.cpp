#include "CollectionInterface.h"

namespace Jerboa
{
	CollectionInterface::CollectionInterface(QObject* parent)
		:
			QObject(parent)
	{
	}

	CollectionInterface::~CollectionInterface()
	{
	}
}
