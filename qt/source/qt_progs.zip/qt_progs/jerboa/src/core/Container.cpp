#include "Container.h"

namespace Jerboa
{
	Container::Container(QObject* parent)
		:
			QObject(parent)
	{
	}

	Container::~Container()
	{
	}
}
