/****************************************************************************
** Meta object code from reading C++ file 'CameraDeviceDialog.h'
**
** Created: Sun Jun 14 15:12:50 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "src/Qt/UIs/CameraDeviceDialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CameraDeviceDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CameraDeviceDialog[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // signals: signature, parameters, type, tag, flags
      20,   19,   19,   19, 0x05,

 // slots: signature, parameters, type, tag, flags
      37,   19,   19,   19, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_CameraDeviceDialog[] = {
    "CameraDeviceDialog\0\0getValueSignal()\0"
    "OK_Button_Clicked()\0"
};

const QMetaObject CameraDeviceDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_CameraDeviceDialog,
      qt_meta_data_CameraDeviceDialog, 0 }
};

const QMetaObject *CameraDeviceDialog::metaObject() const
{
    return &staticMetaObject;
}

void *CameraDeviceDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CameraDeviceDialog))
        return static_cast<void*>(const_cast< CameraDeviceDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int CameraDeviceDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: getValueSignal(); break;
        case 1: OK_Button_Clicked(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void CameraDeviceDialog::getValueSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
