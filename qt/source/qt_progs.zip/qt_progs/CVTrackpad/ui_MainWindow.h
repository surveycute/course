/********************************************************************************
** Form generated from reading ui file 'MainWindow.ui'
**
** Created: Sun Jun 14 15:12:23 2009
**      by: Qt User Interface Compiler version 4.5.1
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSalir;
    QAction *actionAprender_Fondo;
    QAction *actionFuente;
    QAction *actionAprender_fondo;
    QAction *actionTest;
    QAction *actionPantalla_Virtual;
    QAction *actionAutom_tico;
    QAction *actionAprendido;
    QAction *actionAcerca_de_CVTrackpad;
    QWidget *centralWidget;
    QWidget *cameraContainer;
    QPushButton *exeButton;
    QPushButton *learningButton;
    QMenuBar *menuBar;
    QMenu *menuArchivo;
    QMenu *menuCamara;
    QMenu *menuCaptura;
    QMenu *menuB_squeda;
    QMenu *menuAyuda;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(647, 582);
        actionSalir = new QAction(MainWindow);
        actionSalir->setObjectName(QString::fromUtf8("actionSalir"));
        actionAprender_Fondo = new QAction(MainWindow);
        actionAprender_Fondo->setObjectName(QString::fromUtf8("actionAprender_Fondo"));
        actionFuente = new QAction(MainWindow);
        actionFuente->setObjectName(QString::fromUtf8("actionFuente"));
        actionAprender_fondo = new QAction(MainWindow);
        actionAprender_fondo->setObjectName(QString::fromUtf8("actionAprender_fondo"));
        actionTest = new QAction(MainWindow);
        actionTest->setObjectName(QString::fromUtf8("actionTest"));
        actionPantalla_Virtual = new QAction(MainWindow);
        actionPantalla_Virtual->setObjectName(QString::fromUtf8("actionPantalla_Virtual"));
        actionAutom_tico = new QAction(MainWindow);
        actionAutom_tico->setObjectName(QString::fromUtf8("actionAutom_tico"));
        actionAprendido = new QAction(MainWindow);
        actionAprendido->setObjectName(QString::fromUtf8("actionAprendido"));
        actionAcerca_de_CVTrackpad = new QAction(MainWindow);
        actionAcerca_de_CVTrackpad->setObjectName(QString::fromUtf8("actionAcerca_de_CVTrackpad"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralWidget->sizePolicy().hasHeightForWidth());
        centralWidget->setSizePolicy(sizePolicy);
        cameraContainer = new QWidget(centralWidget);
        cameraContainer->setObjectName(QString::fromUtf8("cameraContainer"));
        cameraContainer->setGeometry(QRect(0, 0, 640, 480));
        exeButton = new QPushButton(centralWidget);
        exeButton->setObjectName(QString::fromUtf8("exeButton"));
        exeButton->setGeometry(QRect(480, 490, 161, 31));
        learningButton = new QPushButton(centralWidget);
        learningButton->setObjectName(QString::fromUtf8("learningButton"));
        learningButton->setGeometry(QRect(320, 490, 151, 31));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 647, 23));
        menuArchivo = new QMenu(menuBar);
        menuArchivo->setObjectName(QString::fromUtf8("menuArchivo"));
        menuCamara = new QMenu(menuBar);
        menuCamara->setObjectName(QString::fromUtf8("menuCamara"));
        menuCaptura = new QMenu(menuBar);
        menuCaptura->setObjectName(QString::fromUtf8("menuCaptura"));
        menuB_squeda = new QMenu(menuCaptura);
        menuB_squeda->setObjectName(QString::fromUtf8("menuB_squeda"));
        menuAyuda = new QMenu(menuBar);
        menuAyuda->setObjectName(QString::fromUtf8("menuAyuda"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuArchivo->menuAction());
        menuBar->addAction(menuCamara->menuAction());
        menuBar->addAction(menuCaptura->menuAction());
        menuBar->addAction(menuAyuda->menuAction());
        menuArchivo->addAction(actionSalir);
        menuCamara->addAction(actionFuente);
        menuCaptura->addAction(actionAprender_fondo);
        menuCaptura->addAction(menuB_squeda->menuAction());
        menuCaptura->addAction(actionPantalla_Virtual);
        menuB_squeda->addAction(actionAutom_tico);
        menuB_squeda->addAction(actionAprendido);
        menuAyuda->addAction(actionAcerca_de_CVTrackpad);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        actionSalir->setText(QApplication::translate("MainWindow", "Exit", 0, QApplication::UnicodeUTF8));
        actionAprender_Fondo->setText(QApplication::translate("MainWindow", "Aprender Fondo", 0, QApplication::UnicodeUTF8));
        actionFuente->setText(QApplication::translate("MainWindow", "Source...", 0, QApplication::UnicodeUTF8));
        actionAprender_fondo->setText(QApplication::translate("MainWindow", "Learn Background", 0, QApplication::UnicodeUTF8));
        actionTest->setText(QApplication::translate("MainWindow", "Test", 0, QApplication::UnicodeUTF8));
        actionPantalla_Virtual->setText(QApplication::translate("MainWindow", "Set Virtual Screen", 0, QApplication::UnicodeUTF8));
        actionAutom_tico->setText(QApplication::translate("MainWindow", "Automatic", 0, QApplication::UnicodeUTF8));
        actionAprendido->setText(QApplication::translate("MainWindow", "Learned", 0, QApplication::UnicodeUTF8));
        actionAcerca_de_CVTrackpad->setText(QApplication::translate("MainWindow", "About CVTrackpad...", 0, QApplication::UnicodeUTF8));
        exeButton->setText(QApplication::translate("MainWindow", "Minimize", 0, QApplication::UnicodeUTF8));
        learningButton->setText(QApplication::translate("MainWindow", "Learn Backgroung", 0, QApplication::UnicodeUTF8));
        menuArchivo->setTitle(QApplication::translate("MainWindow", "File", 0, QApplication::UnicodeUTF8));
        menuCamara->setTitle(QApplication::translate("MainWindow", "Camera", 0, QApplication::UnicodeUTF8));
        menuCaptura->setTitle(QApplication::translate("MainWindow", "Capture", 0, QApplication::UnicodeUTF8));
        menuB_squeda->setTitle(QApplication::translate("MainWindow", "Tracking Method", 0, QApplication::UnicodeUTF8));
        menuAyuda->setTitle(QApplication::translate("MainWindow", "Help", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
