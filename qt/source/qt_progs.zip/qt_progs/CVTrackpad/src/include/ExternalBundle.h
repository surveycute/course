/*
 *  ExternalBundle.h
 *  CVTrackpad
 *
 *  Created by Endika Gutiérrez Salas on 05/03/09.
 *  Copyright 2009 Univerity of Deusto. All rights reserved.
 *
 */


#define GET_BUNDLE(name)                    \
{                                           \
            \
            \
    return name                             \
}
