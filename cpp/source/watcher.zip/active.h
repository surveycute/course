#if !defined ACTIVE_H
#define ACTIVE_H
//------------------------------------
//  (c) Reliable Software, 1997
//------------------------------------

#include "thread.h"
#include <windows.h>

class ActiveObject
{
public:
    ActiveObject ();
    virtual ~ActiveObject () {}
    void Kill ();

protected:
    virtual void InitThread () = 0;
    virtual void Loop () = 0;
    virtual void FlushThread () = 0;

    int             _isDying;

    static DWORD WINAPI ThreadEntry ( void *pArg);
    Thread          _thread;
};

#endif