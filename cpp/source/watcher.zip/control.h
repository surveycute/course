#if !defined CONTROL_H
#define CONTROL_H
//------------------------------------
//  (c) Reliable Software, 1997
//------------------------------------

#include <windows.h>
#include "FolderWatcher.h"

class Controller
{
public:
    Controller(HWND hwnd, CREATESTRUCT * pCreate);
    ~Controller ();
    BOOL    SysCommand (HWND hwnd, int sysCmd);
    void    OnFolderChange (HWND hwnd, char const *folder);

private:

    FolderWatcher _folderWatcher;

    HINSTANCE   _hInst;
};

#endif

