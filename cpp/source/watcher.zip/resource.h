//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Folder Watcher.rc
//
#define IDM_ABOUT                       101
#define IDI_LOGO                        110
#define IDC_ICON_GENERIC                1001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
