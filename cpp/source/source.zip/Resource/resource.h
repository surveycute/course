//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by fft.rc
//
#define DLG_MAIN                        106
#define DLG_ABOUT                       107
#define ICO_RS                          109
#define ICO_FFT                         110
#define ICO_CC                          111
#define IDC_BUTTON_START                1003
#define IDC_BUTTON_ABOUT                1004
#define IDC_RADIO_8_BITS                1005
#define IDC_RADIO_16_BITS               1006
#define IDC_COMBO_SAMPLING              1008
#define IDC_SCROLLBAR                   1012
#define IDC_EDIT_FFTS                   1013
#define IDC_COMBO_POINTS                1014
#define IDC_RADIO_MIKE                  1020
#define IDC_RADIO_FILE                  1021
#define IDC_RADIO_IMAGE                 1022
#define IDC_BUTTON_RELISOFT             1023
#define IDC_EDIT_FILE                   1024
#define IDC_BUTTON_FILE                 1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
