#if !defined DLGPROCEDURE_H
#define DLGPROCEDURE_H
//------------------------------------
//  Reliable Software, (c) 1996-2002
//------------------------------------
#include <windows.h>

BOOL CALLBACK DialogProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

#endif
