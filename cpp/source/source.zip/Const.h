#if !defined CONST_H
#define CONST_H
//------------------------------------
//  Reliable Software, (c) 1996-2002
//------------------------------------
#define IDB_START 101
#define IDB_STOP  102

#define IDS_FREQ_PANE   200
#define IDS_WAVE_PANE   201
#endif
