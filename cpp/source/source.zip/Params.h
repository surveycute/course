#if !defined PARAMS_H
#define PARAMS_H
//------------------------------------
//  Reliable Software, (c) 1996-2002
//------------------------------------
// defaults
const int FFT_POINTS = 256;
const int CHANNELS = 1;
const int MIN_SAMP_BUF = 64;

#endif