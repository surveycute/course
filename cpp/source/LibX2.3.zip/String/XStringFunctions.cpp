//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XStringFunctions.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include "XStringFunctions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
int strncmpi(const char* strA, const char* strB, unsigned long ulLen)
{
        #define strncmpi_ALPHABET_CAP_OFFSET  ((char) 32)
        //------------------
        for (unsigned long i = 0L;i < ulLen;++i)
                if (strA[i] != strB[i])
                {
                        if (strA[i] >= 'A' && strA[i] <= 'Z' && (strA[i] + strncmpi_ALPHABET_CAP_OFFSET) == strB[i])
                                continue;
                        else if (strB[i] >= 'A' && strB[i] <= 'Z' && (strB[i] + strncmpi_ALPHABET_CAP_OFFSET) == strA[i])
                                continue;
                        else
                                return 1;
                }
        //------------------
        return 0;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
