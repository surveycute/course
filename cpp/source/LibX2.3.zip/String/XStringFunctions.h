//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XStringFunctions.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XStringFunctionsH
#define XStringFunctionsH
//---------------------------------------------------------------------------
int strncmpi(const char* strA, const char* strB, unsigned long ulLen);
//---------------------------------------------------------------------------
#endif
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
