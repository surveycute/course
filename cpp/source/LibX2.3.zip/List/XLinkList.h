//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XLinkList.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XLinkListH
#define XLinkListH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Buffer/XBuffer.h>
//---------------------------------------------------------------------------
template <typename T>
class TXLinkList
{
protected:
	//---------------------
        unsigned long Count;
        TXBuffer List;
	//---------------------
public:
	//---------------------
        int ID; // For debugging
//---------------------------
        TXLinkList();
        ~TXLinkList();
	//---------------------
        unsigned long getCount() const;
        void Clear(bool bClean = false);
	//---------------------
        const T** getList() const;
        T** editList();
	//---------------------
        bool Add(T* pT);
        bool AddUnique(T* pT);
        bool Remove(T* pT); // returns removed object
        bool Delete(T* pT);
	//---------------------
};
//---------------------------------------------------------------------------
template <typename T>
inline TXLinkList<T>::TXLinkList()
{
	//------------------
        Count = 0L;
	//------------------
}
//---------------------------------------------------------------------------
template <typename T>
inline TXLinkList<T>::~TXLinkList()
{
	//------------------
        Clear(true);
	//------------------
}
//---------------------------------------------------------------------------
template <typename T>
inline void TXLinkList<T>::Clear(bool bClean /*= false*/)
{
	//------------------
        Count = 0L;
        List.Clear(bClean);
	//------------------
}
//---------------------------------------------------------------------------
template <typename T>
inline unsigned long TXLinkList<T>::getCount() const
{
	//------------------
        return Count;
}
//---------------------------------------------------------------------------
template <typename T>
inline const T** TXLinkList<T>::getList() const
{
	//------------------
        return (const T**)List.getData();
}
//---------------------------------------------------------------------------
template <typename T>
inline T** TXLinkList<T>::editList()
{
	//------------------
        return (T**)List.editData();
}
//---------------------------------------------------------------------------
template <typename T>
inline bool TXLinkList<T>::Add(T* pT)
{
	//------------------
        if (!List.Append((unsigned char*)&pT, sizeof(T*)))
                return false;
	//------------------
        ++Count;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
template <typename T>
inline bool TXLinkList<T>::AddUnique(T* pT)
{
        T** pList = (T**)List.editData();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pT == pList[i])
                        return true;
	//------------------
        if (!List.Append((unsigned char*)&pT, sizeof(T*)))
                return false;
	//------------------
        ++Count;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
template <typename T>
inline bool TXLinkList<T>::Remove(T* pT)
{
        T** pList = (T**)List.editData();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pT == pList[i])
                {
                        for (++i;i < Count;++i)
                                pList[i-1] = pList[i];
                        --Count;
                        if (!List.lessSize(sizeof(T*)))
                                return false;
                        return true;
                }
	//------------------
        return false;
}
//---------------------------------------------------------------------------
template <typename T>
inline bool TXLinkList<T>::Delete(T* pT)
{
	//------------------
        if (!Remove(pT))
                return false;
	//------------------
        delete pT;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
 
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
