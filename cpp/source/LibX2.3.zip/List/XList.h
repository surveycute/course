//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XList.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XListH
#define XListH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Buffer/XBuffer.h>
//---------------------------------------------------------------------------
template <typename T>
class TXList
{
protected:
	//---------------------
        unsigned long Count;
        TXBuffer List;
	//---------------------
public:
	//---------------------
        int ID; // For debugging
//---------------------------
        TXList();
        ~TXList();
	//---------------------
        unsigned long getCount() const;
        void Clear(bool bClean = false);
	//---------------------
        const T* getList() const;
        T* editList();
	//---------------------
        T* Add(T* pT = (T*)0); // List takes care of further memory management, ie delete'ing
        bool Remove(T* pT); // returns removed object
        bool Delete(T* pT);
	//---------------------
};
//---------------------------------------------------------------------------
template <typename T>
inline TXList<T>::TXList()
{
	//------------------
        Count = 0L;
        ID = 0;
	//------------------
}
//---------------------------------------------------------------------------
template <typename T>
inline TXList<T>::~TXList()
{
	//------------------
        Clear(true);
	//------------------
}
//---------------------------------------------------------------------------
template <typename T>
inline void TXList<T>::Clear(bool bClean /*= false*/)
{
        T** pList = (T**)List.editData();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pList[i]) {delete pList[i];pList[i] = (T*)0;}
	//------------------
        Count = 0L;
        List.Clear(bClean);
	//------------------
}
//---------------------------------------------------------------------------
template <typename T>
inline unsigned long TXList<T>::getCount() const
{
	//------------------
        return Count;
}
//---------------------------------------------------------------------------
template <typename T>
inline const T* TXList<T>::getList() const
{
	//------------------
        return (const T*)List.getData();
}
//---------------------------------------------------------------------------
template <typename T>
inline T* TXList<T>::editList()
{
	//------------------
        return (T*)List.editData();
}
//---------------------------------------------------------------------------
template <typename T>
inline T* TXList<T>::Add(T* pT /*= NULL*/)
{
	//------------------
        if (!pT)
        {
                pT = new T();
                if (!pT)
                        return (T*)0;
        }
	//------------------
        if (!List.Append((unsigned char*)&pT, sizeof(T*)))
        {
                delete pT;
                return (T*)0;
        }
	//------------------
        ++Count;
	//------------------
        return pT;
}
//---------------------------------------------------------------------------
template <typename T>
inline bool TXList<T>::Remove(T* pT)
{
        T** pList = (T**)List.editData();
        unsigned long  i;
	//------------------
        for (i = 0L;i < Count;++i)
                if (pT == pList[i])
                {
                        for (++i;i < Count;++i)
                                pList[i-1] = pList[i];
                        --Count;
                        if (!List.lessSize(sizeof(T*)))
                                return false;
                        return true;
                }
	//------------------
        return false;
}
//---------------------------------------------------------------------------
template <typename T>
inline bool TXList<T>::Delete(T* pT)
{
	//------------------
        if (!Remove(pT))
                return false;
	//------------------
        delete pT;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
