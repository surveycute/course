//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXSound.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./DirectX/DSound/XDXSound.h>
//---------------------------------------------------------------------------
TXDXSound::TXDXSound()
{
    //------------------
    m_Initted = false;
    m_WindowHandle = NULL;
    m_OptionMask = 0L;
	DSound = NULL;
    //------------------
}
//---------------------------------------------------------------------------
TXDXSound::~TXDXSound()
{
    //------------------
    Release(); // ignore failure
    //------------------
}
//---------------------------------------------------------------------------
bool TXDXSound::Init(HWND hwndWindowHandle, unsigned long ulOptionsMask /*= DSSCL_EXCLUSIVE*/)
{
    //------------------
	hr = DirectSoundCreate(NULL, &DSound, NULL);
		if (hr != DS_OK || !DSound) {XDebug("TDXDSound::Init - DirectSoundCreate failed");return false;}
    //------------------
	hr = DSound->SetCooperativeLevel(hwndWindowHandle, ulOptionsMask);
		if (hr != DS_OK) {XDebug("TDXDSound::Init - SetCooperativeLevel failed");return false;}
    //------------------
	m_WindowHandle = hwndWindowHandle;
	m_OptionMask = ulOptionsMask;
    m_Initted = true;
    //------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXDXSound::Release()
{
    //------------------
	hr = DS_OK;
    m_Initted = false;
    m_WindowHandle = NULL;
    m_OptionMask = 0L;
    //------------------
    if (DSound) {DSound->Release();DSound = NULL;}
    //------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXDXSound::isInitted() const
{
    //------------------
    return m_Initted;
}
//---------------------------------------------------------------------------
HWND TXDXSound::getWindowHanlde() const
{
    //------------------
    return m_WindowHandle;
}
//---------------------------------------------------------------------------
unsigned long TXDXSound::getOptionMask() const
{
    //------------------
    return m_OptionMask;
}
//---------------------------------------------------------------------------
const char* TXDXSound::getErrorString(HRESULT hrErrorCode) const
{
	const char* rStr;
    //------------------
	switch (hrErrorCode)
	{
		case DSERR_ALLOCATED:			rStr = "DSERR_ALLOCATED";		break; 
		case DSERR_BADFORMAT:			rStr = "DSERR_BADFORMAT";		break; 
		case DSERR_BUFFERTOOSMALL:		rStr = "DSERR_BUFFERTOOSMALL";	break; 
		case DSERR_CONTROLUNAVAIL:		rStr = "DSERR_CONTROLUNAVAIL";	break; 
		case DSERR_DS8_REQUIRED:		rStr = "DSERR_DS8_REQUIRED";	break; 
		case DSERR_INVALIDCALL:			rStr = "DSERR_INVALIDCALL";		break; 
		case DSERR_INVALIDPARAM:		rStr = "DSERR_INVALIDPARAM";	break; 
		case DSERR_NOAGGREGATION:		rStr = "DSERR_NOAGGREGATION";	break; 
		case DSERR_OUTOFMEMORY:			rStr = "DSERR_OUTOFMEMORY";		break; 
		case DSERR_UNINITIALIZED:		rStr = "DSERR_UNINITIALIZED";	break; 
		case DSERR_UNSUPPORTED:			rStr = "DSERR_UNSUPPORTED";		break; 
		case DS_OK:						rStr = "OK";					break;
		default:						rStr = "Unknown";				break; 
	} // switch (hrErrorCode)
    //------------------
    return rStr;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
