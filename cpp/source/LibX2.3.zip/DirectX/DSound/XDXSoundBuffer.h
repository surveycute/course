//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXSoundBuffer.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XDXSoundBufferH
#define XDXSoundBufferH
//---------------------------------------------------------------------------
#include <windows.h>
#include <mmsystem.h>
#include <DSound.h>
//---------------------------------------------------------------------------
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
class TXDXSoundBuffer
{
public:
	//---------------------
    HRESULT hr; // reused result (public for debugging)
	LPDIRECTSOUNDBUFFER  Buffer;
	//---------------------
//---------------------------
	TXDXSoundBuffer();
	virtual ~TXDXSoundBuffer();
	//---------------------
	// DSBCAPS_CTRLFREQUENCY | DSBCAPS_CTRLPAN | DSBCAPS_CTRLVOLUME |  DSBCAPS_STATIC | DSBCAPS_LOCSOFTWARE
	bool Create(LPDIRECTSOUND DSound, unsigned long ulSize, unsigned long ulOptionsMask = 0L);// m_WaveFormatEx must be set!
	bool CreateFromWaveFile(LPDIRECTSOUND DSound, const char* strFileName, unsigned long ulOptionsMask = 0L);
	bool Release();
    bool isCreated() const;
	//---------------------
    const DSBUFFERDESC& getBufferDesc() const;
	const WAVEFORMATEX& getWaveFormatEx() const;
	//---------------------
    unsigned long getOptionMask() const;
	//---------------------
	bool Lock(void** pPtrA = NULL, unsigned long* pulLenA = NULL, void** pPtrB = NULL, unsigned long* pulLenB = NULL, unsigned long ulOptionsMask = DSBLOCK_FROMWRITECURSOR);
	bool Unlock();
	bool isLocked() const;
	bool getLock(void** pPtrA, unsigned long* pulLenA, void** pPtrB, unsigned long* pulLenB) const;
	//---------------------
private:
	//---------------------
	bool m_Initted;
	DSBUFFERDESC m_BufferDesc;
	WAVEFORMATEX m_WaveFormatEx;
	//---------------------
	void** m_LockPtrA;
	unsigned long m_LockLenA;
	void** m_LockPtrB;
	unsigned long m_LockLenB;
//---------------------------
	//---------------------
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XDXSoundBufferH
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
