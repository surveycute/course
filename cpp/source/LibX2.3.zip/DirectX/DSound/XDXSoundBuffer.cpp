//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXSoundBuffer.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./DirectX/DSound/XDXSoundBuffer.h>
//---------------------------------------------------------------------------
TXDXSoundBuffer::TXDXSoundBuffer()
{
    //------------------
	Buffer = NULL;
    memset(&m_BufferDesc, 0, sizeof(m_BufferDesc));
	memset(&m_WaveFormatEx, 0, sizeof(m_WaveFormatEx));
	m_LockPtrA = m_LockPtrB = NULL;
	m_LockLenA = m_LockLenB = 0L;
    //------------------
}
//---------------------------------------------------------------------------
TXDXSoundBuffer::~TXDXSoundBuffer()
{
    //------------------
    Release(); // ignore failure
    //------------------
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::Create(LPDIRECTSOUND DSound, unsigned long ulSize, unsigned long ulOptionsMask /*= DSSCL_EXCLUSIVE*/)
{
    //------------------
	if (!DSound)
		{XDebug("TXDXSoundBuffer::Create - Validate DSound failed");return false;}
    //------------------
	if (Buffer)
		{XDebug("TXDXSoundBuffer::Create - Buffer already created");return false;}
    //------------------
	if (ulSize < DSBSIZE_MIN || ulSize > DSBSIZE_MAX)
		{XDebug("TXDXSoundBuffer::Create - Validate size failed");return false;}
    //------------------
    memset(&m_BufferDesc, 0, sizeof(m_BufferDesc));
	m_BufferDesc.dwSize = sizeof(DSBUFFERDESC);
	m_BufferDesc.dwFlags = ulOptionsMask;
	m_BufferDesc.dwBufferBytes = ulSize;
	m_BufferDesc.lpwfxFormat = &m_WaveFormatEx;
    //------------------
	hr = DSound->CreateSoundBuffer(&m_BufferDesc, &Buffer, NULL);
		if (hr != DS_OK || !Buffer) {XDebug("TXDXSoundBuffer::Init - DSound->CreateSoundBuffer failed");return false;}
    //------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::Release()
{
	bool r = true;
	//------------------
	hr = DS_OK;
    //------------------
	if (isLocked())
		if (!Unlock())
			r = false;
    //------------------
	m_LockPtrA = m_LockPtrB = NULL;
	m_LockLenA = m_LockLenB = 0L;
    //------------------
    memset(&m_BufferDesc, 0, sizeof(m_BufferDesc));
	memset(&m_WaveFormatEx, 0, sizeof(m_WaveFormatEx));
    //------------------
    if (Buffer) {Buffer->Release();Buffer = NULL;}
    //------------------
	return r;
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::isCreated() const
{
    //------------------
    return (Buffer != NULL);
}
//---------------------------------------------------------------------------
const DSBUFFERDESC& TXDXSoundBuffer::getBufferDesc() const
{
    //------------------
    return m_BufferDesc;
}
//---------------------------------------------------------------------------
const WAVEFORMATEX& TXDXSoundBuffer::getWaveFormatEx() const
{
    //------------------
    return m_WaveFormatEx;
}
//---------------------------------------------------------------------------
unsigned long TXDXSoundBuffer::getOptionMask() const
{
    //------------------
    return m_BufferDesc.dwFlags;
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::Lock(void** pPtrA /*= NULL*/, unsigned long* pulLenA /*= NULL*/, void** pPtrB /*= NULL*/, unsigned long* pulLenB /*= NULL*/, unsigned long ulOptionsMask /*= DSBLOCK_FROMWRITECURSOR*/)
{
    //------------------
	if (!Buffer)
		{XDebug("TXDXSoundBuffer::Lock - Validate buffer failed");return false;}
    //------------------
	if (isLocked())
		{XDebug("TXDXSoundBuffer::Lock - Buffer already locked");return false;}
    //------------------
	hr = Buffer->Lock(0, m_BufferDesc.dwBufferBytes, (void**)&m_LockPtrA, &m_LockLenA, (void**)&m_LockPtrB, &m_LockLenB, ulOptionsMask);
		if (hr != DS_OK) {m_LockPtrA = m_LockPtrB = NULL;XDebug("TXDXSoundBuffer::Lock - Buffer->Lock failed");return false;}
    //------------------
	if (pPtrA)		*pPtrA = m_LockPtrA;
	if (pPtrB)		*pPtrB = m_LockPtrB;
	if (pulLenA)	*pulLenA = m_LockLenA;
	if (pulLenB)	*pulLenB = m_LockLenB;
    //------------------
    return true;
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::Unlock()
{
	bool r = true;
    //------------------
	if (!Buffer)
		{XDebug("TXDXSoundBuffer::Unlock - Validate buffer failed");return false;}
    //------------------
	if (!isLocked())
		{XDebug("TXDXSoundBuffer::Unlock - Buffer not locked");return false;}
    //------------------
	hr = Buffer->Unlock(m_LockPtrA, m_LockLenA, m_LockPtrB, m_LockLenB);
		if (hr != DS_OK) {XDebug("TXDXSoundBuffer::Unlock - Buffer->Unlock failed");r = false;}
    //------------------
	m_LockPtrA = m_LockPtrB = NULL;
	m_LockLenA = m_LockLenB = 0L;
    //------------------
    return r;
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::isLocked() const
{
    //------------------
    return (m_LockPtrA != NULL || m_LockPtrA != NULL);
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::getLock(void** pPtrA /*= NULL*/, unsigned long* pulLenA /*= NULL*/, void** pPtrB /*= NULL*/, unsigned long* pulLenB /*= NULL*/) const
{
    //------------------
	if (!Buffer)
		{XDebug("TXDXSoundBuffer::getLock - Validate buffer failed");return false;}
    //------------------
	if (pPtrA)		*pPtrA = m_LockPtrA;
	if (pPtrB)		*pPtrB = m_LockPtrB;
	if (pulLenA)	*pulLenA = m_LockLenA;
	if (pulLenB)	*pulLenB = m_LockLenB;
    //------------------
    return true;
}
//---------------------------------------------------------------------------
bool TXDXSoundBuffer::CreateFromWaveFile(LPDIRECTSOUND DSound, const char* strFileName, unsigned long ulOptionsMask /*= 0L*/)
{
	MMRESULT mr;
	HMMIO hFile;
	MMCKINFO Child, Parent;
    //------------------
	memset(&m_WaveFormatEx, 0, sizeof(m_WaveFormatEx));
	memset(&Child,  0, sizeof(MMCKINFO));
	memset(&Parent, 0, sizeof(MMCKINFO));
	//------------------
	if (!DSound)
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - Validate DSound failed"); return false;}
	//------------------
	if (Buffer)
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - Buffer already created");return false;}
    //------------------
	if (!strFileName)
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - Validate file name string failed"); return false;}
	//------------------
	hFile = mmioOpen((LPSTR)strFileName, NULL, MMIO_READ | MMIO_ALLOCBUF);
		if (hFile == NULL) {XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioOpen Wave failed"); return false;}
	//------------------
	Parent.fccType = mmioFOURCC('W','A','V','E');
	//------------------
	mr = mmioDescend(hFile, &Parent, NULL, MMIO_FINDRIFF);
		if (mr) {XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioDescend 1 failed");mmioClose(hFile, 0);return false;}
	//------------------
	Child.ckid = mmioFOURCC('f','m','t',' ');
	//------------------
	mr = mmioDescend(hFile, &Child, &Parent, 0);
		if (mr){XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioDescend 2 failed");mmioClose(hFile, 0);return false;}
	//------------------
	if (mmioRead(hFile, (char *)&m_WaveFormatEx, sizeof(WAVEFORMATEX)) != sizeof(WAVEFORMATEX))
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioRead WaveFormatEx failed");mmioClose(hFile, 0);return false;}
	//------------------
   if (m_WaveFormatEx.wFormatTag != WAVE_FORMAT_PCM)
       {XDebug("TXDXSoundBuffer::CreateFromWaveFile - Validate PCM Wave Format failed");mmioClose(hFile,0);return FALSE;}
	//------------------
	mr = mmioAscend(hFile, &Child, 0);
		if (mr){XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioAscend Failed");mmioClose(hFile, 0);return false;}
	//------------------
	Child.ckid = mmioFOURCC('d','a','t','a');
	//------------------
	mr = mmioDescend(hFile, &Child, &Parent, MMIO_FINDCHUNK);
		if (mr){XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioDescend 3 Failed");mmioClose(hFile, 0);return false;}
	//------------------
	if (!Create(DSound, Child.cksize, ulOptionsMask))
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - Create failed");mmioClose(hFile, 0);return false;}
	//------------------
	if (!Lock())
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - Lock failed");mmioClose(hFile, 0);return false;}
	//------------------
	if (mmioRead(hFile, (char*)m_LockPtrA, m_LockLenA) != Child.cksize)
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioRead Data A failed");mmioClose(hFile, 0);return false;}
	//------------------
	if (m_LockLenB)
		if (mmioRead(hFile, (char*)m_LockPtrB, m_LockLenB) != Child.cksize)
		{
			mmioClose(hFile, 0);
			if (!Unlock())
				XDebug("TXDXSoundBuffer::CreateFromWaveFile - Unlock failed");
			XDebug("TXDXSoundBuffer::CreateFromWaveFile - mmioRead Data B failed");
			return false;
		}
	//------------------
	mmioClose(hFile, 0);    
	//------------------
	if (!Unlock())
		{XDebug("TXDXSoundBuffer::CreateFromWaveFile - Unlock failed");return false;}
	//------------------
	return true;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
