//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXSound.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XDXSoundH
#define XDXSoundH
//---------------------------------------------------------------------------
#include <windows.h>
#include <mmsystem.h>
#include <DSound.h>
//---------------------------------------------------------------------------
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
class TXDXSound
{
public:
	//---------------------
    HRESULT hr; // reused result (public for debugging)
	LPDIRECTSOUND   DSound;
	//---------------------
//---------------------------
	TXDXSound();
	virtual ~TXDXSound();
	//---------------------
	// DSSCL_EXCLUSIVE | DSSCL_NORMAL | DSSCL_PRIORITY | DSSCL_WRITEPRIMARY
	bool Init(HWND hwndWindowHandle, unsigned long ulOptionsMask = DSSCL_EXCLUSIVE);
	bool Release();
    bool isInitted() const;
	//---------------------
    HWND getWindowHanlde() const;
    unsigned long getOptionMask() const;
	const char* getErrorString(HRESULT hrErrorCode) const;
	//---------------------
private:
	//---------------------
	bool m_Initted;
	HWND m_WindowHandle;
    unsigned long m_OptionMask;
//---------------------------
	//---------------------
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XDXSoundH
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
