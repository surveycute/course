//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXKeyboard.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XDXKeyboardH
#define XDXKeyboardH
//---------------------------------------------------------------------------
#include <dinput.h>
//---------------------------------------------------------------------------
#include <./DirectX/DInput/XDXInputDevice.h>
//---------------------------------------------------------------------------
class TXDXKeyboard : public TXDXInputDevice
{
public:
	//---------------------
	unsigned char Inkey[256]; // Named in honor of $Inkey in QBasic 1.0
	//---------------------
//---------------------------
	TXDXKeyboard();
	virtual ~TXDXKeyboard();
	//---------------------
	bool isKey(unsigned char dikKey); // reads from last state
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XDXKeyboardH
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
