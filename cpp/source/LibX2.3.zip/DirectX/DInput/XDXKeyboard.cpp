//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXKeyboard.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <windows.h>
#pragma hdrstop
#include <./DirectX/DInput/XDXKeyboard.h>
//---------------------------------------------------------------------------
TXDXKeyboard::TXDXKeyboard() : TXDXInputDevice(GUID_SysKeyboard, &c_dfDIKeyboard)
{
        //------------------
		ulSizeState = sizeof(unsigned char[256]);
		pState = (void*)Inkey;
        //------------------
}
//---------------------------------------------------------------------------
/*virtual*/ TXDXKeyboard::~TXDXKeyboard()
{
        //------------------
        //------------------
}
//---------------------------------------------------------------------------
bool TXDXKeyboard::isKey(unsigned char dikKey)
{
        //------------------
		return ((Inkey[dikKey] & 0x80) != 0);
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
