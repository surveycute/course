//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXMouse.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <windows.h>
#pragma hdrstop
#include <./DirectX/DInput/XDXMouse.h>
//---------------------------------------------------------------------------
TXDXMouse::TXDXMouse() : TXDXInputDevice(GUID_SysKeyboard, &c_dfDIMouse)
{
        //------------------
		ulSizeState = sizeof(DIMOUSESTATE);
		pState = &State;
        //------------------
}
//---------------------------------------------------------------------------
/*virtual*/ TXDXMouse::~TXDXMouse()
{
        //------------------
        //------------------
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
