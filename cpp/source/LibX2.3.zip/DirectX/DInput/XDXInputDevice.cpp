//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXInputDevice.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <windows.h>
#pragma hdrstop
#include <./DirectX/DInput/XDXInputDevice.h>
//---------------------------------------------------------------------------
TXDXInputDevice::TXDXInputDevice(REFGUID rDeviceGuid, LPCDIDATAFORMAT pDataFormat)
{
        //------------------
		m_pDeviceGuid = &rDeviceGuid;
		m_pDataFormat = pDataFormat;
        //------------------
		hr = DI_OK;
		Device = NULL;
		m_OptionMask = 0L;
		m_Acquired = false;
		//------------------
		pState = NULL;
		ulSizeState = 0L;
		//------------------
}
//---------------------------------------------------------------------------
/*virtual*/ TXDXInputDevice::~TXDXInputDevice()
{
        //------------------
		Release();
        //------------------
}
//---------------------------------------------------------------------------
bool TXDXInputDevice::Create(LPDIRECTINPUT8 DInput, HWND hWnd, unsigned long ulOptionsMask)
{
        //------------------
		if (!DInput)
			{XDebug("TXDXInputDevice::Create - Validate DInput failed");return false;}
        //------------------
		if (Device)
			{XDebug("TXDXInputDevice::Create - Device already created");return false;}
        //------------------
		if (!m_pDataFormat || !m_pDeviceGuid)
			{XDebug("TXDXInputDevice::Create - Validate Format and DeviceGuid failed");return false;}
        //------------------
		hr = DInput->CreateDevice(*m_pDeviceGuid, &Device, NULL);
			if (hr != DI_OK) {XDebug("TXDXInputDevice::Create - DInput->CreateDevice failed");return false;}
		hr = Device->SetCooperativeLevel(hWnd, ulOptionsMask);
			if (hr != DI_OK) {XDebug("TXDXInputDevice::Create - Device->SetCooperativeLevel failed");return false;}
		hr = Device->SetDataFormat(m_pDataFormat);
			if (hr != DI_OK) {XDebug("TXDXInputDevice::Create - Device->SetDataFormat failed");return false;}
		//------------------
		m_OptionMask = ulOptionsMask;
		//------------------
		return true;
}
//---------------------------------------------------------------------------
bool TXDXInputDevice::Release()
{
        //------------------
		hr = DI_OK;
		m_OptionMask = 0L;
        //------------------
		Unacquire(); // ignore failure
        //------------------
		if (Device) 
			{Device->Release();Device = NULL;}
        //------------------
		return true;
}
//---------------------------------------------------------------------------
bool TXDXInputDevice::Acquire()
{
        //------------------
		if (!Device)
				return false;
        //------------------
		hr = Device->Acquire();
			if (hr != DI_OK) return false;
        //------------------
		m_Acquired = true;
        //------------------
		return true;
}
//---------------------------------------------------------------------------
bool TXDXInputDevice::Unacquire()
{
        //------------------
		if (!Device)
				return false;
        //------------------
		hr = Device->Unacquire();
			if (hr != DI_OK) return false;
        //------------------
		m_Acquired = false;
        //------------------
		return true;
}
//---------------------------------------------------------------------------
unsigned long TXDXInputDevice::getOptionMask() const
{
        //------------------
		return m_OptionMask;
}
//---------------------------------------------------------------------------
bool TXDXInputDevice::isAcquired() const
{
        //------------------
		return m_Acquired;
}
//---------------------------------------------------------------------------
bool TXDXInputDevice::Poll()
{
        //------------------
		if (!pState || !ulSizeState)
				return false;
        //------------------
		hr = Device->GetDeviceState(ulSizeState, pState);
		if (hr != DI_OK)
		{
			int TrapPreventor = 0;
	        //------------------
			while (hr == DIERR_INPUTLOST || hr == DIERR_NOTACQUIRED)
			{
		        //------------------
				if (!Acquire())
					return false;
		        //------------------
				hr = Device->GetDeviceState(ulSizeState, pState);
		        //------------------
				if (TrapPreventor++ > 100) 
					return false;
		        //------------------
			}
	        //------------------
			if (hr != DI_OK)
				return false;
	        //------------------
		}
        //------------------
		return true;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
