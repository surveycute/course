//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXInputDevice.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XDXInputDeviceH
#define XDXInputDeviceH
//---------------------------------------------------------------------------
#include <dinput.h>
//---------------------------------------------------------------------------
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
class TXDXInputDevice
{
public:
	//---------------------
	HRESULT hr;
	LPDIRECTINPUTDEVICE8 Device;
	void* pState;
	unsigned long ulSizeState;
	//---------------------
//---------------------------
	TXDXInputDevice(REFGUID rDeviceGuid, LPCDIDATAFORMAT pDataFormat);
	virtual ~TXDXInputDevice();
	//---------------------
	bool Create(LPDIRECTINPUT8 DInput, HWND hWnd, unsigned long ulOptionsMask);
	bool Release();
	//---------------------
	bool Acquire();
	bool Unacquire();
	//---------------------
	unsigned long getOptionMask() const;
	bool isAcquired() const;
	//---------------------
	bool Poll();
	//---------------------
private:
	//---------------------
    unsigned long m_OptionMask;
	bool m_Acquired;
	//--------------------- Defined by derived class
	LPCDIDATAFORMAT m_pDataFormat;
	LPCGUID m_pDeviceGuid;
	//---------------------
//---------------------------
	//---------------------
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XDXMouseH
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
