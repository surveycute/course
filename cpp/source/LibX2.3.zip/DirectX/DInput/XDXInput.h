//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXInput.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XDXInputH
#define XDXInputH
//---------------------------------------------------------------------------
#include <dinput.h>
//---------------------------------------------------------------------------
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
class TXDXInput
{
public:
	//---------------------
    HRESULT hr; // reused result (public for debugging)
	LPDIRECTINPUT8 DInput;	
	//---------------------
//---------------------------
	TXDXInput();
	virtual ~TXDXInput();
	//---------------------
	bool Init(HINSTANCE hInstance);
	bool Release();
    bool isInitted() const;
	//---------------------
	const char* getErrorString(HRESULT hrErrorCode) const;
	//---------------------
private:
	//---------------------
	bool m_Initted;
    HINSTANCE m_hInstance;
	//---------------------
//---------------------------
	//---------------------
	//---------------------
}; // TXDXInput
//---------------------------------------------------------------------------
#endif // XDXInputH
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
