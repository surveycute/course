//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXInput.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#define INITGUID
#include <windows.h>
#pragma hdrstop
#include <./DirectX/DInput/XDXInput.h>
//---------------------------------------------------------------------------
TXDXInput::TXDXInput()
{
	//------------------
	hr = DI_OK;
	m_hInstance = NULL;
	m_Initted = false;
	DInput = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXDXInput::~TXDXInput()
{
	//------------------
	Release();
	//------------------
}
//---------------------------------------------------------------------------
bool TXDXInput::Init(HINSTANCE hInstance)
{
	//------------------
	if (m_Initted)
		return false; // already initted
	//------------------
	hr = DirectInput8Create(hInstance, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&DInput, NULL);
		if (hr != DI_OK) return false;
	//------------------
	m_hInstance = hInstance;
	m_Initted = true;
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXDXInput::Release()
{
	//------------------
	hr = DI_OK;
	m_hInstance = NULL;
	m_Initted = false;
	//------------------
	if (DInput) {DInput->Release();DInput = NULL;}
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXDXInput::isInitted() const
{
	//------------------
	return m_Initted;
}
//---------------------------------------------------------------------------
const char* TXDXInput::getErrorString(HRESULT hrErrorCode) const
{
	const char* rStr;
    //------------------
	switch (hrErrorCode)
	{
        case DIERR_DEVICENOTREG:        rStr = "Input Device not registered";             break;
        case DIERR_INVALIDPARAM:        rStr = "Invalid params";                          break;
        case DIERR_NOINTERFACE:         rStr = "Interface not valid";                     break;
        case DIERR_NOTINITIALIZED:      rStr = "Direct input not initialized";            break;
        case DIERR_OUTOFMEMORY:         rStr = "Out of memory";                           break;
		case DI_OK:						rStr = "OK";					break;
		default:						rStr = "Unknown";				break; 
	} // switch (hrErrorCode)
    //------------------
    return rStr;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
