//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXDraw.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XDXDrawH
#define XDXDrawH
//---------------------------------------------------------------------------
#include <ddraw.h>
//---------------------------------------------------------------------------
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
class TXDXDraw
{
public:
	//---------------------
    HRESULT hr; // reused result (public for debugging)
    LPDIRECTDRAW7 DDraw;
	//---------------------
//---------------------------
    TXDXDraw();
    virtual ~TXDXDraw();
	//---------------------
    bool Init();
    bool Release();
    bool isInitted() const;
	//---------------------
    bool setViewFullscreen(HWND hwndWindowHandle, unsigned short usWidth, unsigned short usHeight, unsigned short usBitDepth, unsigned long ulOptionsMask);
    bool setViewWindowed(HWND hwndWindowHandle, unsigned long ulOptionsMask);
    bool isFullScreen() const;
    HWND getWindowHanlde() const;
    const SIZE& getSize() const;
    unsigned short getBitDepth() const;
    unsigned long getOptionMask() const;
	//---------------------
    const char* getErrorString(HRESULT hrErrorCode) const;
	//---------------------
private:
	//---------------------
    bool m_Initted;
    bool m_FullScreen;
    HWND m_WindowHandle;
    SIZE m_Size;
    unsigned short m_BitDepth;
    unsigned long m_OptionMask;
	//---------------------
//---------------------------
	//---------------------
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XDXDrawH
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
