//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXSurface.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./DirectX/DDraw/XDXSurface.h>
//---------------------------------------------------------------------------
TXDXSurface::TXDXSurface()
{
    //------------------
    hr = DD_OK;
    Surface = NULL;
	memset(&m_Rect, 0, sizeof(RECT));
    memset(&m_SurfDesc, 0, sizeof(m_SurfDesc));
    memset(&m_LockSurfDesc, 0, sizeof(m_LockSurfDesc));
    //------------------
}
//---------------------------------------------------------------------------
TXDXSurface::~TXDXSurface()
{
    //------------------
    Release();
    //------------------
}
//---------------------------------------------------------------------------
bool TXDXSurface::Create(LPDIRECTDRAW7 DDraw, unsigned long ulOptionMask /*= DDSCAPS_OFFSCREENPLAIN*/, unsigned long lWidth /*= 0*/, unsigned long lHeight /*= 0*/, unsigned int uBackbufferCount /*= 0*/)
{
    //------------------
    if (!DDraw)
            {XDebug("Validate DDraw failed");return false;}
    //------------------
    if (Surface)
            {XDebug("Surface already created");return false;}
    //------------------
    memset(&m_Rect, 0, sizeof(RECT));
	memset(&m_SurfDesc, 0, sizeof(m_SurfDesc));
    m_SurfDesc.dwSize = sizeof(m_SurfDesc);
    m_SurfDesc.dwFlags = DDSD_CAPS;
    m_SurfDesc.ddsCaps.dwCaps = ulOptionMask;
    //------------------
    if (uBackbufferCount)
    {
            m_SurfDesc.dwFlags |= DDSD_BACKBUFFERCOUNT;
            m_SurfDesc.dwBackBufferCount = uBackbufferCount;
    }
    //------------------
    if (lWidth > 0L && lHeight > 0L)
    {
            m_SurfDesc.dwFlags |= DDSD_HEIGHT | DDSD_WIDTH;
            m_SurfDesc.dwWidth  = lWidth;
            m_SurfDesc.dwHeight = lHeight;
			m_Rect.right  = lWidth;
			m_Rect.bottom = lHeight;
    }
    //------------------
    hr = DDraw->CreateSurface(&m_SurfDesc, &Surface, NULL);
            if (hr != DD_OK) {XDebug("DDraw->CreateSurface failed");return false;}
    //------------------
    return true;
}
//---------------------------------------------------------------------------
bool TXDXSurface::CreateAttached(LPDIRECTDRAWSURFACE7 surfParent, unsigned long ulOptionMask /*= DDSCAPS_BACKBUFFER*/)
{
    //------------------
    if (Surface)
            {XDebug("Surface already created");return false;}
    //------------------
    if (!surfParent)
            {XDebug("Surface validate failed");return false;}
    //------------------
    memset(&m_SurfDesc, 0, sizeof(m_SurfDesc));
    m_SurfDesc.dwSize = sizeof(m_SurfDesc);
	m_SurfDesc.ddsCaps.dwCaps  = ulOptionMask;
    //------------------
    hr = surfParent->GetAttachedSurface(&m_SurfDesc.ddsCaps, &Surface);
            if (hr != DD_OK) {XDebug("surfParent->GetAttachedSurface failed");return false;}
    //------------------
    return true;
}
//---------------------------------------------------------------------------
bool TXDXSurface::Release()
{
    //------------------
    hr = DD_OK;
	memset(&m_Rect, 0, sizeof(RECT));
    memset(&m_SurfDesc, 0, sizeof(m_SurfDesc));
    memset(&m_LockSurfDesc, 0, sizeof(m_LockSurfDesc));
    //------------------
    if (Surface) {Surface->Release();Surface = NULL;}
    //------------------
    return true;
}
//---------------------------------------------------------------------------
bool TXDXSurface::isCreated()
{
    //------------------
    return (Surface != NULL);
}
//---------------------------------------------------------------------------
const DDSURFACEDESC2& TXDXSurface::getSurfaceDesc() const
{
    //------------------
    return m_SurfDesc;
}
//---------------------------------------------------------------------------
unsigned long TXDXSurface::getOptionMask() const
{
    //------------------
    return m_SurfDesc.ddsCaps.dwCaps;
}
//---------------------------------------------------------------------------
unsigned long TXDXSurface::getWidth() const
{
    //------------------
    return m_Rect.right;
}
//---------------------------------------------------------------------------
unsigned long TXDXSurface::getHeight() const
{
    //------------------
    return m_Rect.bottom;
}
//---------------------------------------------------------------------------
const RECT* TXDXSurface::getPRect() const
{
    //------------------
    return &m_Rect;
}
//---------------------------------------------------------------------------
const RECT& TXDXSurface::getRect() const
{
    //------------------
    return m_Rect;
}
//---------------------------------------------------------------------------
unsigned char* TXDXSurface::Lock(unsigned long ulOptionMask, unsigned long ulTimeOut /*= 250L*/)
{
    //------------------
    if (!Surface)
            {XDebug("Validate Surface failed");return NULL;}
    //------------------
    memset(&m_LockSurfDesc, 0, sizeof(m_LockSurfDesc));
    m_LockSurfDesc.dwSize = sizeof(m_LockSurfDesc);
    //------------------
    hr = Surface->Lock(NULL, &m_LockSurfDesc, ulOptionMask, NULL);
	if (hr == DDERR_WASSTILLDRAWING)
	{
		unsigned long waitTill = GetTickCount() + ulTimeOut;
		while (hr == DDERR_WASSTILLDRAWING && GetTickCount() < waitTill)
				hr = Surface->Lock(NULL, &m_LockSurfDesc, ulOptionMask, NULL);
		if (hr == DDERR_WASSTILLDRAWING) 
			{XDebug("Surface->Lock timed out");return NULL;}
	}
    //------------------
    if (hr != DD_OK) {XDebug("Surface->Lock failed");return NULL;}
    //------------------
    return (unsigned char*)m_LockSurfDesc.lpSurface;
}
//---------------------------------------------------------------------------
bool TXDXSurface::Unlock()
{
    //------------------
    if (!Surface)
            {XDebug("Validate Surface failed");return false;}
    //------------------
    hr = Surface->Unlock(NULL);
            if (hr != DD_OK) {XDebug("Surface->Unlock failed");return false;}
    //------------------
    m_LockSurfDesc.lpSurface = NULL;
    //------------------
    return true;
}
//---------------------------------------------------------------------------
bool TXDXSurface::isLocked() const
{
    //------------------
    return (m_LockSurfDesc.lpSurface != NULL);
}
//---------------------------------------------------------------------------
bool TXDXSurface::Flip(unsigned long ulOptionMask /*= DDFLIP_WAIT*/)
{
    //------------------
    if (!Surface)
            {XDebug("Validate Surface failed");return false;}
    //------------------
	if ( (m_SurfDesc.ddsCaps.dwCaps & DDSCAPS_FLIP) == 0)
		{XDebug("Surface not flippable");return false;}
    //------------------
	hr = Surface->Flip(NULL, ulOptionMask);
		if (hr != DD_OK) {XDebug("Surface->Flip failed");return false;}
    //------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXDXSurface::ColorFill(unsigned long ulColor, unsigned long ulOptionMask /*= DDBLT_WAIT*/)
{
	DDBLTFX BltFX;
    //------------------
	ZeroMemory(&BltFX, sizeof(DDBLTFX));
	BltFX.dwSize = sizeof(DDBLTFX);
	BltFX.dwFillColor = ulColor;
    //------------------
	hr = Surface->Blt(NULL, NULL, NULL, (DDBLT_COLORFILL | ulOptionMask), &BltFX);
		if (hr != DD_OK) {XDebug("Surface->Blt Color Fill failed");return false;}
    //------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXDXSurface::LoadBitmapFile(const char* strFileName)
{
	bool r = true;
	HDC hDC, hdcImg;
	HANDLE hImg;
	HGDIOBJ hOldObject;
    //------------------
	hImg = LoadImage(NULL, strFileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (!hImg) {XDebug("LoadImage failed");r = false;}
	else
	{
		//------------------
		hr = Surface->GetDC(&hDC);
		if (hr != DD_OK) {XDebug("Surface->GetDC failed");r = false;}
		else
		{
			//------------------
			hdcImg = CreateCompatibleDC(hDC);
			if (!hDC) {XDebug("CreateCompatibleDC failed");r = false;}
			else
			{
				BITMAP bmp;
				//------------------
				hOldObject = SelectObject(hdcImg, hImg);
				if (GetObject(hImg, sizeof(BITMAP), &bmp))
				{
					/*
					char str[124];
					sprintf(str, "Bitmap %lux%lu %dBpp", bmp.bmWidth, bmp.bmHeight, bmp.bmBitsPixel);
					XDebug(str);
					*/
				}
				else 
				{
					
					XDebug("GetObject Failed");
					LPVOID lpMsgBuf;
					FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),(LPTSTR) &lpMsgBuf, 0, NULL);
					XDebug((char*)lpMsgBuf);
					LocalFree( lpMsgBuf );
				}
				//------------------
				BitBlt(hDC, 0, 0, bmp.bmWidth, bmp.bmHeight, hdcImg, 0, 0, SRCCOPY);
				//------------------
				SelectObject(hDC, hOldObject);
				DeleteDC(hdcImg);
				//------------------
			} // CreateCompatibleDC
			//------------------
			hr = Surface->ReleaseDC(hDC);
				if (hr != DD_OK) {XDebug("Surface->ReleaseDC failed");return false;}
			//------------------
		} // Surface->GetDC
		//------------------
		DeleteObject(hImg);
		//------------------
	} // LoadImage
    //------------------
	return r;
}
//---------------------------------------------------------------------------
bool TXDXSurface::LoadBitmapResource(HINSTANCE hInstance, const char* strResourceName)
{
	bool r = true;
	HDC hDC, hdcImg;
	HBITMAP hBmp;
	HGDIOBJ hOldObject;
    //------------------
	hBmp = LoadBitmap(hInstance, strResourceName);
	if (!hBmp) {XDebug("LoadBitmap failed");r = false;}
	else
	{
		//------------------
		hr = Surface->GetDC(&hDC);
		if (hr != DD_OK) {XDebug("Surface->GetDC failed");r = false;}
		else
		{
			//------------------
			hdcImg = CreateCompatibleDC(hDC);
			if (!hdcImg) {XDebug("CreateCompatibleDC failed");r = false;}
			else
			{
				BITMAP bmp;
				//------------------
				hOldObject = SelectObject(hdcImg, hBmp);
				if (GetObject(hBmp, sizeof(BITMAP), &bmp))
				{
					/*
					char str[124];
					sprintf(str, "Bitmap %lux%lu %dBpp", bmp.bmWidth, bmp.bmHeight, bmp.bmBitsPixel);
					XDebug(str);
					*/
				}
				else 
				{
					
					XDebug("GetObject Failed");
					LPVOID lpMsgBuf;
					FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),(LPTSTR) &lpMsgBuf, 0, NULL);
					XDebug((char*)lpMsgBuf);
					LocalFree( lpMsgBuf );
				}
				//------------------
				BitBlt(hDC, 0, 0,bmp.bmWidth, bmp.bmHeight, hdcImg, 0, 0, SRCCOPY);
				//------------------
				SelectObject(hDC, hOldObject);
				DeleteDC(hdcImg);
				//------------------
			} // CreateCompatibleDC
			//------------------
			hr = Surface->ReleaseDC(hDC);
				if (hr != DD_OK) {XDebug("Surface->ReleaseDC failed");return false;}
			//------------------
		} // Surface->GetDC
		//------------------
		DeleteObject(hBmp);
		//------------------
	} // LoadBitmap
    //------------------
	return r;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
