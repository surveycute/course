//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXDraw.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <windows.h>
#pragma hdrstop
#include <./DirectX/DDraw/XDXDraw.h>
//---------------------------------------------------------------------------
TXDXDraw::TXDXDraw()
{
        //------------------
        hr = DD_OK;
        DDraw = NULL;
        m_Initted = false;
        m_FullScreen = false;
        m_WindowHandle = NULL;
        m_Size.cx = 0;
        m_Size.cy = 0;
        m_BitDepth = 0;
        m_OptionMask = 0L;
        //------------------
}
//---------------------------------------------------------------------------
TXDXDraw::~TXDXDraw()
{
        //------------------
        Release(); // ignore failure
        //------------------
}
//---------------------------------------------------------------------------
bool TXDXDraw::Init()
{
        //------------------
		if (m_Initted)
			return false; // already initted
        //------------------
        hr = DirectDrawCreateEx( NULL, (VOID**)&DDraw, IID_IDirectDraw7, NULL );
                if (hr != DD_OK) {XDebug("DirectDrawCreateEx failed");return false;}
                if (!DDraw) {XDebug("DDraw validate failed");return false;}
        //------------------
        m_Initted = true;
        //------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXDXDraw::Release()
{
        //------------------
		hr = DD_OK;
        m_Initted = false;
        m_FullScreen = false;
        m_WindowHandle = NULL;
        m_Size.cx = 0;
        m_Size.cy = 0;
        m_BitDepth = 0;
        m_OptionMask = 0L;
        //------------------
        if (DDraw) {DDraw->Release();DDraw = NULL;}
        //------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXDXDraw::isInitted() const
{
        //------------------
        return m_Initted;
}
//---------------------------------------------------------------------------
bool TXDXDraw::setViewFullscreen(HWND hwndWindowHandle, unsigned short usWidth, unsigned short usHeight, unsigned short usBitDepth, unsigned long ulOptionsMask)
{
        //------------------
        hr = DirectDrawCreateEx(NULL, (VOID**)&DDraw, IID_IDirectDraw7, NULL);
                if (hr != DD_OK) {XDebug("DirectDrawCreateEx failed");return false;}
                if (!DDraw) {XDebug("DDraw validate failed");return false;}
        hr = DDraw->SetCooperativeLevel(hwndWindowHandle,  ulOptionsMask);
                if (hr != DD_OK) {XDebug("DDraw->SetCoopreativeLevel failed");return false;}
        hr = DDraw->SetDisplayMode(usWidth, usHeight, usBitDepth, 0, 0);
                if (hr != DD_OK) {XDebug("DDraw->SetDisplayMod failed");return false;}
        //------------------
        m_FullScreen = true;
        m_WindowHandle = hwndWindowHandle;
        m_Size.cx = usWidth;
        m_Size.cy = usHeight;
        m_BitDepth = usBitDepth;
        m_OptionMask = ulOptionsMask;
        //------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXDXDraw::setViewWindowed(HWND hwndWindowHandle, unsigned long ulOptionsMask)
{
        //------------------
		// @TODO
        //------------------
        m_FullScreen = true;
        m_WindowHandle = hwndWindowHandle;
        m_OptionMask = ulOptionsMask;
        //------------------
        return false; // @TODO
}
//---------------------------------------------------------------------------
bool TXDXDraw::isFullScreen() const
{
        //------------------
        return m_FullScreen;
}
//---------------------------------------------------------------------------
HWND TXDXDraw::getWindowHanlde() const
{
        //------------------
        return m_WindowHandle;
}
//---------------------------------------------------------------------------
const SIZE& TXDXDraw::getSize() const
{
        //------------------
        return m_Size;
}
//---------------------------------------------------------------------------
unsigned short TXDXDraw::getBitDepth() const
{
        //------------------
        return m_BitDepth; // @TODO get system bit depth when in windowed mode
}
//---------------------------------------------------------------------------
unsigned long TXDXDraw::getOptionMask() const
{
        //------------------
        return m_OptionMask;
}
//---------------------------------------------------------------------------
const char* TXDXDraw::getErrorString(HRESULT hrErrorCode) const
{
        const char* rStr;
        //------------------
        switch (hrErrorCode)
        {
                case DDERR_EXCLUSIVEMODEALREADYSET:     rStr = "EXCLUSIVE MODE ALREADY SET";              break;
                case DDERR_HWNDALREADYSET:              rStr = "window mode already set";                 break;
                case DDERR_HWNDSUBCLASSED:              rStr = "window is subclassed";                    break;
                case DDERR_INVALIDOBJECT:               rStr = "invalid object ";                         break;
                case DDERR_INVALIDCAPS:                 rStr = "caps";                                    break;
                case DDERR_INVALIDPARAMS:               rStr = "params";                                  break;
                case DDERR_NOEXCLUSIVEMODE:             rStr = "no exclusive";                            break;
                case DDERR_OUTOFMEMORY:                 rStr = "out of video mem";                        break;
                case DDERR_OUTOFVIDEOMEMORY:            rStr = "out of mem";                              break;
                case DDERR_SURFACEBUSY:                 rStr = "Surface Busy";                            break;
                case DDERR_SURFACELOST:                 rStr = "Surface Lost";                            break;
                case DDERR_WASSTILLDRAWING:             rStr = "was still drawing";                       break;
                case DDERR_INVALIDRECT:                 rStr = "Invalid Rectangle";                       break;
                case DDERR_GENERIC:                     rStr = "Generic Error";                           break;
                case DDERR_NOBLTHW:                     rStr = "***No blitter hardware***";               break;
                case DDERR_UNSUPPORTED:                 rStr = "****unsupported****";                     break;
                case DDERR_EXCEPTION:                   rStr = "DirectX Exception";                       break;
                case DDERR_INVALIDCLIPLIST:             rStr = "Invalid Clip List";                       break;
                case DDERR_NOALPHAHW:                   rStr = "Alpha not supported by hardware";         break;
                case DDERR_NOCLIPLIST:                  rStr = "NO Clip List";                            break;
                case DDERR_NODDROPSHW:                  rStr = "DDraw Raster Operations Not supported";   break;
                case DDERR_NORASTEROPHW:                rStr = "Windows Raster Operations not supported"; break;
                case DDERR_NOROTATIONHW:                rStr = "Rotation Not supported by hardware";      break;
                case DDERR_NOSTRETCHHW:                 rStr = "Streching not supported";                 break;
                case DDERR_NOZBUFFERHW:                 rStr = "Z Buffer not supported";                  break;
				case DD_OK:								rStr = "OK";									  break;
                default :                               rStr = "Unknown Error";                           break;
        } // switch (hrErrorCode)
        //------------------
        return rStr;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
