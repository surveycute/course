//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XDXSurface.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XDXSurfaceH
#define XDXSurfaceH
//---------------------------------------------------------------------------
#include <windows.h>
#include <DDraw.h>
//---------------------------------------------------------------------------
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
class TXDXSurface
{
public:
	//---------------------
    HRESULT hr; // reused result (public for debugging)
    LPDIRECTDRAWSURFACE7 Surface;
	//---------------------
//---------------------------
    TXDXSurface();
    ~TXDXSurface();
	//---------------------
	// DDSCAPS_PRIMARYSURFACE | DDSCAPS_COMPLEX | DDSCAPS_FLIP
    bool Create(LPDIRECTDRAW7 DDraw, unsigned long ulOptionMask = DDSCAPS_OFFSCREENPLAIN, unsigned long lWidth = 0, unsigned long lHeight = 0, unsigned int uBackbufferCount = 0);
    bool CreateAttached(LPDIRECTDRAWSURFACE7 surfParent, unsigned long ulOptionMask = DDSCAPS_BACKBUFFER);
    bool Release();
	//---------------------
    bool isCreated();
    const DDSURFACEDESC2& getSurfaceDesc() const;
	//---------------------
    unsigned long getOptionMask() const;
    unsigned long getWidth() const;
    unsigned long getHeight() const;
	const RECT* getPRect() const;
	const RECT& getRect() const;
	//---------------------
	// DDLOCK_SURFACEMEMORYPTR | DDLOCK_WRITEONLY | DDLOCK_WAIT | DDLOCK_NOSYSLOCK
    unsigned char* Lock(unsigned long ulOptionMask, unsigned long ulTimeOut = 250L); 
    bool Unlock();
	bool isLocked() const;
	//---------------------
	bool Flip(unsigned long ulOptionMask = DDFLIP_WAIT);
	bool ColorFill(unsigned long ulColor, unsigned long ulOptionMask = DDBLT_WAIT);
	bool LoadBitmapFile(const char* strFileName);
	bool LoadBitmapResource(HINSTANCE hInstance, const char* strResourceName);
	//---------------------

private:
	//---------------------
	RECT m_Rect;
    DDSURFACEDESC2 m_SurfDesc;
    DDSURFACEDESC2 m_LockSurfDesc;
	//---------------------
//---------------------------
	//---------------------
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XDXSurfaceH
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
