//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XBuffer.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h> // malloc realloc free
#pragma hdrstop
#ifdef __BORLANDC__
        #pragma message Including Borland compatible string.h header.
        #include <string.h> // memcpy
#else
        #include <string>
#endif
#include <./Buffer/XBuffer.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXBuffer::TXBuffer()
{
	//------------------
	BlockSize = XBuffer_Default_BlockSize;
	AllocSize = 0L;
	Size = 0L;
	Data = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXBuffer::~TXBuffer()
{
	//------------------
	Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXBuffer::setBlockSize(const unsigned long& ulBlockSize)
{
	//------------------
	BlockSize = ulBlockSize;
	//------------------
}
//---------------------------------------------------------------------------
/*private*/bool TXBuffer::allocate(unsigned long ulAllocSize)
{
	unsigned char* NewData; // temp buffer
	//------------------
	NewData = (unsigned char*)XBuffer_Allocate(ulAllocSize);
		if (!NewData) return false;
	//------------------
	if (Data) XBuffer_Free(Data);
	//------------------
	Data = NewData;
	AllocSize = ulAllocSize;
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXBuffer::setAllocation(unsigned long ulAllocSize)
{
	//------------------
	if (ulAllocSize == 0)
	{
		Clear();
		return true;
	}
	//------------------
	if (!Data)
		return allocate(ulAllocSize);
	//------------------
	#ifdef XBuffer_Reallocatable
		//------------------
		AllocSize = ulAllocSize;
		//------------------
		Data = (unsigned char*)XBuffer_Reallocate(Data, AllocSize);
			if (!Data)
                                {AllocSize = Size = 0L;return false;} // oops, lost contents
		//------------------
	#else // #ifdef XBuffer_Reallocatable
		//------------------
		unsigned char* NewData;
		//------------------
		NewData = (unsigned char*)XBuffer_Allocate(ulAllocSize);
			if (!NewData) return false;
		//------------------
		if (ulAllocSize < Size)
			Size = ulAllocSize;
		//------------------
		if (Size)
			memcpy(NewData, Data, Size); // only copy used size
		//------------------
		XBuffer_Free(Data); // free old buffer
		Data = NewData;
		AllocSize = ulAllocSize;
	//------------------
	#endif //#ifdef XBuffer_Reallocatable  #else
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXBuffer::addAllocation(const unsigned long& ulAllocSize)
{
	//------------------
	AllocSize += ulAllocSize;
	//------------------
	return setAllocation(ulAllocSize);
}
//---------------------------------------------------------------------------
bool TXBuffer::addBlockAllocation(const unsigned long& ulAllocSize)
{
	//------------------
	return setAllocation(AllocSize + ulAllocSize + BlockSize);
}
//---------------------------------------------------------------------------
bool TXBuffer::trimAllocation()
{
	//------------------
	return setAllocation(Size);
}
//---------------------------------------------------------------------------
bool TXBuffer::setSize(const unsigned long& ulSize)
{
	//------------------
	if (ulSize > AllocSize)
		if (!setAllocation(ulSize + BlockSize))
			return false;
	//------------------
	Size = ulSize;
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXBuffer::addSize(const unsigned long& ulSize)
{
	//------------------
	return setSize(Size + ulSize);
}
//---------------------------------------------------------------------------
bool TXBuffer::lessSize(const unsigned long& ulSize)
{
	//------------------
	return setSize(Size - ulSize);
}
//---------------------------------------------------------------------------
unsigned long TXBuffer::getBlockSize() const
{
	//------------------
	return BlockSize;
}
//---------------------------------------------------------------------------
unsigned long TXBuffer::getAllocSize() const
{
	//------------------
	return AllocSize;
}
//---------------------------------------------------------------------------
unsigned long TXBuffer::getSize() const
{
	//------------------
	return Size;
}
//---------------------------------------------------------------------------
bool TXBuffer::isEmpty() const
{
	//------------------
	return (Size == 0);
}
//---------------------------------------------------------------------------
const unsigned char* TXBuffer::getData() const
{
	//------------------
	return Data;
}
//---------------------------------------------------------------------------
unsigned char* TXBuffer::editData()
{
	//------------------
	return Data;
}
//---------------------------------------------------------------------------
const char* TXBuffer::getString()
{
	//------------------
	return editString();
}
//---------------------------------------------------------------------------
char* TXBuffer::editString()
{
	//------------------
	if (Data[Size-1] != 0)
	{
		if (AllocSize == Size)
			if (!addBlockAllocation(1))
				return NULL;
		Data[Size] = '\0';
	}
	//------------------
	return (char*)Data;
}
//---------------------------------------------------------------------------
void TXBuffer::Clear(bool bClean /*= true*/)
{
	//------------------
	if (bClean)
        {
                if (Data) {XBuffer_Free(Data);Data = NULL;}
                AllocSize = 0L;
        }
	//------------------
	Size = 0L;
	//------------------
}
//---------------------------------------------------------------------------
bool TXBuffer::Set(unsigned char* pData, unsigned long ulSize)
{
	//------------------
	if (!setSize(ulSize))
		return false;
	//------------------
	memcpy(Data, pData, ulSize);
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXBuffer::Append(unsigned char* pData, unsigned long ulSize)
{
	unsigned long oldSize = Size;
	//------------------
	if (!addSize(ulSize)) // This may reallocate, invalidating Data pointers
		return false;
	//------------------
	memcpy(&Data[oldSize], pData, ulSize);
	//------------------
	return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
