//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XBuffer.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XBufferH
#define XBufferH
//---------------------------------------------------------------------------
#define XBuffer_Reallocatable true
#define XBuffer_Free(s)     free(s)
#define XBuffer_Allocate(s)     malloc(s)
#define XBuffer_Reallocate(b,s) realloc(b,s)
#define XBuffer_Default_BlockSize  4
//---------------------------------------------------------------------------
class TXBuffer
{
private:
	//---------------------
	unsigned long BlockSize; // size to round additional allocations up to
	unsigned long AllocSize; // size allocated
	unsigned long Size;      // size used
	//---------------------
	unsigned char* Data;
	//---------------------
	bool allocate(unsigned long ulAllocSize);
	//---------------------
public:
	//---------------------

//---------------------------
	TXBuffer();
	~TXBuffer();
	//---------------------
	void setBlockSize(const unsigned long& ulBlockSize);
	bool setAllocation(unsigned long ulAllocSize); // does realloc
	bool addAllocation(const unsigned long& ulAllocSize);
	bool addBlockAllocation(const unsigned long& ulAllocSize);
	bool trimAllocation();
	//---------------------
	bool setSize(const unsigned long& ulSize);
	bool addSize(const unsigned long& ulSize);
        bool lessSize(const unsigned long& ulSize);
	//---------------------
	unsigned long getBlockSize() const;
	unsigned long getAllocSize() const;
	unsigned long getSize() const;
	bool isEmpty() const;
	//---------------------
	const unsigned char* getData() const;
	unsigned char* editData(); // No safety mechanism, use at own risk
	const char* getString(); // can reallocate for NULL
	char* editString();      // can reallocate for NULL
	//---------------------
	void Clear(bool bClean = true);
	bool Set(unsigned char* pData, unsigned long Size);
	bool Append(unsigned char* pData, unsigned long Size);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
