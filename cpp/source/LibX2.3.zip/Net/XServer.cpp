//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XServer.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <windows.h>
 #include <string.h> // strdup()
 #pragma hdrstop
#include <./Net/XServer.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
TXServer::TXServer()
{
	//------------------
	Host = NULL;
	Resolved = false;
	//------------------
}
//---------------------------------------------------------------------------
TXServer::TXServer(const char* strHost, const unsigned short& sPort)
{
	//------------------
	TXServer();
	set(strHost, sPort);
	//------------------
}
//---------------------------------------------------------------------------
TXServer::~TXServer()
{
	//------------------
	if (Host) free(Host);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXServer::getHost() const
{
	//------------------
	return Host;
}
//---------------------------------------------------------------------------
void TXServer::setHost(const char* strHost)
{
	//------------------
	Resolved = false;
	if (Host) free(Host);
	Host = strdup(strHost);
	//------------------
}
//---------------------------------------------------------------------------
const unsigned short& TXServer::getPort() const
{
	//------------------
	return Port;
}
//---------------------------------------------------------------------------
void TXServer::setPort(const unsigned short& sPort)
{
	//------------------
	Port = sPort; // doesn't require another Resolve
	//------------------
}
//---------------------------------------------------------------------------
void TXServer::set(const char* strHost, const unsigned short& sPort)
{
	//------------------
	setHost(strHost);
	setPort(sPort);
	//------------------
}
//---------------------------------------------------------------------------
void TXServer::set(const sockaddr& saddr)
{
	//------------------
	memcpy(&Addr, &saddr, sizeof(saddr));
	Resolved = true;
	Port = ntohs(Addr.sin_port);
	Host = strdup(getIPString());
	//------------------
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
const sockaddr_in& TXServer::getAddr() const
{
	//------------------
	return Addr;
}
//---------------------------------------------------------------------------
const sockaddr_in* TXServer::getAddrPtr() const
{
	//------------------
	return &Addr;
}
//---------------------------------------------------------------------------
const size_t TXServer::getAddrSize() const
{
	//------------------
	return sizeof(Addr);
}
//---------------------------------------------------------------------------
bool TXServer::Resolve()
{
	//------------------
	if (Resolved)
		return true;
	//------------------
	return forceResolve();
}
//---------------------------------------------------------------------------
bool TXServer::forceResolve()
{
	hostent* hostInfo;
	//------------------
	Resolved = false;
	memset(&Addr, 0, sizeof(sockaddr_in));
	//------------------
	if (!Host) Addr.sin_addr.s_addr = INADDR_ANY; // (winsock2.h) is realy just 0x0L, so no htonl
	else
	{
		//------------------
		hostInfo = gethostbyname(Host);
			if (!hostInfo)
                        {
                            int i = WSAGetLastError();
                            return false;
                        }
		//------------------
		Addr.sin_family = AF_INET;
		memcpy(&Addr.sin_addr.s_addr, hostInfo->h_addr_list[0], hostInfo->h_length);
		//------------------
	}
	//------------------
	Addr.sin_port = htons(Port);
	//------------------
	Resolved = true;
	//------------------
	return true;
}
//---------------------------------------------------------------------------
const bool TXServer::isResolved() const
{
	//------------------
	return Resolved;
}
//---------------------------------------------------------------------------
unsigned long TXServer::getIP()
{
	//------------------
	if (!Resolve())
		return 0L;
	//------------------
	return Addr.sin_addr.s_addr;
}
//---------------------------------------------------------------------------
const char* TXServer::getIPString() // Resolves if necessary
{
	//------------------
	if (!Resolve())
		return "";
	//------------------
	return inet_ntoa(Addr.sin_addr);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
