//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XSocket.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include "XSocket.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXSocket::TXSocket()
{
	//------------------
	Connected = false;
	Socket = INVALID_SOCKET;
	//------------------
}
//---------------------------------------------------------------------------
TXSocket::TXSocket(SOCKET soc, bool bConnected /*= true*/)
{
	//------------------
	Connected = bConnected;
	Socket = soc;
	//------------------
}
//---------------------------------------------------------------------------
TXSocket::~TXSocket()
{
	//------------------
	Disconnect();
	//------------------
}
//---------------------------------------------------------------------------
bool TXSocket::quickConnect(char* Host, unsigned long Port)
{
	TXServer tempServer(Host, Port);
	//------------------
	if (!tempServer.Resolve())
		return false;
	//------------------
	return Connect();
}
//---------------------------------------------------------------------------
bool TXSocket::Connect(TXServer* pServer /*= NULL*/)
{
	//------------------
        lastError = -1;
	//------------------
	if (Connected)
		return false;
	//------------------
	if (!pServer) pServer = &Server;
	//------------------
	if (!pServer->Resolve())
    	        return false;
	//------------------
	Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (Socket == INVALID_SOCKET)
			return false;
	//-------------------------------
	if (connect(Socket, (sockaddr*)pServer->getAddrPtr(), pServer->getAddrSize()) == SOCKET_ERROR)
        {
                lastError = WSAGetLastError();
		return false;
        }
        //------------------
        Connected = true;
	//------------------
	return true;
}
//---------------------------------------------------------------------------
void TXSocket::Disconnect()
{
	//------------------
	Connected = false;
	if (Socket != INVALID_SOCKET)
		closesocket(Socket);
	//------------------
}
//---------------------------------------------------------------------------
bool TXSocket::isConnected() const
{
	//------------------
	return Connected;
}
//---------------------------------------------------------------------------
int TXSocket::getLastError() const
{
	//------------------
        return lastError;
}
//---------------------------------------------------------------------------
const char* TXSocket::getLastErrorString() const
{
        char* s;
        //------------------
        switch (lastError)
        {
                case WSANOTINITIALISED: s = "WSANOTINITIALISED"; break;
                case WSAENETDOWN:       s = "WSAENETDOWN"; break;
                case WSAEADDRINUSE:     s = "WSAEADDRINUSE"; break;
                case WSAEINTR:          s = "WSAEINTR"; break;
                case WSAEINPROGRESS:    s = "WSAEINPROGRESS"; break;
                case WSAEALREADY:       s = "WSAEALREADY"; break;
                case WSAEADDRNOTAVAIL:  s = "WSAEADDRNOTAVAIL"; break;
                case WSAEAFNOSUPPORT:   s = "WSAEAFNOSUPPORT"; break;
                case WSAECONNREFUSED:   s = "WSAECONNREFUSED"; break;
                case WSAEFAULT:         s = "WSAEFAULT"; break;
                case WSAEINVAL:         s = "WSAEINVAL"; break;
                case WSAEISCONN:        s = "WSAEISCONN"; break;
                case WSAENETUNREACH:    s = "WSAENETUNREACH"; break;
                case WSAENOBUFS:        s = "WSAENOBUFS"; break;
                case WSAENOTSOCK:       s = "WSAENOTSOCK"; break;
                case WSAETIMEDOUT:      s = "WSAETIMEDOUT"; break;
                case WSAEWOULDBLOCK:    s = "WSAEWOULDBLOCK"; break;
                case WSAEACCES:         s = "WSAEACCES"; break;
                default:                s = "UKNOWN/NONE";break;
        }
        //------------------
        return s;
}
//---------------------------------------------------------------------------
int TXSocket::Read(char* pBuff, int Len)
{
	Len = recv(Socket, pBuff, Len, 0);
	//------------------
	if (Len  == -1)
	{
                lastError = WSAGetLastError();
		//------------------
                if (lastError == WSAECONNABORTED || lastError == WSAECONNRESET)
			Disconnect();
		//------------------
		return -1;
	}
	//------------------
	return Len;
}
//---------------------------------------------------------------------------
bool TXSocket::Read(char* pBuff, int* pLen)
{
	//------------------
	*pLen = recv(Socket, pBuff, *pLen, 0);
	//------------------
	if ( (*pLen) == -1)
	{
                lastError = WSAGetLastError();
		//------------------
                if (lastError == WSAECONNABORTED || lastError == WSAECONNRESET)
			Disconnect();
		//------------------
		return false;
	}
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXSocket::Write(char* pBuff, int Len)
{
	int r;
	//------------------
	while (Len > 0)
	{
		//------------------
		r = send(Socket, pBuff, Len, 0);
			if (r < 1)
			{
                                lastError = WSAGetLastError();
                                if (lastError == WSAECONNABORTED || lastError == WSAECONNRESET)
					Disconnect();
				return false;
			}
		//------------------
		Len 	-= r;
		pBuff 	+= r;
		//------------------
	} // while (Len > 0)
	//------------------
	return true;
}
//---------------------------------------------------------------------------
int TXSocket::Pending(unsigned short secTimeOut /*= 0*/)
{
	int r;
	fd_set fd;
	timeval tv;
	//------------------
	FD_ZERO(&fd);
	FD_SET((unsigned int)Socket ,&fd);
	//------------------
	tv.tv_sec  = secTimeOut;
	tv.tv_usec = 0; // this param alone doesnt work?
	//------------------
	r = select(Socket+1, &fd, NULL, NULL, &tv);
	//------------------
	if (r <= 0)
		return r; // -1 for error , or 0 for timed out
	//------------------
// Does this ever happen?:
//	if (fd.fd_array[0] != (u_int)Socket)
//		return -1; // Received reply, but it didn't match
	//------------------
	return fd.fd_count;
}
//---------------------------------------------------------------------------
int TXSocket::ReadWait(char* pBuff, int Len, unsigned short secTimeOut /*= 0*/)
{
	int r = Pending(secTimeOut);
	//------------------
	if (r <= 0)
		return r;
	//------------------
	return Read(pBuff, Len);
}
//---------------------------------------------------------------------------
bool TXSocket::ReadWait(char* pBuff, int* pLen, unsigned short secTimeOut /*= 0*/)
{
	int r = Pending(secTimeOut);
	//------------------
	if (r == -1)
		return false;
	//------------------
	if (r == 0)
	{
		*pLen = 0;
		return true;
	}
	//------------------
	return Read(pBuff, pLen);
}
//---------------------------------------------------------------------------
bool TXSocket::Bind(TXServer* pServer /*= NULL*/)
{
	//------------------
	if (!pServer) pServer = &Server;
	//------------------
	return (bind(Socket, (sockaddr*)pServer->getAddrPtr(), pServer->getAddrSize()) != SOCKET_ERROR);
}
//---------------------------------------------------------------------------
bool TXSocket::Listen(int Backlog /*= SOMAXCONN*/)
{
	//------------------
	return (listen(Socket, Backlog) != SOCKET_ERROR);
}
//---------------------------------------------------------------------------
SOCKET TXSocket::Accept(TXServer* ClientInfo /*= NULL*/)
{
	sockaddr newAddr;
	int sizeAddr = sizeof(newAddr);
	SOCKET newSocket = accept(Socket, &newAddr, &sizeAddr);
	//------------------
	//if (newSocket != INVALID_SOCKET)

	//------------------
	//------------------
	return newSocket;
}
//---------------------------------------------------------------------------
const char* TXSocket::getIPString()
{
        //------------------
        return Server.getIPString();
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
