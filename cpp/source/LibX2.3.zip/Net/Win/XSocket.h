//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XSocket.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XSocketH
#define XSocketH
//---------------------------------------------------------------------------
#include <Net/XServer.h>
//---------------------------------------------------------------------------
class TXSocket
{
private:
	bool Connected;
	SOCKET Socket;
        int lastError;
public:
	//---------------------
	TXServer Server;
//---------------------------
	TXSocket();
	TXSocket(SOCKET soc, bool bConnected /*= true*/);
	~TXSocket();
	//---------------------
	bool quickConnect(char* Host, unsigned long Port);
	bool Connect(TXServer* pServer = NULL);
	void Disconnect();
	//---------------------
	bool isConnected() const;
        int getLastError() const;
        const char* getLastErrorString() const;
	//---------------------
	int Read(char* pBuff, int Len);
	bool Read(char* pBuff, int* pLen);
	bool Write(char* pBuff, int Len);
	int Pending(unsigned short secTimeOut = 0);
	int ReadWait(char* pBuff, int Len, unsigned short secTimeOut = 0);
	bool ReadWait(char* pBuff, int* pLen, unsigned short secTimeOut = 0);
	//---------------------
	bool Bind(TXServer* pServer = NULL);
	bool Listen(int Backlog = SOMAXCONN);
	SOCKET Accept(TXServer* ClientInfo = NULL);
	//---------------------
        const char* getIPString();
        //---------------------
};
//---------------------------------------------------------------------------
#endif // XSocketH
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
