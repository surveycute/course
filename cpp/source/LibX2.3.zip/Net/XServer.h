//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XServer.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XServerH
#define XServerH
//---------------------------------------------------------------------------
#include <winsock2.h>
//---------------------------------------------------------------------------
class TXServer
{
private:
	//---------------------
	bool Resolved;
	sockaddr_in Addr;
	char* Host; // NULL for INADDR_ANY
	unsigned short Port;
	//---------------------
public:
	//---------------------

//---------------------------
	TXServer();
	TXServer(const char* strHost, const unsigned short& sPort);
	~TXServer();
	//---------------------
	const char* getHost() const;
	void setHost(const char* strHost);
	const unsigned short& getPort() const;
	void setPort(const unsigned short& sPort);
	void set(const char* strHost, const unsigned short& sPort);
	void set(const sockaddr& saddr);
	const sockaddr_in& getAddr() const;
	const sockaddr_in* getAddrPtr() const;
	const size_t getAddrSize() const;
	//---------------------
	bool Resolve(); // Returns true if already resolved
	bool forceResolve();
	const bool isResolved() const;
        unsigned long getIP() ; // Resolves if necessary (0L on fail)
        const char* getIPString(); // Resolves if necessary ("" on fail)
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
