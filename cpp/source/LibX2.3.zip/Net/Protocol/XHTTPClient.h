//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XHTTPClient.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XHTTPClientH
#define XHTTPClientH
//---------------------------------------------------------------------------
#include <Net/Protocol/XURL.h>
#include <Net/Win/XSocket.h>
#include <Buffer/XBuffer.h>
//---------------------------------------------------------------------------
#define XHTTPClient_Default_POST_Content_Type  "application/x-www-form-urlencoded"
#define	XHTTPClient_Default_ReadBufferSize 2048
#define XHTTPClient_Free(s)     free(s)  // Must work with strdup()
#define XHTTPClient_Allocate(s)     malloc(s)
#define XHTTPClient_Default_HTTPVersionString "HTTP/1.1"
typedef enum {httpcReady = 0, httpcDone, httpcConnected,
                httpcSending, httpcListen, httpcRead, httpcProcess,
                httpcDestoying,
                httpcFailConnect, httpcFailRead, httpcFailedWrite, httpcReplyFail} XHTTPClient_Status;
//---------------------------------------------------------------------------
class TXHTTPClient
{
private:
	//---------------------
	unsigned short ReadBufferSize;
	char* ReadBuffer;

	XHTTPClient_Status Status;
	TXServer Server;
	TXSocket Socket;
	TXBuffer Buffer;
	unsigned int DataOffset;
	unsigned short ReplyValue;
	char* httpParameters;
	char* httpVersion; // TODO get/set
	//---------------------
public:
	//---------------------
	TXURL URL;
//---------------------------
	TXHTTPClient();
	~TXHTTPClient();
	//---------------------
	TXSocket* getSocket();
	//---------------------
	bool Connect(const char* strHost = NULL, unsigned short usPort = 80);
	void Disconnect();
	//---------------------
	bool GET(const char* strURL = NULL, unsigned short usPort = 80);
        bool POST(const char* pData, unsigned long lenData, const char* strContentType = NULL);
	bool POST(const char* strURL, const char* strData);
	bool GET(const char* strPath, const char* strFile);
	bool POST(const char* strPath, const char* strFile, const char* strData);
	//---------------------
	bool Step(); // returns true untill done/error
	bool ListenStep();
	bool ReadStep();
	bool Process(); 
	//---------------------
	bool isActive() const;
	bool isDone() const;
	bool isError() const;
	const XHTTPClient_Status getStatus() const;
	//---------------------
	void ClearData(bool bClean = true);
        const unsigned long getDataSize() const;
	const char* getData() const;
	TXBuffer& editData();
	const char* getDataString();
	bool hasData() const;
	//---------------------
        const unsigned short& getReplyCode();
	//---------------------
	bool setReadBufferSize(const int& newSize);
	const unsigned short& getReadBufferSize() const;
	void setHTTPParameters(const char* strParameters);
        void setHTTPVersionString(const char* strVer);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
