//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XHTTPClient.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <string>
#pragma hdrstop
#include <./Net/Protocol/XHTTPClient.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXHTTPClient::TXHTTPClient()
{
	//---------------------
	Status = httpcReady;
	httpParameters = NULL;
	httpVersion = strdup(XHTTPClient_Default_HTTPVersionString);
	Buffer.setBlockSize(0L);
	ReadBuffer = NULL;
	ReadBufferSize = 0;
	setReadBufferSize(XHTTPClient_Default_ReadBufferSize);
	DataOffset = 0;
	//---------------------
}
//---------------------------------------------------------------------------
TXHTTPClient::~TXHTTPClient()
{
	//---------------------
        Status = httpcDestoying;
	//---------------------
        if (httpVersion)        XHTTPClient_Free(httpVersion);
        if (httpParameters)     XHTTPClient_Free(httpParameters);
        if (ReadBuffer)         XHTTPClient_Free(ReadBuffer);
	//---------------------
}
//---------------------------------------------------------------------------
TXSocket* TXHTTPClient::getSocket()
{
	//---------------------
	return &Socket;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::Connect(const char* strHost /*= NULL*/, unsigned short usPort /*= 80*/)
{
	//---------------------
	if (strHost)
	{
		Server.setHost(strHost);
		Server.setPort(usPort);
	}
	//---------------------
	if (!Socket.Connect(&Server))
	{
		Status = httpcFailConnect;
		return false;
	}
	//---------------------
	Status = httpcConnected;
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
void TXHTTPClient::Disconnect()
{
	//---------------------
	Socket.Disconnect();
	Status = httpcReady;
	//---------------------
}
//---------------------------------------------------------------------------
bool TXHTTPClient::GET(const char* strURL /*= NULL*/, unsigned short usPort /*= 80*/)
{
	int Size;
	char* strBuffer;
	//---------------------
        if (Status != httpcReady)
        	Buffer.Clear();
	//---------------------
	if (strURL)
		if (!URL.set(strURL)) // Processes strURL into Host / File
			return false;
	//---------------------
	Server.set(URL.getHost(), usPort);
	//---------------------
	Status = httpcSending;
	//---------------------
	if (!Connect())
	        return false;
	//---------------------
	Size = 18; // 'GET ' (space between File+Ver) '\r\nHost: '  \r\n and \r\n + NULL
        Size += strlen(URL.getFile()) + strlen(httpVersion) + strlen(URL.getHost());
	if (httpParameters)
                Size += strlen(httpParameters);
	//---------------------
	strBuffer = (char*)XHTTPClient_Allocate(Size);
                if (!strBuffer) return false;
	//---------------------
	strBuffer[0] = '\0';
	strcat(strBuffer, "GET ");
	strcat(strBuffer, URL.getFile());
	strcat(strBuffer, " ");
	strcat(strBuffer, httpVersion);
	strcat(strBuffer, "\r\nHost: ");
        strcat(strBuffer, URL.getHost());
        strcat(strBuffer, "\r\n");
        if (httpParameters)
                strcat(strBuffer, httpParameters);
        strcat(strBuffer, "\r\n");
	//---------------------
	if (!Socket.Write(strBuffer, Size - 1/*Don't include NULL*/))
	{
		Status = httpcFailedWrite;
                if (strBuffer) XHTTPClient_Free(strBuffer);
		return false;
	}
	//---------------------
        if (strBuffer) XHTTPClient_Free(strBuffer);
	Status = httpcListen;
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::POST(const char* pData, unsigned long lenData, const char* strContentType /*= NULL*/)
{
        int Size;
        char* strBuffer;
        char strLenData[12];
	//---------------------
        if (Status != httpcReady)
        	Buffer.Clear();
	//---------------------
        ltoa(lenData, strLenData, 10);
        if (!strContentType) strContentType = XHTTPClient_Default_POST_Content_Type;
	//---------------------
	Server.set(URL.getHost(), 80);// @TODO port
	//---------------------
        if (!Connect())
                return false;
	//---------------------
	Status = httpcSending;
	//---------------------
        Size = 53/* 'POST '  (space between file+ver) '\r\nHost: ' \r\n 'Content-Type: ' '\r\nContent-Length: ' then \r\n\r\n + NULL*/;
        Size += strlen(URL.getFile()) + strlen(httpVersion) + strlen(URL.getHost()) + strlen(strLenData) + strlen(strContentType);
        if (httpParameters) Size += strlen(httpParameters);
	//---------------------
        strBuffer = (char*)XHTTPClient_Allocate(Size + lenData);
	//---------------------
        strBuffer[0] = '\0';
        strcat(strBuffer, "POST ");
        strcat(strBuffer, URL.getFile());
        strcat(strBuffer, " ");
        strcat(strBuffer, httpVersion);
        strcat(strBuffer, "\r\nHost: ");
        strcat(strBuffer, URL.getHost());
        strcat(strBuffer, "\r\n");
	//---------------------
        if (httpParameters)
                strcat(strBuffer, httpParameters);
	//---------------------
        strcat(strBuffer, "Content-Type: ");
        strcat(strBuffer, strContentType);
        strcat(strBuffer, "\r\nContent-Length: ");
        strcat(strBuffer, strLenData);
        strcat(strBuffer, "\r\n\r\n");
	//---------------------
        memcpy(&strBuffer[Size - 1 /* cover up NULL*/], pData, lenData);
	//---------------------
	if (!Socket.Write(strBuffer, lenData + Size - 1/*Don't include NULL*/))
	{
		Status = httpcFailedWrite;
                if (strBuffer) XHTTPClient_Free(strBuffer);
		return false;
	}
	//---------------------
        if (strBuffer) XHTTPClient_Free(strBuffer);
	Status = httpcListen;
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
bool TXHTTPClient::POST(const char* strURL, const char* strData)
{
	//---------------------
	// TODO
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::GET(const char* strPath, const char* strFile)
{
	//---------------------
	// TODO
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::POST(const char* strPath, const char* strFile, const char* strData)
{
	//---------------------
	// TODO
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::Step()
{
	//---------------------
	switch (Status)
	{
                case httpcDestoying: return false;
		case httpcReady: return false;
		case httpcDone:
                        Socket.Disconnect();
                        return false; // done
		case httpcConnected:
			break;
		case httpcListen:
			if (!ListenStep())
				return false; // done/error
			break;
		case httpcRead:
			if (!ReadStep())
				return false; // done/error
			break;
		case httpcProcess:
			if (!Process())
                                return false; // done/error
			break;
		case httpcFailConnect: // |--------------
		case httpcFailRead:    // |
		case httpcFailedWrite: // |
                        Socket.Disconnect();
			return false;  // \----done/error
	}
	//---------------------
	return true; // not done
}
//---------------------------------------------------------------------------
bool TXHTTPClient::ListenStep()
{
	int Len = Socket.Pending();
	//---------------------
	if (Len > 0)
	{
		if (!ReadStep())
        	        return false;
	}
	else if (Len < 0)
			return false; // Socket Error
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::ReadStep()
{
	int r = Socket.Read(ReadBuffer, (int)ReadBufferSize);
	//---------------------
	if (r < 0)
	{
		Status = httpcFailRead;
		return false;
	}
	//---------------------
	if (r == 0)
	{
		//---------------------
		if (Status == httpcRead)
			Status = httpcProcess;
		//---------------------
	}
	else
	{
		//---------------------
		 if (!Buffer.Append((unsigned char*)ReadBuffer, r))
			return false;
		//---------------------
		Status = httpcRead;
		//---------------------
	}
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::Process()
{

        int mCount;
        char strMatch[] = "\r\n\r\n";
	const char* pData  = (const char*)Buffer.getString();
        //---------------------
        DataOffset = 0;
        mCount = 0;
        while (*pData != ' ')
        {
                pData++;
                DataOffset++;
        }
        pData++;
        DataOffset++;
        ReplyValue = atoi(pData);
        //---------------------
        while (*pData != '\0' && mCount < 4)
        {
                //---------------------
                if (*pData == strMatch[mCount])
                        mCount++;
                else
                        mCount = 0;
                //---------------------
                DataOffset++;
                pData++;
                //---------------------
        }
        //---------------------
        if (mCount != 4)
        {
        	Status = httpcReplyFail;
                return false;
        }
        //---------------------
        Status = httpcDone;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::isActive() const
{
	//---------------------
	return !(isDone() || isError());
}
//---------------------------------------------------------------------------
bool TXHTTPClient::isDone() const
{
	//---------------------
	return Status == httpcDone;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::isError() const
{
	//---------------------
	return (Status == httpcFailConnect || Status == httpcFailRead || Status == httpcFailedWrite);
}
//---------------------------------------------------------------------------
const XHTTPClient_Status TXHTTPClient::getStatus() const
{
	//---------------------
	return Status;
}
//---------------------------------------------------------------------------
void TXHTTPClient::ClearData(bool bClean /*= true*/)
{
	//---------------------
	Buffer.Clear(bClean);
	//---------------------
}
//---------------------------------------------------------------------------
const unsigned long TXHTTPClient::getDataSize() const
{
	//---------------------
	return Buffer.getSize() - DataOffset;
}
//---------------------------------------------------------------------------
const char* TXHTTPClient::getData() const
{
	//---------------------
	return (const char*)(& (Buffer.getData()[DataOffset]) );
}
//---------------------------------------------------------------------------
TXBuffer& TXHTTPClient::editData()
{
	//---------------------
	return Buffer;
}
//---------------------------------------------------------------------------
const char* TXHTTPClient::getDataString()
{
	//---------------------
	return (& (Buffer.getString())[DataOffset] );
}
//---------------------------------------------------------------------------
bool TXHTTPClient::hasData() const
{
	//---------------------
	return (!Buffer.isEmpty());
}
//---------------------------------------------------------------------------
const unsigned short& TXHTTPClient::getReplyCode()
{
	//---------------------
	return ReplyValue;
}
//---------------------------------------------------------------------------
bool TXHTTPClient::setReadBufferSize(const int& newSize)
{
	//---------------------
	if (ReadBuffer) XHTTPClient_Free(ReadBuffer);
	ReadBuffer = (char*)XHTTPClient_Allocate(newSize);
	if (!ReadBuffer)
	{
		ReadBufferSize = 0;
		return false;
	}
	//---------------------
	ReadBufferSize = (unsigned short)newSize;
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
const unsigned short& TXHTTPClient::getReadBufferSize() const
{
	//---------------------
	return ReadBufferSize;
}
//---------------------------------------------------------------------------
void TXHTTPClient::setHTTPParameters(const char* strParameters)
{
	//---------------------
	if (httpParameters) XHTTPClient_Free(httpParameters);
	httpParameters = strdup(strParameters);
	//---------------------
}
//---------------------------------------------------------------------------
void TXHTTPClient::setHTTPVersionString(const char* strVer)
{
	//---------------------
	if (httpVersion) XHTTPClient_Free(httpVersion);
	httpVersion = strdup(strVer);
	//---------------------
}
//---------------------------------------------------------------------------


//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
