//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XURL.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XURLH
#define XURLH
//---------------------------------------------------------------------------
#define XURL_Free(s)  free(s)
#define XURL_Allocate(s) malloc(s)
//---------------------------------------------------------------------------
class TXURL
{
private:
	//---------------------
	char* URL;
	char* Host;
	char* File;
	//---------------------
public:
	//---------------------

//---------------------------
	TXURL();
	TXURL(const char* strURL);
	TXURL(const char* strHost, const char* strFile = (void*)0);
	TXURL(TXURL& newUrl);
        ~TXURL();
	//---------------------
	TXURL& operator =(TXURL& newUrl);
	//---------------------
	void set(TXURL& newUrl);
	bool set(const char* strURL);
	bool set(const char* strHost, const char* strFile);
	bool setHost(const char* strHost);
	bool setFile(const char* strFile);
	//---------------------
	const char* getURL();
	char* editURL();
	const char* getFile();
	const char* getHost();
	//---------------------
	char* Encode(const char* strIn);
	char* Decode(const char* strIn);
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XURLH
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
