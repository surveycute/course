//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XURL.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h> // malloc realloc free
#include <string> // strdup
#pragma hdrstop
#include "XURL.h"
#include <./Buffer/XBuffer.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXURL::TXURL()
{
	//---------------------
	URL =  Host = File = NULL;
	//---------------------
}
//---------------------------------------------------------------------------
TXURL::TXURL(const char* strURL)
{
	//---------------------
	set(strURL); // ignore failure
	//---------------------
}
//---------------------------------------------------------------------------
TXURL::TXURL(const char* strHost, const char* strFile /*= NULL*/)
{
	//---------------------
	URL =  Host = File = NULL;
	//---------------------
	set(strHost, strFile); // ignore failure
	//---------------------
}
//---------------------------------------------------------------------------
TXURL::TXURL(TXURL& newUrl)
{
	//---------------------
	set(newUrl);
	//---------------------
}
//---------------------------------------------------------------------------
TXURL& TXURL::operator =(TXURL& newUrl)
{
	//---------------------
	set(newUrl);
	//---------------------
	return *this;
}
//---------------------------------------------------------------------------
TXURL::~TXURL()
{
	//---------------------
        if (URL) free(URL);
        if (Host) free(Host);
        if (File) free(File);
	//---------------------
}
//---------------------------------------------------------------------------
void TXURL::set(TXURL& newUrl)
{
	//---------------------
	if (URL) XURL_Free(URL);
	if (Host) XURL_Free(Host);
	if (File) XURL_Free(File);
	//---------------------
	URL = strdup(newUrl.URL);
	Host = strdup(newUrl.Host);
	File = strdup(newUrl.File);
	//---------------------
}
//---------------------------------------------------------------------------
bool TXURL::set(const char* strURL)
{
	char* p = (char*)strURL;
	char* pp;
	//---------------------
	if (URL) {XURL_Free(URL);URL = NULL;}
	if (Host) {XURL_Free(Host);Host = NULL;}
	if (File) {XURL_Free(File);File = NULL;}
	//---------------------
	if (strncmp(p, "http://",  7) == 0)
		p += 7;
	//---------------------
	URL = strdup(p);
	pp  = strchr(p, '/');
	if (pp && strlen(pp))
	{
                int lenHost = strlen(p) - strlen(pp);
		Host = (char*)XURL_Allocate(lenHost + 1/*NULL*/);
			if (!Host) return false;
		strncpy(Host, p, lenHost);
                Host[lenHost] = '\0';
		File = strdup(pp);
	}
	else
	{
		Host = strdup(p);
		File = strdup("/");
	}
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXURL::setHost(const char* strHost)
{
	//---------------------
	return set(strHost, File);
}
//---------------------------------------------------------------------------
bool TXURL::setFile(const char* strFile)
{
	//---------------------
	return set(Host, strFile);
}
//---------------------------------------------------------------------------
bool TXURL::set(const char* strHost, const char* strFile)
{
	//---------------------
	if (URL) XURL_Free(URL);
	//---------------------
        if (strncmp(strHost, "http://", 7) == 0)
                strHost += 7;
	//---------------------
        if (strHost != Host)
        {
        	if (Host) XURL_Free(Host);
	        Host = strdup(strHost);
        }
	//---------------------
        if (strFile != File)
        {
        	if (File) XURL_Free(File);
	        File = strdup(strFile);
        }
	//---------------------
	URL = (char*)XURL_Allocate(strlen(Host) + strlen(File) + 2/*NULL + Possible added slash*/ );
		if (!URL) return false;
	//---------------------
	URL[0] = '\0';
	//---------------------
	strcat(URL, Host);
	//---------------------
	if (!File)
		File = strdup("/");
	//---------------------
	if (!strlen(File))
		strcat(URL, "/");
	else
	{
		if (File[0] != '/')
			strcat(URL, "/");
		strcat(URL, File);
	}
	//---------------------
        if (File) XURL_Free(File);
        File = strdup(strFile);
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
const char* TXURL::getFile()
{
	//---------------------
	return File;
}
//---------------------------------------------------------------------------
const char* TXURL::getHost()
{
	//---------------------
	return Host;
}
//---------------------------------------------------------------------------
char* TXURL::editURL()
{
	//---------------------
	return URL;
}
//---------------------------------------------------------------------------
const char* TXURL::getURL()
{
	//---------------------
	return URL;
}
//---------------------------------------------------------------------------
char* TXURL::Encode(const char* strIn)
{
        div_t divResult;
        TXBuffer Buff;
        int diff;
        unsigned char* pp;
        const char* p = strIn;
        char strHex[4] = "%00";
	//---------------------
        if (!Buff.setSize(strlen(strIn) + 1/*NULL*/))
                return NULL;
        pp = Buff.editData();
	//---------------------
        while (*p != '\0')
        {
        	//---------------------
                if (    (*p >= 'a' && *p <= 'z') ||
                        (*p >= 'A' && *p <= 'Z') ||
                        (*p >= '0' && *p <= '9') ||
                        *p == '/' || *p == '.' || *p == '+' || *p == '_')
                {
                	//---------------------
                        *(pp++) = *p;
                	//---------------------
                }
                else
                {
                	//---------------------
                        divResult = div((int)*p, 16);
                	//---------------------
                        if (divResult.quot > 9) divResult.quot += 55; // 'A' = 65    65 - 10 = 55   so 10 + 55 = 65 = A correct
                        else                    divResult.quot += 48; // '0' = 48
                	//---------------------
                        if (divResult.rem > 9)  divResult.rem  += 55;
                        else                    divResult.rem  += 48;
                	//---------------------
                        strHex[1] = (char)divResult.quot;
                        strHex[2] = (char)divResult.rem;
                	//---------------------
                        diff = pp - Buff.getData();
                        if (!Buff.addSize(3))
                                return NULL;
                	//---------------------
                        pp = Buff.editData();
                        pp += diff;
                        memcpy(pp, strHex, 3);
                        pp += 3;
                	//---------------------
                }
        	//---------------------
                p++;
        	//---------------------
        } // while
	//---------------------
        *(pp++) = '\0';
	//---------------------
        return strdup(Buff.getString());
}
//---------------------------------------------------------------------------
char* TXURL::Decode(const char* strInPath)
{
	//---------------------
        // @TODO
	//---------------------
	return strdup(strInPath);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
