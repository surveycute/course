//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XLogger.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XLoggerH
#define XLoggerH
//---------------------------------------------------------------------------
#include <./File/XFile.h>
//---------------------------------------------------------------------------
class TXLogger
{
private:
	//---------------------
        TXFile File;
        char* LogFileName;
	//---------------------
public:
	//---------------------

//---------------------------
        TXLogger();
        TXLogger(const char* strLogFileName);
        ~TXLogger();
	//---------------------
        void Init(const char* strLogFileName);
        void Log(const char* strMessage);
        void Log(int iValue);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
