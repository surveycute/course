//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XFile.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <io.h>
#include <string> // for strlen()
#include <sys/stat.h>
#pragma hdrstop
#include <File/XFile.h>
//---------------------------------------------------------------------------
TXFile::TXFile()
{
	//------------------
	Handle = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXFile::TXFile(const char* strFileName, const char* strMode /*= "rw"*/)
{
        //------------------
        Open(strFileName, strMode); // ignore failure, test with isOpen()
        //------------------
}
//---------------------------------------------------------------------------
TXFile::~TXFile()
{
	//------------------
	Close();
	//------------------
}
//---------------------------------------------------------------------------
bool TXFile::Open(const char* strFileName, const char* strMode /*= "rw"*/)
{
	//------------------
	Close();
	//------------------
	if ((Handle = fopen(strFileName, strMode)) == NULL)
		return false;
	//------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXFile::Clear(const char* strFileName)
{
	//------------------
        if (!Open(strFileName, "w+"))
                return false;
	//------------------
        Close();
	//------------------
	return true;
}
//---------------------------------------------------------------------------
void TXFile::Close()
{
	//------------------
	if (Handle)
	{
		fclose(Handle);
		Handle = NULL;
	}
	//------------------
}
//---------------------------------------------------------------------------
FILE* TXFile::getHandle()
{
	//------------------
	return Handle;
}
//---------------------------------------------------------------------------
void TXFile::setHandle(FILE* pf)
{
	//------------------
	if (!Handle)
                Handle = pf;
	//------------------
}
//---------------------------------------------------------------------------
bool TXFile::setCursor(long lOffset, int Source /*= SEEK_SET*/) // SEEK_SET, SEEK_CUR, SEEK_END
{
	//------------------
        if (!Handle)
                return false;
	//------------------
        return (fseek(Handle, lOffset, Source) == 0);
}
//---------------------------------------------------------------------------
unsigned long TXFile::getLength(bool bRestoreCursor /*= true*/)
{
        unsigned long curPos, rLen;
	//------------------
        if (!Handle)
                return 0L;
	//------------------
        if (bRestoreCursor)
        {
        	//------------------
                curPos = ftell(Handle);
                fseek(Handle, 0L, SEEK_END);
                rLen = ftell(Handle);
                fseek(Handle, curPos, SEEK_SET);
        	//------------------
                return rLen;
        }
	//------------------
        fseek(Handle, 0L, SEEK_END);
	//------------------
        return ftell(Handle);;
}
//---------------------------------------------------------------------------
bool TXFile::WriteChar(const unsigned char& c)
{
	//------------------
	if (!Handle)
		return false;
	//------------------
	return (fputc(c, Handle) == c);
}
//---------------------------------------------------------------------------
int TXFile::ReadChar()
{
	//------------------
	if (!Handle)
		return XF_ERROR;
	//------------------
	return getc(Handle);
}
//---------------------------------------------------------------------------
int TXFile::Read(void* pBuffer, const int& Len)
{
	//------------------
	if (!Handle)
		return XF_ERROR;
	//------------------
	return (int)fread(pBuffer, 1/*Size*/, Len/*Items*/, Handle); // returns 'Items' read, not bytes
}
//---------------------------------------------------------------------------
bool TXFile::Write(const void* pBuffer, const int& Len)
{
	//------------------
	if (!Handle)
		return false;
	//------------------
	return (fwrite(pBuffer, Len/*Size*/, 1/*Items*/, Handle) == 1); // fwrite returns items wrote, not bytes
}
//---------------------------------------------------------------------------
bool TXFile::WriteString(const char* str, int Len /*= -1*/)
{
	//------------------
        if (Len == -1) Len = (int)strlen(str);
	//------------------
	return (int)Write(str, Len);
}
//---------------------------------------------------------------------------
int TXFile::ReadString(char* str, const int& Len)
{
	int r;
	//------------------
	r = Read(str, Len);
	if (r > 0)
		str[r] = '\0';
	//------------------
	return r;
}
//---------------------------------------------------------------------------
bool TXFile::isOpen() const
{
	//------------------
	return (Handle != NULL);
}
//---------------------------------------------------------------------------
bool TXFile::fileExists(const char* strFileName) const
{
	//------------------
	return (access(strFileName, 0/*exists*/) == 0);
}
//---------------------------------------------------------------------------
bool TXFile::fileReadable(const char* strFileName) const
{
	//------------------
	return (access(strFileName, 4/*readable*/) == 0);
}
//---------------------------------------------------------------------------
bool TXFile::fileWritable(const char* strFileName) const
{
	//------------------
	return (access(strFileName, 2/*writable*/) == 0);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
