//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XFile.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XFileH
#define XFileH
//---------------------------------------------------------------------------
#include <stdio.h> // needed for FILE
#define XF_ERROR  (-2)
//---------------------------------------------------------------------------
class TXFile
{
private:
	//---------------------
	FILE* Handle;
	//---------------------
public:
//---------------------------
	TXFile();
        TXFile(const char* strFileName, const char* strMode = "rw"); // r w a +  t/b
        ~TXFile();
        //---------------------
        bool Open(const char* strFileName, const char* strMode = "rw"); // r w a +  t/b
	void Close();
        bool Clear(const char* strFileName); // File will be left closed, and needs not be opened already
	//---------------------
        FILE* getHandle();
        void setHandle(FILE* pf); // Current file must be closed. For injecting an already open file handle
	//---------------------
        bool setCursor(long lOffset, int Source = SEEK_SET); // SEEK_SET, SEEK_CUR, SEEK_END
	//---------------------
        unsigned long getLength(bool bRestoreCursor = true);
	bool WriteChar(const unsigned char& c);
	int ReadChar(); // returns character, EOF(-1), or XF_ERROR(-2)
	//---------------------
	int Read(void* pBuffer, const int& Len); // returns bytes read. Short count, possibly zero, on EOF, or XF_ERROR
	bool Write(const void* pBuffer, const int& Len);
	//---------------------
	bool WriteString(const char* str, int Len = -1); // same as Write
	int ReadString(char* str, const int& Len); // returns bytes read, EOF(-1), or XF_ERROR(-2)
	//---------------------
	bool isOpen() const;
	bool fileExists(const char* strFileName) const;
	bool fileReadable(const char* strFileName) const;
	bool fileWritable(const char* strFileName) const;
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
