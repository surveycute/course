//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XLogger.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <string>
#pragma hdrstop
#include <./File/XLogger.h>
//---------------------------------------------------------------------------
TXLogger::TXLogger()
{
	//------------------
        LogFileName = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXLogger::TXLogger(const char* strLogFileName)
{
	//------------------
        LogFileName = NULL;
        Init(strLogFileName);
	//------------------
}
//---------------------------------------------------------------------------
TXLogger::~TXLogger()
{
	//------------------
        if (LogFileName) {free(LogFileName); LogFileName = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
void TXLogger::Init(const char* strLogFileName)
{
	//------------------
        if (LogFileName) {free(LogFileName); LogFileName = NULL;}
        LogFileName = strdup(strLogFileName);
	//------------------
}
//---------------------------------------------------------------------------
void TXLogger::Log(const char* strMessage)
{
	//------------------
        if (!LogFileName || !strMessage)
                return;
	//------------------
        if (!File.Open(LogFileName, "a+"))
                return;
	//------------------
        File.WriteString(strMessage);
        File.WriteString("\n");
	//------------------
        File.Close();
	//------------------
}
//---------------------------------------------------------------------------
void TXLogger::Log(int iValue)
{
        char str[12];
	//------------------
        if (!LogFileName)
                return;
	//------------------
        if (!File.Open((const char*)LogFileName, "a+"))
                return;
	//------------------
        itoa(iValue, str, 10);
        File.WriteString(str);
        File.WriteString("\n");
	//------------------
        File.Close();
	//------------------
}
//---------------------------------------------------------------------------


//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
