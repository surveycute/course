//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplayLineBlock.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <string>
#pragma hdrstop
#include <./Yahoo/XYahooDisplayLineBlock.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooDisplayLineBlockFont::TXYahooDisplayLineBlockFont()
{
	//------------------
        maskValid = fmNone;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooDisplayLineBlockFont::TXYahooDisplayLineBlockFont(const TXYahooDisplayLineBlockFont& r)
{
	//------------------
        Copy(r);
	//------------------
}
//---------------------------------------------------------------------------
TXYahooDisplayLineBlockFont::~TXYahooDisplayLineBlockFont()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLineBlockFont::Copy(const TXYahooDisplayLineBlockFont& r)
{
	//------------------
        maskValid       = r.maskValid;
        Height          = r.Height;
        Size            = r.Size;
        Color           = r.Color;
	//------------------
}
//---------------------------------------------------------------------------
//*************************************************************************//
//---------------------------------------------------------------------------
TXYahooDisplayLineBlock::TXYahooDisplayLineBlock()
{
	//------------------
        Type = fmtNone;
        Text = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooDisplayLineBlock::TXYahooDisplayLineBlock(const TXYahooDisplayLineBlock& lb)
{
	//------------------
        Copy(lb);
	//------------------
}
//---------------------------------------------------------------------------
TXYahooDisplayLineBlock::~TXYahooDisplayLineBlock()
{
	//------------------
        if (Text) XYahoo_Free(Text);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLineBlock::Copy(const TXYahooDisplayLineBlock& lb)
{
	//------------------
        if (lb.Text)    Text = strdup(lb.Text);
        else            Text = NULL;
	//------------------
        Font.Copy(lb.Font);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLineBlock::setText(const char* str)
{
	//------------------
        if (Text) XYahoo_Free(Text);
        Text = strdup(str);
        lenText = strlen(Text);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLineBlock::setText(const char* str, unsigned short len)
{
	//------------------
        if (Text) XYahoo_Free(Text);
	//------------------
        Text = (char*)malloc(len + 1);
        if (!Text)
        {
                lenText = 0;
                return;
        }
	//------------------
        strncpy(Text, str, len);
        Text[len] = 0;
        lenText = len;
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooDisplayLineBlock::getText() const
{
	//------------------
        return (const char*)Text;
}
//---------------------------------------------------------------------------
char* TXYahooDisplayLineBlock::editText()
{
	//------------------
        return Text;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
