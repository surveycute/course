//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooUser.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <string.h>
#include <limits.h> // Used for incrementor: INT_MAX, INT_MIN
#pragma hdrstop
#include <./Yahoo/XYahooUser.h>
#include <./Yahoo/XYahooChannel.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooUser::TXYahooUser()
{
	//------------------
        RefCount = 0;
        Name = NULL;
        State = NULL;
        INF = NULL;
        Age = 0;
        Sex = 'U';
	//------------------
}
//---------------------------------------------------------------------------
TXYahooUser::~TXYahooUser()
{
	//------------------
        Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooUser::Clear()
{
	//------------------
        if (Name) {XYahoo_Free(Name);Name = NULL;}
        if (State) {XYahoo_Free(State);State = NULL;}
        if (INF) {XYahoo_Free(INF);INF = NULL;}
        //------------------
        Age = 0;
        Sex = 'U';
	//------------------
        pChannels.Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooUser::incRefCount()
{
	//------------------
        if (RefCount < INT_MAX)
                RefCount++;
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooUser::decRefCount()
{
	//------------------
        if (RefCount > INT_MIN)
                RefCount++;
	//------------------
}
//---------------------------------------------------------------------------
bool TXYahooUser::isRefCount() const
{
	//------------------
        return (RefCount != 0);
}
//---------------------------------------------------------------------------
const int TXYahooUser::getRefCount() const
{
	//------------------
        return RefCount;
}
//---------------------------------------------------------------------------
void TXYahooUser::setName(const char* strName)
{
	//------------------
        if (Name) {XYahoo_Free(Name);Name = NULL;}
        Name = strdup(strName);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooUser::getName() const
{
	//------------------
        return Name;
}
//---------------------------------------------------------------------------
void TXYahooUser::setState(const char* strState)
{
	//------------------
        if (State) {XYahoo_Free(State);State = NULL;}
        State = strdup(strState);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooUser::getState() const
{
        //------------------
        return State;
}
//---------------------------------------------------------------------------
void TXYahooUser::setINF(const char* strINF)
{
        //------------------
        if (INF) {XYahoo_Free(INF);INF = NULL;}
        INF = strdup(INF);
        //------------------
}
//---------------------------------------------------------------------------
const char* TXYahooUser::getINF() const
{
        //------------------
        return State;
}
//---------------------------------------------------------------------------


//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
