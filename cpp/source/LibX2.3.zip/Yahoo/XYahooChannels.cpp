//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooChannels.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <mem.h>
#pragma hdrstop
#include <./Yahoo/XYahooChannels.h>
#include <./Yahoo/XYahooClient.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooChannels::TXYahooChannels()
{
	//------------------
        ID = 4;
        Count = 0L;
        pYahooClient = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooChannels::~TXYahooChannels()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChannels::setYahooClient(TXYahooClient* psetYahooClient)
{
	//------------------
        pYahooClient = psetYahooClient;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooChannel* TXYahooChannels::AddNew(const char* strTitle, XChannelType Type /*= xctNone*/)
{
        TXYahooChannel* pChannel = Add();
	//------------------
        if (!pChannel)
                return NULL;
	//------------------
        if (strTitle)   pChannel->Set(pYahooClient, strTitle);
        else            pChannel->setYahooClient(pYahooClient);
        pChannel->Type = Type;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addChatEnter();
        if (!pLine)
                return NULL;
        pLine->Type = xrdtNone;
	//------------------
        if (pYahooClient && pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyNewChannel(*pChannel, *pLine);
	//------------------
        return pChannel;
}
//---------------------------------------------------------------------------
bool TXYahooChannels::DeleteByTitle(const char* strTitle) //Title is room name or PM name
{
        TXYahooChannel** pChannels =  (TXYahooChannel**)editList();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pChannels[i]->isTitle(strTitle))
                        return Delete(pChannels[i]);
	//------------------
        return false;
}
//---------------------------------------------------------------------------
TXYahooChannel* TXYahooChannels::getByTitle(const char* strTitle)
{
        TXYahooChannel** pChannels =  (TXYahooChannel**)editList();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pChannels[i]->isTitle(strTitle))
                        return pChannels[i];
	//------------------
        return NULL;
}
//---------------------------------------------------------------------------
TXYahooChannel* TXYahooChannels::getaddStatus()
{
        TXYahooChannel** pChannels = (TXYahooChannel**)editList();
        unsigned long i, c = getCount();
	//------------------
        for (i = 0L;i < c;++i)
                if (pChannels[i]->Type == xctStatus)
                        return pChannels[i];
	//------------------
        TXYahooChannel* pChannel;
        char* str;
        const char* strAlias;
        int len;
	//------------------
        strAlias = pYahooClient->Session.Account.getAlias();
        if (!strAlias)
                return NULL;
        len = strlen(strAlias);
        len += 3;
	//------------------
        str = (char*)XYahoo_Allocate(len);
        if (!str)
                return NULL;
	//------------------
        str[0] = '<';
        str[1] = '\0';
        strcat(str, strAlias);
        strcat(str, ">");
	//------------------
        pChannel = AddNew(str, xctStatus);
	//------------------
        XYahoo_Free(str);
	//------------------
        if (!pChannel)
                return NULL;
	//------------------
        return pChannel;
}
//---------------------------------------------------------------------------
TXYahooChannel* TXYahooChannels::getaddRoom(const char* strRoomName)
{
        TXYahooChannel** pChannels = (TXYahooChannel**)editList();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pChannels[i]->isTitle(strRoomName))
                        return pChannels[i];
	//------------------
        TXYahooChannel* pChannel = AddNew(strRoomName/*strTitle*/, xctChat);
	//------------------
        if (!pChannel)
                return NULL;
	//------------------
        XLOG("Channels getaddRoom:");
        XLOG(strRoomName);
	//------------------
        return pChannel;
}
//---------------------------------------------------------------------------
TXYahooChannel* TXYahooChannels::getaddUser(const char* strUser)
{
        TXYahooChannel** pChannels = (TXYahooChannel**)editList();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pChannels[i]->isTitle(strUser))
                        return pChannels[i];
	//------------------
        TXYahooChannel* pChannel = AddNew(strUser/*strTitle*/, xctPager);
        pChannel->pPagerUser = pYahooClient->Users.getadd(strUser);
        if (!pChannel->pPagerUser)
                return NULL;
	//------------------
        pChannel->pPagerUser->incRefCount();
	//------------------
        if (!pChannel)
                return NULL;
	//------------------
        XLOG("Channels getaddUser:");
        XLOG(strUser);
	//------------------
        return pChannel;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
