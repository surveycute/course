//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooAccounts.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <mem.h>
#pragma hdrstop
#include <./Yahoo/XYahooAccounts.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooAccounts::TXYahooAccounts() : TXList<TXYahooAccount>()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
