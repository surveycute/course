//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XQuickMessage.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <string.h>
#pragma hdrstop
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Yahoo/XQuickMessage.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXQuickMessage::TXQuickMessage()
{
	//------------------
        AutoSend = false;
        Title = NULL;
        Message = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXQuickMessage::~TXQuickMessage()
{
	//------------------
        if (Title)   {XYahoo_Free(Title);Title = NULL;}
        if (Message) {XYahoo_Free(Message);Message = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
const char* TXQuickMessage::getTitle() const
{
	//------------------
	return Title;
}
//---------------------------------------------------------------------------
const char* TXQuickMessage::getMessage() const
{
	//------------------
        return Message;
}
//---------------------------------------------------------------------------
const bool TXQuickMessage::isAutoSend() const
{
	//------------------
        return AutoSend;
}
//---------------------------------------------------------------------------
void TXQuickMessage::setTitle(const char* strTitle)
{
	//------------------
        if (Title) XYahoo_Free(Title);
	//------------------
        if (strTitle) Title = strdup(strTitle);
        else          Title = NULL;
	//------------------
}
//---------------------------------------------------------------------------
void TXQuickMessage::setMessage(const char* strMessage)
{
	//------------------
        if (Message) XYahoo_Free(Message);
	//------------------
        if (strMessage) Message = strdup(strMessage);
        else            Message = NULL;
	//------------------
}
//---------------------------------------------------------------------------
void TXQuickMessage::setAutoSend(bool bAuto)
{
	//------------------
        AutoSend = bAuto;
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
