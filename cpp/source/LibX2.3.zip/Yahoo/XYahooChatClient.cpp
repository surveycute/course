//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooChatClient.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdio.h>
#pragma hdrstop
//---------------------------------------------------------------------------
#include <./Yahoo/XYahooChatClient.h>
#include <./Yahoo/Protocol/XYMSGSession.h>
#include <./Yahoo/XYahooClient.h>
#include <./Yahoo/XYahooDisplay.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooChatClient::TXYahooChatClient() 
{
	//------------------
        pYahooClient = NULL;
        Handler.setChatClient(this);
	//------------------
}
//---------------------------------------------------------------------------
TXYahooChatClient::~TXYahooChatClient()
{
	//------------------
        tempLine.Reset();
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient::setYahooClient(TXYahooClient* psetYahooClient)
{
	//------------------
        pYahooClient = psetYahooClient;
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient:: DroppedMessage(short int Code, const char* strRoomName, const char* strUser, const char* strMessage)
{
        char* str;
        TXYahooDisplayLine* pLine;
	//------------------
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddStatus();
	//------------------
        if (!pChannel)
                return;
	//------------------
        if (!strUser || !strRoomName)
        {
                str = (char*)XYahoo_Allocate(61);
                if (str)
                {
                        sprintf(str, "***DROP:<missing name or room> code %d", (unsigned int)((unsigned)Code) );
                        pLine = pChannel->Lines.addSystem(str);
                        XYahoo_Free(str);
                }
        }
        else
        {
                str = (char*)XYahoo_Allocate(strlen(strUser) + strlen(strRoomName) + 41);
                if (str)
                {
                        sprintf(str, "***DROP(Chat Message):%s (%s) code %d", strUser, strRoomName, (unsigned int)((unsigned)Code) );
                        pLine = pChannel->Lines.addSystem(str);
                        XYahoo_Free(str);
                }
        }
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyChatLine(*pChannel, *pLine);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient::ReceiveMessage(const char* strRoomName, const char* strUser, const char* strMessage)
{
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddRoom(strRoomName);
	//------------------
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addChatMessage(strUser, strMessage);
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyChatLine(*pChannel, *pLine);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient::EnterRoom(const char* strRoomName, const char* strAlias)
{
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddRoom(strRoomName);
	//------------------
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addChatEnter();
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyChatLine(*pChannel, *pLine);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient::JoinedRoom(const char* strRoomName, const char* strUser)
{
        TXYahooChannel* pChannel = pYahooClient->Channels.getByTitle(strRoomName);
	//------------------
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addChatUserJoin(strUser);
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
        {
                pYahooClient->pDisplay->notifyChatLine(*pChannel, *pLine);
                pYahooClient->pDisplay->notifyChatUserList(*pChannel);
        }
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient::LeftRoom(const char* strRoomName, const char* strUser)
{
        TXYahooChannel* pChannel = pYahooClient->Channels.getByTitle(strRoomName);
	//------------------
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addChatUserLeave(strUser);
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
        {
                pYahooClient->pDisplay->notifyChatLine(*pChannel, *pLine);
                pYahooClient->pDisplay->notifyChatUserList(*pChannel);
        }
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient::SendMessage(TXYMSGSession& Session, const char* strMessage)
{
	//------------------
        if (Session.ChatStatus != ymsgchatChatting)
                return;
	//------------------
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddRoom(Session.getRoomName());
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addChatMessage(Session.Account.getAlias(), strMessage, true/*bSelf*/);
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyChatLine(*pChannel, *pLine);
	//------------------
        Session.Builder.ChatMessage(Session, strMessage); // ignore error
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChatClient::UpdateUserList(const char* strRoomName)
{
        TXYahooChannel* pChannel = pYahooClient->Channels.getByTitle(strRoomName);
	//------------------
        if (!pChannel)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyChatUserList(*pChannel);
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
