//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooCaptcha.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include "XYahooCaptcha.h"
#include <./Yahoo/Protocol/XYMSGConstants.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooCaptcha::TXYahooCaptcha()
{
	//------------------
        Status = ycapReady;
        GETParams  = strdup("Accept-Language: en\r\nAccept: */*\r\nUser-Agent: Mozilla/4.0 (compatible; YahElite 324.7) \r\nCache-Control: no-cache\r\nConnection: close\r\nReferer: http://");
        POSTParams = strdup("Accept-Language: en\r\nAccept: */*\r\nUser-Agent: Mozilla/4.0 (compatible; YahElite 324.7) \r\nCache-Control: no-cache\r\nConnection: close\r\nReferer: http://");
        CaptchaAddress = NULL;
        ImageAddress = NULL;
        HTTPClient.setHTTPVersionString("HTTP/1.0");
	//------------------
}
//---------------------------------------------------------------------------
TXYahooCaptcha::~TXYahooCaptcha()
{
	//------------------
        if (GETParams)  XYahoo_Free(GETParams);
        if (POSTParams) XYahoo_Free(POSTParams);
	//------------------
        if (CaptchaAddress)  XYahoo_Free(CaptchaAddress);
        if (ImageAddress) XYahoo_Free(ImageAddress);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooCaptcha::Clear(bool bClean /*= true*/)
{
	//------------------
        if (CaptchaAddress)  {XYahoo_Free(CaptchaAddress);CaptchaAddress = NULL;}
        if (ImageAddress) {XYahoo_Free(ImageAddress);ImageAddress = NULL;}
	//------------------
        HTTPClient.ClearData(bClean);
        Status = ycapReady;
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooCaptcha::setGetParams(const char* strGetParams)
{
	//------------------
        if (GETParams)  XYahoo_Free(GETParams);
        GETParams = strdup(strGetParams);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooCaptcha::setPostParams(const char* strPostParams)
{
	//------------------
        if (POSTParams)  XYahoo_Free(POSTParams);
        POSTParams = strdup(strPostParams);
	//------------------
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::Step()
{
	//------------------
        switch (Status)
        {
                case ycapReady:
                        return true;
                case ycapGetting: // Getting request is already done
                        if (!HTTPClient.Step())
                        {
                        	//------------------
                                if (!HTTPClient.isDone())
                                {
                                        XLOG("Captcha Step ycapGetting - HTTPClient:Step Failed ");
                                        Status = ycapError;
                                }
                                else
                                {
                                	//------------------
                                        if (HTTPClient.getReplyCode() != 200/*Ok*/)
                                        {
                                                Status = ycapError;
                                                XLOG("Captcha Step ycapGetting - HTTP Reply Failure:");
                                                XLOG(HTTPClient.getReplyCode());
                                        }
                                        else if (strncmp(HTTPClient.getData(), "\xFF\xD8\xFF\xE0", 4) != 0)
                                        {
                                                Status = ycapError;
                                                XLOG("Captcha Step ycapGetting - Data key not valid");
                                        }
                                        else
                                                Status = ycapUserInput;
                                	//------------------
                                }
                        	//------------------
                                return false;
                        }
                        return true;
                case ycapPosting: // Post request is already done
                        if (!HTTPClient.Step())
                        {
                        	//------------------
                                if (!HTTPClient.isDone() || HTTPClient.getReplyCode() != 301/*Moved Permanently*/)
                                {
                                        XLOG("Captcha Step ycapGetting - HTTP Reply not 301 or HTTPClient:Step failed:");
                                        XLOG(HTTPClient.getReplyCode());
                                        Status = ycapError;
                                }
                                else
                                        Status = ycapDone;
                        	//------------------
                                return false;
                        }
                        return true;
                case ycapUserInput:
                        return false; // wait for input
                case ycapDone:
                        Clear(false/*bClean*/); // sets Status to ycapReady
                        Status = ycapDone;
                        return false; // could fall through
                case ycapError:
                        XLOG("Captcha Step ycapError - Execute while on error");
                        return false; // done/error
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::ParseMessage(char* str)
{
        int mCount = 0; // match Index/Counter
        char* pTemp;
        char strMatchHTTP[] = "http://";
        char strMatchJPG[] = ".jpg";
        char tempBuffer[1024];
	//------------------ Find first http://
        while (*str != '\0' && mCount < 7/*http://*/)
        {
        	//------------------
                if (*str == strMatchHTTP[mCount])
                        mCount++;
                else
                        mCount = 0;
        	//------------------
                str++;
        	//------------------
        }
	//------------------
        if (mCount != 7)
                return false;
	//------------------ Copy from http:// start till next /
        pTemp = tempBuffer;
        pTemp[0] = '\0';
        strcat(pTemp, "http://");
        pTemp += 7;
	//------------------
        while (*str != '\0' && *str != '/')
        {
        	//------------------
                *pTemp = *str;
                str++;
                pTemp++;
        	//------------------
        }
	//------------------
        *pTemp = '\0'; // add NULL terminator (pTemp = strTempCaptcha)
        if (CaptchaAddress) XYahoo_Free(CaptchaAddress);
        CaptchaAddress = strdup(tempBuffer);
        mCount = 0;
	//------------------ Find next http://
        while (*str != '\0' && mCount < 7/*http://*/)
        {
        	//------------------
                if (*str == strMatchHTTP[mCount])
                        mCount++;
                else
                        mCount = 0;
        	//------------------
                str++;
        	//------------------
        }
	//------------------
        if (mCount != 7)
                return false;
	//------------------ Copy till end .jpg
        mCount = 0;
        pTemp = tempBuffer;
        pTemp[0] = '\0';
        strcat(pTemp, "http://");
        pTemp += 7;
      	//------------------
        while (str != '\0' && mCount < 4)
        {
               	//------------------
                if (*str == strMatchJPG[mCount]) mCount++;
                else                             mCount = 0;
               	//------------------
                *pTemp = *str;
                //------------------
                pTemp++;
                str++;
                //------------------
        }
        //------------------
        *pTemp = '\0'; // add NULL terminator (pTemp = strTempImage)
        //------------------
        if (mCount != 4)
                return false;
	//------------------
        if (ImageAddress) XYahoo_Free(ImageAddress);
        ImageAddress = strdup(tempBuffer);
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::RequestCaptcha(char* strMessage /*= NULL*/)
{
        char strParam[5024];
	//------------------
        XLOG("RequestCatptcha...");
        if (Status == ycapDone || Status == ycapError)
                Clear(false/*bClean*/);
        else if (Status != ycapReady)
                {Status = ycapError;return false;}
	//------------------
        if (strMessage)
                if (!ParseMessage(strMessage))
                        {Status = ycapError;return false;}
	//------------------
        if (!HTTPClient.URL.set(ImageAddress))
                {Status = ycapError;return false;}
	//------------------ Prepare GET HTTP parameters
        strParam[0] = '\0';
        strcat(strParam, GETParams);
        strcat(strParam, HTTPClient.URL.getHost()); // referal
        strcat(strParam, "\r\n");
	//------------------
        HTTPClient.setHTTPParameters(strParam);
	//------------------
        if (!HTTPClient.GET())
                {Status = ycapError;return false;}
	//------------------
        Status = ycapGetting;
        XLOG("RequestCatptcha...Done ;ycapGetting...");
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::PostReply(char* strReply)
{
        char strParam[5024];
        char strBuffer[5024];
        char* tmpImageAddress;
	//------------------
        XLOG("Captcha PostReply...");
        if (Status != ycapUserInput)
                return false;
	//------------------
        strBuffer[0] = '\0';
        strcat(strBuffer, "question=");
	//------------------
        tmpImageAddress = HTTPClient.URL.Encode(ImageAddress);
        if (!tmpImageAddress)
                return false;
	//------------------
        strcat(strBuffer, tmpImageAddress);
        XYahoo_Free(tmpImageAddress);
	//------------------
        strcat(strBuffer, "&.intl=us&answer=");
        strcat(strBuffer, strReply);
	//------------------
        if (!HTTPClient.URL.set(CaptchaAddress, "/captcha1"))
                {Status = ycapError;return false;}
	//------------------
        Status = ycapPosting;
	//------------------
        strParam[0] = '\0';
        strcat(strParam, POSTParams);
        strcat(strParam, HTTPClient.URL.getHost()); // referal
        strcat(strParam, "\r\n");
	//------------------
        HTTPClient.setHTTPParameters(strParam);
	//------------------
        if (!HTTPClient.POST(strBuffer, strlen(strBuffer)))
                {Status = ycapError;return false;}
	//------------------
        XLOG("Captcha PostReply...Done");
	//------------------
        return true;
}
//---------------------------------------------------------------------------
const unsigned long TXYahooCaptcha::getImageSize() const
{
	//------------------
        if (Status != ycapUserInput)
                return 0L;
	//------------------
        return HTTPClient.getDataSize();
}
//---------------------------------------------------------------------------
const char* TXYahooCaptcha::getImageData() const
{
	//------------------
        return HTTPClient.getData();
}
//---------------------------------------------------------------------------
XYahooCaptchaStatusType TXYahooCaptcha::getStatus() const
{
	//------------------
        return Status;
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::isDone() const
{
	//------------------
        return (Status == ycapDone);
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::isError() const
{
	//------------------
        return (Status == ycapError);
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::isReady() const
{
	//------------------
        return (Status == ycapReady);
}
//---------------------------------------------------------------------------
bool TXYahooCaptcha::isUserInput() const
{
	//------------------
        return (Status == ycapUserInput);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
