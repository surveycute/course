//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooChatClient.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooChatClientH
#define XYahooChatClientH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Handler/XYMSGHandlerChatClient.h>
#include <./Yahoo/XYahooDisplayLine.h>
//---------------------------------------------------------------------------
class TXYMSGSession; // predefined
class TXYahooClient; // predefined
//---------------------------------------------------------------------------
class TXYahooChatClient
{
private:
	//---------------------
        TXYahooDisplayLine tempLine;
	//---------------------
public:
	//---------------------
        TXYahooClient* pYahooClient;
        TXYMSGHandlerChatClient Handler;
//---------------------------
        TXYahooChatClient();
        virtual ~TXYahooChatClient();
        void setYahooClient(TXYahooClient* psetYahooClient);
	//---------------------
        virtual void DroppedMessage(short int Code, const char* strRoomName, const char* strUser, const char* strMessage);
        virtual void ReceiveMessage(const char* strRoomName, const char* strUser, const char* strMessage);
	//---------------------
        virtual void EnterRoom(const char* strRoomName, const char* strAlias);
        virtual void JoinedRoom(const char* strRoomName, const char* strUser);
        virtual void LeftRoom(const char* strRoomName, const char* strUser);
	//---------------------
        virtual void SendMessage(TXYMSGSession& Session, const char* strMessage);
	//---------------------
        void UpdateUserList(const char* strRoomName);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
