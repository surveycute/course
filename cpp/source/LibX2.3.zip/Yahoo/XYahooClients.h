//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooClients.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooClientsH
#define XYahooClientsH
//---------------------------------------------------------------------------
#include <./List/XList.h>
#include <./Yahoo/XYahooClient.h>
//---------------------------------------------------------------------------
class TXYahooClients : public TXList<TXYahooClient>
{
        //---------------------
public:
        //---------------------
//---------------------------
        TXYahooClients();
        ~TXYahooClients();
	//---------------------
        bool Step(); // Run all on same thread (for testing)
        void DisconnectAll();
        TXYahooClient* needsCaptcha();
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
