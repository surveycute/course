//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooPagerClient.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooPagerClientH
#define XYahooPagerClientH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Handler/XYMSGHandlerPagerClient.h>
#include <./Yahoo/XYahooDisplayLine.h>
//---------------------------------------------------------------------------
class TXYMSGSession; // predefined
class TXYahooClient; // predefined
//---------------------------------------------------------------------------
class TXYahooPagerClient
{
private:
	//---------------------
        TXYahooDisplayLine tempLine;
	//---------------------
public:
	//---------------------
        TXYahooClient* pYahooClient;
        TXYMSGHandlerPagerClient Handler;
	//---------------------
//---------------------------
        TXYahooPagerClient();
        virtual ~TXYahooPagerClient(){};
        void setYahooClient(TXYahooClient* psetYahooClient);
	//---------------------
        virtual void Online(const char* strAlias);
        virtual void DroppedMessage(short int Code, const char* strUser, const char* strMessage);
        virtual void ReceiveMessage(const char* strUser, const char* strMessage);
	//---------------------
        virtual void SendMessage(TXYMSGSession& Session, const char* strUser, const char* strMessage);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
