//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooChannels.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooChannelsH
#define XYahooChannelsH
//---------------------------------------------------------------------------
#include <./List/XList.h>
#include <./Yahoo/XYahooChannel.h>
#include <./Yahoo/XYahooDisplayLine.h>
//---------------------------------------------------------------------------
class TXYahooDisplay; // pre defined
//---------------------------------------------------------------------------
class TXYahooChannels : public TXList<TXYahooChannel>
{
private:
	//---------------------
        TXYahooClient* pYahooClient;
	//---------------------
public:
	//---------------------
//---------------------------
        TXYahooChannels();
        ~TXYahooChannels();
        void setYahooClient(TXYahooClient* psetYahooClient);
	//---------------------
        TXYahooChannel* AddNew(const char* strTitle, XChannelType Type = xctNone);
        bool DeleteByTitle(const char* strTitle); //Title is room name or PM name
	//---------------------
        TXYahooChannel* getaddStatus();
        TXYahooChannel* getByTitle(const char* strTitle); //Title is room name or PM name
	//---------------------
        TXYahooChannel* getaddRoom(const char* strRoomName);
        TXYahooChannel* getaddUser(const char* strUser);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
