//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooCrypt.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#pragma hdrstop
//-------------------
#include <./Yahoo/Auth/XYahooMD5.h>
#include <./Yahoo/Auth/XYahooSHA.h>
#include <./Yahoo/Auth/XYahooAuth.h>
#include "XYahooCrypt.h"
//---------------------------------------------------------------------------

#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooCrypt::TXYahooCrypt()
{
   strcpy(md5_salt_prefix, "$1$");
   strcpy(b64t, "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");
   strcpy(base64digits, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._");
   strcpy(tAlphabet1,       "FBZDWAGHrJTLMNOPpRSKUVEXYChImkwQ");
   strcpy(tAlphabet2,	    "F0E1D2C3B4A59687abcdefghijklmnop");
   strcpy(tChallengeLookup, "qzec2tb3um1olpar8whx4dfgijknsvy5");
   strcpy(tOperandLookup,   "+|&%/*^-");
   strcpy(tDelimitLookup,   ",;");
}
//---------------------------------------------------------------------------
void TXYahooCrypt::to_y64(unsigned char *out, const unsigned char *in, int inlen)
{
	//------------------
        // Big endian to base 64 string
	for (; inlen >= 3; inlen -= 3)
	{
		*out++ = base64digits[in[0] >> 2];
		*out++ = base64digits[((in[0] << 4) & 0x30) | (in[1] >> 4)];
		*out++ = base64digits[((in[1] << 2) & 0x3c) | (in[2] >> 6)];
		*out++ = base64digits[in[2] & 0x3f];
		in += 3;
	}
	//------------------
	if (inlen > 0)
	{
		unsigned char fragment;
        	*out++ = base64digits[in[0] >> 2];
		fragment = (unsigned char)((in[0] << 4) & 0x30);
		if (inlen > 1)
			fragment |= (unsigned char)(in[1] >> 4);
		*out++ = base64digits[fragment];
		*out++ = (inlen < 2) ? '-' : base64digits[(in[1] << 2) & 0x3c];
		*out++ = '-';
	}
	//------------------
	*out = '\0';
	//------------------
}
//---------------------------------------------------------------------------
bool TXYahooCrypt::YahooCrypt(char* name, char* pass, char *seed, char* resp_6, char* resp_96)
{
        bool r = true;
        char* hash1 = NULL;
        char* hash2 = NULL;
        char* cryptr = NULL;
        //------------------
        hash1 = (char*)malloc(25);
        hash2 = (char*)malloc(25);
        cryptr = (char*)malloc(48);
        //------------------
        if (!hash2 || !hash1 || !cryptr)
            r = false;
        else if (!YahooCryptA(name, pass, seed, resp_6, resp_96, hash1, hash2, cryptr))
                    r = false;
        //------------------
        if (hash1)  {free(hash1);hash1 = NULL;}
        if (hash2)  {free(hash2);hash2 = NULL;}
        if (cryptr) {free(cryptr);cryptr = NULL;}
        //------------------
        return r;
}
//---------------------------------------------------------------------------
bool TXYahooCrypt::YahooCryptA(char* name, char* pass, char *seed, char* resp_6, char* resp_96, char* hash1, char* hash2, char* cryptr)
{
        md5_byte_t			result[16];
        md5_state_t			ctx;
        SHA_CTX				ctx1;
        SHA_CTX				ctx2;
        char* loc;
        char* alphabet1              = tAlphabet1;
        char* alphabet2		= tAlphabet2;
        char* challenge_lookup	= tChallengeLookup;
        char* operand_lookup		= tOperandLookup;
        char* delimit_lookup		= tDelimitLookup;
        char* password_hash		= hash1;
        char* crypt_hash		= hash2;
        char* crypt_result           = cryptr;
        char* buffer;
        char	pass_hash_xor1[64];
        char	pass_hash_xor2[64];
        char	crypt_hash_xor1[64];
        char	crypt_hash_xor2[64];
        unsigned char digest1[20];
        unsigned char digest2[20];
        unsigned char comparison_src[20];
        unsigned char magic_key_char[4];
        const unsigned char *magic_ptr;
        unsigned int	magic[64];
        unsigned int	magic_work = 0;
        unsigned int	magic_4 = 0;
	unsigned int	local_store;
        int 	x;
        int 	y;
        int 	cnt = 0;
        int 	magic_cnt = 0;
        int 	magic_len;
        //------------------
        memset(password_hash, 0, 25);
        memset(crypt_hash, 0, 25);
        memset(&pass_hash_xor1, 0, 64);
        memset(&pass_hash_xor2, 0, 64);
        memset(&crypt_hash_xor1, 0, 64);
        memset(&crypt_hash_xor2, 0, 64);
        memset(&digest1, 0, 20);
        memset(&digest2, 0, 20);
        memset(&magic, 0, 64);
        memset(resp_6, 0, 100);
        memset(resp_96, 0, 100);
        memset(&magic_key_char, 0, 4);
        memset(&comparison_src, 0, 20);
        //------------------
	magic_ptr = (unsigned char*)(seed);
        while (*magic_ptr != '\0')
        {
                //------------------
		if (*magic_ptr == '(' || *magic_ptr == ')') //Ignore parentheses.
                   {magic_ptr++;continue;}
                //------------------
		if (isalpha(*magic_ptr) || isdigit(*magic_ptr)) //Characters and digits verify against the challenge lookup.
                {
                        //------------------
			loc = strchr(challenge_lookup, *magic_ptr);
  			   if (!loc)
                              return false;  /* SME XXX Error - disconnect here */
                        //------------------
			magic_work = loc - challenge_lookup; // Get offset into lookup table and shl 3.
			magic_work <<= 3;
			magic_ptr++;
                        //------------------
			continue;
		}
                else
                {
                        //------------------
			loc = strchr(operand_lookup, *magic_ptr);
			   if (!loc)
                              return false;/* SME XXX Disconnect */
                        //------------------
			local_store = loc - operand_lookup;
			if (magic_cnt >= 64) break; // Shouldnt happen
			magic[magic_cnt++] = magic_work | local_store;
			magic_ptr++;
                        //------------------
			continue;
		}
                //------------------
	} // while (*magic_ptr != (int)NULL)
        //------------------
	magic_len = magic_cnt;
	magic_cnt = 0;
        //------------------
        unsigned char byte1;
        unsigned char byte2;
        //------------------
	for (magic_cnt = magic_len-2; magic_cnt >= 0; magic_cnt--)
        {
	   if ((magic_cnt + 1 > magic_len) || (magic_cnt > magic_len)) break; // Bad. Abort

	   byte1 = (unsigned char)(magic[magic_cnt]);
	   byte2 = (unsigned char)(magic[magic_cnt+1]);
	   byte1 *= (unsigned char)(0xcd);
	   byte1 ^= byte2;
	   magic[magic_cnt+1] = byte1;
        }
        //------------------
	unsigned int bl;
        unsigned int cl;
        //------------------
	magic_cnt = 1;
	x = 0;
	do
        {
                //------------------
	        bl = 0;
	        cl = magic[magic_cnt++];
                //------------------
	        if (magic_cnt >= magic_len)
		        break;
                //------------------
	        if (cl > 0x7F)
                {
                        //------------------
	   	        if (cl < 0xe0)	bl = cl = (cl & 0x1f) << 6;
	   	        else
                        {
                                //------------------
     		                bl = magic[magic_cnt++];
	   	                cl = (cl & 0x0f) << 6;
	   	                bl = ((bl & 0x3f) + cl) << 6;
                                //------------------
	   	        }
                        //------------------
	   	        cl = magic[magic_cnt++];
	   	        bl = (cl & 0x3f) + bl;
                        //------------------
	        }
                else	bl = cl;
                //------------------
	        comparison_src[x++] = (unsigned char)((bl & 0xff00) >> 8);
	        comparison_src[x++] =(unsigned char)( bl & 0xff);
                //------------------
	} while (x < 20);
        //------------------
	memcpy(&magic_key_char[0], comparison_src, 4); // First four bytes are magic key.
	magic_4 = magic_key_char[0] | (magic_key_char[1]<<8) | (magic_key_char[2]<<16) | (magic_key_char[3]<<24);
        //------------------
        int leave;
   	unsigned char	test[3];
        //------------------
	for (x = 0; x < 65535; x++)
        {
                //------------------
	        leave = 0;
	        for (y = 0; y < 5; y++)
                {
                        //------------------
	   	        memset(&result, 0, 16);
	   	        memset(&test, 0, 3);
		        test[0] = x;      // Calculate Buffer
		        test[1] = x >> 8;
		        test[2] = y;
		        md5_init(&ctx);
		        md5_append(&ctx, magic_key_char, 4);
		        md5_append(&ctx, test, 3);
		        md5_finish(&ctx, result);
		        if (!memcmp(result, comparison_src+4, 16)) {leave = 1;break;}
                        //------------------
                }
                //------------------
                if (leave == 1) break;
                //------------------
	} // for (x = 0; x < 65535; x++)
        //------------------
        if (y == 5) return false;
        //------------------
	if (y != 0) // If y != 0, we need some help.
        {
	        unsigned int	updated_key;
                //------------------
	        updated_key = yahoo_auth_finalCountdown(magic_4, 0x60, y, x);
	        updated_key = yahoo_auth_finalCountdown(updated_key, 0x60, y, x);
	        magic_key_char[0] = updated_key & 0xff;
	        magic_key_char[1] = (updated_key >> 8) & 0xff;
	        magic_key_char[2] = (updated_key >> 16) & 0xff;
	        magic_key_char[3] = (updated_key >> 24) & 0xff;
                //------------------
	}
        //------------------
	md5_init(&ctx);
        md5_append(&ctx, (const md5_byte_t*)pass, strlen(pass));
	md5_finish(&ctx, result);
        to_y64((unsigned char*)password_hash, (unsigned char*)result, 16);
	md5_init(&ctx);
        //------------------
        if (!YahooCryptB(pass, "$1$_2S43d5f$", crypt_result, 48))
           return false;
        //------------------
        md5_append(&ctx, (const md5_byte_t*)crypt_result, strlen(crypt_result));
	md5_finish(&ctx, result);
        //------------------
        to_y64((unsigned char*)crypt_hash, result, 16);
	for (x = 0; x < (int)strlen(password_hash); x++) pass_hash_xor1[cnt++] = password_hash[x] ^ 0x36;
	if (cnt < 64) memset(&(pass_hash_xor1[cnt]), 0x36, 64-cnt);
	cnt = 0;
	for (x = 0; x < (int)strlen(password_hash); x++) pass_hash_xor2[cnt++] = password_hash[x] ^ 0x5c;
	if (cnt < 64) memset(&(pass_hash_xor2[cnt]), 0x5c, 64-cnt);
        //------------------
	shaInit(&ctx1);
	shaInit(&ctx2);
        //------------------
        shaUpdate(&ctx1, (unsigned char*)pass_hash_xor1, 64);
	if (y >= 3) ctx1.sizeLo = 0x1ff;
	shaUpdate(&ctx1, magic_key_char, 4);
	shaFinal(&ctx1, digest1);
        //------------------
        shaUpdate(&ctx2, (unsigned char*)pass_hash_xor2, 64);
	shaUpdate(&ctx2, digest1, 20);
	shaFinal(&ctx2, digest2);
        //------------------
        unsigned int	val;
        unsigned int	lookup;
        char		byte[6];
        //------------------
	for (x = 0; x < 20; x += 2)
        {
                //------------------
	        val = 0;
	        lookup = 0;
                memset(&byte, 0, 6);
                //------------------
	        val = digest2[x]; // First two bytes of digest stuffed together.
	        val <<= 8;
	        val += digest2[x+1];
                //------------------
	        lookup = (val >> 0x0b);
	        lookup &= 0x1f;
	        if (lookup >= strlen(alphabet1))
                        break;
                //------------------
	        sprintf(byte, "%c", alphabet1[lookup]);
	        strcat(resp_6, byte);
	        strcat(resp_6, "=");
                //------------------
	        lookup = (val >> 0x06);
	        lookup &= 0x1f;
	        if (lookup >= strlen(alphabet2))
                        break;
                //------------------
	        sprintf(byte, "%c", alphabet2[lookup]);
	        strcat(resp_6, byte);
                //------------------
	        lookup = (val >> 0x01);
	        lookup &= 0x1f;
	        if (lookup >= strlen(alphabet2))
                        break;
                //------------------
	        sprintf(byte, "%c", alphabet2[lookup]);
	        strcat(resp_6, byte);
                //------------------
	        lookup = (val & 0x01);
	        if (lookup >= strlen(delimit_lookup))
                        break;
                //------------------
	        sprintf(byte, "%c", delimit_lookup[lookup]);
	        strcat(resp_6, byte);
                //------------------
	} // for (x = 0; x < 20; x += 2)
        //------------------
	cnt = 0;
	memset(&digest1, 0, 20);
	memset(&digest2, 0, 20);
        //------------------
	for (x = 0; x < (int)strlen(crypt_hash); x++)
                crypt_hash_xor1[cnt++] = crypt_hash[x] ^ 0x36;
	if (cnt < 64)
                memset(&(crypt_hash_xor1[cnt]), 0x36, 64-cnt);
        //------------------
	cnt = 0;
	for (x = 0; x < (int)strlen(crypt_hash); x++)
                crypt_hash_xor2[cnt++] = crypt_hash[x] ^ 0x5c;
	if (cnt < 64)
                memset(&(crypt_hash_xor2[cnt]), 0x5c, 64-cnt);
        //------------------
	shaInit(&ctx1);
	shaInit(&ctx2);
        //------------------
        shaUpdate(&ctx1, (unsigned char*)crypt_hash_xor1, 64);
	if (y >= 3) ctx1.sizeLo = 0x1ff;
	shaUpdate(&ctx1, magic_key_char, 4);
	shaFinal(&ctx1, digest1);
        //------------------
        shaUpdate(&ctx2, (unsigned char*)crypt_hash_xor2, 64);
	shaUpdate(&ctx2, digest1, 20);
	shaFinal(&ctx2, digest2);
        //------------------
	for (x = 0; x < 20; x += 2)
        {
                //------------------
		val = 0;
		lookup = 0;
		memset(&byte, 0, 6);
                //------------------
		val = digest2[x];
		val <<= 8;
		val += digest2[x+1];
                //------------------
		lookup = (val >> 0x0b);
		lookup &= 0x1f;
		if (lookup >= strlen(alphabet1))
			break;
                //------------------
		sprintf(byte, "%c", alphabet1[lookup]);
		strcat(resp_96, byte);
		strcat(resp_96, "=");
                //------------------
		lookup = (val >> 0x06);
		lookup &= 0x1f;
		if (lookup >= strlen(alphabet2))
			break;
                //------------------
		sprintf(byte, "%c", alphabet2[lookup]);
		strcat(resp_96, byte);
                //------------------
		lookup = (val >> 0x01);
		lookup &= 0x1f;
		if (lookup >= strlen(alphabet2))
			break;
                //------------------
		sprintf(byte, "%c", alphabet2[lookup]);
		strcat(resp_96, byte);
                //------------------
		lookup = (val & 0x01);
		if (lookup >= strlen(delimit_lookup))
			break;
                //------------------
		sprintf(byte, "%c", delimit_lookup[lookup]);
		strcat(resp_96, byte);
                //------------------
	} // for (x = 0; x < 20; x += 2)
        //------------------
        return true;
}
//------------------------------------------------------------------------------------
bool TXYahooCrypt::YahooCryptB(const char *key, const char *salt, char* buffer, int buflen)
{
	md5_byte_t alt_result[16];
	md5_state_t ctx;
	md5_state_t alt_ctx;
	size_t salt_len;
	size_t key_len;
	size_t cnt;
	char *cp;
        //------------------
	if (strncmp (md5_salt_prefix, salt, sizeof (md5_salt_prefix) - 1) == 0)
		salt += sizeof (md5_salt_prefix) - 1;
        //------------------
	salt_len = MIN (strcspn (salt, "$"), 8);
	key_len = strlen (key);
        //------------------
	md5_init(&ctx);
        //------------------
        md5_append(&ctx, (const md5_byte_t*)key, key_len);
        md5_append(&ctx, (const md5_byte_t*)md5_salt_prefix, sizeof (md5_salt_prefix) - 1);
        md5_append(&ctx, (const md5_byte_t*)salt, salt_len);
        //------------------
	md5_init(&alt_ctx);
        md5_append(&alt_ctx, (const md5_byte_t*)key, key_len);
        md5_append(&alt_ctx, (const md5_byte_t*)salt, salt_len);
        md5_append(&alt_ctx, (const md5_byte_t*)key, key_len);
        //------------------
	md5_finish(&alt_ctx, alt_result);
        //------------------
	for (cnt = key_len; cnt > 16; cnt -= 16)
		md5_append(&ctx, alt_result, 16);
        //------------------
	md5_append(&ctx, alt_result, cnt);
        //------------------
	alt_result[0] = '\0';
	for (cnt = key_len; cnt > 0; cnt >>= 1)
		md5_append(&ctx, (cnt & 1) != 0 ? alt_result : (md5_byte_t *)key, 1);
        //------------------
	md5_finish(&ctx, alt_result);
        //------------------
	for (cnt = 0; cnt < 1000; ++cnt)
        {
                //------------------
		md5_init(&ctx);
                //------------------
		if ((cnt & 1) != 0)
                        md5_append(&ctx, (const md5_byte_t*)key, key_len);
		else
			md5_append(&ctx, alt_result, 16);
                //------------------
		if (cnt % 3 != 0)
                        md5_append(&ctx, (const md5_byte_t*)salt, salt_len);
                //------------------
		if (cnt % 7 != 0)
                        md5_append(&ctx, (const md5_byte_t*)key, key_len);
                //------------------
		if ((cnt & 1) != 0)
			md5_append(&ctx, alt_result, 16);
		else
                        md5_append(&ctx, (const md5_byte_t*)key, key_len);
                //------------------
		md5_finish(&ctx, alt_result);
                //------------------
	} // for (cnt = 0; cnt < 1000; ++cnt)
        //------------------
	strncpy(buffer, md5_salt_prefix, MAX (0, buflen));
	cp = buffer + strlen(buffer);
	buflen -= sizeof (md5_salt_prefix);
        //------------------
	strncpy(cp, salt, MIN ((size_t) buflen, salt_len));
	cp = cp + strlen(cp);
	buflen -= MIN ((size_t) buflen, salt_len);
        //------------------
	if (buflen > 0) {
		*cp++ = '$';
		--buflen;
	}
        //------------------

#define b64_from_24bit(B2, B1, B0, N) \
	do { \
		unsigned int w = ((B2) << 16) | ((B1) << 8) | (B0); \
		int n = (N); \
		while (n-- > 0 && buflen > 0) { \
			*cp++ = b64t[w & 0x3f]; \
			--buflen; \
			w >>= 6; \
		}\
	} while (0)

        //------------------
	b64_from_24bit (alt_result[0], alt_result[6], alt_result[12], 4);
	b64_from_24bit (alt_result[1], alt_result[7], alt_result[13], 4);
	b64_from_24bit (alt_result[2], alt_result[8], alt_result[14], 4);
	b64_from_24bit (alt_result[3], alt_result[9], alt_result[15], 4);
	b64_from_24bit (alt_result[4], alt_result[10], alt_result[5], 4);
	b64_from_24bit (0, 0, alt_result[11], 2);
        //------------------
	if (buflen <= 0) return false;
	else             *cp = '\0';	/* Terminate the string.  */
        //------------------
	md5_init(&ctx);
	md5_finish(&ctx, alt_result);
	memset (&ctx, '\0', sizeof (ctx));
	memset (&alt_ctx, '\0', sizeof (alt_ctx));
        //------------------
	return true;
}
//------------------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
