//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooCrypt.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooCryptH
#define XYahooCryptH
//---------------------------------------------------------------------------
#define MIN(a,b) (a < b) ? a : b  
#define MAX(a,b) (a > b) ? a : b  
//---------------------------------------------------------------------------
class TXYahooCrypt
{
private:
	//---------------------
        char md5_salt_prefix[4];
        char b64t[65];
        char base64digits[65];
        char tAlphabet1[33];
        char tAlphabet2[33];
        char tChallengeLookup[33];
        char tOperandLookup[9];
        char tDelimitLookup[3];
	//---------------------
public:
	//---------------------
//---------------------------
	//---------------------
        TXYahooCrypt();
        void to_y64(unsigned char *out, const unsigned char *in, int inlen);
        bool YahooCrypt(char* name, char* pass, char *seed, char* resp_6, char* resp_96);
        bool YahooCryptA(char* name, char* pass, char *seed, char* resp_6, char* resp_96, char* hash1, char* hash2, char* cryptr);
        bool YahooCryptB(const char *key, const char *salt, char* buffer, int buflen);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
