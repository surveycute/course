//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplay.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooDisplayH
#define XYahooDisplayH
//---------------------------------------------------------------------------
//#include <./Yahoo/XYahooDisplayLine.h>
class TXYahooDisplayLine; // predefined
class TXYahooChannel; // predefined
//---------------------------------------------------------------------------
class TXYahooDisplay
{
private:
	//---------------------
	//---------------------
public:
	//---------------------
	//---------------------
//---------------------------
        TXYahooDisplay();
	//---------------------
        virtual void notifyPagerStatus(TXYahooChannel& Channel, TXYahooDisplayLine& Line);
        virtual void notifyChatStatus(TXYahooChannel& Channel, TXYahooDisplayLine& Line);
        virtual void notifyNewChannel(TXYahooChannel& Channel, TXYahooDisplayLine& Line);
        virtual void notifyChatLine(TXYahooChannel& Channel, TXYahooDisplayLine& Line);
        virtual void notifyPagerLine(TXYahooChannel& Channel, TXYahooDisplayLine& Line);
        virtual void notifyChatUserList(TXYahooChannel& Channel);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
