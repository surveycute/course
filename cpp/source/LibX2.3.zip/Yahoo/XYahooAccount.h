//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooAccount.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooAccountH
#define XYahooAccountH
//---------------------------------------------------------------------------
class TXYahooAccount
{
private:
	//---------------------
        char* Main;
        char* Title;
        char* User;
        char* Alias;
        char* Password;
	//---------------------
        char* AutoJoinRoomName;
	//---------------------
public:
	//---------------------
        void* pData; // for user defined data
	//---------------------
//---------------------------
	//---------------------
        TXYahooAccount();
        ~TXYahooAccount();
	//---------------------
        void Clear();
        void Copy(TXYahooAccount& cpyAccount);
	//---------------------
        const char* getTitle() const;
        const char* getUser() const;
        const char* getAlias() const;
        const char* getPassword() const;
        const char* getAutoJoinRoomName() const;
        const char* getMain() const;
        bool isMain() const;
	//---------------------
        void set(const char* strUser, const char* strAlias, const char* strPassword, const char* strAutoJoinRoomName = (const char*)0);
        void setTitle(const char* strTitle);
        void setUser(const char* strUser);
        void setAlias(const char* strAlias);
        void setPassword(const char* strPassword);
        void setAutoJoin(const char* strRoomName);
        void clearAutoJoin();
        void setMain(const char* strMain);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
