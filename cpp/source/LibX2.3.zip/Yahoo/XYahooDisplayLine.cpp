//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplayLine.cpp    
//--------------------------------
//---------------------------------------------------------------------------
//#include <alloc>
#include <stdlib.h> // for strtol
#pragma hdrstop
#ifdef __BORLANDC__
        #pragma message Including Borland compatible string.h header.
        #include <string.h> // memcpy
#else
        #include <string>
        #include <./String/XStringFunctions.h>
#endif
#include <./Yahoo/XYahooDisplayLine.h>
#include <./Buffer/XBuffer.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
TXYahooDisplayLine::TXYahooDisplayLine()
{
	//------------------
        TimeStamp = 0.0;
        CurrentTop = CurrentBottom = 0L;
        Height = 0;
	//------------------
        Reset();
	//------------------
}
//---------------------------------------------------------------------------
TXYahooDisplayLine::~TXYahooDisplayLine()
{
	//------------------
        Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLine::Reset()
{
	//------------------
        BlockCount = 0;
        User = Text = NULL;
        InfTags = NULL;
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLine::Clear()
{
	//------------------
        Blocks.Clear();
	//------------------
        BlockCount = 0;
	//------------------
        if (User) {XYahoo_Free(User);User = NULL;}
        if (Text) {XYahoo_Free(Text);Text = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLine::setUser(const char* strUser)
{
	//------------------
        if (User) {XYahoo_Free(User);User = NULL;}
        User = strdup(strUser);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplayLine::setText(const char* strText)
{
	//------------------
        if (Text) {XYahoo_Free(Text);Text = NULL;}
        Text = strdup(strText);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooDisplayLine::getText() const
{
	//------------------
        return Text;
}
//---------------------------------------------------------------------------
bool TXYahooDisplayLine::parseTextBlocks(const char* strText)
{
/*
        <font INF ID:YHLT VER:327 LINE:15 SEX:U TM:22 AVA:YA\yhlt></font>
        <font face="Tahoma" size="11">[2mtext</font>
lonly_x2006><font size="22">text
*/
/*
\033[0m   Resets all attributes.
\033[1m   Bold        \033[x1m unset bold.
\033[2m   Italic      \033[x2m unset italic.
\033[4m   Underline   \033[x4m unset underline.
\033[3?m  Selects a basic color where ? is one of 0123456789
\033[#RRGGBBm   where RRGGBB are 2 digit hex 00 to FF
*/
        TXYahooDisplayLineBlock* pBlock;
        const char* p; // current position in string iteration
        const char* pStart;
        enumFormatEscape Type;
        enumFormatEscape NewType;
        int lenText;
	//------------------
        if (strText)
                setText(strText);
        if (!Text)
                return true;
	//------------------
        Type = fmtNone;
        p = pStart = Text;
	//------------------
        while (*p != '\0')
        {
                //------------------
                if (*p == '<')
		{
			//------------------
			// need stack
			// Blocks is managed list now
		        // use TXYahooDisplayLineBlockFonts for stack
		      	// have list of start tag, tag close char, fin tag, fin tag close char
		      	// start-Tag push the stack, fin-tag-close char pops it
		      	// start: tag inner text / text / fin: tag inner text
		      	//     <b> <red> <i> <blue>
		      	//                <  <  >   <  >  >
		        //------------------
                        lenText = p - pStart;
                        p++;// skip past <
                        switch  (*p)
                        {
                                case '/':
                		        //------------------
                                        p++; // skip /
                		        //------------------
                                        switch (*p)
                                        {
                                                case 'b': NewType = fmtEndBold;         p++; break;
                                                case 'i': NewType = fmtEndItalic;       p++; break;
                                                case 'u': NewType = fmtEndUnderline;    p++; break;
                                                default:
                                		        //------------------
                                                             if (strncmpi(p, "font", 4) == 0) {NewType = fmtEndFont; p += 4;}
			                                else if (strncmpi(p, "fade", 4) == 0) {NewType = fmtEndFade; p += 4;}
			                                else if (strncmpi(p, "alt", 3) == 0)  {NewType = fmtEndAlt;  p += 3;}
                                                        else NewType = fmtNone;
                                		        //------------------
                                                        break;
                                        } // switch (*p)
                		        //------------------
                                        break;
                                case 'b': NewType = fmtBold;            p++; break;
                                case 'i': NewType = fmtItalic;          p++; break;
                                case 'u': NewType = fmtUnderline;       p++; break;
                                default:
                       		        //------------------
                                             if (strncmpi(p, "font ", 5) == 0) {NewType = fmtFont; p += 5;}
                                        else if (strncmpi(p, "fade ", 5) == 0) {NewType = fmtFade; p += 5;}
                                        else if (strncmpi(p, "alt ", 4) == 0)  {NewType = fmtAlt;  p += 4;}
                                        else NewType = fmtNone;
                       		        //------------------
                                        break;
                        } // switch  (*p)
			//------------------
			if (NewType != fmtNone)
			{
		        	//------------------
                                if (Type != fmtNone && p != pStart)
                                {
			                //------------------
			                pBlock = Blocks.Add();
		        	        if (!pBlock)
                                                return false;
        			        //------------------
                                        pBlock->Type = Type;
                                        pBlock->setText(pStart, lenText);
		        	        //------------------
                                }
        			//------------------
                                pStart = p;
                                Type = NewType;
				//------------------
			} // if (Type != fmtNone)
			//------------------
                }
		else if (*p == '>' && Type != fmtNone && Type != fmtText && Type != fmtEscape)
		{
                        //------------------
                        if (p != pStart)
                        {
			        //------------------
			        pBlock = Blocks.Add();
		        	if (!pBlock)
                                        return false;
                                //------------------
                                pBlock->Type = Type;
                                pBlock->setText(pStart, p - pStart);
                                //------------------
                        }
        		//------------------
                        p++;
                        pStart = p;
                        Type = fmtNone;
		        //------------------
                }
		else if (Type == fmtEscape && *p == 'm')
		{
			//------------------
                        if (p != pStart)
                        {
			        //------------------
			        pBlock = Blocks.Add();
			        if (!pBlock)
                                        return false;
			        //------------------
                                pBlock->Type = Type;
                                pBlock->setText(pStart, p - pStart);
			        //------------------
                        }
			//------------------
                        p++;
                        pStart = p;
                        Type = fmtNone;
			//------------------
		}
		else if (strncmpi(p, "\033[", 2) == 0)
		{
			//------------------
                        if (Type != fmtNone && p != pStart)
                        {
			        //------------------
			        pBlock = Blocks.Add();
			        if (!pBlock)
                                        return false;
			        //------------------
                                pBlock->Type = Type;
                                pBlock->setText(pStart, p - pStart);
			        //------------------
                        }
			//------------------
                        p += 2;
                        pStart = p;
                        Type = fmtEscape;
			//------------------
		}
                else if (Type == fmtNone)
                {
			//------------------
                        Type = fmtText;
                        p++;
			//------------------
                }
                else p++;
		//------------------
        } // while (*p != '\0')
	//------------------
        if (Type != fmtNone && p != pStart)
        {
                //------------------
                pBlock = Blocks.Add();
                if (!pBlock)
                        return false;
                //------------------
                pBlock->Type = Type;
                pBlock->setText(pStart, p - pStart);
                //------------------
        }
	//------------------
        TXYahooDisplayLineBlock** pBlocks = (TXYahooDisplayLineBlock**)Blocks.editList();
        unsigned long i, len = Blocks.getCount();
	//------------------
        for (i = 0L;i < len;++i)
        {
        	//------------------
                switch (pBlocks[i]->Type)
                {
                        // "face=\"Comic Sans MS\" size=\"12\">"
                        case fmtFont:
                                p = pBlocks[i]->getText();
                                while (*p)
                                {
                                        //if (strncmp(p, "face=\"", 6) == 0)

                                        p++;
                                }
                                break;
                        case fmtINF:
                                InfTags = pBlocks[i]->getText();
                                break;
                        case fmtEscape:
                                p = pBlocks[i]->getText();
                                switch (*p)
                                {                                
                                        case '#': // color
                                                pBlocks[i]->Font.Color = strtol(pBlocks[i]->getText()+1, NULL, 16);
                                                pBlocks[i]->Font.Color = ((pBlocks[i]->Font.Color & 0xFF0000) >> 16) + (pBlocks[i]->Font.Color & 0x00FF00) + ((pBlocks[i]->Font.Color & 0x0000FF) << 16); 
                                                pBlocks[i]->Font.maskValid = fmColor;
                                                break;
                                        case '0': // reset
                                                break;
                                        case '1': // bold
                                                pBlocks[i]->Type = fmtBold;
                                                i--; // reprocess
                                                break;
                                        case '2': // italic
                                                pBlocks[i]->Type = fmtItalic;
                                                i--; // reprocess
                                                break;
                                        case '4': // underline
                                                pBlocks[i]->Type = fmtUnderline;
                                                i--; // reprocess
                                                break;
                                        case '3': // baic color (followed by 0-9)
                                                break;
                                }
                                break;
                } // switch (pBlocks[i]->Type)
        	//------------------
        } // for (i = 0L;i < len;++i)  // iterating blocks
	//------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
