//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooCaptcha.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooCaptchaH
#define XYahooCaptchaH
//---------------------------------------------------------------------------
#include <./Net/Protocol/XHTTPClient.h>
//---------------------------------------------------------------------------
typedef enum {ycapReady = 0, ycapGetting, ycapUserInput, ycapPosting, ycapDone, ycapError} XYahooCaptchaStatusType;
//---------------------------------------------------------------------------
class TXYahooCaptcha
{
private:
	//---------------------
        char* GETParams;
        char* POSTParams;
	//---------------------
        char* CaptchaAddress;
        char* ImageAddress;
	//---------------------
        TXHTTPClient HTTPClient;
	//---------------------
        XYahooCaptchaStatusType Status;
	//---------------------
public:
	//---------------------
//---------------------------
        TXYahooCaptcha();
        ~TXYahooCaptcha();
	//---------------------
        void Clear(bool bClean = true);
	//---------------------
        void setGetParams(const char* strGetParams);
        void setPostParams(const char* strPostParams);
	//---------------------
        bool Step();
        bool ParseMessage(char* str);
	//---------------------
        bool RequestCaptcha(char* strMessage = NULL);
        bool PostReply(char* strReply);
	//---------------------
        const unsigned long getImageSize() const;
        const char* getImageData() const;
	//---------------------
        XYahooCaptchaStatusType getStatus() const;
        bool isDone() const;
        bool isError() const;
        bool isReady() const;
        bool isUserInput() const;
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
