//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XQuickMessage.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XQuickMessageH
#define XQuickMessageH
//---------------------------------------------------------------------------
#include <./List/XList.h>
//---------------------------------------------------------------------------
class TXQuickMessage
{
private:
	//---------------------
        bool AutoSend;
        char* Title;
        char* Message;
	//---------------------
public:
	//---------------------
//---------------------------
        TXQuickMessage();
        ~TXQuickMessage();
	//---------------------
        const char* getTitle() const;
        const char* getMessage() const;
        const bool isAutoSend() const;
        void setTitle(const char* strTitle);
        void setMessage(const char* strMessage);
        void setAutoSend(bool bAuto);
	//---------------------
};
//---------------------------------------------------------------------------
class TXQuickMessages : public TXList<TXQuickMessage>
{
public:
//---------------------------
        TXQuickMessages() :  TXList<TXQuickMessage>() {};

        bool CheckIndex(unsigned long Index)
        {
                unsigned long l = getCount();
                if (Index >= l)      //   0 1 2 [3] (4) 5 6 7
                        for (unsigned long i = l;i < Index + 1;++i)
                                if (!Add())
                                        return false;
                return true;
        }


};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
