//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooMultiClient.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooMultiClientH
#define XYahooMultiClientH
//---------------------------------------------------------------------------
#include <./List/XLinkList.h>
#include <./Yahoo/XYahooDisplay.h>
#include <./Yahoo/XQuickMessage.h>
#include <./Yahoo/XYahooClients.h>
#include <./Yahoo/XYahooAccounts.h>
#include <./Yahoo/Protocol/Filter/XYMSGFilterCore.h>
#include <./Yahoo/Protocol/Filter/XYMSGFilterLocalIgnores.h>
//---------------------------------------------------------------------------
class TXYahooMultiClient
{
private:
        //---------------------
        bool initted;
        //---------------------
        TXQuickMessages QuickMessages;
        //---------------------
        TXLinkList<TXYahooChannel> pChannelIndex;
        TXLinkList<TXYahooUser>    pUserIndex;
        //---------------------
        TXYahooChannel* pSelectedChannel;
        TXYahooClient*  pSelectedClient;
        TXYahooAccount* pSelectedAccount;
        TXYahooUser*    pSelectedUser;
        //---------------------
        TXYahooClients Clients;
        TXYahooAccounts Accounts;
        TXYahooDisplay* pDisplay;
        //---------------------
public:
        //---------------------
        TXYMSGFilterCore FilterCore;
        TXYMSGFilterLocalIgnores FilterLocalIgnores;
        //---------------------
//---------------------------
        TXYahooMultiClient();
        ~TXYahooMultiClient();
        //---------------------
        bool init();
        void release();
        //---------------------
        void setDisplay(TXYahooDisplay* tpDisplay);
        //---------------------
        unsigned long getQuickMessageCount() const;
        unsigned long getChannelCount() const;
        unsigned long getClientCount() const;
        unsigned long getAccountCount() const;
        unsigned long getUserCount() const;
        //---------------------
        const TXQuickMessage** getQuickMessages() const;
        const TXYahooChannel** getChannels() const;
        const TXYahooClient** getClients() const;
        const TXYahooAccount** getAccounts() const;
        const TXYahooUser** getUsers() const;
        //---------------------
        TXQuickMessage** editQuickMessages();
        TXYahooChannel** editChannels();
        TXYahooClient** editClients();
        TXYahooAccount** editAccounts();
        TXYahooUser** edittUsers();
        //---------------------
        TXYahooChannel* selectChannel(int idx);
        TXYahooClient* selectClient(int idx);
        TXYahooAccount* selectAccount(int idx);
        TXYahooUser* selectUser(int idx);
        //---------------------
        int selectChannel(const TXYahooChannel* pChannel);
        int selectClient(const TXYahooClient* pClient);
        int selectAccount(const TXYahooAccount* pAccount);
        int selectUser(const TXYahooUser* pUser);
        //---------------------
        TXYahooChannel* getSelChannel() const;
        TXYahooClient* getSelClient() const;
        TXYahooAccount* getSelAccount() const;
        TXYahooUser* getSelUser() const;
        //---------------------
        int getSelChannelIndex() const;
        int getSelClientIndex() const;
        int getSelAccountIndex() const;
        int getSelUserIndex() const;
        //---------------------
        TXQuickMessage* addQuickMessage();
        TXYahooAccount* addAccount();
        //--------------------- all AddUnique
        bool addChannelIndex(TXYahooChannel* pChannel);
        bool addUserIndex(TXYahooUser* pUser);
        //---------------------
        bool removeChannelIndex(TXYahooChannel* pChannel);
        bool removeUserIndex(TXYahooUser* pUser);
        bool removeAccount(int Idx);
        bool removeAccount(TXYahooAccount* pAccount, bool bRemoveClient = true);
        bool removeClient(TXYahooClient* pClient, bool bRemoveAccount = true);
        //---------------------
        void clearChannelIndex();
        bool checkIndexQuickMessage(int Idx);
        //---------------------
        TXYahooClient* activateAccount(TXYahooAccount* pAccount = (TXYahooAccount*)0 /* defaults to selected account*/);
        //---------------------
        bool postMessage(const char* strMessage);
        bool Connect(const char* strHost, unsigned short usPort, TXYahooAccount* pAccount = (TXYahooAccount*)0 /* defaults to selected account*/ );
        bool Connect(const char* strHost, unsigned short usPort, TXYahooClient* pClient);
        void Logoff(TXYahooClient* pClient);
        void DisconnectAll();
        bool toggleConnect(const char* strHost, unsigned short usPort, TXYahooAccount* pAccount = (TXYahooAccount*)0 /* defaults to selected account*/ );
        bool toggleConnect(const char* strHost, unsigned short usPort, TXYahooClient* pClient);
        int getLastLoginError();
        //---------------------
        bool Step();
        TXYahooClient* ClientNeedsCaptcha();
        //---------------------
};
//---------------------------------------------------------------------------
extern TXYahooMultiClient ymc;
//---------------------------------------------------------------------------
#endif // XYahooMultiClientH
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
