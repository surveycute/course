//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplay.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./Yahoo/XYahooDisplay.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooDisplay::TXYahooDisplay()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplay::notifyPagerStatus(TXYahooChannel& Channel, TXYahooDisplayLine& Line)
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplay::notifyChatStatus(TXYahooChannel& Channel, TXYahooDisplayLine& Line)
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplay::notifyNewChannel(TXYahooChannel& Channel, TXYahooDisplayLine& Line)
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplay::notifyChatLine(TXYahooChannel& Channel, TXYahooDisplayLine& Line)
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplay::notifyPagerLine(TXYahooChannel& Channel, TXYahooDisplayLine& Line)
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooDisplay::notifyChatUserList(TXYahooChannel& Channel)
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
