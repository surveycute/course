//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooUsers.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooUsersH
#define XYahooUsersH
//---------------------------------------------------------------------------
#include <./List/XList.h>
#include <./List/XLinkList.h>
#include <./Yahoo/XYahooUser.h>
//---------------------------------------------------------------------------
class TXYahooUserList : public TXLinkList<TXYahooUser>
{
public:
	//---------------------
//---------------------------
        TXYahooUserList();
        ~TXYahooUserList();
	//---------------------
        TXYahooUser* get(const char* strName = (void*)0);
        int get(TXYahooUser* pUser);
        TXYahooUser getbyName(const char* strName);
        bool Add(TXYahooUser* pUser);
        bool AddUnique(TXYahooUser* pUser);
        bool Remove(TXYahooUser* pUser);
	//---------------------
};
//---------------------------------------------------------------------------
class TXYahooUsers : public TXList<TXYahooUser>
{

public:
	//---------------------
//---------------------------
        TXYahooUsers();
        ~TXYahooUsers();
	//---------------------
        const TXYahooUser** getList() const;
        TXYahooUser** editList();
	//---------------------
        TXYahooUser* get(const char* strName);
        TXYahooUser* getadd(const char* strName = (void*)0);
        TXYahooUser* add(const char* strName = (void*)0);
	//---------------------
};
//---------------------------------------------------------------------------
class TXYahooUserGroup
{
private:
	//---------------------
        char* GroupName;
	//---------------------
public:
	//---------------------
        TXYahooUsers Users;
	//---------------------
//---------------------------
        TXYahooUserGroup();
        ~TXYahooUserGroup();
	//---------------------
        void setGroupName(const char* strGroupName);
        const char* getGroupName() const;
	//---------------------
};
//---------------------------------------------------------------------------
class TXYahooUserGroups : public TXList<TXYahooUserGroup>
{

public:
	//---------------------
//---------------------------
        TXYahooUserGroups();
        ~TXYahooUserGroups();
	//---------------------
        const TXYahooUserGroup** getList() const;
        TXYahooUserGroup** editList();
	//---------------------
        TXYahooUser* findUser(const char* strUserName);
        TXYahooUserGroup* get(const char* strGroupName);
        TXYahooUserGroup* getadd(const char* strGroupName = (void*)0);
        TXYahooUserGroup* add(const char* strGroupName = (void*)0);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
