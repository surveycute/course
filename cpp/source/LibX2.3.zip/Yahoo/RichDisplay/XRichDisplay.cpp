//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XRichDisplay.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <string.h>
#pragma hdrstop
#include <./Yahoo/RichDisplay/XRichDisplay.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXRichDisplay::TXRichDisplay()
{
	//------------------
        Count = 0L;
	//------------------
}
//---------------------------------------------------------------------------
TXRichDisplay::~TXRichDisplay()
{
	//------------------
        Clear(true);
	//------------------
}
//---------------------------------------------------------------------------
void TXRichDisplay::Clear(bool bClean /*= false*/)
{
        TXRichDisplayLine* pLine = (TXRichDisplayLine*)Lines.editData();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                pLine[i].Clear();
	//------------------
        Lines.Clear(bClean);
        Count = 0L;
	//------------------
}
//---------------------------------------------------------------------------
unsigned long TXRichDisplay::getCount() const
{
	//------------------
        return Count;
}
//---------------------------------------------------------------------------
const TXRichDisplayLine* TXRichDisplay::getList() const
{
	//------------------
        return (const TXRichDisplayLine*)Lines.getData();
}
//---------------------------------------------------------------------------
TXRichDisplayLine* TXRichDisplay::editList()
{
	//------------------
        return (TXRichDisplayLine*)Lines.editData();
}
//---------------------------------------------------------------------------
bool TXRichDisplay::addChatMessage(const char* strUser, const char* strMsg)
{
	//------------------
        tempLine.Reset();
	//------------------
        if (!tempLine.parseTextBlocks(strMsg))
        {
                tempLine.Clear();
                return false;
        }
	//------------------
        tempLine.Type = xrdtChatMessage;
        tempLine.User = strdup(strUser);
	//------------------
        if (!Lines.Append((unsigned char*)&tempLine, sizeof(TXRichDisplayLine)))
        {
                tempLine.Clear();
                return false;
        }
	//------------------
        Count++;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXRichDisplay::addPagerMessage(const char* strUser, const char* strMsg)
{
	//------------------
        tempLine.Reset();
	//------------------
        if (!tempLine.parseTextBlocks(strMsg))
        {
                tempLine.Clear();
                return false;
        }
	//------------------
        tempLine.Type = xrdtPagerMessage;
        tempLine.User = strdup(strUser);
        tempLine.Text = strdup(strMsg);
	//------------------
        if (!Lines.Append((unsigned char*)&tempLine, sizeof(TXRichDisplayLine)))
        {
                tempLine.Clear();
                return false;
        }
	//------------------
        Count++;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXRichDisplay::addChatUserJoin(const char* strUser)
{
	//------------------
        tempLine.Reset();
	//------------------
        tempLine.Type = xrdtChatUserJoin;
        tempLine.User = strdup(strUser);
	//------------------
        if (!Lines.Append((unsigned char*)&tempLine, sizeof(TXRichDisplayLine)))
        {
                tempLine.Clear();
                return false;
        }
	//------------------
        Count++;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXRichDisplay::addChatUserLeave(const char* strUser)
{
	//------------------
        tempLine.Reset();
	//------------------
        tempLine.Type = xrdtChatUserLeave;
        tempLine.User = strdup(strUser);
	//------------------
        if (!Lines.Append((unsigned char*)&tempLine, sizeof(TXRichDisplayLine)))
        {
                tempLine.Clear();
                return false;
        }
	//------------------
        Count++;
	//------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
