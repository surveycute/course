//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XRichDisplayLine.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <string.h>
#pragma hdrstop
#include <./Yahoo/RichDisplay/XRichDisplayLine.h>
#include <./Buffer/XBuffer.h>
#include <./String/XStringFunctions.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXRichDisplayLine::TXRichDisplayLine()
{
	//------------------
        TimeStamp = 0.0;
        CurrentTop = CurrentBottom = 0L;
        Height = 0;
	//------------------
        Reset();
	//------------------
}
//---------------------------------------------------------------------------
TXRichDisplayLine::~TXRichDisplayLine()
{
	//------------------
        Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXRichDisplayLine::Reset()
{
	//------------------
        BlockCount = 0;
        User = InfTags = Text = NULL;
	//------------------
}
//---------------------------------------------------------------------------
void TXRichDisplayLine::Clear()
{
	//------------------
        for (int i;i < BlockCount;++i)
                if (Block[i])
                {
                        if (Block[i]->Text) XYahoo_Free(Block[i]->Text);
                        XYahoo_Free(Block[i]);
                        Block[i] = NULL;
                }
	//------------------
        BlockCount = 0;
	//------------------
        if (User) {XYahoo_Free(User);User = NULL;}
        if (InfTags) {XYahoo_Free(InfTags);InfTags = NULL;}
        if (Text) {XYahoo_Free(Text);Text = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
bool TXRichDisplayLine::parseTextBlocks(const char* strText)
{
        enum {fmtNormal = 0, fmtINF, fmtFont, fmtEndFont, fmtOtherTag, fmtEscape} State;
        XRichDisplayBlock newBlock;
        const char* p;
        char* strOut;
        char* pOut;
        char* strEsc;
        char* pEsc;
        char endEsc;
	//------------------
        strEsc = (char*)XYahoo_Allocate(strlen(strText) + 1/*NULL Terminator*/);
        if (!strEsc)
                return false;
        strOut = (char*)XYahoo_Allocate(strlen(strText) + 1/*NULL Terminator*/);
        if (!strOut)
                return false;
	//------------------
        pEsc = strEsc;
        pOut = strOut;
	//------------------
	//------------------
/*
        <font INF ID:YHLT VER:327 LINE:15 SEX:U TM:22 AVA:YA\yhlt></font>
        <font face="Tahoma" size="11">[2mtext</font>
lonly_x2006><font size="22">text
*/
/*
\033[0m   Resets all attributes.
\033[1m   Bold        \033[x1m unset bold.
\033[2m   Italic      \033[x2m unset italic.
\033[4m   Underline   \033[x4m unset underline.
\033[3?m  Selects a basic color where ? is one of 0123456789
\033[#RRGGBBm   where RRGGBB are 2 digit hex 00 to FF
*/
	//------------------
        p = strText;
        while (*p != '\0')
        {
        	//------------------
                if (State == fmtNormal)
                {
                	//------------------
                        if (*p == '<')
                        {
                        	//------------------
                                if (strncmpi(p, "</font", 6) == 0) // search for end > to handle end font with others
                                {
                                	//------------------
                                        if (pOut != strOut)
                                        {
                                        	//------------------
                                                *pOut = '\0';
                                                newBlock.Text = strdup(strOut);
                                                pOut = strOut;
                                        	//------------------
                                                if (!addBlock(newBlock))
                                                {
                                                        XYahoo_Free(strEsc);
                                                        XYahoo_Free(strOut);
                                                        return false;
                                                }
                                        	//------------------
                                        }
                                	//------------------
                                        State = fmtEndFont;
                                        endEsc = '>';
                                        pEsc = strEsc;
                                	//------------------
                                        continue;
                                }
                        	//------------------
                                if (strncmpi(p, "<font ", 6) == 0)
                                {
                                	//------------------
                                        p += 6;
                                	//------------------
                                        if (strncmpi(p, "INF ", 4) == 0)
                                        {
                                        	//------------------
                                                p += 4;
                                                State = fmtINF;
                                        	//------------------
                                        }
                                        else State = fmtFont;
                                	//------------------
                                        if (pOut != strOut)
                                        {
                                        	//------------------
                                                *pOut = '\0';
                                                newBlock.Text = strdup(strOut);
                                                pOut = strOut;
                                        	//------------------
                                                if (!addBlock(newBlock))
                                                {
                                                        XYahoo_Free(strEsc);
                                                        XYahoo_Free(strOut);
                                                        return false;
                                                }
                                        	//------------------
                                        }
                                	//------------------
                                        endEsc = '>';
                                        pEsc = strEsc;
                                	//------------------
                                        continue;
                                }
                                // else keep <
                        	//------------------
                        }
                        else if (*p == '\33')
                        {
                        	//------------------
                                if (pOut != strOut)
                                {
                                        //------------------
                                        *pOut = '\0';
                                        newBlock.Text = strdup(strOut);
                                        pOut = strOut;
                                        //------------------
                                        if (!addBlock(newBlock))
                                        {
                                                XYahoo_Free(strEsc);
                                                XYahoo_Free(strOut);
                                                return false;
                                        }
                                        //------------------
                                }
                                //------------------
                                State = fmtEscape;
                                endEsc = 'm';
                                pEsc = strEsc;
                               	//------------------
                                continue;
                        }
                	//------------------
                        *(pOut++) = *(p++);
                	//------------------
                }
                else
                {
                	//------------------
                        if (*p == endEsc)
                        {
                        	//------------------
                                *pEsc = '\0';
                        	//------------------
                                switch (State)
                                {
                                        case fmtINF:
                                                if (InfTags) XYahoo_Free(InfTags);
                                                InfTags = strdup(strEsc);
                                                break;
                                        case fmtFont:
                                                break;
                                        case fmtEndFont:
                                                break;
                                        case fmtOtherTag:
                                                break;
                                        case fmtEscape:
                                                break;
                                }
                        	//------------------
                                p++;
                                State = fmtNormal;
                        	//------------------
                        }
                        else *(pEsc++) = *(p++);
                	//------------------
                }
               	//------------------
        }
	//------------------
        if (pOut != strOut)
        {
                //------------------
                *pOut = '\0';
                newBlock.Text = strdup(strOut);
                //------------------
                if (!addBlock(newBlock))
                {
                        XYahoo_Free(strEsc);
                        XYahoo_Free(strOut);
                        return false;
                }
                //------------------
        }
	//------------------
        XYahoo_Free(strEsc);
        XYahoo_Free(strOut);
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXRichDisplayLine::addBlock(const XRichDisplayBlock& newBlock)
{
	//------------------
        if (BlockCount >= c_XRichDisplay_Block_Max)
        {
        	//------------------
                int Size = strlen(newBlock.Text) + strlen(Block[BlockCount - 1]->Text);
                char* newText = (char*)XYahoo_Allocate(Size + 1/*NULL terminator*/);
                        if (!newText) return false;
        	//------------------
                newText[0] = '\0';
                strcat(newText, Block[BlockCount - 1]->Text);
                strcat(newText, newBlock.Text);
        	//------------------
                XYahoo_Free(Block[BlockCount - 1]->Text);
                Block[BlockCount - 1]->Text = newText;
        	//------------------
                return true;
        }
	//------------------
        Block[BlockCount] = (XRichDisplayBlock*)XYahoo_Allocate(sizeof(XRichDisplayBlock));
        if (!Block[BlockCount])
                return false;
	//------------------
        memcpy(Block[BlockCount], &newBlock, sizeof(XRichDisplayBlock));
	//------------------
        BlockCount++;
	//------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
