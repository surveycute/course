//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XRichDisplayLinePagerNotify.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XRichDisplayLinePagerNotifyH
#define XRichDisplayLinePagerNotifyH
//---------------------------------------------------------------------------
#include <./Yahoo/RichDisplay/XRichDisplayLineBase.h>
//---------------------------------------------------------------------------
class TXRichDisplayLinePagerNotify : public TXRichDisplayLineBase
{
private:
	//---------------------
	//---------------------
public:
	//---------------------
	//---------------------
//---------------------------
	//---------------------
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
