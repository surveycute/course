//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XRichDisplay.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XRichDisplayH
#define XRichDisplayH
//---------------------------------------------------------------------------
#include <./Buffer/XBuffer.h>
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Yahoo/RichDisplay/XRichDisplayLine.h>
//---------------------------------------------------------------------------
class TXRichDisplay
{
private:
	//---------------------
        TXBuffer Lines;
        unsigned long Count;
	//---------------------
public:
	//---------------------
        TXRichDisplayLine tempLine;
	//---------------------
//---------------------------
	//---------------------
        TXRichDisplay();
        ~TXRichDisplay();
	//---------------------
        void Clear(bool bClean = false);
        unsigned long getCount() const;
        const TXRichDisplayLine* getList() const;
        TXRichDisplayLine* editList();
	//---------------------
        bool addChatMessage(const char* strUser, const char* strMsg);
        bool addPagerMessage(const char* strUser, const char* strMsg);
        bool addChatUserJoin(const char* strUser);
        bool addChatUserLeave(const char* strUser);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
