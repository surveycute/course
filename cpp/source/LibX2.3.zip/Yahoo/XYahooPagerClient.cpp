//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooPagerClient.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdio.h>
#pragma hdrstop
#include <./Yahoo/XYahooPagerClient.h>
#include <./Yahoo/Protocol/XYMSGSession.h>
#include <./Yahoo/XYahooClient.h>
#include <./Yahoo/XYahooDisplay.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooPagerClient::TXYahooPagerClient()
{
	//------------------
        pYahooClient = NULL;
        Handler.setPagerClient(this);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooPagerClient::setYahooClient(TXYahooClient* psetYahooClient)
{
	//------------------
        pYahooClient = psetYahooClient;
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooPagerClient::Online(const char* strAlias)
{
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddStatus();
	//------------------
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addOnline();
        if (!pLine)
                return ;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyPagerStatus(*pChannel, *pLine);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooPagerClient::DroppedMessage(short int Code, const char* strUser, const char* strMessage)
{
	//------------------
        char* str;
        TXYahooDisplayLine* pLine;
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddStatus();
	//------------------
        if (!pChannel)
                return;
	//------------------
        if (!strUser)
        {
                str = (char*)XYahoo_Allocate(55);
                if (str)
                {
                        sprintf(str, "***DROP(Pager Message):<missing user name> code %d", (unsigned int)((unsigned)Code) );
                        pLine = pChannel->Lines.addSystem(str);
                        XYahoo_Free(str);
                }
        }
        else
        {
                str = (char*)XYahoo_Allocate(strlen(strUser) + 40);
                if (str)
                {
                        sprintf(str, "***DROP(Pager Message):%s code %d", strUser, (unsigned int)((unsigned)Code) );
                        pLine = pChannel->Lines.addSystem(str);
                        XYahoo_Free(str);
                }
        }
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyPagerLine(*pChannel, *pLine);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooPagerClient::ReceiveMessage(const char* strUser, const char* strMessage)
{
	//------------------
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddUser(strUser);
	//------------------
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addPagerMessage(strUser, strMessage);
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyPagerLine(*pChannel, *pLine);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooPagerClient::SendMessage(TXYMSGSession& Session, const char* strUser, const char* strMessage)
{
	//------------------
        if (Session.PagerStatus != ymsgpagerOnline)
                return;
	//------------------
        TXYahooChannel* pChannel = pYahooClient->Channels.getaddUser(strUser);
        if (!pChannel)
                return;
	//------------------
        TXYahooDisplayLine* pLine = pChannel->Lines.addChatMessage(Session.Account.getAlias(), strMessage, true/*bSelf*/);
	//------------------
        if (!pLine)
                return;
	//------------------
        if (pYahooClient->pDisplay)
                pYahooClient->pDisplay->notifyChatLine(*pChannel, *pLine);
	//------------------
        Session.Builder.PrivateMessage(Session, strUser, strMessage); // ignore error
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
