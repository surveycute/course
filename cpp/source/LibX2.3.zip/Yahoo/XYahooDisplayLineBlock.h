//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplayLineBlock.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooDisplayLineBlockH
#define XYahooDisplayLineBlockH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./List/XList.h>
#include <./List/XLinkList.h>
//---------------------------------------------------------------------------
typedef enum {fmtNone = 0, fmtText, fmtINF, fmtFont, fmtEndFont, fmtFade, fmtEndFade, fmtAlt, fmtEndAlt, fmtEscape, fmtEndEscape, fmtBold, fmtEndBold, fmtItalic, fmtEndItalic, fmtUnderline, fmtEndUnderline} enumFormatEscape;
typedef enum {fmNone = 0, fmColor = 1, fmSize = 2} enumLineBlockFontMask;
//---------------------------------------------------------------------------
class TXYahooDisplayLineBlockFont
{
public:
	//---------------------
        enumLineBlockFontMask maskValid;
	//---------------------
        unsigned short Height;
        unsigned char Size;
        unsigned long Color;
	//---------------------
//---------------------------
        TXYahooDisplayLineBlockFont();
        TXYahooDisplayLineBlockFont(const TXYahooDisplayLineBlockFont& r);
        ~TXYahooDisplayLineBlockFont();
	//---------------------
        void Copy(const TXYahooDisplayLineBlockFont& r);
	//---------------------
};
//---------------------------------------------------------------------------
class TXYahooDisplayLineBlockFonts    : public TXList<TXYahooDisplayLineBlockFont>{};
class TXYahooDisplayLineBlockFontList : public TXLinkList<TXYahooDisplayLineBlockFont>{};
//---------------------------------------------------------------------------
class TXYahooDisplayLineBlock
{
private:
	//---------------------
	//---------------------
public:
	//---------------------
        char* Text;
	//---------------------
        unsigned short lenText;
        bool Active;
        enumFormatEscape Type;
	//---------------------
        TXYahooDisplayLineBlockFont Font;
	//---------------------
//---------------------------
        TXYahooDisplayLineBlock();
        TXYahooDisplayLineBlock(const TXYahooDisplayLineBlock& lb);
        ~TXYahooDisplayLineBlock();
	//---------------------
        void Copy(const TXYahooDisplayLineBlock& lb);
	//---------------------
        void setText(const char* str);
        void setText(const char* str, unsigned short len);
        const char* getText() const;
        char* editText();
	//---------------------
};
//---------------------------------------------------------------------------
class TXYahooDisplayLineBlocks    : public TXList<TXYahooDisplayLineBlock>{};
class TXYahooDisplayLineBlockList : public TXLinkList<TXYahooDisplayLineBlock>{};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
