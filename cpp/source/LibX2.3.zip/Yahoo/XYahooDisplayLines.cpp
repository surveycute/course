//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplayLines.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <string.h>
#pragma hdrstop
#include <./Yahoo/XYahooDisplayLines.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooDisplayLines::TXYahooDisplayLines() : TXList<TXYahooDisplayLine>()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
TXYahooDisplayLines::~TXYahooDisplayLines()
{
	//------------------
        Clear(true);
	//------------------
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addSystem(const char* strMsg)
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtSystem;
        p->Text = strdup(strMsg);
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addStatus(const char* strMsg)
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtStatus;
        p->Text = strdup(strMsg);
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addOnline()
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtOnline;
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addOffline()
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtOffline;
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addChatEnter()
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtChatSelfJoin;
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addChatLeave()
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtChatSelfLeave;
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addChatMessage(const char* strUser, const char* strMsg, bool bSelf /*= false*/)
{
	//------------------
        if (!strUser || !strMsg)
                return NULL;
	//------------------
        TXYahooDisplayLine* p = Add();
        if (!p)
                return NULL;
	//------------------
        if (bSelf)      p->Type = xrdtSelfChatMessage;
        else            p->Type = xrdtChatMessage;
	//------------------
        if (!p->parseTextBlocks(strMsg))
                return NULL;
	//------------------
        p->User = strdup(strUser);
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addPagerMessage(const char* strUser, const char* strMsg, bool bSelf /*= false*/)
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        if (bSelf)      p->Type = xrdtSelfPagerMessage;
        else            p->Type = xrdtPagerMessage;
        p->User = strdup(strUser);
        p->Text = strdup(strMsg);
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addChatUserJoin(const char* strUser)
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtChatUserJoin;
        p->User = strdup(strUser);
	//------------------
        return p;
}
//---------------------------------------------------------------------------
TXYahooDisplayLine* TXYahooDisplayLines::addChatUserLeave(const char* strUser)
{
        TXYahooDisplayLine* p = Add();
	//------------------
        if (!p)
                return NULL;
	//------------------
        p->Type = xrdtChatUserLeave;
        p->User = strdup(strUser);
	//------------------
        return p;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
