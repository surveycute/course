//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooAccount.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h> // malloc realloc free
#include <string.h> // for strdup()
#pragma hdrstop
#include "XYahooAccount.h"
#include <./Yahoo/Protocol/XYMSGConstants.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooAccount::TXYahooAccount()
{
	//------------------
        Title = Main = User = Alias = Password = NULL;
        pData = NULL;
        AutoJoinRoomName = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooAccount::~TXYahooAccount()
{
	//------------------
        Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::Clear()
{
	//------------------
        if (Title)      {XYahoo_Free(Title);Title = NULL;}
        if (Main)       {XYahoo_Free(Main);Main = NULL;}
        if (User)       {XYahoo_Free(User);User = NULL;}
        if (Alias)      {XYahoo_Free(Alias);Alias = NULL;}
        if (Password)   {XYahoo_Free(Password);Password = NULL;}
        if (AutoJoinRoomName)   {XYahoo_Free(AutoJoinRoomName);AutoJoinRoomName = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::Copy(TXYahooAccount& cpyAccount)
{
	//------------------
        set(cpyAccount.getUser(), cpyAccount.getAlias(), cpyAccount.getPassword(), cpyAccount.getAutoJoinRoomName());
        pData = cpyAccount.pData;
        if (Title) XYahoo_Free(Title);
        Title = strdup(cpyAccount.getTitle());
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooAccount::getTitle() const
{
	//------------------
        return Title;
}
//---------------------------------------------------------------------------
const char* TXYahooAccount::getUser() const
{
	//------------------
	return User;
}
//---------------------------------------------------------------------------
const char* TXYahooAccount::getAlias() const
{
	//------------------
	return Alias;
}
//---------------------------------------------------------------------------
const char* TXYahooAccount::getPassword() const
{
	//------------------
	return Password;
}
//---------------------------------------------------------------------------
const char* TXYahooAccount::getAutoJoinRoomName() const
{
	//------------------
	return AutoJoinRoomName;
}
//---------------------------------------------------------------------------
const char* TXYahooAccount::getMain() const
{
	//------------------
	return AutoJoinRoomName;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
bool TXYahooAccount::isMain() const
{
	//------------------
        if (!Main || !User)
                return false;
	//------------------
	return (strcmp(Main, User) == 0);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void TXYahooAccount::set(const char* strUser, const char* strAlias, const char* strPassword, const char* strAutoJoinRoomName /*= (void*)0*/)
{
	//------------------
        if (User) XYahoo_Free(User);
        if (Alias) XYahoo_Free(Alias);
        if (Password) XYahoo_Free(Password);
        if (AutoJoinRoomName) XYahoo_Free(AutoJoinRoomName);
	//------------------
        if (strUser)     User = strdup(strUser);
        else User = NULL;
        if (strAlias)    Alias = strdup(strAlias);
        else Alias = NULL;
        if (strPassword) Password = strdup(strPassword);
        else Password = NULL;
        if (strAutoJoinRoomName) AutoJoinRoomName = strdup(strAutoJoinRoomName);
        else AutoJoinRoomName = NULL;
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::setTitle(const char* strTitle)
{
	//------------------
        if (Title) XYahoo_Free(Title);
        Title = strdup(strTitle);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::setUser(const char* strUser)
{
	//------------------
        if (User) XYahoo_Free(User);
        User = strdup(strUser);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::setAlias(const char* strAlias)
{
	//------------------
        if (Alias) XYahoo_Free(Alias);
        Alias = strdup(strAlias);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::setPassword(const char* strPassword)
{
	//------------------
        if (Password) XYahoo_Free(Password);
        Password = strdup(strPassword);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::setAutoJoin(const char* strRoomName)
{
	//------------------
        if (AutoJoinRoomName) XYahoo_Free(AutoJoinRoomName);
        AutoJoinRoomName = strdup(strRoomName);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::clearAutoJoin()
{
	//------------------
        if (AutoJoinRoomName) {XYahoo_Free(AutoJoinRoomName);AutoJoinRoomName = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooAccount::setMain(const char* strMain)
{
	//------------------
        if (Main) XYahoo_Free(Main);
        Main = strdup(strMain);
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
