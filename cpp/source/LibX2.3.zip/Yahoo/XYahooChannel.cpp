//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooChannel.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h> // malloc realloc free
#include <string.h> // strdup strcmp
#pragma hdrstop
#include <./Yahoo/XYahooChannel.h>
#include <./Yahoo/XYahooChatClient.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooChannel::TXYahooChannel()
{
	//------------------
        Type = xctNone;
        Title = NULL;
        pPagerUser = NULL;
        pYahooClient = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooChannel::~TXYahooChannel()
{
	//------------------
        if (pPagerUser)
        {
                pPagerUser->decRefCount();
                pPagerUser = NULL;
        }
        Clear(true/*bClean*/);
        pChatUsers.Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChannel::setYahooClient(TXYahooClient* psetYahooClient)
{
	//------------------
        pYahooClient = psetYahooClient;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooClient* TXYahooChannel::getYahooClient() const
{
	//------------------
        return pYahooClient;
}
//---------------------------------------------------------------------------
void TXYahooChannel::Clear(bool bClean /*= false*/)
{
	//------------------
        Lines.Clear(bClean);
        if (Title) {XYahoo_Free(Title);Title = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChannel::Set(TXYahooClient* psetYahooClient, const char* strTitle)
{
	//------------------
        setYahooClient(psetYahooClient);
        setTitle(strTitle);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooChannel::setTitle(const char* strTitle)
{
	//------------------
        if (Title) XYahoo_Free(Title);
	//------------------
        if (!strTitle)  Title = NULL;
        else            Title = strdup(strTitle);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooChannel::getTitle() const
{
	//------------------
        return Title;
}
//---------------------------------------------------------------------------
bool TXYahooChannel::isTitle(const char* strTitle) const
{
	//------------------
        if (!strTitle)
        {
                if (!Title)     return true;
                else            return false;
        }
	//------------------
        return (strcmp(strTitle, Title) == 0);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
