//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooChannel.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooChannelH
#define XYahooChannelH
//---------------------------------------------------------------------------
#include <./Yahoo/XYahooDisplayLines.h>
#include <./Yahoo/XYahooUser.h>
#include <./Yahoo/XYahooUsers.h>
//---------------------------------------------------------------------------
class TXYahooClient; // predefined
//---------------------------------------------------------------------------
class TXYahooChannel
{
private:
	//---------------------
        char* Title;
        TXYahooClient* pYahooClient;
	//---------------------
public:
	//---------------------
        XChannelType Type;
        TXYahooDisplayLines Lines;
        TXYahooUser* pPagerUser;
        TXYahooUserList pChatUsers;
//---------------------------
        TXYahooChannel();
        ~TXYahooChannel();
	//---------------------
        void setYahooClient(TXYahooClient* psetYahooClient);
        TXYahooClient* getYahooClient() const;
	//---------------------
        void Clear(bool bClean = false);
	//---------------------
        void Set(TXYahooClient* psetYahooClient, const char* strTitle);
        void setTitle(const char* strTitle);
        const char* getTitle() const;
        bool isTitle(const char* strTitle) const;
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
