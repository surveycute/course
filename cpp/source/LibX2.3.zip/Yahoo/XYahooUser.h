//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooUser.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooUserH
#define XYahooUserH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h> // for XYahoo_Allocate() and XYahoo_Free()
#include <./List/XLinkList.h>
//---------------------------------------------------------------------------
class TXYahooChannel; // predefined
//---------------------------------------------------------------------------
class TXYahooUser
{
private:
	//---------------------
        int RefCount;
        char* Name;
        char* State;
        char* INF;
	//---------------------
public:
	//---------------------
        int Age;
        char Sex; // U M or F
	//---------------------
        TXLinkList<TXYahooChannel> pChannels; // could be room and/or PM
//---------------------------
        TXYahooUser();
        ~TXYahooUser();
        void Clear();
	//---------------------
        void incRefCount();
        void decRefCount();
        bool isRefCount() const;
        const int getRefCount() const;
	//---------------------
        void setName(const char* strName);
        const char* getName() const;
        void setState(const char* strState);
        const char* getState() const;
        void setINF(const char* strINF);
        const char* getINF() const;
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
