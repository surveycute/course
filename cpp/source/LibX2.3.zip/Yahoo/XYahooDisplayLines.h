//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplayLines.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooDisplayLinesH
#define XYahooDisplayLinesH
//---------------------------------------------------------------------------
#include <./Buffer/XBuffer.h>
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Yahoo/XYahooDisplayLine.h>
#include <./List/XList.h>
//---------------------------------------------------------------------------
class TXYahooDisplayLines : public TXList<TXYahooDisplayLine>
{
private:
	//---------------------
	//---------------------
public:
	//---------------------
//---------------------------
	//---------------------
        TXYahooDisplayLines();
        ~TXYahooDisplayLines();
	//---------------------
        TXYahooDisplayLine* addSystem(const char* strMsg);
        TXYahooDisplayLine* addStatus(const char* strMsg);
        TXYahooDisplayLine* addOnline();
        TXYahooDisplayLine* addOffline();
        TXYahooDisplayLine* addChatEnter();
        TXYahooDisplayLine* addChatLeave();
        TXYahooDisplayLine* addChatMessage(const char* strUser, const char* strMsg, bool bSelf = false);
        TXYahooDisplayLine* addPagerMessage(const char* strUser, const char* strMsg, bool bSelf = false);
        TXYahooDisplayLine* addChatUserJoin(const char* strUser);
        TXYahooDisplayLine* addChatUserLeave(const char* strUser);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
