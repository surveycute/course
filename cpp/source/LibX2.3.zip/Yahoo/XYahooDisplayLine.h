//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooDisplayLine.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooDisplayLineH
#define XYahooDisplayLineH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Yahoo/XYahooDisplayLineBlock.h>
#define c_XRichDisplay_Block_Max 4
//---------------------------------------------------------------------------
class TXYahooDisplayLine
{
private:
	//---------------------
	//---------------------
public:
	//---------------------
        unsigned short BlockCount;
        TXYahooDisplayLineBlocks Blocks;
	//---------------------
        XRichDisplayType Type;
        double TimeStamp;
        unsigned short Height;
	//--------------------- Temp stored
        unsigned long CurrentTop;
        unsigned long CurrentBottom;
	//---------------------
        char* User;
        const char* InfTags; // link to string managed by block
        char* Text; // used when not using Blocks
	//---------------------
//---------------------------
        TXYahooDisplayLine();
        ~TXYahooDisplayLine();
	//---------------------
        void Reset(); // clear without free'ing memory for reuse
        void Clear();
	//---------------------
        void setUser(const char* strUser);
        void setText(const char* strText);
        const char* getText() const;
	//---------------------
        bool parseTextBlocks(const char* strText);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
