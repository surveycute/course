//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooClient.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooClientH
#define XYahooClientH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGSession.h>
#include <./Yahoo/XYahooPagerClient.h>
#include <./Yahoo/XYahooChatClient.h>
#include <./Yahoo/XYahooChannels.h>
#include <./Yahoo/XYahooDisplay.h>
#include <./Yahoo/XYahooUsers.h>
#include <./Yahoo/Protocol/Filter/XYMSGFilters.h>
#include <./Yahoo/Protocol/Filter/XYahooIgnoredUsers.h>
//---------------------------------------------------------------------------
class TXYahooClient
{
private:
	//---------------------
public:
	//---------------------
        void* pData;
	//---------------------
        TXYMSGSession           Session;
        TXYahooChannels         Channels;
	//---------------------
        TXYahooChatClient       ChatClient;
        TXYahooPagerClient      PagerClient;
	//---------------------
        TXYahooDisplay*         pDisplay;
	//---------------------
        TXYahooUsers            Users;
	//---------------------
        TXYMSGFilterList        Filters;
        TXYahooIgnoredUsers     IgnoredUsers;
//---------------------------
        TXYahooClient();
        ~TXYahooClient();
	//---------------------
        void Clear(bool bClean = false);
	//---------------------
        void setDisplay(TXYahooDisplay* psetDisplay);
        bool InitPager();
        bool InitChat();
	//---------------------
        bool Step();
	//---------------------
        bool isCaptcha();
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
