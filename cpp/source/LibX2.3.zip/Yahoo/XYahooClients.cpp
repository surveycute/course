//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooClients.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <mem.h>
#pragma hdrstop
#include <./Yahoo/XYahooClients.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooClients::TXYahooClients() : TXList<TXYahooClient>()
{
	//------------------
        ID = 3;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooClients::~TXYahooClients()
{
	//------------------
        XLOG("~XYhooClients...diconnect all");
        DisconnectAll();
        XLOG("~XYhooClients...Done");
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooClients::DisconnectAll()
{
	//------------------
        TXYahooClient** pClients = (TXYahooClient**)editList();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                pClients[i]->Session.Disconnect();
	//------------------
}
//---------------------------------------------------------------------------
bool TXYahooClients::Step()
{
        bool r = true;
        TXYahooClient** pClients = (TXYahooClient**)editList();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (!pClients[i]->Step())
                        r = false;
	//------------------
        return r;
}
//---------------------------------------------------------------------------
TXYahooClient* TXYahooClients::needsCaptcha()
{
        TXYahooClient** pClients = (TXYahooClient**)editList();
	//------------------
        for (unsigned long i = 0L;i < Count;++i)
                if (pClients[i]->isCaptcha())
                        return pClients[i];
	//------------------
        return (TXYahooClient*)0;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
