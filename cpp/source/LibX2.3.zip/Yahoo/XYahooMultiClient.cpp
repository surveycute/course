//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooMultiClient.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <./Yahoo/XYahooMultiClient.h>
//---------------------------------------------------------------------------
TXYahooMultiClient::TXYahooMultiClient()
{
        //------------------
        initted = false;
        pDisplay = (TXYahooDisplay*)0;
        pSelectedAccount = (TXYahooAccount*)0;
        pSelectedClient  = (TXYahooClient*) 0;
        pSelectedChannel = (TXYahooChannel*)0;
        pSelectedUser    = (TXYahooUser*)   0;
        //------------------
}
//---------------------------------------------------------------------------
TXYahooMultiClient::~TXYahooMultiClient()
{
        //------------------
        release();
        //------------------
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::init()
{
        //------------------
        WSADATA wsa;
        WSAStartup( MAKEWORD( 2, 2 ), &wsa );
        initted = true;
        //------------------
        return true;
}
//---------------------------------------------------------------------------
void TXYahooMultiClient::release()
{
        //------------------
        if (initted)
        {
                //------------------
                WSACleanup();
                //------------------
        }
        //------------------
        initted = false;
        //------------------
}
//---------------------------------------------------------------------------
void TXYahooMultiClient::setDisplay(TXYahooDisplay* tpDisplay)
{
        //------------------
        pDisplay = tpDisplay;
        //------------------
}
//---------------------------------------------------------------------------
unsigned long TXYahooMultiClient::getQuickMessageCount() const
{
        //------------------
        return QuickMessages.getCount();
}
//---------------------------------------------------------------------------
unsigned long TXYahooMultiClient::getChannelCount() const
{
        //------------------
        return pChannelIndex.getCount();
}
//---------------------------------------------------------------------------
unsigned long TXYahooMultiClient::getClientCount() const
{
        //------------------
        return Clients.getCount();
}
//---------------------------------------------------------------------------
unsigned long TXYahooMultiClient::getAccountCount() const
{
        //------------------
        return Accounts.getCount();
}
//---------------------------------------------------------------------------
unsigned long TXYahooMultiClient::getUserCount() const
{
        //------------------
        return pUserIndex.getCount();
}
//---------------------------------------------------------------------------
const TXQuickMessage** TXYahooMultiClient::getQuickMessages() const
{
        //------------------
        return (const TXQuickMessage**)QuickMessages.getList();
}
//---------------------------------------------------------------------------
const TXYahooChannel** TXYahooMultiClient::getChannels() const
{
        //------------------
        return (const TXYahooChannel**)pChannelIndex.getList();
}
//---------------------------------------------------------------------------
const TXYahooClient** TXYahooMultiClient::getClients() const
{
        //------------------
        return (const TXYahooClient**)Clients.getList();
}
//---------------------------------------------------------------------------
const TXYahooAccount** TXYahooMultiClient::getAccounts() const
{
        //------------------
        return (const TXYahooAccount**)Accounts.getList();
}
//---------------------------------------------------------------------------
const TXYahooUser** TXYahooMultiClient::getUsers() const
{
        //------------------
        return pUserIndex.getList();
}
//---------------------------------------------------------------------------
TXQuickMessage** TXYahooMultiClient::editQuickMessages()
{
        //------------------
        return (TXQuickMessage**)QuickMessages.editList();
}
//---------------------------------------------------------------------------
TXYahooChannel** TXYahooMultiClient::editChannels()
{
        //------------------
        return (TXYahooChannel**)pChannelIndex.editList();
}
//---------------------------------------------------------------------------
TXYahooClient** TXYahooMultiClient::editClients()
{
        //------------------
        return (TXYahooClient**)Clients.editList();
}
//---------------------------------------------------------------------------
TXYahooAccount** TXYahooMultiClient::editAccounts()
{
        //------------------
        return (TXYahooAccount**)Accounts.editList();
}
//---------------------------------------------------------------------------
TXYahooUser** TXYahooMultiClient::edittUsers()
{
        //------------------
        return (TXYahooUser**)pUserIndex.editList();
}
//---------------------------------------------------------------------------
TXYahooChannel* TXYahooMultiClient::selectChannel(int idx)
{
        //------------------
        if (idx >= 0 && ((unsigned long)idx) < pChannelIndex.getCount())
        {
                pSelectedChannel = ((TXYahooChannel**)pChannelIndex.editList())[idx];
                selectClient(pSelectedChannel->getYahooClient());
        }
        else
        {
                pSelectedChannel = (TXYahooChannel*)0;
                selectClient((TXYahooClient*)0);
        }
        //------------------
        return pSelectedChannel;
}
//---------------------------------------------------------------------------
TXYahooClient* TXYahooMultiClient::selectClient(int idx)
{
        //------------------
        if (idx >= 0 && ((unsigned long)idx) < Clients.getCount())
        {
                pSelectedClient = ((TXYahooClient**)Clients.editList())[idx];
                pSelectedAccount = &pSelectedClient->Session.Account;
        }
        else
        {
                pSelectedClient = (TXYahooClient*)0;
                pSelectedAccount = (TXYahooAccount*)0;
        }
        //------------------
        return pSelectedClient;
}
//---------------------------------------------------------------------------
TXYahooAccount* TXYahooMultiClient::selectAccount(int idx)
{
        //------------------
        if (idx >= 0 && ((unsigned long)idx) < Accounts.getCount())
        {
                //------------------
                pSelectedAccount = ((TXYahooAccount**)Accounts.editList())[idx];
                pSelectedClient = (TXYahooClient*)pSelectedAccount->pData;
                //------------------
        }
        else
        {
                pSelectedClient = (TXYahooClient*)0;
                pSelectedAccount = (TXYahooAccount*)0;
        }
        //------------------
        return pSelectedAccount;
}
//---------------------------------------------------------------------------
TXYahooUser* TXYahooMultiClient::selectUser(int idx)
{
        //------------------
        if (idx >= 0 && ((unsigned long)idx) < pUserIndex.getCount())
                pSelectedUser = ((TXYahooUser**)pUserIndex.editList())[idx];
        else
                pSelectedUser = (TXYahooUser*)0;
        //------------------
        return pSelectedUser;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::selectChannel(const TXYahooChannel* pChannel)
{
        TXYahooChannel** pChannels = (TXYahooChannel**)pChannelIndex.editList();
        unsigned long idx, cnt = pChannelIndex.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pChannel == pChannels[idx])
                {
                        pSelectedChannel = pChannels[idx];
                        return (int)idx;
                }
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::selectClient(const TXYahooClient* pClient)
{
        TXYahooClient** pClients = (TXYahooClient**)Clients.editList();
        unsigned long idx, cnt = Clients.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pClient == pClients[idx])
                {
                        pSelectedClient = pClients[idx];
                        pSelectedAccount = &pSelectedClient->Session.Account;
                        return (int)idx;
                }
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::selectAccount(const TXYahooAccount* pAccount)
{
        TXYahooAccount** pAccounts = (TXYahooAccount**)Accounts.editList();
        unsigned long idx, cnt = Accounts.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pAccount == pAccounts[idx])
                {
                        pSelectedAccount = pAccounts[idx];
                        return (int)idx;
                }
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::selectUser(const TXYahooUser* pUser)
{
        TXYahooUser** pUsers = (TXYahooUser**)pUserIndex.editList();
        unsigned long idx, cnt = pUserIndex.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pUser == pUsers[idx])
                {
                        pSelectedUser = pUsers[idx];
                        return (int)idx;
                }
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
TXYahooChannel* TXYahooMultiClient::getSelChannel() const
{
        //------------------
        return pSelectedChannel;
}
//---------------------------------------------------------------------------
TXYahooClient* TXYahooMultiClient::getSelClient() const
{
        //------------------
        return pSelectedClient;
}
//---------------------------------------------------------------------------
TXYahooAccount* TXYahooMultiClient::getSelAccount() const
{
        //------------------
        return pSelectedAccount;
}
//---------------------------------------------------------------------------
TXYahooUser* TXYahooMultiClient::getSelUser() const
{
        //------------------
        return pSelectedUser;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::getSelChannelIndex() const
{
        TXYahooChannel** pChannels = (TXYahooChannel**)pChannelIndex.getList();
        unsigned long idx, cnt = pChannelIndex.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pSelectedChannel == pChannels[idx])
                        return (int)idx;
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::getSelClientIndex() const
{
        TXYahooClient** pClients = (TXYahooClient**)Clients.getList();
        unsigned long idx, cnt = Clients.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pSelectedClient == pClients[idx])
                        return (int)idx;
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::getSelAccountIndex() const
{
        TXYahooAccount** pAccounts = (TXYahooAccount**)Accounts.getList();
        unsigned long idx, cnt = Accounts.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pSelectedAccount == pAccounts[idx])
                        return (int)idx;
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::getSelUserIndex() const
{
        TXYahooUser** pUsers = (TXYahooUser**)pUserIndex.getList();
        unsigned long idx, cnt = pUserIndex.getCount();
        //------------------
        for (idx = 0L;idx < cnt;++idx)
                if (pSelectedUser == pUsers[idx])
                        return (int)idx;
        //------------------
        return -1;
}
//---------------------------------------------------------------------------
TXQuickMessage* TXYahooMultiClient::addQuickMessage()
{
        //------------------
        return QuickMessages.Add();
}
//---------------------------------------------------------------------------
TXYahooAccount* TXYahooMultiClient::addAccount()
{
        //------------------
        return Accounts.Add();
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::addChannelIndex(TXYahooChannel* pChannel)
{
        //------------------
        return pChannelIndex.AddUnique(pChannel);
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::addUserIndex(TXYahooUser* pUser)
{
        //------------------
        return pUserIndex.AddUnique(pUser);
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::removeChannelIndex(TXYahooChannel* pChannel)
{
        //------------------
        return pChannelIndex.Remove(pChannel);
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::removeUserIndex(TXYahooUser* pUser)
{
        //------------------
        return pUserIndex.Remove(pUser);
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::removeAccount(int Idx)
{
        if (Idx < 0 || (unsigned long)Idx > ymc.getAccountCount())
            return false;
        //------------------
        return removeAccount(ymc.editAccounts()[Idx]);
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::removeAccount(TXYahooAccount* pAccount, bool bRemoveClient /*= true*/)
{
        TXYahooClient* pClient = (TXYahooClient*)pAccount->pData;
        //------------------
        if (pSelectedAccount == pAccount)
            pSelectedAccount = NULL;
        //------------------
        if (!Accounts.Remove(pAccount))
                return false;
        //------------------
        if (bRemoveClient && pClient)
            if (!removeClient(pClient, false/*bRemoveAccount*/))
                    return false;
        //------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::removeClient(TXYahooClient* pClient, bool bRemoveAccount /*= true*/)
{
        TXYahooAccount* pAccount = &pClient->Session.Account;
        //------------------
        if (pSelectedClient == pClient)
            pSelectedClient = NULL;
        //------------------
        if (!Clients.Remove(pClient))
                return false;
        //------------------
        if (bRemoveAccount && pAccount)
            if (!removeAccount(pAccount, false/*bRemoveAccount*/))
                return false;
        //------------------
        return true;
}
//---------------------------------------------------------------------------
void TXYahooMultiClient::clearChannelIndex()
{
        //------------------
        pChannelIndex.Clear();
        //------------------
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::checkIndexQuickMessage(int Idx)
{
        //------------------
        return QuickMessages.CheckIndex(Idx);
}
//---------------------------------------------------------------------------
TXYahooClient* TXYahooMultiClient::activateAccount(TXYahooAccount* pAccount /*= (TXYahooAccount*)0  defaults to selected account*/)
{
       	//------------------
        if (!pAccount)
                pAccount = pSelectedAccount;
        if (!pAccount)
                return (TXYahooClient*)0;
       	//------------------
        TXYahooClient* pClient = (TXYahooClient*)pAccount->pData;
       	//------------------
        if (!pClient)
        {
               	//------------------
                pClient = Clients.Add();
                if (!pClient)
                        return (TXYahooClient*)0;
               	//------------------
                pClient->pData = (void*)pAccount;
               	//------------------
                pClient->InitPager();
                pClient->InitChat();
               	//------------------
                pClient->setDisplay(pDisplay);
               	//------------------
                if (!pClient->Filters.Add((TXYMSGFilterBase*)&FilterCore))
                        return (TXYahooClient*)0;
                if (!pClient->Filters.Add((TXYMSGFilterBase*)&FilterLocalIgnores))
                        return (TXYahooClient*)0;
               	//------------------
                pAccount->pData = pClient;
               	//------------------
                pClient->Session.Account.Copy(*pAccount);
       	        //------------------
        }
       	//------------------
        return pClient;
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::postMessage(const char* strMessage)
{
       	//------------------
        if (!pSelectedChannel || !pSelectedClient)
                return false;
       	//------------------
        if (pSelectedChannel->Type == xctChat)
        {
                pSelectedClient->ChatClient.SendMessage(pSelectedClient->Session, strMessage);
        }
        else if (pSelectedChannel->Type == xctPager)
        {
               	//------------------
                if (!pSelectedChannel->pPagerUser)
                        return false;
               	//------------------
                pSelectedClient->PagerClient.SendMessage(pSelectedClient->Session, pSelectedChannel->pPagerUser->getName(), strMessage);
               	//------------------
        }
       	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::Connect(const char* strHost, unsigned short usPort, TXYahooAccount* pAccount /*= (TXYahooAccount*)0  defaults to selected account*/ )
{
       	//------------------
        if (pAccount)
        {
                if (!pAccount)
                        return false;
                selectAccount(pAccount);
        }
       	//------------------
        if (!pSelectedAccount)
                return false;
       	//------------------
        selectClient(activateAccount(pSelectedAccount));
       	//------------------
        if (!pSelectedClient || !pSelectedAccount)
                return false;
       	//------------------
        TXYMSGSession*  pSession = &pSelectedClient->Session;
       	//------------------
        if (pSession->PagerStatus != ymsgpagerOffline)
                return true; // already connected/connecting
       	//------------------
        pSession->Disconnect();
        //------------------------------
        if (!pSession->Connect(strHost, usPort))
                return false;
        if (!pSession->Socket.isConnected())
                return false;
        //------------------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::Connect(const char* strHost, unsigned short usPort, TXYahooClient* pClient)
{
       	//------------------
        selectClient(pClient);
       	//------------------
        if (!pSelectedClient)
                return false;
       	//------------------
        return Connect(strHost, usPort, &pSelectedClient->Session.Account);
}
//---------------------------------------------------------------------------
void TXYahooMultiClient::Logoff(TXYahooClient* pClient)
{
       	//------------------
        if (pClient)
                selectClient(pClient);
       	//------------------
        if (!pSelectedClient)
                return ;
       	//------------------
        if (pSelectedClient->Session.PagerStatus != ymsgpagerOffline)
                pSelectedClient->Session.Disconnect();
       	//------------------
        return ;
}
//---------------------------------------------------------------------------
void TXYahooMultiClient::DisconnectAll()
{
       	//------------------
        Clients.DisconnectAll();
       	//------------------
}
//---------------------------------------------------------------------------
int TXYahooMultiClient::getLastLoginError()
{
       	//------------------
        if (!pSelectedClient)
                return 0;
       	//------------------
        return pSelectedClient->Session.Socket.getLastError();
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::toggleConnect(const char* strHost, unsigned short usPort, TXYahooAccount* pAccount /*= (TXYahooAccount*)0  defaults to selected account*/ )
{
       	//------------------
        if (pAccount)
                selectAccount(pAccount);
       	//------------------
        if (!pSelectedAccount)
                return false;
       	//------------------
        selectClient(activateAccount(pSelectedAccount));
       	//------------------
        if (!pSelectedClient || !pSelectedAccount)
                return false;
       	//------------------
        if (pSelectedClient->Session.PagerStatus == ymsgpagerOffline)
                return Connect(strHost, usPort, &pSelectedClient->Session.Account);
       	//------------------
        pSelectedClient->Session.Disconnect();
       	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::toggleConnect(const char* strHost, unsigned short usPort, TXYahooClient* pClient)
{
       	//------------------
        selectClient(pClient);
       	//------------------
        if (!pSelectedClient)
                return false;
       	//------------------
        if (pSelectedClient->Session.PagerStatus == ymsgpagerOffline)
                return Connect(strHost, usPort, &pSelectedClient->Session.Account);
       	//------------------
        pSelectedClient->Session.Disconnect();
       	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooMultiClient::Step()
{
       	//------------------
        return Clients.Step();
}
//---------------------------------------------------------------------------
TXYahooClient* TXYahooMultiClient::ClientNeedsCaptcha()
{
       	//------------------
        return Clients.needsCaptcha();
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
