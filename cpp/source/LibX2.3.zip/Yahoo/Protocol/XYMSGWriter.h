//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGWriter.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGWriterH
#define XYMSGWriterH
//---------------------------------------------------------------------------
#include <./Net/Win/XSocket.h>
#include <./Buffer/XBuffer.h>
#include <./Yahoo/Protocol/XYMSGHeader.h>
#include <./Yahoo/Protocol/XYMSGHash.h>
//---------------------------------------------------------------------------
typedef enum {ymsgwsReady = 0, ymsgwsProcess, ymsgwsWrite, ymsgwsDestroying, ymsgwsError} XYMSGWriter_Status;
//---------------------------------------------------------------------------
class TXYMSGWriter
{
public:
	//---------------------
	//---------------------
private:
	//---------------------
        XYMSGWriter_Status Status;
//---------------------------
        bool Process();
        bool WritePacket(TXSocket& Socket);
	//---------------------
public:
	//---------------------
        TXBuffer DataBuffer;
        TXYMSGHeader Header;
        TXYMSGHash DataHash;
//---------------------------
        TXYMSGWriter();
        ~TXYMSGWriter();
	//---------------------
        void Clear(bool bClean = true);
        bool Send(); // no Socket means your going to Step through
        bool Send(TXSocket& Socket); // Socket means blocking send
        bool Step(TXSocket& Socket);
	//---------------------
        XYMSGWriter_Status getStatus() const;
        bool isReady() const;
        bool isError() const;
	//---------------------
        // @TODO Caching interface
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
