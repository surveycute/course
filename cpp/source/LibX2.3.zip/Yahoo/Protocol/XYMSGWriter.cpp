//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGWriter.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./Yahoo/Protocol/XYMSGWriter.h>
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGWriter::TXYMSGWriter()
{
	//------------------
        Clear();
	//------------------
}
//---------------------------------------------------------------------------
TXYMSGWriter::~TXYMSGWriter()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
bool TXYMSGWriter::Send()
{
	//------------------
        if (Status != ymsgwsReady && Status != ymsgwsError)
                return false;
	//------------------
        Status = ymsgwsProcess;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGWriter::Send(TXSocket& Socket)
{
	//------------------
        if (Status != ymsgwsReady && Status != ymsgwsError)
                return false;
	//------------------
        if (!Process())
                return false;
      	//------------------
        if (!WritePacket(Socket))
                return false;
      	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGWriter::Step(TXSocket& Socket)
{
	//------------------
        switch (Status)
        {
                case ymsgwsReady:
                        return true;
                case ymsgwsError:
                case ymsgwsDestroying:
                        XDebug("Writer Step Error");
                        return false;
                case ymsgwsWrite:
                        if (!WritePacket(Socket))
                                return false;
                        Status = ymsgwsReady;
                        break;
                case ymsgwsProcess:
                        if (!Process())
                                return false;
                        Status = ymsgwsWrite;
                        break;
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
void TXYMSGWriter::Clear(bool bClean /*= true*/)
{
	//------------------
        Header.Clear();;
        DataBuffer.Clear(bClean);
        DataHash.Clear(bClean);
        Status = ymsgwsReady;
	//------------------
}
//---------------------------------------------------------------------------
bool TXYMSGWriter::Process()
{
        XYMSGHashType* pHashList = DataHash.editList();
        unsigned short i, l = DataHash.getCount();
        unsigned short addSize, totalSize;
        char* pBuffer;
        char str[8];
	//------------------
        DataBuffer.Clear(false/*bClean*/);
	//------------------
        if (!DataBuffer.setAllocation(c_XYMSGMinimumBufferSize))
                return false;
	//------------------
        if (!DataBuffer.setSize(c_XYMSGHeader_Size))
                return false;
	//------------------
        totalSize = addSize = 0L;
        pBuffer = (char*)DataBuffer.editData();
        pBuffer += c_XYMSGHeader_Size;
        pBuffer[0] = '\0';
	//------------------
        for (i = 0;i < l;++i)
        {
        	//------------------
                if (!pHashList[i].strValue)
                {
                        itoa(pHashList[i].iValue, str, 10);
                        pHashList[i].strValue = strdup(str);
                }
        	//------------------
                itoa(pHashList[i].Key, str, 10);
        	//------------------
                addSize = 4 + strlen(str) + strlen(pHashList[i].strValue);
                if (!DataBuffer.addSize(addSize + 1/*NULL terminator*/))
                        return false;
        	//------------------
                totalSize += addSize;
                pBuffer = (char*)DataBuffer.editData();
                pBuffer += c_XYMSGHeader_Size;
        	//------------------
                strcat(pBuffer, str);
                strcat(pBuffer, c_XYMSGDelimitter);
                strcat(pBuffer, pHashList[i].strValue);
                strcat(pBuffer, c_XYMSGDelimitter);
        	//------------------
        } // for (i = 0;i < l;++i)
	//------------------
        Header.Size = totalSize;
        Header.Pack();
        memcpy((char*)DataBuffer.editData(), Header.Buffer, c_XYMSGHeader_Size);
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGWriter::WritePacket(TXSocket& Socket)
{
	//------------------
        return Socket.Write((char*)DataBuffer.editData(), DataBuffer.getSize());
}
//---------------------------------------------------------------------------
XYMSGWriter_Status TXYMSGWriter::getStatus() const
{
	//------------------
        return Status;
}
//---------------------------------------------------------------------------
bool TXYMSGWriter::isReady() const
{
	//------------------
        return (Status == ymsgwsReady);
}
//---------------------------------------------------------------------------
bool TXYMSGWriter::isError() const
{
	//------------------
        return (Status == ymsgwsError);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
