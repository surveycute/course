//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGSessions.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <mem.h>
#pragma hdrstop
#include <./Yahoo/Protocol/XYMSGSessions.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGSessions::TXYMSGSessions() : TXList<TXYMSGSession>()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
