//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGBuilder.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include "XYMSGBuilder.h"
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Yahoo/Protocol/XYMSGSession.h>
#include <./Debug/XDebug.h>
#include <stdio.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGBuilder::TXYMSGBuilder()
{
	//---------------------
        TimeOut = 5000L;
	//---------------------
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::Step(TXYMSGSession& Session)
{
	//---------------------
        if (!Writer.Step(Session.Socket))
        {
        	//---------------------
        	//---------------------
                XDebug("Builder Step - Writer Step failed");
                return false;
        }
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::WaitTurn(TXYMSGSession& Session)
{
	//---------------------
        if (Writer.isReady())
                return true;
	//---------------------
        unsigned long TimeOutTime = GetTickCount() + TimeOut;
	//---------------------
        while (!Writer.isReady())
                if (GetTickCount() > TimeOutTime)
                {
                        char str[120];
                        sprintf(str, "Builder WaitTurn Timed Out. Abandoning. Writer: %d", (int)Writer.getStatus());
                        XDebug(str);
                        return false;
                }
                else if (!Writer.Step(Session.Socket))
                    return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::LogonRequestChallenge(TXYMSGSession& Session)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChallengeRequest, xymsgstateOffline, 0L);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::LogonReplyChallenge(TXYMSGSession& Session, const char* strReplyA, const char* strReplyB)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChallengeReply, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswChallengeStringA, strReplyA))
                return false;
        if (!Writer.DataHash.Add(xymsgswChallengeStringB, strReplyB))
                return false;
        if (!Writer.DataHash.Add(xymsgswUserName, Session.Account.getUser()))
                return false;
        if (!Writer.DataHash.Add(xymsgswAliasName, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(192, "-1"))
                return false;
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(xymsgswMessengerVer, c_XYahoo_MessengerVersion))
                return false;
        if (!Writer.DataHash.Add(148, "360"))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::Logoff(TXYMSGSession& Session)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Session.Socket.Disconnect();
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::PagePing(TXYMSGSession& Session)
{
        //---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcPagePing, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::ChatPing(TXYMSGSession& Session)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChatPing, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswChatName, Session.Account.getAlias()))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::ChatOnline(TXYMSGSession& Session)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChatOnline, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswChatName, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(xymsgswABCDE, "abcde"))
                return false;
        if (!Writer.DataHash.Add(xymsgswLocale, "us"))
                return false;
        if (!Writer.DataHash.Add(xymsgswMessengerVer, c_XYahoo_MessengerVersion))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::ChatJoin(TXYMSGSession& Session, const char* strRoomName)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChatJoin, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(xymsgswRoomName, strRoomName))
                return false;
        if (!Writer.DataHash.Add(xymsgswRoomNumber, "0"))
                return false;
        if (!Writer.DataHash.Add(xymsgswRoomMode, "2"))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::ChatLogout(TXYMSGSession& Session)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChatLogout, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::ChatLeave(TXYMSGSession& Session)
{
	//---------------------
/*        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChatLeave, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(xymsgswRoomMode, "0"))
                return false;
        if (!Writer.DataHash.Add(xymsgswRoomName, ))
                return false;
        if (!Writer.DataHash.Add(xymsgswChatName, Session.Account.getAlias()))
                return false;
	//---------------------
        if (!Session.Send())
                return false;
*/
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::PrivateMessage(TXYMSGSession& Session, const char* strUser, const char* strMessage)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcPageMessage, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(xymsgswIMTo, strUser))
                return false;
        if (!Writer.DataHash.Add(xymsgswText, strMessage))
                return false;
        if (!Writer.DataHash.Add(xymsgswIMVironment, ";0"))
                return false;
        if (!Writer.DataHash.Add(xymsgswIM1, "0"))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::AddBuddy(TXYMSGSession& Session, const char* strUser, const char* strMessage /*= NULL*/)
{
	//---------------------
/*        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcPageMessage, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
	//---------------------
        if (!Session.Send())
                return false;
	//---------------------
*/
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::ChatMessage(TXYMSGSession& Session, const char* strMessage)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcChatMessage, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswAlias, Session.Account.getAlias()))
                return false;
        if (!Writer.DataHash.Add(xymsgswRoomName, Session.getRoomName()))
                return false;
        if (!Writer.DataHash.Add(xymsgswUserText, strMessage))
                return false;
        if (!Writer.DataHash.Add(xymsgswTextMode, "1"))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::ActivateIdentity(TXYMSGSession& Session, const char* strIdentity)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcActivateIdentity, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswIdentity, strIdentity))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGBuilder::DeactivateIdentity(TXYMSGSession& Session, const char* strIdentity)
{
	//---------------------
        if (!WaitTurn(Session))
                return false;
	//---------------------
        Writer.Header.Set(xymsgsvcDeactivateIdentity, Session.State, Session.SessionID);
        Writer.DataHash.Clear();
	//---------------------
        if (!Writer.DataHash.Add(xymsgswIdentity, strIdentity))
                return false;
	//---------------------
        if (!Writer.Send())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
