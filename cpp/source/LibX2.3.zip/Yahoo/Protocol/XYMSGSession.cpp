//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGSession.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#pragma hdrstop
#include <./Yahoo/Protocol/XYMSGSession.h>
#include <./Yahoo/Protocol/Handler/XYMSGHandlerBase.h>
#include <stdio.h>
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGSession::TXYMSGSession()
{
	//------------------
        ChatOnline = false;
        HandlerCount = 0;
        pData = NULL;
	//------------------
        PagerStatus = ymsgpagerOffline;
        ChatStatus = ymsgchatOffline;
	//------------------
        RoomName = joinRoomName = NULL;
        VoiceAuth = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXYMSGSession::~TXYMSGSession()
{
	//------------------
        XLOG("~XYMSGSession...clear");
        Clear();
        XLOG("~XYMSGSession...Done");
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGSession::Clear()
{
	//------------------
        Disconnect();
	//------------------
        ChatOnline = false;
        PagerStatus = ymsgpagerOffline;
	//------------------
        if (RoomName) XYahoo_Free(RoomName);
        if (joinRoomName) XYahoo_Free(joinRoomName);
        if (VoiceAuth) XYahoo_Free(VoiceAuth);
	//------------------
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Step()
{
	//------------------
        if (!Reader.Step(Socket))
        {
                //------------------
                switch (Reader.getStatus())
                {
                        //case ymsgrsReady:
                        //        break;
                        case ymsgrsDone:
                                if (!Handle())
                                        return false;
                                Reader.Clear(false/*bClean*/);
                                break;
                        case ymsgrsFilter:
                                Reader.Accept();
                                //Reader.Dump();
                                break;
                        case ymsgrsError:
                        case ymsgrsDestroying:
                                XLOG("Session Error - Reader Step Failed");
                                readActive = false;
                                return false;
                } // switch (Reader.getStatus())
                //------------------
        } // Reader Step
	//------------------
        if (!Builder.Step(/*TXYMSGSession*/*this))
        {
                char str[120];
                sprintf(str, "Builder step failed. Last Error: %s", Socket.getLastErrorString());
                XDebug(str);
                writeActive = false;
        }
	//------------------
        switch (ChatStatus)
        {
                case ymsgchatGetCapchaImage:
                        if (!Captcha.Step())
                        {
                                if (Captcha.isUserInput())
                                        ChatStatus = ymsgchatCaptchaUserInput;
                                else
                                {
                                        if (Captcha.isDone()) ChatStatus = ymsgchatChatting;
                                        else                  ChatStatus = ymsgchatOffline; // error
                                }
                                return false; // error or need input
                        }
                        break;
                case ymsgchatCaptchaWait:
                        if (!Captcha.Step())
                        {
                                if (Captcha.isDone())
                                        ChatStatus = ymsgchatCaptchaDone;
                                else if (!Captcha.isUserInput())
                                {
                                        ChatStatus = ymsgchatOffline; // error;
                                        XLOG("Session Error - Caption Step Failed");
                                        return false;
                                }
                        }
                        break;
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Send()
{
	//------------------
        writeActive = true;
	//------------------
        return Builder.Writer.Send(Socket); // Bypass Builder, Builder.Send() calls Session.Send()
}
//---------------------------------------------------------------------------
void TXYMSGSession::setServer(const TXServer& xsvrServer)
{
	//------------------
        Socket.Server.set(xsvrServer.getHost(), xsvrServer.getPort());
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGSession::setServer(const char* strHost, unsigned short usPort /*= c_XYMSG_Default_Port*/)
{
	//------------------
        Socket.Server.set(strHost, usPort);
	//------------------
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Connect(const char* strHost /*= NULL*/, unsigned short usPort /*= c_XYMSG_Default_Port*/)
{
	//------------------
        if (!PagerStatus != ymsgpagerConnecting)
                return false;
	//------------------
        if (strHost)
                Socket.Server.set(strHost, usPort);
	//------------------
        if (!Socket.Connect())
                return false;
	//------------------
        PagerStatus = ymsgpagerConnected;
        char str[128];
        sprintf(str, "Connected to '%s'=>'%s'", Socket.Server.getHost(), Socket.Server.getIPString());
        XDebug(str);
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Disconnect(bool bHard /*= false*/)
{
        bool r = true;
        if (bHard)      {XLOG("XYMSGSession::Disconnect (Hard)");}
        else            XLOG("XYMSGSession::Disconnect (Soft)");
	//------------------
        if (!bHard && PagerStatus == ymsgpagerOnline)
        {
                XLOG("XYMSGSession::Disconnect... pagerOnline...");
        	//------------------
                if (ChatStatus == ymsgchatChatting)
                {
                        XLOG("XYMSGSession::Disconnect... pagerOnline...chatChatting (LeavingRoom)");
                        if (!LeaveRoom())
                        {
                                r = false;
                                XLOG("XYMSGSession::Disconnect... pagerOnline...chatChatting (LeavingRoom) - Leave Failed!");
                        }
                }
        	//------------------
                if (!Logoff())
                        r = false;
        	//------------------
        }
	//------------------
        Socket.Disconnect();
        PagerStatus = ymsgpagerOffline;
        ChatStatus = ymsgchatOffline;
        ChatOnline = false;
        Captcha.Clear();
	//------------------
        return r;
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Handle()
{
	//------------------
        for (unsigned short i = 0L;i < HandlerCount;++i)
                switch (Handlers[i]->Handle(/*XYahooSession&*/ *this))
                {
                        //case ymsghNone: continue
                        case ymsghOk:
                                return true; //handled
                        case ymsghError:
                                return false;
                }
	//------------------
        Reader.Dump(); // Not handled, dump and return success
	//------------------
        return true;
}
//---------------------------------------------------------------------------
void TXYMSGSession::clearHandlers(bool bClean /*= true*/)
{
	//------------------
        HandlerCount = 0;
	//------------------
}
//---------------------------------------------------------------------------
bool TXYMSGSession::addHandler(TXYMSGHandlerBase* pHandler)
{
	//------------------
        if (HandlerCount - 1 <= c_XYahooSession_Handler_Max)
                Handlers[HandlerCount++] = pHandler;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGSession::removeHandler(TXYMSGHandlerBase* pHandler)
{
        unsigned short i, ii;
	//------------------
        for (i = 0L;i < HandlerCount;++i)
                if (Handlers[i] == pHandler)
                {
                	//------------------ adjust list
                        for (ii = i+1;ii < HandlerCount;++ii)
                                Handlers[ii-1] = Handlers[ii];
                	//------------------ trim size
                        HandlerCount--;
                	//------------------
                        return true; // done
                }
	//------------------
        return false; // not found
}
//---------------------------------------------------------------------------
void TXYMSGSession::setAccount(const char* strUser, const char* strPassword)
{
	//------------------
	setAccount(strUser, strUser, strPassword);
}
//---------------------------------------------------------------------------
void TXYMSGSession::setAccount(const char* strUser, const char* strAlias, const char* strPassword)
{
	//------------------
        Account.set(strUser, strAlias, strPassword);
	//------------------
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Logon()
{
	//------------------
        if (PagerStatus == ymsgpagerOffline)
                if (!Connect())
                        return false;
	//------------------
        if (PagerStatus != ymsgpagerConnected)
                return false;
	//------------------
        PagerStatus = ymsgpagerAuth;
	//------------------
        if (!Builder.LogonRequestChallenge(/*TXYMSGSession*/*this))
                return false;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Logon(const char* strUser, const char* strPassword)
{
	//------------------
        return Logon(strUser, strUser, strPassword);
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Logon(const char* strUser, const char* strAlias, const char* strPassword)
{
	//------------------
        if (PagerStatus != ymsgpagerOffline && PagerStatus != ymsgpagerConnected)
                return false;
	//------------------
        setAccount(strUser, strAlias, strPassword);
	//------------------
        return Logon();
}
//---------------------------------------------------------------------------
bool TXYMSGSession::Logoff()
{
	//------------------
        return Builder.Logoff(/*TXYMSGSession*/*this);
}
//---------------------------------------------------------------------------
bool TXYMSGSession::JoinRoom(const char* strRoomName /*= NULL*/)
{
	//------------------
        if (PagerStatus != ymsgpagerOnline)
                return false;
	//------------------
        if (strRoomName)
        {
        	//------------------
                if (joinRoomName) XYahoo_Free(joinRoomName);
                joinRoomName = strdup(strRoomName);
        	//------------------
        }
        else if (!joinRoomName)
                return false;
	//------------------
       // if (ChatStatus > ymsgchatRequestChat)
       //         if (!LeaveRoom())
        //                return true;
       	//------------------
        if (!ChatOnline)
        {
       	        //------------------
                if (!Builder.ChatOnline(/*TXYMSGSession*/*this))
                        return false;
       	        //------------------
        }
        else
        {
       	        //------------------
                ChatStatus = ymsgchatRequestCaptcha;
                if (!Builder.ChatJoin(/*TXYMSGSession*/*this, strRoomName))
                        return false;
       	        //------------------
        }
        //------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGSession::LeaveRoom()
{
	//------------------
        if (!Builder.ChatLogout(/*TXYMSGSession*/*this))
                return false;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
void TXYMSGSession::setCurrentRoom(const char* strRoomName)
{
	//------------------
        if (RoomName) XYahoo_Free(RoomName);
        RoomName  = strdup(strRoomName);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYMSGSession::getJoinRoomName() const
{
	//------------------
        return joinRoomName;
}
//---------------------------------------------------------------------------
const char* TXYMSGSession::getRoomName() const
{
	//------------------
        return RoomName;
}
//---------------------------------------------------------------------------
void TXYMSGSession::setVoiceAuth(const char* strVoiceAuth)
{
	//------------------
        if (VoiceAuth) XYahoo_Free(VoiceAuth);
        VoiceAuth = strdup(strVoiceAuth);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYMSGSession::getVoiceAuth() const
{
	//------------------
        return VoiceAuth;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
