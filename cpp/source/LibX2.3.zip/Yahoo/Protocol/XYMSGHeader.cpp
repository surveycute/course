//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHeader.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <winsock2.h> // needed for ntoh(), hton(), ntohl(), and htonl()
#pragma hdrstop
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Yahoo/Protocol/XYMSGHeader.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGHeader::TXYMSGHeader()
{
	//------------------
        Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGHeader::Clear()
{
	//------------------
        ProtocalID[0] = 'Y';
        ProtocalID[1] = 'M';
        ProtocalID[2] = 'S';
        ProtocalID[3] = 'G';
        ProtocalVersion = c_XYMSGHeader_Version;
        Size    = 0;
        Service = 0;
        State   = 0L;
        Session = 0L;
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGHeader::Pack()
{
	//------------------
        ProtocalVersion  = ntohs(c_XYMSGHeader_Version); // gets packet funny, leaves following 2 bytes unused
        Size    = ntohs(Size);
        Service = ntohs(Service);
        State   = ntohl(State);
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGHeader::Unpack()
{
	//------------------
        ProtocalVersion = htons(ProtocalVersion);
        Size    = htons(Size);
        Service = htons(Service);
        State   = htonl(State);
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGHeader::Set(XYMSGService xymsgsvcService, XYMSGAwayState  xymsgstateState, unsigned long ulSession)
{
	//------------------
        Service = xymsgsvcService;
        State   = xymsgstateState;
        Session = ulSession;
	//------------------
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
