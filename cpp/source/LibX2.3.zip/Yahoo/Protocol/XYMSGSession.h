//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGSession.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGSessionH
#define XYMSGSessionH
//---------------------------------------------------------------------------
#include <./Buffer/XBuffer.h>
#include <./Yahoo/XYahooAccount.h>
#include <./Net/Win/XSocket.h>
#include <./Yahoo/Protocol/XYMSGConstants.h>
#include <./Yahoo/Protocol/XYMSGReader.h>
#include <./Yahoo/Protocol/XYMSGBuilder.h>
#include <./Yahoo/XYahooUsers.h>
#include <./Yahoo/XYahooCaptcha.h>
//---------------------------------------------------------------------------
class TXYMSGHandlerBase; // Predefined
//---------------------------------------------------------------------------
class TXYMSGSession
{
private:
	//---------------------
        bool readActive;
        bool writeActive;
	//---------------------
        TXYMSGHandlerBase* Handlers[c_XYahooSession_Handler_Max];
        unsigned short HandlerCount;
	//---------------------
        char* RoomName;
        char* joinRoomName;
        char* VoiceAuth;
	//---------------------
public:
	//---------------------
        void* pData; // for user defined data
	//---------------------
        bool ChatOnline;
        XYMSGPagerStatus PagerStatus;
        XYMSGChatStatus  ChatStatus;
	//---------------------
        unsigned long  SessionID;
        XYMSGAwayState State;
	//---------------------
        TXSocket Socket;
        TXYahooAccount Account;
        //---------------------
        TXYahooCaptcha Captcha;
        TXYMSGReader Reader;
        TXYMSGBuilder Builder;
        //---------------------
        TXYahooUsers ServerIgnores;
        TXYahooUsers LocalIgnores;
        TXYahooUserGroups ServerBuddyGroups;
        TXYahooUsers LocalBuddies;
        //---------------------
//---------------------------
	//---------------------
        TXYMSGSession();
        ~TXYMSGSession();
	//---------------------
        void Clear();
	//---------------------
        bool Step();
	//---------------------
        bool Send(); // sets readActive and sends current Writer data
	//---------------------
        void setServer(const TXServer& xsvrServer);
        void setServer(const char* strHost, unsigned short usPort = c_XYMSG_Default_Port);
        bool Connect(const char* strHost = NULL, unsigned short usPort = c_XYMSG_Default_Port);
        bool Disconnect(bool bHard = false);
	//---------------------
        bool Handle(); // searches registered Handlers to handle current Reader data
        void clearHandlers(bool bClean = true);
        bool addHandler(TXYMSGHandlerBase* newHandler);
        bool removeHandler(TXYMSGHandlerBase* pHandler); // returns false if not found
	//---------------------
        void setAccount(const char* strUser, const char* strPassword);
        void setAccount(const char* strUser, const char* strAlias, const char* strPassword);
        bool Logon();
        bool Logon(const char* strUser, const char* strPassword);
        bool Logon(const char* strUser, const char* strAlias, const char* strPassword);
        bool Logoff();
	//---------------------
        bool JoinRoom(const char* strRoomName = NULL); // NULL retries last
        bool LeaveRoom();
	//---------------------
        void setCurrentRoom(const char* strRoomName);
        const char* getJoinRoomName() const;
        const char* getRoomName() const ;
	//---------------------
        void setVoiceAuth(const char* strVoiceAuth);
        const char* getVoiceAuth() const;
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
