//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGReader.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGReaderH
#define XYMSGReaderH
//---------------------------------------------------------------------------
#include <./Net/Win/XSocket.h>
#include <./Buffer/XBuffer.h>
#include <./Yahoo/Protocol/XYMSGHeader.h>
#include <./Yahoo/Protocol/XYMSGHash.h>
//---------------------------------------------------------------------------
typedef enum {ymsgrsReady = 0, ymsgrsCleanup, ymsgrsReadHeader, ymsgrsFilter,
                ymsgrsDumpData, ymsgrsReadData, ymsgrsDone, ymsgrsProcess, ymsgrsDestroying,
                ymsgrsError} XYMSGReader_Status;
//---------------------------------------------------------------------------
class TXYMSGReader
{
private:
	//---------------------
        TXBuffer DataBuffer;
        unsigned long ProcessIndex;
        XYMSGReader_Status Status;
	//---------------------
        bool ReadHeader(TXSocket& Socket);
        bool DumpDataStep(TXSocket& Socket);
        bool ReadDataStep(TXSocket& Socket);
        bool Process();
	//---------------------
public:
	//---------------------
        int userID; // gerneral purpose ID for use by user
        TXYMSGHeader Header;
        TXYMSGHash DataHash;
//---------------------------
        TXYMSGReader();
        ~TXYMSGReader();
	//---------------------
        bool Step(TXSocket& Socket); // false error/(done?)
	//---------------------
        bool Clear(bool bClean = true);
        bool Inject(const char* strPacket, const unsigned short usSize); // not thread safe
        bool InjectHeader(const char* strPacket, const unsigned short usSize); // not thread safe
        bool InjectBody(const char* strPacket, const unsigned short usSize, bool bProcess = true); // not thread safe
	//---------------------
        void Accept();
        void Dump();
	//---------------------
        XYMSGReader_Status getStatus() const;
        bool isReady() const;
        bool isError() const;
        bool isDone() const;
        bool isFilter() const;
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
