//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGBuilder.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGBuilderH
#define XYMSGBuilderH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGWriter.h>
//#include <./Yahoo/Protocol/XYMSGSession.h>
#include <./Yahoo/Auth/XYahooCrypt.h>
//---------------------------------------------------------------------------
class TXYMSGSession; // predefined
//---------------------------------------------------------------------------
class TXYMSGBuilder
{
private:
	//---------------------
        unsigned long TimeOut;
        TXYahooCrypt Crypt;
	//---------------------
public:
	//---------------------
        TXYMSGWriter Writer;
	//---------------------
//---------------------------
	//---------------------
        TXYMSGBuilder();
	//---------------------
        bool Step(TXYMSGSession& Session);
        bool WaitTurn(TXYMSGSession& Session);
	//---------------------
        bool LogonRequestChallenge(TXYMSGSession& Session);
        bool LogonReplyChallenge(TXYMSGSession& Session, const char* strReplyA, const char* strReplyB);
        bool Logoff(TXYMSGSession& Session);
	//---------------------
        bool PagePing(TXYMSGSession& Session);
        bool ChatPing(TXYMSGSession& Session);
	//---------------------
        bool ChatOnline(TXYMSGSession& Session);
        bool ChatLogout(TXYMSGSession& Session);
        bool ChatJoin(TXYMSGSession& Session, const char* strRoomName);
        bool ChatLeave(TXYMSGSession& Session);
	//---------------------
        bool PrivateMessage(TXYMSGSession& Session, const char* strUser, const char* strMessage);
        bool AddBuddy(TXYMSGSession& Session, const char* strUser, const char* strMessage = NULL);
        bool ChatMessage(TXYMSGSession& Session, const char* strMessage);
	//---------------------
        bool ActivateIdentity(TXYMSGSession& Session, const char* strIdentity);
        bool DeactivateIdentity(TXYMSGSession& Session, const char* strIdentity);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
