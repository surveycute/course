//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooIgnoredUser.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#include <string.h>
#pragma hdrstop
#include <./Yahoo/Protocol/Filter/XYahooIgnoredUser.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooIgnoredUser::TXYahooIgnoredUser()
{
	//------------------
        Name = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooIgnoredUser::~TXYahooIgnoredUser()
{
	//------------------
        if (Name) {XYahoo_Free(Name);Name = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooIgnoredUser::getName() const
{
	//------------------
        return Name;
}
//---------------------------------------------------------------------------
void TXYahooIgnoredUser::setName(const char* strName)
{
	//------------------
        if (Name) {XYahoo_Free(Name);Name = NULL;}
        Name = strdup(strName);
	//------------------
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
