//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooIgnoredUsers.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooIgnoredUsersH
#define XYahooIgnoredUsersH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Filter/XYahooIgnoredUser.h>
#include <./List/XList.h>
#include <./List/XLinkList.h>
//---------------------------------------------------------------------------
class TXYahooIgnoredUserList : public TXLinkList<TXYahooIgnoredUser>
{
public:
        TXYahooIgnoredUserList() : TXLinkList<TXYahooIgnoredUser>()
        {};

};
//---------------------------------------------------------------------------
class TXYahooIgnoredUsers : public TXList<TXYahooIgnoredUser>
{
private:
	//---------------------
	//---------------------
public:
//---------------------------
        TXYahooIgnoredUsers();
        ~TXYahooIgnoredUsers();
	//---------------------
        const TXYahooIgnoredUser** getList() const;
        TXYahooIgnoredUser** editList();
	//---------------------
        TXYahooIgnoredUser* AddName(const char* strName);
        TXYahooIgnoredUser* getAdd(const char* strName = NULL);
        const TXYahooIgnoredUser* getbyName(const char* strName) const;
        TXYahooIgnoredUser* editbyName(const char* strName);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
