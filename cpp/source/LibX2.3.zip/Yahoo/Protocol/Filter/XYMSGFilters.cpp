//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGFilters.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./Yahoo/Protocol/Filter/XYMSGFilters.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGFilterList::TXYMSGFilterList() : TXLinkList<TXYMSGFilterBase>()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
TXYMSGFilterBase* TXYMSGFilterList::get(const char* strName, bool bCaseSensitive /*= true*/)
{
	//------------------
	//------------------
        return (TXYMSGFilterBase*)0;
}
//---------------------------------------------------------------------------
short int TXYMSGFilterList::FilterChatMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash)
{
	//------------------
        unsigned short rc;
        TXYMSGFilterBase** pFilters = editList();
        unsigned long i, cnt = getCount();
	//------------------
        for (i = 0L;i < cnt;++i)
        {
        	//------------------
                rc = pFilters[i]->FilterChatMessage(Header, Client, DataHash);
        	//------------------
                if (rc != 0)
                        return rc;
        	//------------------
        }
	//------------------
        return 0;
}
//---------------------------------------------------------------------------
short int TXYMSGFilterList::FilterPagerMessage(const TXYMSGHeader& Header, const TXYahooPagerClient& Client, const TXYMSGHash& DataHash)
{
	//------------------
        unsigned short rc;
        TXYMSGFilterBase** pFilters = editList();
        unsigned long i, cnt = getCount();
	//------------------
        for (i = 0L;i < cnt;++i)
        {
        	//------------------
                rc = pFilters[i]->FilterPagerMessage(Header, Client, DataHash);
        	//------------------
                if (rc != 0)
                        return rc;
        	//------------------
        }
	//------------------
        return 0;
}
//---------------------------------------------------------------------------
//*************************************************************************//
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
