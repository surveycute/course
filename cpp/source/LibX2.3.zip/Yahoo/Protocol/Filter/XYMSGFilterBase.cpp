//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGFilterBase.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./Yahoo/Protocol/Filter/XYMSGFilterBase.h>
#include <./Yahoo/Protocol/XYMSGHeader.h>
#include <./Yahoo/XYahooChatClient.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGFilterBase::TXYMSGFilterBase()
{
	//------------------
        Name = NULL;
        hasChatUser = hasPagerUser = false;
	//------------------
}
//---------------------------------------------------------------------------
TXYMSGFilterBase::~TXYMSGFilterBase()
{
	//------------------
        if (Name) XYahoo_Free(Name);
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGFilterBase::setName(const char* strName)
{
	//------------------
        if (Name) XYahoo_Free(Name);
        Name = strdup(strName);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYMSGFilterBase::getName() const
{
	//------------------
        return Name;
}
//---------------------------------------------------------------------------
short int TXYMSGFilterBase::FilterChatMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash)
{
	//------------------
	//------------------
        return 0;
}
//---------------------------------------------------------------------------
short int TXYMSGFilterBase::FilterPagerMessage(const TXYMSGHeader& Header, const TXYahooPagerClient& Client, const TXYMSGHash& DataHash)
{
	//------------------
	//------------------
        return 0;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
