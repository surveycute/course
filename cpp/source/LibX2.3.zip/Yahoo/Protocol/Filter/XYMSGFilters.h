//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGFilters.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGFiltersH
#define XYMSGFiltersH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Filter/XYMSGFilterBase.h>
#include <./List/XList.h>
#include <./List/XLinkList.h>
//---------------------------------------------------------------------------
class TXYMSGFilterList : public TXLinkList<TXYMSGFilterBase>
{
public:
	//---------------------
//---------------------------
        TXYMSGFilterList();
        virtual ~TXYMSGFilterList(){};
        TXYMSGFilterBase* get(const char* strName, bool bCaseSensitive = true);
        virtual short int FilterChatMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash);
        virtual short int FilterPagerMessage(const TXYMSGHeader& Header, const TXYahooPagerClient& Client, const TXYMSGHash& DataHash);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
