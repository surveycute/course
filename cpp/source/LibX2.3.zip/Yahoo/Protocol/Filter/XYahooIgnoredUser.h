//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooIgnoredUser.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYahooIgnoredUserH
#define XYahooIgnoredUserH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h> // for XYahoo_Allocate() and XYahoo_Free()
//---------------------------------------------------------------------------
class TXYahooIgnoredUser
{
private:
	//---------------------
        char* Name;
	//---------------------
public:
//---------------------------
        TXYahooIgnoredUser();
        ~TXYahooIgnoredUser();
	//---------------------
        const char* getName() const;
        void setName(const char* strName);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
