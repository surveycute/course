//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooIgnoredUsers.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <string.h>
#pragma hdrstop
#include <./Yahoo/Protocol/Filter/XYahooIgnoredUsers.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooIgnoredUsers::TXYahooIgnoredUsers() : TXList<TXYahooIgnoredUser>()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
TXYahooIgnoredUsers::~TXYahooIgnoredUsers()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
const TXYahooIgnoredUser** TXYahooIgnoredUsers::getList() const
{
	//------------------
        return (const TXYahooIgnoredUser**) TXList<TXYahooIgnoredUser>::getList();
}
//---------------------------------------------------------------------------
TXYahooIgnoredUser** TXYahooIgnoredUsers::editList()
{
	//------------------
        return (TXYahooIgnoredUser**) TXList<TXYahooIgnoredUser>::editList();
}
//---------------------------------------------------------------------------
TXYahooIgnoredUser* TXYahooIgnoredUsers::AddName(const char* strName)
{
        TXYahooIgnoredUser* pIUser = Add();
	//------------------
        if (!pIUser)
                return NULL;
	//------------------
        if (strName)
                pIUser->setName(strName);
	//------------------
        return pIUser;
}
//---------------------------------------------------------------------------
TXYahooIgnoredUser* TXYahooIgnoredUsers::getAdd(const char* strName /*= NULL*/)
{
	//------------------
        if (!strName)
                return Add();
	//------------------
        TXYahooIgnoredUser* pIUser = editbyName(strName); // handles NULL strName
        if (pIUser)
                return pIUser;
	//------------------
        return AddName(strName);
}
//---------------------------------------------------------------------------
const TXYahooIgnoredUser* TXYahooIgnoredUsers::getbyName(const char* strName) const
{
        const TXYahooIgnoredUser** pIUsers = getList();
        unsigned long i, cnt = getCount();
	//------------------
        for (i = 0L;i < cnt;++i)
                if (strcmp(strName, pIUsers[i]->getName()) == 0)
                        return pIUsers[i];
	//------------------
        return NULL;
}
//---------------------------------------------------------------------------
TXYahooIgnoredUser* TXYahooIgnoredUsers::editbyName(const char* strName)
{
        TXYahooIgnoredUser** pIUsers = editList();
        unsigned long i, cnt = getCount();
	//------------------
        for (i = 0L;i < cnt;++i)
                if (strcmp(strName, pIUsers[i]->getName()) == 0)
                        return pIUsers[i];
	//------------------
        return NULL;
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
