//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGFilterBase.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGFilterBaseH
#define XYMSGFilterBaseH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGHash.h>
#include <./Yahoo/Protocol/XYMSGHeader.h>
#include <./Yahoo/XYahooChatClient.h>
#include <./Yahoo/XYahooPagerClient.h>
//---------------------------------------------------------------------------
class TXYahooChatClient; // predefined
//---------------------------------------------------------------------------
class TXYMSGFilterBase
{
private:
	//---------------------
        char* Name;
	//---------------------
public:
	//---------------------
        bool hasChatUser;
        bool hasPagerUser;
//---------------------------
        TXYMSGFilterBase();
        virtual ~TXYMSGFilterBase();
	//---------------------
        void setName(const char* strName);
        const char* getName() const;
	//---------------------
        short int FilterChatMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash);
        short int FilterPagerMessage(const TXYMSGHeader& Header, const TXYahooPagerClient& Client, const TXYMSGHash& DataHash);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
