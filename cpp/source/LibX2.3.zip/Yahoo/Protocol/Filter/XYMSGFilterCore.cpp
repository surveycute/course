//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGFilterCore.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./Yahoo/Protocol/Filter/XYMSGFilterCore.h>
#include <./Yahoo/Protocol/XYMSGHeader.h>
#include <./Yahoo/XYahooChatClient.h>
#include <./Yahoo/XYahooClient.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGFilterCore::TXYMSGFilterCore() : TXYMSGFilterBase()
{
	//------------------
        hasChatUser = hasPagerUser = true;
	//------------------
        setName("Filter-Core");
	//------------------
}
//---------------------------------------------------------------------------
short int TXYMSGFilterCore::FilterHeader(const TXYMSGHeader& Header)
{
	//------------------
        if (Header.ProtocalVersion != 15L)
                return 1;
        if (Header.Session == 0L)
                return 2;
	//------------------
        return 0;
}
//---------------------------------------------------------------------------
short int TXYMSGFilterCore::FilterChatMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash)
{
	//------------------
        if (!Client.pYahooClient)
                return 10; // Generic (pYahooClient not set)
	//------------------
        if (Client.pYahooClient->Session.ChatStatus != ymsgchatChatting)
                return 11; // not chatting
	//------------------
        if (!FilterHeader(Header))
                return 12; // filter header
	//------------------
        if (!DataHash.getByKey(xymsgswChatName)) // @TODO add alias based checking
                return 13; // no chat name (your alias) hash
        if (!DataHash.getByKey(xymsgswUserText)) // @TODO add alias based checking
                return 14; // no text hash
	//------------------
        const XYMSGHashType* pHash = DataHash.getByKey(xymsgswRoomName);
	//------------------
        if (!pHash)
                return 15; // no room name hash
	//------------------
        if (strcmp(Client.pYahooClient->Session.getRoomName(), pHash->strValue) != 0)
                return 16; // room name mismatch
	//------------------
        pHash = DataHash.getByKey(xymsgswUserText);
        if (strncmp(pHash->strValue, "1234", 4) == 0)
                return 22; // @TODO @XDEBUG test
	//------------------
        return 0;
}
//---------------------------------------------------------------------------
short int  TXYMSGFilterCore::FilterPagerMessage(const TXYMSGHeader& Header, const TXYahooPagerClient& Client, const TXYMSGHash& DataHash)
{
	//------------------
        if (!FilterHeader(Header))
                return 12; // filter header
	//------------------
        //xymsgswIMFrom)
        const XYMSGHashType* pHash = DataHash.getByKey(xymsgswText);
        if (!pHash)
                return 21; // no text hash
        if (!pHash->strValue)
                return 22; // blank text
        if (strncmp(pHash->strValue, "1234", 4) == 0)
                return 23; // @TODO @XDEBUG test
	//------------------
        return 0;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
