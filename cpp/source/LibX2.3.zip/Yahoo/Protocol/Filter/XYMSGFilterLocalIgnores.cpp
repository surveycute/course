//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGFilterLocalIgnores.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./Yahoo/Protocol/Filter/XYMSGFilterLocalIgnores.h>
#include <./Yahoo/Protocol/XYMSGHeader.h>
#include <./Yahoo/XYahooChatClient.h>
#include <./Yahoo/XYahooClient.h>
#include <./Yahoo/Protocol/Filter/XYahooIgnoredUsers.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGFilterLocalIgnores::TXYMSGFilterLocalIgnores() : TXYMSGFilterBase()
{
	//------------------
        setName("Filter-LocalIgnores");
        hasChatUser = hasPagerUser = true;
	//------------------
}
//---------------------------------------------------------------------------
short int TXYMSGFilterLocalIgnores::FilterChatMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash)
{
// xymsgswUserText, xymsgswRoomName
        TXYahooIgnoredUser* pIUser;
      	//------------------
        if (!Client.pYahooClient)
                return 100; // error
      	//------------------
        const XYMSGHashType* pHashFrom = Client.pYahooClient->Session.Reader.DataHash.getByKey(xymsgswChatName);
        if (!pHashFrom)
                return 101;
      	//------------------
        pIUser = Client.pYahooClient->IgnoredUsers.editbyName(pHashFrom->strValue);
        //------------------
        if (pIUser)
                return 102;
        //------------------
        return 0;
}
//---------------------------------------------------------------------------
short int  TXYMSGFilterLocalIgnores::FilterPagerMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash)
{
// xymsgswText
        TXYahooIgnoredUser* pIUser;
      	//------------------
        if (!Client.pYahooClient)
                return 100; // error
      	//------------------
        const XYMSGHashType* pHashFrom = Client.pYahooClient->Session.Reader.DataHash.getByKey(xymsgswIMFrom);
        if (!pHashFrom)
                return 101;
      	//------------------
        pIUser = Client.pYahooClient->IgnoredUsers.editbyName(pHashFrom->strValue);
        //------------------
        if (pIUser)
                return 102;
        //------------------
        return 0;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
