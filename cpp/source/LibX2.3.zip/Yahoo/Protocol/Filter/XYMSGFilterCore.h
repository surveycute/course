//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGFilterCore.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGFilterCoreH
#define XYMSGFilterCoreH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Filter/XYMSGFilterBase.h>
//#include <./Yahoo/Protocol/XYMSGHeader.h>
//#include <./Yahoo/XYahooChatClient.h>
//---------------------------------------------------------------------------
class TXYMSGHeader; // predefined
class TXYahooChatClient; // predefined
//---------------------------------------------------------------------------
class TXYMSGFilterCore : public TXYMSGFilterBase
{
private:
	//---------------------
	//---------------------
public:
	//---------------------
//---------------------------
        TXYMSGFilterCore();
	//---------------------
        virtual short int FilterHeader(const TXYMSGHeader& Header);
        virtual short int FilterChatMessage(const TXYMSGHeader& Header, const TXYahooChatClient& Client, const TXYMSGHash& DataHash);
        virtual short int FilterPagerMessage(const TXYMSGHeader& Header, const TXYahooPagerClient& Client, const TXYMSGHash& DataHash);
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XYMSGFilterCoreH
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
