//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHash.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGHashH
#define XYMSGHashH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h> // for XYahoo_Allocate() and XYahoo_Free()
#include <./Buffer/XBuffer.h> 
//---------------------------------------------------------------------------
typedef struct
{
   unsigned short Key;
   int iValue; // doubles as str len -1 not yet set
   char* strValue;
} XYMSGHashType;
//---------------------------------------------------------------------------
class TXYMSGHash
{
private:
	//---------------------
        XYMSGHashType tempHash;
        TXBuffer Buffer;
        unsigned short Count;
	//---------------------
public:
//---------------------------
	//---------------------
        TXYMSGHash();
        ~TXYMSGHash();
	//---------------------
        void Clear(bool bClean = true);
        bool PreSetCount(const unsigned short& usCount);
        bool PreAddCount(const unsigned short& usAddCount);
        bool Add(const unsigned short& usKey, const int& iValue = 0);
        bool Add(const unsigned short& usKey, const char* strValue = (void*)0, int maxLen = -1);
	//---------------------
        XYMSGHashType* editByKey(const unsigned short usKey);
        XYMSGHashType* editByIndex(const unsigned short usIndex);
        const XYMSGHashType* getByKey(const unsigned short usKey) const;
        const XYMSGHashType* getByIndex(const unsigned short usIndex) const;
	//---------------------
        XYMSGHashType* editList();
        const XYMSGHashType* getList() const;
        unsigned short getCount() const;
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
