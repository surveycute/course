//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGReader.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#pragma hdrstop
#include <./Yahoo/Protocol/XYMSGReader.h>
#include <./Debug/XDebug.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGReader::TXYMSGReader()
{
	//---------------------
        Clear();
	//---------------------
}
//---------------------------------------------------------------------------
TXYMSGReader::~TXYMSGReader()
{
	//---------------------
        Status = ymsgrsDestroying;
	//---------------------
}
//---------------------------------------------------------------------------
bool TXYMSGReader::Step(TXSocket& Socket)
{
	//---------------------
        switch (Status)
        {
                case ymsgrsReady:
                case ymsgrsReadHeader:
                        //XDebug("readerReading header...");
                        return ReadHeader(Socket);
                case ymsgrsFilter:
                        // @TODO
                        //XDebug("readerFilter->ReadData");
                        Status = ymsgrsReadData;
                        break;
                case ymsgrsDumpData:
                        XDebug("readerDumpData");
                        return DumpDataStep(Socket);
                case ymsgrsReadData:
                        //XDebug("readerReadData");
                        return ReadDataStep(Socket);
                case ymsgrsCleanup:
                        //XDebug("readerCleanup");
                        return Clear(false/*bClean*/);
                case ymsgrsProcess:
                        //XDebug("readerProcess");
                        return Process();
                case ymsgrsDone:
                        //XDebug("readerDone");
                        return false;
                case ymsgrsError:
                case ymsgrsDestroying:
                        XDebug("readerError/Destroying");
                        return false;
        }
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::ReadHeader(TXSocket& Socket)
{
	//---------------------
        int l = Socket.ReadWait(Header.Buffer, c_XYMSGHeader_Size);
        if (l != 0)
        {
        	//---------------------
                if (l != c_XYMSGHeader_Size)
                        return false;
        	//---------------------
                Header.Unpack();
                Status = ymsgrsFilter;
        	//---------------------
                if (!DataBuffer.setAllocation(Header.Size))
                        return false;
        	//---------------------
        }
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::DumpDataStep(TXSocket& Socket)
{
	//---------------------
        char* pBuffer = (char*)DataBuffer.editData();
        int left = Header.Size - DataBuffer.getSize();
        int len = Socket.ReadWait(pBuffer, left);
	//---------------------
        if (len < 0)  return false;
        if (len == 0) return true;
	//---------------------
        DataBuffer.addSize(len); // should be pre allocated
	//---------------------
        if (DataBuffer.getSize() >= (unsigned long)Header.Size)
                Status = ymsgrsCleanup;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::ReadDataStep(TXSocket& Socket)
{
	//---------------------
        char* pBuffer = (char*)DataBuffer.editData();
        int left = Header.Size - DataBuffer.getSize();
        int len = Socket.ReadWait(pBuffer, left);
	//---------------------
        if (len < 0)  return false;
        if (len == 0)
        {
                if (DataBuffer.getSize() >= (unsigned long)Header.Size)
                        Status = ymsgrsProcess;
                return true;
        }
	//---------------------
        DataBuffer.addSize(len); // should be pre allocated
	//---------------------
        if (DataBuffer.getSize() >= (unsigned long)Header.Size)
                Status = ymsgrsProcess;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::Clear(bool bClean /*= true*/)
{
	//---------------------
        ProcessIndex = 0L;
	//---------------------
        Header.Clear();
        DataHash.Clear(bClean);
        DataBuffer.Clear(bClean);
	//---------------------
        Status = ymsgrsReady;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::Process()
{
        bool onData;
        int len, Key;
        const char* strBuff = DataBuffer.getString();
        const char* p;
        char str[8];
	//---------------------
        // Header is already Unpack()'d
	//---------------------
        onData = false;
        p = strBuff;
        len = 0;
        while (p[0])
                if (p[0] == c_XYMSGDelimitter_A && p[1] == c_XYMSGDelimitter_B)
                {
                	//---------------------
                        if (onData)
                        {
                        	//---------------------
                                if (!DataHash.Add(Key, strBuff, len))
                                        return false;
                        	//---------------------
                                onData = false;
                        	//---------------------
                        }
                        else // if (onData)
                        {
                        	//---------------------
                                str[0] = '\0';
                                strncat(str, strBuff, len);
                                Key = atoi(str);
                        	//---------------------
                                if (Key == 0 && str[0] != '0')
                                        return false; // non-numeric key
                        	//---------------------
                                onData = true;
                        	//---------------------
                        } // else // if (onData)
                	//---------------------
                        len = 0;
                        p += 2;
                        strBuff = p;
                	//---------------------
                }
                else // if Delimetters
                {
                	//---------------------
                        len++;
                        p++;
                	//---------------------
                }
	//---------------------
        Status = ymsgrsDone;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::Inject(const char* strPacket, const unsigned short usSize)
{
	//---------------------
        if (usSize < c_XYMSGHeader_Size)
                return false;
	//---------------------
        memcpy(Header.Buffer, strPacket, c_XYMSGHeader_Size);
        Header.Unpack();
	//---------------------
        if (!DataBuffer.Append((unsigned char*)&strPacket[c_XYMSGHeader_Size], usSize - c_XYMSGHeader_Size))
                return false;
	//---------------------
        if (!Process())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::InjectHeader(const char* strPacket, const unsigned short usSize)
{
	//---------------------
        if (usSize < c_XYMSGHeader_Size)
                return false;
	//---------------------
        memcpy(Header.Buffer, strPacket, c_XYMSGHeader_Size);
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::InjectBody(const char* strPacket, const unsigned short usSize, bool bProcess /*= true*/)
{
	//---------------------
        if (usSize == 0)
                return true;
	//---------------------
        if (!DataBuffer.Append((unsigned char*)&strPacket[c_XYMSGHeader_Size], usSize - c_XYMSGHeader_Size))
                return false;
	//---------------------
        if (!Process())
                return false;
	//---------------------
        return true;
}
//---------------------------------------------------------------------------
void TXYMSGReader::Accept()
{
	//---------------------
        if (Status == ymsgrsFilter)
                Status = ymsgrsReadData;
	//---------------------
}
//---------------------------------------------------------------------------
void TXYMSGReader::Dump()
{
	//---------------------
        if (Status == ymsgrsFilter)
                Status = ymsgrsDumpData;
	//---------------------
}
//---------------------------------------------------------------------------
XYMSGReader_Status TXYMSGReader::getStatus() const
{
	//---------------------
        return Status;
}
//---------------------------------------------------------------------------
bool TXYMSGReader::isReady() const
{
	//---------------------
        return (Status == ymsgrsReady);
}
//---------------------------------------------------------------------------
bool TXYMSGReader::isError() const
{
	//---------------------
        return (Status == ymsgrsError);
}
//---------------------------------------------------------------------------
bool TXYMSGReader::isDone() const
{
	//---------------------
        return (Status == ymsgrsDone);
}
//---------------------------------------------------------------------------
bool TXYMSGReader::isFilter() const
{
	//---------------------
        return (Status == ymsgrsFilter);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
