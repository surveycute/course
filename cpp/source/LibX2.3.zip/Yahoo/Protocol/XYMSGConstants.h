//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGConstants.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGConstantsH
#define XYMSGConstantsH
//---------------------------------------------------------------------------
#define XDEBUG
//---------------------------------------------------------------------------
#define XYahoo_Free(s)     free(s)
#define XYahoo_Allocate(s) malloc(s)
//---------------------------------------------------------------------------
#ifndef _DEBUG // IDE's _DEBUG macro
        #undef XDEBUG
#endif
#ifdef XDEBUG
        #include <./File/XLogger.h>
        extern TXLogger* Logger;
        #define XLOG_INIT(s)   TXLogger* Logger = new TXLogger(s);
        #define XLOG_RELEASE() if (Logger) {Logger->Log("------Ending Log-----");delete Logger;Logger = NULL;}
        #define XLOG(s) if (Logger) Logger->Log(s);
#else
        #define XLOG_INIT(s)
        #define XLOG_RELEASE()
        #define XLOG(s)
#endif
//---------------------------------------------------------------------------
#define c_XYahooSession_Handler_Max  4
//---------------------------------------------------------------------------
#define c_XYMSGHeader_Size        20
#define c_XYMSGMinimumBufferSize  35 // Header + data on the mid-small side
#define c_XYMSGHeader_Version     16L//14L
//---------------------------------------------------------------------------
#define c_XYMSG_Default_Port  5050
#define c_XYMSGDelimitter_A  '\xC0'
#define c_XYMSGDelimitter_B  '\x80'
#define c_XYMSGDelimitter  "\xC0\x80"
#define c_XYahoo_MessengerVersion  "9.0.0.1389" // "6,0,0,1643" //   "5, 5, 0, 1214"
#define c_XYahoo_PingTime 240000L // 4 minutes
//---------------------------------------------------------------------------
typedef enum {xctNone = 0, xctSystem, xctStatus, xctChat, xctPager} XChannelType;
typedef enum {xrdtNone = 0, xrdtSystem, xrdtStatus, xrdtOnline, xrdtOffline, xrdtSelfChatMessage, xrdtSelfPagerMessage, xrdtChatMessage, xrdtPagerMessage, xrdtChatSelfJoin, xrdtChatSelfLeave, xrdtChatUserJoin, xrdtChatUserLeave } XRichDisplayType;
typedef enum {ymsghNone = 0, ymsghOk = 1, ymsghError = -1} XYMSGHandlerReturnType;
typedef enum {ymsgpagerOffline = 0, ymsgpagerConnecting, ymsgpagerConnected, ymsgpagerAuth, ymsgpagerOnline} XYMSGPagerStatus;
typedef enum {ymsgchatOffline = 0, ymsgchatRequestChat, ymsgchatRequestCaptcha, ymsgchatGetCapchaImage, ymsgchatCaptchaUserInput, ymsgchatCaptchaWait, ymsgchatCaptchaDone, ymsgchatChatting} XYMSGChatStatus;
//--------------------------------------------------------------------------- YMSG Servces
typedef enum
{
   xymsgsvcChallengeReply         = 0x54,
   xymsgsvcChallengeRequest       = 0x57,
   xymsgsvcLoginData              = 0x55, // aka  LIST
   xymsgsvcMail                   = 0x0B, // 11
   xymsgsvcPagerOnline            = 0x01, // 1
   xymsgsvcUserStatus             = 0x0A, // 10
   xymsgsvcChatOnline             = 0x96, // 150
   xymsgsvcPagePing               = 0x12, // 18
   xymsgsvcChatPing               = 0xA1, // 161
   xymsgsvcIsBack                 = 0x04, // 4
   xymsgsvcChatJoin               = 0x98, // 152
   xymsgsvcChatLeave              = 0x9B, // 155
   xymsgsvcChatLogout             = 0xA0, // 160
   xymsgsvcChatMessage            = 0xA8, // 168
   xymsgsvcPageMessage            = 0x06, // 6
   xymsgsvcBuddyAdd               = 0x83,
   xymsgsvcBuddyAddNotify         = 0xD6,
   xymsgsvcBuddyRemove            = 0x84,
   xymsgsvcFileTransfer           = 0x4D,
   xymsgsvcAudibleMessage         = 0xD0,
   xymsgsvcChatInvite             = 0x9D, // 157
   xymsgsvcConferenceInvite       = 0x18, // 24
   xymsgsvcConferenceDecline      = 0x1A, // 26
   xymsgsvcActivateIdentity       = 0x07, // 7
   xymsgsvcDeactivateIdentity     = 0x08, // 8
} XYMSGService;
//--------------------------------------------------------------------------- YMSG Switches
typedef enum
{
   xymsgswUserName     = 0,
   xymsgswAlias        = 1,
   xymsgswAliasName    = 2,
   xymsgswIdentity     = 3, // main account name
   xymsgswIMFrom       = 4,
   xymsgswIMTo         = 5,
   xymsgswAwayState    = 10,
   xymsgswStatus       = 13,
   xymsgswText         = 14,
   xymsgswIMVironment  = 63,
   xymsgswIM1          = 64,
   xymsgswRoomName     = 104,
   xymsgswUserText     = 117,
   xymsgswTextMode     = 124,
   xymsgswInviteUser   = 118,
   xymsgswMessengerVer = 135,
   xymsgswChallengeString = 94,
   xymsgswChallengeStringA = 6, // not the only 6
   xymsgswChallengeStringB = 96,
   xymsgswListIgnores      = 88,
   xymsgswListBuddies      = 87,
   xymsgswListFirstName    = 216,
   xymsgswListLastName     = 254,
   xymsgswLocale           = 98,
   xymsgswABCDE            = 6, // not the only 6
   xymsgswChatName         = 109,
   xymsgswRoomNumber       = 129,
   xymsgswRoomMode         = 62,
   xymsgswRoomSwitchA      = 24,
   xymsgswRoomGuestCount   = 108, // legacy usage name?
   xymsgseRoomMessage      = 105,
   xymsgswRoomVoiceAuth    = 130,
   xymsgswChatMessage      = 168,

   xymsgswUserNick         = 141, // used in ChatJoin reply
   xymsgswChatJoinError    = 144,
/*
   89  in list packet, probably Alias list

*/
} XYMSGSwitch;
//--------------------------------------------------------------------------- YMSG Status
typedef enum
{
   xymsgstatusNone        = 0x0,
   xymsgstatusOk          = 0x1,
   xymsgstatusOnline      = 0x5a55aa56,
   xymsgstatusPageMessage = 0x21,
} XYMSGStatus;
//--------------------------------------------------------------------------- YMSG Away States
typedef enum
{
   xymsgstateOffline     = 0x5a55aa56,
   xymsgstateAvailable   = 0,
   xymsgstateBRB         = 1,
   xymsgstateBusy        = 2,
   xymsgstateNotAtHome   = 3,
   xymsgstateNotAtDesk   = 4,
   xymsgstateNotInOffice = 5,
   xymsgstateOnPhone     = 6,
   xymsgstateOnVacation  = 7,
   xymsgstateOutToLunch  = 8,
   xymsgstateSteppedOut  = 9,
   xymsgstateInvisible   = 12,
   xymsgstateCustom      = 99,
   xymsgstateIdle        = 999,
   xymsgstateTyping      = 0x16,
   xymsgstateWebLogin    = 0x5a55aa55,
} XYMSGAwayState;
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------



//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
