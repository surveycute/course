//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerChatCore.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#pragma hdrstop
#include "XYMSGHandlerChatCore.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
XYMSGHandlerReturnType TXYMSGHandlerChatCore::Handle(TXYMSGSession& Session)
{
	//------------------
        switch (Session.Reader.Header.Service)
        {
                case xymsgsvcChatOnline:
                        if (!HandleChatOnline(Session))
                                return ymsghError;
                        return ymsghOk;
                case xymsgsvcChatJoin: // AKA List
                        if (Session.ChatStatus == ymsgchatChatting)
                                return ymsghNone;
                        if (!HandleChatJoin(Session))
                                return ymsghError;
                        if (Session.ChatStatus == ymsgchatChatting) // just went online, pass on user list
                                return ymsghNone;
                        return ymsghOk;
                //case xymsgsvcChatLeave:
        }
	//------------------
        return ymsghNone;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatCore::HandleChatOnline(TXYMSGSession& Session)
{
	//------------------
        if (!Session.ChatOnline)
        {
                //------------------
                Session.ChatStatus = ymsgchatRequestCaptcha;
                if (!Session.Builder.ChatJoin(Session, Session.getJoinRoomName()))
                        return false;
        	//------------------
        }
	//------------------
        Session.ChatOnline = true;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatCore::HandleChatJoin(TXYMSGSession& Session)
{
        const XYMSGHashType* pHash;
	//------------------
        if (Session.ChatStatus == ymsgchatRequestCaptcha) // First Join Reply
        {
        	//------------------
                if (Session.Reader.DataHash.getByKey(xymsgswRoomVoiceAuth))
                { // VoiceAuth present means there is no Captcha needed.
                	//------------------
                        pHash = Session.Reader.DataHash.getByKey(xymsgswRoomName);
                        if (pHash)
                        {
                                Session.setCurrentRoom(pHash->strValue);
                                Session.ChatStatus = ymsgchatChatting;
                        }
                	//------------------
                }
                else
                {
                	//------------------
                        pHash = Session.Reader.DataHash.getByKey(xymsgswChatName);
                        if ( pHash && (strcmpi(pHash->strValue, Session.Account.getAlias()) == 0) )
                        {
                        	//------------------
                                pHash = Session.Reader.DataHash.getByKey(xymsgseRoomMessage); // has captcha
                                if (!pHash)
                                        return false;
                        	//------------------
                                if (!Session.Captcha.RequestCaptcha(pHash->strValue))
                                        return false;
                        	//------------------
                                Session.ChatStatus = ymsgchatGetCapchaImage;
                        	//------------------
                        }
                	//------------------

                }
	        //------------------
                return true;
        }
        else if (Session.ChatStatus == ymsgchatCaptchaDone) // Second Join Reply
        {
	        //------------------
                pHash = Session.Reader.DataHash.getByKey(xymsgswRoomVoiceAuth);
                if (pHash)
                { // VoiceAuth present means there is no Captcha needed.
                	//------------------
                        Session.setVoiceAuth(pHash->strValue);
                	//------------------
                        pHash = Session.Reader.DataHash.getByKey(xymsgswRoomName);
                        if (pHash)
                        {
                        	//------------------
                                if (!Session.Builder.ChatPing(Session))
                                        return false;
                        	//------------------
                                Session.setCurrentRoom(pHash->strValue);
                                Session.ChatStatus = ymsgchatChatting;
                        	//------------------
                                return HandleChatList(Session);
                        }
                	//------------------
                }
	        //------------------
        }
	//------------------
        //else ignore straggling Join's
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatCore::HandleChatList(TXYMSGSession& Session)
{
	//------------------
	//------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
