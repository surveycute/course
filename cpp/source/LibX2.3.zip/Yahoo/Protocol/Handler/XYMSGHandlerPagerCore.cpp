//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerPagerCore.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#pragma hdrstop
#include "XYMSGHandlerPagerCore.h"
#include <./Debug/XDebug.h>
#include <stdio.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
XYMSGHandlerReturnType TXYMSGHandlerPagerCore::Handle(TXYMSGSession& Session)
{
	//------------------
        switch (Session.Reader.Header.Service)
        {
                case xymsgsvcChallengeRequest:
                        if (!HandleLogonChallenge(Session))
                                return ymsghError;
                        return ymsghOk;
                case xymsgsvcLoginData: // AKA List
                        if (!HandleLoginData(Session))
                                return ymsghError;
                        return ymsghOk;
                case xymsgsvcPagerOnline:
                        if (!HandlePageOnline(Session))
                                return ymsghError;
                        return ymsghOk;
        }
	//------------------
        return ymsghNone;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerPagerCore::HandleLogonChallenge(TXYMSGSession& Session)
{
        const XYMSGHashType* pHash;
	//------------------
        if (Session.PagerStatus != ymsgpagerAuth)
                return false;
	//------------------
        if (Session.Reader.DataHash.getCount() < 2)
                return false;
	//------------------
        pHash = Session.Reader.DataHash.getByKey(xymsgswAlias);
                if (!pHash) return false;
        if (strcmpi(Session.Account.getAlias(), pHash->strValue) != 0) // Case Insensitive!
                return false;
	//------------------
        pHash = Session.Reader.DataHash.getByKey(xymsgswChallengeString);
                if (!pHash) return false;
	//------------------
        if (!pHash->strValue || strlen(pHash->strValue) < 5)
                return false;
	//------------------
        char RepA[128];
        char RepB[100];
        if (!YahooCrypt.YahooCrypt((char*)Session.Account.getUser(), (char*)Session.Account.getPassword(), pHash->strValue,  RepA, RepB))
                return false;
	//------------------
        if (!Session.Builder.LogonReplyChallenge(Session, RepA, RepB))
                return false;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerPagerCore::HandleLoginData(TXYMSGSession& Session) // AkA List
{
/*
 4-20-09
logged in main:
List (85)
   (group)
87:Friends:name1\nname2\n
88:ignore1,ignore2
89:main,alias1
59: cookie tv
219: <empty>
59: cookie tz
219: <empty>
59:C\tmg=1
219: <emtpy>
153:1
90:1
3:main (confirmed always main)
100:0
101:<empty>
102:<empty>
15001:0
15002:us
213:0
216:Firstname
254:Lastname
93:86400
149:hash--
150:hash--
151:hash--
217:0

*/
        const XYMSGHashType* pHash;
        char* p, *pStart;
        TXYahooUserGroup* pGroup = NULL;
	//------------------
        pHash = Session.Reader.DataHash.getByKey(xymsgswIdentity);
        Session.Account.setMain(pHash->strValue);
	//------------------
        pHash = Session.Reader.DataHash.getByKey(xymsgswListBuddies);
        Session.ServerBuddyGroups.Clear();
        if (pHash->strValue)
        {
        	//------------------
                p = pStart = pHash->strValue;
        	//------------------
                while (*p)
                        switch (*p)
                        {
                                case ':':
                                	//------------------
                                        *p = '\0';
                                	//------------------
                                        pGroup = Session.ServerBuddyGroups.add(pStart);
                                        if (!pGroup)
                                                return false;
                                	//------------------
                                        pStart = ++p;
                                	//------------------
                                        break;
                                case ',':
                                       	//------------------
                                        *p = '\0';
                                	//------------------
                                        if (pGroup)
                                                if (!pGroup->Users.add(pStart))
                                                        return false;
                                	//------------------
                                        pStart = ++p;
                                	//------------------
                                        break;
                                case '\n':
                                	//------------------
                                        *p = '\0';
                                	//------------------
                                        if (strlen(pStart) && pGroup)
                                                if (!pGroup->Users.add(pStart))
                                                        return false;
                                	//------------------
                                        pGroup = NULL;
                                        pStart = ++p;
                                	//------------------
                                        break;
                                default:
                                	//------------------
                                        ++p;
                                	//------------------
                                        break;
                        } // switch
        	//------------------
        } // if (pHash->strValue)
	//------------------
        pHash = Session.Reader.DataHash.getByKey(xymsgswListIgnores);
        Session.ServerIgnores.Clear();
        if (pHash->strValue)
        {
                p = strtok(pHash->strValue, ",");
                while (p)
                {
                        if (!Session.ServerIgnores.add(p))
                                return false;
                        p = strtok(NULL, ",");
                }
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerPagerCore::HandlePageOnline(TXYMSGSession& Session)
{
        char str[120];
        sprintf(str, "HandlePageOnline - PagerStatus: %d ChatStatus: %d Writer: %d",
                   Session.PagerStatus, Session.ChatStatus, Session.Builder.Writer.getStatus());
        XDebug(str);
        const XYMSGHashType* pHash;
	//------------------
        if (Session.PagerStatus != ymsgpagerAuth)
                return false;
	//------------------
        pHash = Session.Reader.DataHash.getByKey(xymsgswAlias);
        if (strcmp(Session.Account.getAlias(), pHash->strValue) != 0)
                return false;
	//------------------
        Session.SessionID = Session.Reader.Header.Session;
        Session.State = (XYMSGAwayState)Session.Reader.Header.State;
	//------------------
        Session.PagerStatus = ymsgpagerOnline;
	//------------------
        sprintf(str, "HandlePageOnline BEFORE PAGE PING - PagerStatus: %d ChatStatus: %d Writer: %d",
                   Session.PagerStatus, Session.ChatStatus, Session.Builder.Writer.getStatus());
        XDebug(str);
        if (!Session.Builder.PagePing(Session))
                return false;
	//------------------
        sprintf(str, "HandlePageOnline BEFORE AUTO JOIN - PagerStatus: %d ChatStatus: %d Writer: %d",
                   Session.PagerStatus, Session.ChatStatus, Session.Builder.Writer.getStatus());
        XDebug(str);
        if (Session.Account.getAutoJoinRoomName())
                if (!Session.JoinRoom(Session.Account.getAutoJoinRoomName()))
                        return false;
	//------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
