//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerChatClient.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGHandlerChatClientH
#define XYMSGHandlerChatClientH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Handler/XYMSGHandlerChatCore.h>
//---------------------------------------------------------------------------
class TXYahooChatClient; // Predefined
//---------------------------------------------------------------------------
class TXYMSGHandlerChatClient : public TXYMSGHandlerChatCore
{
private:
	//---------------------
        const XYMSGHashType* pHashRoom;
        const XYMSGHashType* pHashUser;
        const XYMSGHashType* pHashText;
        XYMSGHandlerReturnType r; // used repeditively in Handle()
        TXYahooChatClient* pChatClient;
	//---------------------
public:
	//---------------------
//---------------------------
        TXYMSGHandlerChatClient();
	//---------------------
        void setChatClient(TXYahooChatClient* psetChatClient);
	//---------------------
        //XYMSGHandlerReturnType: ymsghNone, ymsghOk, ymsgError
        virtual XYMSGHandlerReturnType Handle(TXYMSGSession& Session);
	//---------------------
        bool HandleChatMessage(TXYMSGSession& Session);
        bool HandleJoin(TXYMSGSession& Session);
        bool HandleUserList(TXYMSGSession& Session);
        bool HandleLeave(TXYMSGSession& Session);
        bool HandleLogout(TXYMSGSession& Session);
	//---------------------
        virtual bool HandleChatList(TXYMSGSession& Session);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
