//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerPagerClient.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGHandlerPagerClientH
#define XYMSGHandlerPagerClientH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Handler/XYMSGHandlerPagerCore.h>
//---------------------------------------------------------------------------
class TXYahooPagerClient; // Predefined
//---------------------------------------------------------------------------
class TXYMSGHandlerPagerClient : public TXYMSGHandlerPagerCore
{
private:
	//---------------------
        XYMSGHandlerReturnType r; // used repeditively in Handle()
        TXYahooPagerClient* pPagerClient;
	//---------------------
public:
	//---------------------
//---------------------------
        TXYMSGHandlerPagerClient();
	//---------------------
        void setPagerClient(TXYahooPagerClient* psetChatClient);
	//---------------------
        //XYMSGHandlerReturnType: ymsghNone, ymsghOk, ymsgError
        virtual XYMSGHandlerReturnType Handle(TXYMSGSession& Session);
	//---------------------
        virtual bool HandlePageMessage(TXYMSGSession& Session);
	//---------------------
        virtual bool HandleLoginData(TXYMSGSession& Session); // AkA List
        virtual bool HandlePageOnline(TXYMSGSession& Session);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
