//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerChatCore.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGHandlerChatCoreH
#define XYMSGHandlerChatCoreH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Handler/XYMSGHandlerBase.h>
//---------------------------------------------------------------------------
class TXYMSGHandlerChatCore : public TXYMSGHandlerBase
{
public:
	//---------------------
//---------------------------
	//---------------------
        //XYMSGHandlerReturnType: ymsghNone, ymsghOk, ymsgError
        virtual XYMSGHandlerReturnType Handle(TXYMSGSession& Session);
	//---------------------
        bool HandleChatOnline(TXYMSGSession& Session);
        bool HandleChatJoin(TXYMSGSession& Session);
        virtual bool HandleChatList(TXYMSGSession& Session);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
