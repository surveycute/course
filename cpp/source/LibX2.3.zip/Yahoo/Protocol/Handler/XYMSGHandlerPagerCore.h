//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerPagerCore.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGHandlerPagerCoreH
#define XYMSGHandlerPagerCoreH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/Handler/XYMSGHandlerBase.h>
#include <./Yahoo/Auth/XYahooCrypt.h>
//---------------------------------------------------------------------------
class TXYMSGHandlerPagerCore : public TXYMSGHandlerBase
{
public:
	//---------------------
        TXYahooCrypt YahooCrypt;
//---------------------------
	//---------------------
        //XYMSGHandlerReturnType: ymsghNone, ymsghOk, ymsgError
        virtual XYMSGHandlerReturnType Handle(TXYMSGSession& Session);
	//---------------------
        bool HandleLogonChallenge(TXYMSGSession& Session);
        virtual bool HandleLoginData(TXYMSGSession& Session); // AkA List
        virtual bool HandlePageOnline(TXYMSGSession& Session);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
