//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerBase.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGHandlerBaseH
#define XYMSGHandlerBaseH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGSession.h>
//---------------------------------------------------------------------------
class TXYMSGHandlerBase
{
private:
public:
	//---------------------
//---------------------------
	//---------------------
        virtual XYMSGHandlerReturnType Handle(TXYMSGSession& Session);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
