//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerChatClient.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#pragma hdrstop
#include <./Yahoo/Protocol/Handler/XYMSGHandlerChatClient.h>
#include <./Yahoo/XYahooChatClient.h>
#include <./Yahoo/XYahooClient.h>
#include <./Yahoo/XYahooChannel.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGHandlerChatClient::TXYMSGHandlerChatClient()
{
	//------------------
        pChatClient = NULL;
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGHandlerChatClient::setChatClient(TXYahooChatClient* psetChatClient)
{
	//------------------
        pChatClient = psetChatClient;
	//------------------
}
//---------------------------------------------------------------------------
XYMSGHandlerReturnType TXYMSGHandlerChatClient::Handle(TXYMSGSession& Session)
{
	//------------------
        r = TXYMSGHandlerChatCore::Handle(Session);
                if (r != ymsghNone)
                        return r;
	//------------------
        if (!pChatClient)
                return ymsghNone;
	//------------------
        switch (Session.Reader.Header.Service)
        {
                case xymsgsvcChatMessage:
                        if (!HandleChatMessage(Session))
                                return ymsghError;
                        return ymsghOk;
                case xymsgsvcChatJoin: // user List and single joins
                        if (!HandleJoin(Session))
                                return ymsghError;
                        return ymsghOk;
                case xymsgsvcChatLeave:
                        if (!HandleLeave(Session))
                                return ymsghError;
                        return ymsghOk;
                case xymsgsvcChatLogout:
                        if (!HandleLogout(Session))
                                return ymsghError;
                        return ymsghOk;
        }
	//------------------
        return ymsghNone;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatClient::HandleChatMessage(TXYMSGSession& Session)
{
	//------------------
        if (!pChatClient->pYahooClient)
                return false;
	//------------------
        const XYMSGHashType* pHashUser = Session.Reader.DataHash.getByKey(xymsgswChatName);
        const XYMSGHashType* pHashText = Session.Reader.DataHash.getByKey(xymsgswUserText);
        const XYMSGHashType* pHashRoom = Session.Reader.DataHash.getByKey(xymsgswRoomName);
	//------------------
        if (!pHashUser || !pHashText || !pHashRoom)
                pChatClient->DroppedMessage(9999, NULL, NULL, NULL);
        else
        {
                short int Code = pChatClient->pYahooClient->Filters.FilterChatMessage(Session.Reader.Header, *pChatClient, Session.Reader.DataHash);
        	//------------------
                if (Code == 0)
                        pChatClient->ReceiveMessage(pHashRoom->strValue, pHashUser->strValue, pHashText->strValue);
                else
                        pChatClient->DroppedMessage(Code, pHashRoom->strValue, pHashUser->strValue, pHashText->strValue);
        	//------------------
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatClient::HandleJoin(TXYMSGSession& Session)
{
	//------------------
        if (Session.ChatStatus != ymsgchatChatting)
                return true;
	//------------------
        if (Session.Reader.DataHash.getCount() > 5)
                return HandleUserList(Session);
	//------------------
        if (Session.Reader.DataHash.getByKey(xymsgswChatJoinError))
        {
                // Captcha failed
                //Session.JoinRoom
                Session.ChatStatus = ymsgchatOffline;
                return true;
        }
        pHashRoom = Session.Reader.DataHash.getByKey(xymsgswRoomName);
        pHashUser = Session.Reader.DataHash.getByKey(xymsgswChatName);
	//------------------
        if (!pHashRoom || !pHashUser)
                return false;
	//------------------
        if (strcmp(Session.getRoomName(), pHashRoom->strValue) != 0)
                return true;
	//------------------
        if (strcmp("Yahoo", pHashUser->strValue) == 0)
                pChatClient->EnterRoom(pHashRoom->strValue, Session.Account.getAlias());
        else
        {
        	//------------------
                TXYahooChannel* pChannel = pChatClient->pYahooClient->Channels.getaddRoom(pHashRoom->strValue);
                if (!pChannel)
                        return false;
        	//------------------
                pChatClient->JoinedRoom(pHashRoom->strValue, pHashUser->strValue);
                if (!pChannel->pChatUsers.get(pHashUser->strValue))
                {
                	//------------------
                        TXYahooUser* pUser = pChatClient->pYahooClient->Users.getadd(pHashUser->strValue);
                        if (!pUser)
                                return false;
                	//------------------
                        if (!pChannel->pChatUsers.AddUnique(pUser))
                                return false;
                	//------------------
                }
        	//------------------
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatClient::HandleUserList(TXYMSGSession& Session)
{
	//------------------
        if (!Session.ChatStatus != ymsgchatChatting)
                return true;
	//------------------
        if (strcmp(Session.getRoomName(), Session.Reader.DataHash.getByKey(xymsgswRoomName)->strValue) != 0)
                return true;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatClient::HandleLeave(TXYMSGSession& Session)
{
	//------------------
        if (Session.ChatStatus != ymsgchatChatting)
                return true;
	//------------------
        pHashRoom = Session.Reader.DataHash.getByKey(xymsgswRoomName);
        pHashUser = Session.Reader.DataHash.getByKey(xymsgswChatName);
	//------------------
        if (!pHashRoom || !pHashUser)
                return false;
	//------------------
        if (strcmp(Session.getRoomName(), pHashRoom->strValue) != 0)
                return true;
	//------------------
        pChatClient->LeftRoom(pHashRoom->strValue, pHashUser->strValue);
	//------------------
        TXYahooChannel* pChannel = pChatClient->pYahooClient->Channels.getaddRoom(pHashRoom->strValue);
        if (!pChannel)
                return false;
	//------------------
        TXYahooUser* pUser = pChannel->pChatUsers.get(pHashUser->strValue);
        if (pUser)
                pChannel->pChatUsers.Remove(pUser); // ignore failure
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatClient::HandleLogout(TXYMSGSession& Session)
{
	//------------------
        if (!Session.ChatStatus != ymsgchatChatting)
                return true;
	//------------------
        if (strcmp(Session.Account.getAlias(), Session.Reader.DataHash.getByKey(xymsgswAlias)->strValue) != 0)
                return true;
	//------------------
        Session.ChatStatus = ymsgchatOffline;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerChatClient::HandleChatList(TXYMSGSession& Session)
{
/*
13:1                            xymsgswStatus
104: room name                  xymsgswRoomName
105: room description           xymsgseRoomMessage
108:13
126:328704
128:1001
129:1009                        xymsgswRoomNumber
130: <auth key>                 xymsgswRoomVoiceAuth
----------------------------------------------
109:UserName                    xymsgswChatName
110:0,20,19 <age?>
142:State
111:neuter,female,male
113:1024,66560,33792
*/
        TXYahooChannel* pChannel = pChatClient->pYahooClient->Channels.getaddRoom(Session.getRoomName());
        if (!pChannel)
                return false;
	//------------------
        //TXYahooDisplayLine* pLine = pChannel->Lines.addChatMessage(Session.Account.getAlias(), strMessage, true/*bSelf*/);

        const XYMSGHashType* pHash;
        const XYMSGHashType* pRoomNameHash;
        TXYahooUser* pUser = NULL;
	//------------------
        pHash = Session.Reader.DataHash.getByKey(xymsgswRoomName);
        const XYMSGHashType* Hashes = Session.Reader.DataHash.getList();
        unsigned long i, Len = Session.Reader.DataHash.getCount();
	//------------------
        //pChatClient->pYahooClient->Users.Clear();
	//------------------
        for (i = 0;i < Len;++i)
        {
        	//------------------
                switch (Hashes[i].Key)
                {
                        case xymsgswChatName:
                                pUser = pChannel->pChatUsers.get(Hashes[i].strValue);
                                if (!pUser)
                                {
                                        pUser = pChatClient->pYahooClient->Users.getadd(Hashes[i].strValue);
                                        if (!pUser)
                                                return false;
                                        if (!pChannel->pChatUsers.AddUnique(pUser))
                                                return false;
                                }
                                break;
                        case 110: // Age?
                                if (pUser)
                                        pUser->Age = Hashes[i].iValue;
                                break;
                        case 142: // State code
                                if (pUser)
                                        pUser->setState(Hashes[i].strValue);
                                break;
                        case 111: // Sex: neuter,female,male
                                if (pUser && Hashes[i].strValue)
                                        pUser->Sex = Hashes[i].strValue[0];
                                break;
                }
        	//------------------
        }
	//------------------
        pChatClient->UpdateUserList(pHash->strValue);
	//------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
