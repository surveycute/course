//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHandlerPagerClient.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#pragma hdrstop
#include <./Yahoo/Protocol/Handler/XYMSGHandlerPagerClient.h>
#include <./Yahoo/XYahooPagerClient.h>
#include <./Yahoo/XYahooClient.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYMSGHandlerPagerClient::TXYMSGHandlerPagerClient()
{
	//------------------
        pPagerClient = NULL;
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGHandlerPagerClient::setPagerClient(TXYahooPagerClient* psetChatClient)
{
	//------------------
        pPagerClient = psetChatClient;
	//------------------
}
//---------------------------------------------------------------------------
XYMSGHandlerReturnType TXYMSGHandlerPagerClient::Handle(TXYMSGSession& Session)
{
	//------------------
        r = TXYMSGHandlerPagerCore::Handle(Session);
                if (r != ymsghNone)
                        return r;
	//------------------
        if (!pPagerClient)
                return ymsghNone;
	//------------------
        switch (Session.Reader.Header.Service)
        {
                case xymsgsvcPageMessage:
                        if (!HandlePageMessage(Session))
                                return ymsghError;
                        return ymsghOk;
        }
	//------------------
        return ymsghNone;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerPagerClient::HandlePageMessage(TXYMSGSession& Session)
{
	//------------------
        if (!pPagerClient->pYahooClient)
                return false;
	//------------------
        const XYMSGHashType* pHashFrom = Session.Reader.DataHash.getByKey(xymsgswIMFrom);
        const XYMSGHashType* pHashText = Session.Reader.DataHash.getByKey(xymsgswText);
	//------------------
        if (!pHashFrom || !pHashText)
                pPagerClient->DroppedMessage(9999, NULL, NULL);
        else
        {
                short int Code = pPagerClient->pYahooClient->Filters.FilterPagerMessage(Session.Reader.Header, *pPagerClient, Session.Reader.DataHash);
        	//------------------
                if (Code == 0)
                        pPagerClient->ReceiveMessage(pHashFrom->strValue, pHashText->strValue);
                else
                        pPagerClient->DroppedMessage(Code, pHashFrom->strValue, pHashText->strValue);
        	//------------------
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerPagerClient::HandleLoginData(TXYMSGSession& Session)
{
	//------------------
        if (!TXYMSGHandlerPagerCore::HandleLoginData(Session))
                return false;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHandlerPagerClient::HandlePageOnline(TXYMSGSession& Session)
{
	//------------------
        if (!TXYMSGHandlerPagerCore::HandlePageOnline(Session))
                return false;
	//------------------
        pPagerClient->Online(Session.Reader.DataHash.getByKey(xymsgswAlias)->strValue);
	//------------------
        return true;
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
