//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHeader.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XYMSGHeaderH
#define XYMSGHeaderH
//---------------------------------------------------------------------------
#include <./Yahoo/Protocol/XYMSGConstants.h>
//---------------------------------------------------------------------------
class TXYMSGHeader
{
public:
	//---------------------
        union
        {
                struct
                {
                        unsigned char  ProtocalID[4];
                        unsigned long  ProtocalVersion; //  Standard Order
                        unsigned short Size;           //  Network Order    Not Including header
                        unsigned short Service;        //  Network Order
                        unsigned long  State;          //  Network Order
                        unsigned long  Session;
                };
                char Buffer[c_XYMSGHeader_Size];
        };
	//---------------------
//---------------------------
        TXYMSGHeader();
        void Clear();
        void Pack();
        void Unpack();
        void Set(XYMSGService xymsgsvcService, XYMSGAwayState  xymsgstateState, unsigned long ulSession);
	//---------------------
};
//---------------------------------------------------------------------------
#endif
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
