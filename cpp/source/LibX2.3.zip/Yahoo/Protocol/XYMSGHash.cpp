//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYMSGHash.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h> // malloc realloc free
#include <string.h> // for strdup()
#pragma hdrstop
#include <./Yahoo/Protocol/XYMSGHash.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
const int XYMSGHashTypeSize = sizeof(XYMSGHashType);
//---------------------------------------------------------------------------
TXYMSGHash::TXYMSGHash()
{
	//------------------
        Count = 0;
	//------------------
}
//---------------------------------------------------------------------------
TXYMSGHash::~TXYMSGHash()
{
	//------------------
        Clear();
	//------------------
}
//---------------------------------------------------------------------------
void TXYMSGHash::Clear(bool bClean /*= true*/)
{
        XYMSGHashType* pList = (XYMSGHashType*)Buffer.editData();
	//------------------
        for (unsigned short i = 0;i < Count;++i)
                if (pList[i].strValue)
                        XYahoo_Free(pList[i].strValue);
	//------------------
        if (bClean) Buffer.Clear();
        else Buffer.setSize(0L);
        Count = 0;
	//------------------
}
//---------------------------------------------------------------------------
bool TXYMSGHash::PreSetCount(const unsigned short& usCount)
{
	//------------------
        return Buffer.setAllocation((unsigned long)usCount);
}
//---------------------------------------------------------------------------
bool TXYMSGHash::PreAddCount(const unsigned short& usAddCount)
{
	//------------------
        return Buffer.addBlockAllocation((unsigned long)usAddCount);
}
//---------------------------------------------------------------------------
bool TXYMSGHash::Add(const unsigned short& usKey, const int& iValue /*= 0*/)
{
	//------------------
        tempHash.Key = usKey;
        tempHash.iValue = iValue;
        tempHash.strValue = NULL;
	//------------------
        if (!Buffer.Append((unsigned char*)&tempHash, XYMSGHashTypeSize))
                return false;
	//------------------
        Count++;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYMSGHash::Add(const unsigned short& usKey, const char* strValue /*=  (void*)0*/, int maxLen /*= -1*/)
{
	//------------------
        tempHash.Key = usKey;
        tempHash.iValue = -1;
	//------------------
        if (!strValue)  tempHash.strValue = strdup("");
        else
        {
                if (maxLen == -1) tempHash.strValue = strdup(strValue);
                else
                {
                        tempHash.strValue = (char*)XYahoo_Allocate(maxLen + 1/*NULL Terminator*/);
                        tempHash.strValue[0] = '\0';
                        strncat(tempHash.strValue, strValue, maxLen);
                }
        }
	//------------------
        if (!Buffer.Append((unsigned char*)&tempHash, XYMSGHashTypeSize))
        {
                XYahoo_Free(tempHash.strValue);
                return false;
        }
	//------------------
        Count++;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
XYMSGHashType* TXYMSGHash::editByKey(const unsigned short usKey)
{
        XYMSGHashType* pList = (XYMSGHashType*)Buffer.editData();
	//------------------
        for (unsigned short i = 0;i < Count;++i)
                if (pList[i].Key == usKey)
                        return &pList[i];
	//------------------ Not found
        return NULL;
}
//---------------------------------------------------------------------------
XYMSGHashType* TXYMSGHash::editByIndex(const unsigned short usIndex)
{
	//------------------
        if ((unsigned long)usIndex < Buffer.getSize())
                return &((XYMSGHashType*)Buffer.editData())[usIndex];
	//------------------ Out of bounds
        return NULL;
}
//---------------------------------------------------------------------------
const XYMSGHashType* TXYMSGHash::getByKey(const unsigned short usKey) const
{
        const XYMSGHashType* pList = (const XYMSGHashType*)Buffer.getData();
        //------------------
        for (unsigned short i = 0;i < Count;++i)
                if (pList[i].Key == usKey)
                        return &pList[i];
        //------------------ Not found
        return NULL;
}
//---------------------------------------------------------------------------
const XYMSGHashType* TXYMSGHash::getByIndex(const unsigned short usIndex) const
{
        //------------------
        if ((unsigned long)usIndex < Buffer.getSize())
                return &((const XYMSGHashType*)Buffer.getData())[usIndex];
        //------------------ Out of bounds
        return NULL;
}
//---------------------------------------------------------------------------
XYMSGHashType* TXYMSGHash::editList()
{
	//------------------
        return (XYMSGHashType*)Buffer.editData();
}
//---------------------------------------------------------------------------
const XYMSGHashType* TXYMSGHash::getList() const
{
	//------------------
        return (const XYMSGHashType*)Buffer.getData();
}
//---------------------------------------------------------------------------
unsigned short TXYMSGHash::getCount() const
{
	//------------------
        return Count;
}
//---------------------------------------------------------------------------


//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
