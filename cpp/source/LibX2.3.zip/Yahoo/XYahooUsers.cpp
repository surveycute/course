//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooUsers.cpp    
//--------------------------------
//---------------------------------------------------------------------------
//#include <alloc>
#include <string>
#pragma hdrstop
#include <./Yahoo/XYahooUsers.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//#########################################################################//
//---------------------------------------------------------------------------
TXYahooUserList::TXYahooUserList() :  TXLinkList<TXYahooUser>()
{
	//------------------
        ID = 2;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooUserList::~TXYahooUserList()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
TXYahooUser* TXYahooUserList::get(const char* strName /*= NULL*/)
{
        TXYahooUser** pUsers = editList();
        unsigned long i, l = getCount();
	//------------------
        for (i = 0L;i < l;++i)
                if (pUsers[i]->getName() && strcmp(strName, pUsers[i]->getName()) == 0)
                        return pUsers[i];
	//------------------
        return (TXYahooUser*)0;
}
//---------------------------------------------------------------------------
int TXYahooUserList::get(TXYahooUser* pUser)
{
        TXYahooUser** pUsers = editList();
        unsigned long i, l = getCount();
	//------------------
        for (i = 0L;i < l;++i)
                if (pUsers[i] == pUser)
                        return i;
	//------------------
        return -1;
}
//---------------------------------------------------------------------------
bool TXYahooUserList::Add(TXYahooUser* pUser)
{
	//------------------
        pUser->incRefCount();
	//------------------
        return  TXLinkList<TXYahooUser>::Add(pUser);
}
//---------------------------------------------------------------------------
bool TXYahooUserList::AddUnique(TXYahooUser* pUser)
{
	//------------------
        if (get(pUser) == -1)
                if (!Add(pUser))
                        return false;
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooUserList::Remove(TXYahooUser* pUser)
{
	//------------------
        if (TXLinkList<TXYahooUser>::Remove(pUser))
        {
                pUser->decRefCount();
                return true;
        }
	//------------------
        return false;
}
//---------------------------------------------------------------------------
//#########################################################################//
//---------------------------------------------------------------------------
TXYahooUsers::TXYahooUsers() :  TXList<TXYahooUser>()
{
	//------------------
        ID = 1;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooUsers::~TXYahooUsers()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
const TXYahooUser** TXYahooUsers::getList() const
{
	//------------------
        return (const TXYahooUser**) TXList<TXYahooUser>::getList();
}
//---------------------------------------------------------------------------
TXYahooUser** TXYahooUsers::editList()
{
	//------------------
        return (TXYahooUser**) TXList<TXYahooUser>::editList();
}
//---------------------------------------------------------------------------
TXYahooUser* TXYahooUsers::get(const char* strName)
{
        TXYahooUser** pUsers = editList();
        unsigned long i, l = getCount();
	//------------------
        for (i = 0L;i < l;++i)
                if (pUsers[i]->getName() && strcmp(strName, pUsers[i]->getName()) == 0)
                        return pUsers[i];
	//------------------
        return (TXYahooUser*)0;
}
//---------------------------------------------------------------------------
TXYahooUser* TXYahooUsers::getadd(const char* strName /*= NULL*/)
{
        TXYahooUser* pUser = get(strName);
	//------------------
        if (!pUser)
        {
        	//------------------
                pUser = new TXYahooUser();
                if (!pUser)
                        return (TXYahooUser*)0;
        	//------------------
                if (strName)
                        pUser->setName(strName);
	        //------------------
                if (!Add(pUser))
                        return (TXYahooUser*)0;
        	//------------------
        }
	//------------------
        return pUser;
}
//---------------------------------------------------------------------------
TXYahooUser* TXYahooUsers::add(const char* strName /*= NULL*/)
{
	//------------------
        TXYahooUser* pUser = new TXYahooUser();
        if (!pUser)
                return (TXYahooUser*)0;
        //------------------
        if (strName)
                pUser->setName(strName);
        //------------------
        if (!Add(pUser))
                return (TXYahooUser*)0;
	//------------------
        return pUser;
}
//---------------------------------------------------------------------------
//#########################################################################//
//---------------------------------------------------------------------------
TXYahooUserGroup::TXYahooUserGroup()
{
	//------------------
        GroupName = NULL;
	//------------------
}
//---------------------------------------------------------------------------
TXYahooUserGroup::~TXYahooUserGroup()
{
	//------------------
        if (GroupName) {XYahoo_Free(GroupName);GroupName = NULL;}
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooUserGroup::setGroupName(const char* strGroupName)
{
	//------------------                 free
        if (GroupName) XYahoo_Free(GroupName);
        GroupName = strdup(strGroupName);
	//------------------
}
//---------------------------------------------------------------------------
const char* TXYahooUserGroup::getGroupName() const
{
	//------------------
        return GroupName;
}
//---------------------------------------------------------------------------
//#########################################################################//
//---------------------------------------------------------------------------
TXYahooUserGroups::TXYahooUserGroups() :  TXList<TXYahooUserGroup>()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
TXYahooUserGroups::~TXYahooUserGroups()
{
	//------------------
	//------------------
}
//---------------------------------------------------------------------------
const TXYahooUserGroup** TXYahooUserGroups::getList() const
{
	//------------------
        return (const TXYahooUserGroup**) TXList<TXYahooUserGroup>::getList();
}
//---------------------------------------------------------------------------
TXYahooUserGroup** TXYahooUserGroups::editList()
{
	//------------------
        return (TXYahooUserGroup**) TXList<TXYahooUserGroup>::editList();
}
//---------------------------------------------------------------------------
TXYahooUser* TXYahooUserGroups::findUser(const char* strUserName)
{
        TXYahooUserGroup** pGroups = editList();
        unsigned long i, l = getCount();
        TXYahooUser* pUser;
	//------------------
        for (i = 0L;i < l;++i)
        {
        	//------------------
                pUser = pGroups[i]->Users.get(strUserName);
        	//------------------
                if (pUser)
                        return pUser;
        	//------------------
        }
	//------------------
        return (TXYahooUser*)0;
}
//---------------------------------------------------------------------------
TXYahooUserGroup* TXYahooUserGroups::get(const char* strGroupName)
{
        TXYahooUserGroup** pGroups = editList();
        unsigned long i, l = getCount();
	//------------------
        for (i = 0L;i < l;++i)
                if (pGroups[i]->getGroupName() && strcmp(strGroupName, pGroups[i]->getGroupName()) == 0)
                        return pGroups[i];
	//------------------
        return (TXYahooUserGroup*)0;
}
//---------------------------------------------------------------------------
TXYahooUserGroup* TXYahooUserGroups::getadd(const char* strGroupName /*= (void*)0*/)
{
        TXYahooUserGroup* pGroup = get(strGroupName);
	//------------------
        if (!pGroup)
        {
        	//------------------
                pGroup = new TXYahooUserGroup();
                if (!pGroup)
                        return (TXYahooUserGroup*)0;
        	//------------------
                if (strGroupName)
                        pGroup->setGroupName(strGroupName);
	        //------------------
                if (!Add(pGroup))
                        return (TXYahooUserGroup*)0;
        	//------------------
        }
	//------------------
        return pGroup;
}
//---------------------------------------------------------------------------
TXYahooUserGroup* TXYahooUserGroups::add(const char* strGroupName /*= (void*)0*/)
{
	//------------------
        TXYahooUserGroup* pGroup = new TXYahooUserGroup();
        if (!pGroup)
                return (TXYahooUserGroup*)0;
        //------------------
        if (strGroupName)
                pGroup->setGroupName(strGroupName);
        //------------------
        if (!Add(pGroup))
                return (TXYahooUserGroup*)0;
	//------------------
        return pGroup;
}
//---------------------------------------------------------------------------
//#########################################################################//
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
