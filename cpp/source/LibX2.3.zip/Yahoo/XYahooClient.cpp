//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XYahooClient.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <stdlib.h>
#pragma hdrstop
#include <./Yahoo/XYahooClient.h>
#include <./Yahoo/Protocol/XYMSGConstants.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
TXYahooClient::TXYahooClient()
{
	//------------------
        pDisplay = NULL;
        Channels.setYahooClient((TXYahooClient*)this);
	//------------------
}
//---------------------------------------------------------------------------
TXYahooClient::~TXYahooClient()
{
	//------------------
        Clear(true);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooClient::Clear(bool bClean /*= false*/)
{
	//------------------
        Channels.Clear(bClean);
	//------------------
}
//---------------------------------------------------------------------------
void TXYahooClient::setDisplay(TXYahooDisplay* psetDisplay)
{
	//------------------
        pDisplay = psetDisplay;
	//------------------
}
//---------------------------------------------------------------------------
bool TXYahooClient::InitPager()
{
	//------------------
        PagerClient.setYahooClient(this);
	//------------------
        return Session.addHandler(&PagerClient.Handler);
}
//---------------------------------------------------------------------------
bool TXYahooClient::InitChat()
{
	//------------------
        ChatClient.setYahooClient(this);
	//------------------
        return Session.addHandler(&ChatClient.Handler);
}
//---------------------------------------------------------------------------
bool TXYahooClient::Step()
{
	//------------------
        if (!Session.Step())
        {
                switch (Session.ChatStatus)
                {
                        case ymsgchatOffline:
                                // ignore
                                break;
                        case ymsgchatCaptchaUserInput:
                                // caller should test isCaptcha
                                return false;
                        case ymsgchatCaptchaWait:
                                return true; // do nothing, why jump, just return now
                        default:
                                return false; // error
                }
        }
	//------------------
        return true;
}
//---------------------------------------------------------------------------
bool TXYahooClient::isCaptcha()
{
	//------------------
        return (Session.ChatStatus == ymsgchatCaptchaUserInput);
}
//---------------------------------------------------------------------------

//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
