//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XThread.h    
//--------------------------------
//---------------------------------------------------------------------------
#ifndef XThreadH
#define XThreadH
//---------------------------------------------------------------------------
#ifndef _WINDOWS_H
  #ifndef _WINDOWS_
   #ifndef VCL_H
       	#error You must include Windows.h to use XThread. Be sure to include winsock2.h before windows.h, if needed.
   #endif
  #endif
#endif
//---------------------------------------------------------------------------
#define XThread_Start_Critical_Section() CRITICAL_SECTION Section; try {InitializeCriticalSection(&Section);EnterCriticalSection(&Section);
#define XThread_End_Critical_Section()   } __finally {LeaveCriticalSection(&Section); DeleteCriticalSection(&Section);}
//---------------------------------------------------------------------------
class TXCriticalSection
{
private:
	//---------------------
	bool Initted;
	bool Activated;
	CRITICAL_SECTION Handle;
	//---------------------
public:
	//---------------------

//---------------------------
	TXCriticalSection(bool bInit = false);
	~TXCriticalSection();
	//---------------------
	void Init();
	void Delete();
	//---------------------
	void Enter();
	void Leave();
	//---------------------
};
//---------------------------------------------------------------------------
class TXThread
{
private:
	//---------------------
	bool Terminate;
	bool Running;
	HANDLE Handle;
//---------------------------
	static DWORD WINAPI StaticThreadMain(LPVOID pVoid);
	//---------------------
public:
	//---------------------

//---------------------------
	TXThread();
	~TXThread();
	//---------------------
	bool Start();
	bool Stop();
	bool Pause();
	bool Resume();
	//---------------------
	bool isTerminate() const;
	bool isRunning() const;
	void setTerminate();
	void ThreadMain();
	//---------------------
};
//---------------------------------------------------------------------------
#endif // XThreadH
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
