//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
// Source File:
//    XThread.cpp    
//--------------------------------
//---------------------------------------------------------------------------
#include <windows.h>
#pragma hdrstop
#include <./Thread/Win/XThread.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//                      		TXCriticalSection						   //
//---------------------------------------------------------------------------
TXCriticalSection::TXCriticalSection(bool bInit /*= false*/)
{
	//---------------------
	Activated = false;
	//---------------------
	if (bInit)
		Init();
	else
		Initted = false;
	//---------------------
}
//---------------------------------------------------------------------------
TXCriticalSection::~TXCriticalSection()
{
	//---------------------
	Delete(); // Calls Leave() too
	//---------------------
}
//---------------------------------------------------------------------------
void TXCriticalSection::Init()
{
	//---------------------
	InitializeCriticalSection(&Handle);
	Initted = true;
	//---------------------
}
//---------------------------------------------------------------------------
void TXCriticalSection::Delete()
{
	//---------------------
	if (Initted)
	{
		Leave();
		DeleteCriticalSection(&Handle);
		Initted = false;
	}
	//---------------------
}
//---------------------------------------------------------------------------
void TXCriticalSection::Enter()
{
	//---------------------
	EnterCriticalSection(&Handle);
	Activated = true;
	//---------------------
}
//---------------------------------------------------------------------------
void TXCriticalSection::Leave()
{
	//---------------------
	if (Activated)
	{
		LeaveCriticalSection(&Handle);
		Activated = false;
	}
	//---------------------
}
//---------------------------------------------------------------------------
//                      		TXThread 								   //
//---------------------------------------------------------------------------
TXThread::TXThread()
{
	//---------------------
	Handle = NULL;
	Terminate = false;
	Running = false;
	//---------------------
}
//---------------------------------------------------------------------------
TXThread::~TXThread()
{
	//---------------------
	if (Running)
		Stop();
	//---------------------
}
//---------------------------------------------------------------------------
bool TXThread::Start()
{
	//---------------------
	if (Running || Handle)
		if (!Stop())
			return false;
	//---------------------
	Terminate = false;
	//---------------------
	Handle = CreateThread(NULL, 0, StaticThreadMain, this, 0, NULL);
		if (!Handle)
			return false;
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXThread::Stop()
{
	bool r = true;
	//---------------------
	Terminate = true;
	//---------------------
	if (Running)
	{
		//---------------------
		DWORD t = WaitForSingleObject(Handle, 25000L);
		if (t != WAIT_OBJECT_0) // WAIT_FAILED, WAIT_ABANDONED, WAIT_TIMEOUT
			r = false;
		//---------------------
	} // if (Running)
	//---------------------
	if (Handle)
		if (!CloseHandle(Handle))
			r = false;
	//---------------------
	Handle = NULL;
	Running = false; // incase of hung thread
	//---------------------
	return r;
}
//---------------------------------------------------------------------------
bool TXThread::Pause()
{
	//---------------------
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXThread::Resume()
{
	//---------------------
	//---------------------
	return true;
}
//---------------------------------------------------------------------------
bool TXThread::isTerminate() const
{
	//---------------------
	return Terminate;
}
//---------------------------------------------------------------------------
bool TXThread::isRunning() const
{
	//---------------------
	return Running;
}
//---------------------------------------------------------------------------
void TXThread::setTerminate()
{
	//---------------------
	Terminate = true;
	//---------------------
}
//---------------------------------------------------------------------------
/*static*/ DWORD WINAPI TXThread::StaticThreadMain(LPVOID pVoid)
{
	//---------------------
	((TXThread*)pVoid)->Running = true;
	((TXThread*)pVoid)->ThreadMain();
	((TXThread*)pVoid)->Running = false;
	//---------------------
	return 1L;
}
//---------------------------------------------------------------------------
void TXThread::ThreadMain()
{
	//---------------------
	while (!isTerminate())
	{

	}
	//---------------------
}
//---------------------------------------------------------------------------
//--------------------------------
// XLibrary v2.3         
//    by SoCo Software            
//--------------------------------
// Found free and open source     
// at http://www.socosoftware.com 
//--------------------------------
