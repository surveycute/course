//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/Device.h
//**

#ifndef __blue_data_Device_h_included__
#define __blue_data_Device_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/Buffer.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

namespace blue {
namespace data {

	/**
	 * \brief Represents the two types of endianess.
	 * \ingroup Data
	 */
	enum endianess_e
	{
		ENDIAN_BIG,		//!< Big endian
		ENDIAN_LITTLE,	//!< Little endian
	};


	/**
	 * \brief Identifies how to use the value given when setting
	 * the position in a device.
	 * \ingroup Data
	 */
	enum seek_method_e
	{
		SM_BEG,    //!< Seek from the beginning.
		SM_CUR,    //!< Seek from the current position.
		SM_END,    //!< Seek from the end of the device.
	};

}}	// namespaces


// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class Device
	 * \brief Interface for input/output %Devices.
	 * \ingroup Data
	 */
	class BLUE_EXPORT Device
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Virtual destructor. */
		virtual ~Device()
		{}

		/**
		 * Closes access to the %Device.  Any further actions on the
		 * %Device may throw a DeviceInvalidModeException.
		 */
		virtual void close() = 0;


		// ===========================================================
		//  query
		// ===========================================================

		/** Determines if the %Device is open. */
		virtual bool isOpen() const = 0;
		/**
		 * Determines if the %Device can be read from.  If the %Device
		 * cannot be read from, any attempts to read will cause a
		 * DeviceInvalidModeException to be thrown.
		 */
		virtual bool isReadable() const = 0;
		/**
		 * Determines if the %Device can be written to.  If the %Device
		 * cannot be written to, any attempts to write will cause a
		 * DeviceInvalidModeException to be thrown.
		 */
		virtual bool isWriteable() const = 0;
		/**
		 * Determines if the %Device can be accessed randomly.  If so,
		 * the %Device has a set size and a read/write position.
		 *
		 * \sa getSize, getPos, pushPos, popPos
		 */
		virtual bool isSeekable() const = 0;

		/**
		 * Determines if the %Device can be read from without blocking.
		 */
		virtual bool canRead() const = 0;
		/**
		 * Determines if the %Device can be written to without blocking.
		 */
		virtual bool canWrite() const = 0;

		/**
		 * Returns the size of the data in the %Device.  If the %Device is not
		 * seekable, a DeviceInvalidModeException will be thrown.
		 */
		virtual int getSize() const = 0;
		/**
		 * Returns the current read/write position in the %Device.  If the %Device
		 * is not seekable, a DeviceInvalidModeException will be thrown.
		 */
		virtual int getPos() const = 0;

		/**
		 * Returns the endianess of the %Device.
		 */
		virtual endianess_e getEndianess() const;

		/**
		 * Returns the endianess of the platform.
		 */
		static endianess_e getPlatformEndianess();

		
		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Removes all data from the %Device. */
		virtual void purge() = 0;
		/** Flushes any pending writes to the %Device. */
		virtual void flush() = 0;

		/**
		 * Reads data from the %Device.  If the return value of Device::canRead
		 * returned true, this call is guaranteed not to block.  The return
		 * value is the actual number of bytes read from the %Device.  It may or
		 * may not match the requested size.
		 *
		 * If the return value of Device::isReadable returns false, this function
		 * will throw a DeviceInvalidModeException.
		 *
		 * If the read operation failed for some reason, a 
		 * DeviceReadInterruptException is thrown.
		 *
		 * \sa readAll
		 */
		virtual int read( void* buffer, int size ) = 0;
		/** overload */
		virtual int read( Buffer& buffer );
		/** overload */
		virtual Buffer read( int size );
		/**
		 * Reads all data from the %Device.
		 *
		 * \sa read
		 */
		virtual Buffer readAll();

		/** Reads an 8 bit integer from the %Device. */
		virtual int8_t readInt8();
		/** Reads a 16 bit integer from the %Device, swapping endianess if needed. */
		virtual int16_t readInt16();
		/** Reads a 32 bit integer from the %Device, swapping endianess if needed. */
		virtual int32_t readInt32();
		/** Reads a 64 bit integer from the %Device, swapping endianess if needed. */
		virtual int64_t readInt64();
		/** Reads an 8 bit unsigned integer from the %Device, swapping endianess if needed. */
		virtual uint8_t readUint8();
		/** Reads a 16 bit unsigned integer from the %Device. */
		virtual uint16_t readUint16();
		/** Reads a 32 bit unsigned integer from the %Device, swapping endianess if needed. */
		virtual uint32_t readUint32();
		/** Reads a 64 bit unsigned integer from the %Device, swapping endianess if needed. */
		virtual uint64_t readUint64();
		/** Reads a 32 bit float from the %Device. */
		virtual float32_t readFloat32();
		/** Reads a 64 bit float from the %Device. */
		virtual float64_t readFloat64();

		/**
		 * Writes data to the %Device.  Depending on the %Device, the size
		 * passed in may or may not be the size returned.  This value should
		 * be checked to determine how much of the data was written.
		 *
		 * If the return value of Device::isWriteable returns false, this function
		 * will throw a DeviceInvalidModeException.
		 *
		 * If the write operation failed for some reason, a 
		 * DeviceWriteInterruptException is thrown.
		 */
		virtual int write( const void* data, int size ) = 0;
		/** overload */
		virtual int write( const Buffer& buffer );


		/** Writes an 8 bit integer to the %Device. */
		virtual void writeInt8( int8_t var );
		/** Writes a 16 bit integer to the %Device, swapping endianess if needed. */
		virtual void writeInt16( int16_t var );
		/** Writes a 32 bit integer to the %Device, swapping endianess if needed. */
		virtual void writeInt32( int32_t var );
		/** Writes a 64 bit integer to the %Device, swapping endianess if needed. */
		virtual void writeInt64( int64_t var );
		/** Writes an 8 bit unsigned integer to the %Device. */
		virtual void writeUint8( uint8_t var );
		/** Writes a 16 bit unsigned integer to the %Device, swapping endianess if needed. */
		virtual void writeUint16( uint16_t var );
		/** Writes a 32 bit unsigned integer to the %Device, swapping endianess if needed. */
		virtual void writeUint32( uint32_t var );
		/** Writes a 64 bit unsigned integer to the %Device, swapping endianess if needed. */
		virtual void writeUint64( uint64_t var );
		/** Writes a 32 bit float to the %Device. */
		virtual void writeFloat32( float32_t var );
		/** Writes a 64 bit float to the %Device. */
		virtual void writeFloat64( float64_t var );

		/** Sets the read/write position of the device. */
		virtual void setPos( int pos, seek_method_e seek = SM_BEG ) = 0;
		/**
		 * This pushes a new position on the position stack. The position stack
		 * allows multiple objects/functions  to read or write to a %Device (not at
		 * the same time!) without messing with the previous position.
		 *
		 * If the return value of Device::isSeekable returns false, this function
		 * will throw a DeviceInvalidModeException.
		 */
		virtual void pushPos() = 0;
		/** Pops the last position off of the position stack.*/
		virtual void popPos() = 0;

		/**
		 * Sets the endianess to use when reading or writing to this %Device.
		 * This only has an effect if the %Device is read using the read[type]
		 * and write[type] functions (readInt8, writeInt8, etc).
		 */
		virtual void setEndianess( endianess_e endianess );

		/**
		 * Swaps the endianess of the given data.
		 *
		 * \param data - Pointer to the variable to swap.
		 * \param size - Size of the datatype of the given variable.
		 *
		 * \b Usage:
		 * \code
		 * uint32_t var = 1234567;
		 * Device::swapEndianess(&var, sizeof(var));
		 * // var now has its bits swapped.
		 * \endcode
		 */
		static void swapEndianess( void* data, int size );

	protected:
		/** Constructor. Only accessable by deriving classes. */
		Device() :m_endianess(getPlatformEndianess())
		{}

		endianess_e m_endianess;
	};


	/**
	 * \class DeviceReadInterruptException
	 * \brief Thrown when a %Device's read operation fails or is interrupted.
	 * \ingroup DataExceptions
	 */
	class BLUE_EXPORT DeviceReadInterruptException :public common::Exception
	{
	public:
		DeviceReadInterruptException( String desc = String("Read operation interrupted", String::STATIC) )
			:Exception(desc) {}

		virtual String getException() const {
			return (String("DeviceReadInterruptException", String::STATIC));
		}
	};


	/**
	 * \class DeviceWriteInterruptException
	 * \brief Thrown when a %Device's write operation fails or is interrupted.
	 * \ingroup DataExceptions
	 */
	class BLUE_EXPORT DeviceWriteInterruptException :public common::Exception
	{
	public:
		DeviceWriteInterruptException( String desc = String("Write operation interrupted", String::STATIC) )
			:Exception(desc) {}

		virtual String getException() const {
			return (String("DeviceWriteInterruptException", String::STATIC));
		}
	};


	/**
	 * \class DeviceInvalidModeException
	 * \brief Thrown when an operation is attempted on a %Device that cannot be performed.
	 * \ingroup DataExceptions
	 */
	class BLUE_EXPORT DeviceInvalidModeException :public common::Exception
	{
	public:
		DeviceInvalidModeException( String desc = String("Invalid mode for that operation", String::STATIC) )
			:Exception(desc) {}

		virtual String getException() const {
			return (String("DeviceInvalidModeException", String::STATIC));
		}
	};



}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
