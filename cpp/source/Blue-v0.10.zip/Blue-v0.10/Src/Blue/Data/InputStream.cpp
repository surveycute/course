//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/InputStream.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "InputStream.h"

// library headers
#include "Blue/Kernel/Thread.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

namespace {
	using namespace blue;
	using namespace blue::data;

	template<typename type_t> type_t readVariable( InputStream* input )
	{
		type_t var;
		int size = input->read( ((type_t*)&var), sizeof(var) );

		while( size != sizeof(var) ) {
			kernel::Thread::sleep(0);
			size += input->read( ((type_t*)&var) + size, sizeof(var) - size );
		}

		if( Device::getPlatformEndianess() != input->getReadDevice()->getEndianess() ) {
			Device::swapEndianess(&var, sizeof(var));
		}

		return (var);
	}
}


// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream::InputStream() :m_readDevice(0), m_reading(false), m_readFilter(0), m_pushBackOffset(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream::InputStream( Device* device, bool startReading ) :m_readDevice(0), m_reading(false), m_readFilter(0), m_pushBackOffset(0)
	{
		setReadDevice(device, startReading);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream::~InputStream()
	{
		stopReading();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Device* InputStream::getReadDevice() const
	{
		return (m_readDevice);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool InputStream::isReading() const
	{
		bool reading = m_reading;
		if( reading && m_readDevice->isSeekable() ) {
			reading = !(m_readDevice->getPos() == m_readDevice->getSize());
		}

		return (reading || (m_readFilter != 0 && m_readFilter->isValid() && m_readFilter->canRead()) );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	FilterChain* InputStream::getFilterChain() const
	{
		return (m_readFilter);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::setReadDevice( Device* device, bool startReading )
	{
		if( m_reading ) {
			throw DeviceInvalidModeException($("Cannot set read device while reading"));
		}

		m_readDevice = device;

		if( startReading ) {
			this->startReading();
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::startReading()
	{
		if( m_reading ) {
			return;
		}

		if( m_readDevice == 0 ) {
			throw DeviceInvalidModeException($("Cannot read from a null device"));
		}

		if( m_readFilter != 0 ) {
			m_readFilter->reset();
			m_readFilter->lock();
		}

		if( m_pushBackData != Buffer::null ) {
			m_pushBackData = Buffer::null;
			m_pushBackOffset = 0;
		}

		m_reading = true;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::stopReading()
	{
		if( m_readFilter != 0 ) {
			m_readFilter->unlock();
		}

		m_reading = false;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::setFilterChain( FilterChain* chain )
	{
		if( m_reading ) {
			throw DeviceInvalidModeException($("Cannot set input stream filter while reading"));
		}

		m_readFilter = chain;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int8_t InputStream::readInt8()
	{
		return readVariable<int8_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int16_t InputStream::readInt16()
	{
		return readVariable<int16_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int32_t InputStream::readInt32()
	{
		return readVariable<int32_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int64_t InputStream::readInt64()
	{
		return readVariable<int64_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint8_t InputStream::readUint8()
	{
		return readVariable<uint8_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint16_t InputStream::readUint16()
	{
		return readVariable<uint16_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint32_t InputStream::readUint32()
	{
		return readVariable<uint32_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint64_t InputStream::readUint64()
	{
		return readVariable<uint64_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	float32_t InputStream::readFloat32()
	{
		return readVariable<float32_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	float64_t InputStream::readFloat64()
	{
		return readVariable<float64_t>(this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String InputStream::readString( String until )
	{
		String ret;

		while( isReading() ) {
			int8_t ch = readInt8();
			
			for( int i = 0; i < until.getLength(); ++i ) {
				if( ch == until[i] ) {
					return(ret);
				}
			}

			ret += ch;
		}

		return (ret);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String InputStream::readStringNull()
	{
		String ret;

		while( isReading() ) {
			int8_t ch = readInt8();
			if( ch == '\0' ) {
				break;
			}

			ret += ch;
		}

		return (ret);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String InputStream::readStringPascal()
	{
		int32_t len = readInt32();
		char* buffer = new char[len];
		for( int i = 0; i < len; ++i ) {
			buffer[i] = readInt8();
		}

		String ret(buffer, len);
		delete [] buffer;

		return (ret);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( int8_t& var )
	{
		var = readInt8();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( int16_t& var )
	{
		var = readInt16();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( int32_t& var )
	{
		var = readInt32();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( int64_t& var )
	{
		var = readInt64();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( uint8_t& var )
	{
		var = readUint8();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( uint16_t& var )
	{
		var = readUint16();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( uint32_t& var )
	{
		var = readUint32();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( uint64_t& var )
	{
		var = readUint64();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( float32_t& var )
	{
		var = readFloat32();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( float64_t& var )
	{
		var = readFloat64();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InputStream& InputStream::operator>>( String& var )
	{
		var = readString();
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int InputStream::read( void* buffer, int size )
	{
		if( !isReading() ) {
			throw DeviceInvalidModeException($("Cannot read from input stream"));
		}

		if( m_pushBackData != Buffer::null ) {
			int pushRead = min(size, m_pushBackData.getSize() - m_pushBackOffset);
			int read = m_pushBackData.readData(buffer, pushRead, m_pushBackOffset);
			
			m_pushBackOffset += read;

			if( m_pushBackOffset == m_pushBackData.getSize() ) {
				m_pushBackOffset = 0;
				m_pushBackData = Buffer::null;
			}

			return (read);
		}

		if( m_readFilter != 0 && m_readFilter->isValid() ) {
			uint8_t* bytes = (uint8_t*)buffer;
			int bytesRead = 0;

			while( bytesRead < size && isReading() ) {
				if( m_readFilter->canRead() ) {
					bytes[bytesRead++] = m_readFilter->read();
				}
				else {
					if( m_readDevice->isOpen() == false ) {
						stopReading();
						break;
					}

					bool closed = false;
					uint8_t byte;
					if( m_readDevice->canRead() ) {
						if( m_readDevice->read(&byte, sizeof(byte)) == sizeof(byte) ) {
							m_readFilter->write(byte);
							closed = !m_readDevice->isOpen();
						}
						else closed = true;
					}
					else {
						if( bytesRead > 0 ) {
							break;
						}
					}

					if( !closed && m_readDevice->isSeekable() ) {
						closed = m_readDevice->getPos() == m_readDevice->getSize();
					}

					if( closed ) {
						m_readFilter->streamClosed();
						stopReading();
					}
				}
				kernel::Thread::sleep(0);
			}

			return (bytesRead);
		}
		else {
			int bytesRead = m_readDevice->read(buffer, size);

			bool closed = false;
			if( m_readDevice->isOpen() == false ) {
				closed = true;
			}
			if( !closed && m_readDevice->isSeekable() ) {
				closed = m_readDevice->getPos() == m_readDevice->getSize();
			}

			if( closed ) {
				stopReading();
			}

			return (bytesRead);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int InputStream::read( Buffer& buffer )
	{
		return read(buffer.getData(), buffer.getSize());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer InputStream::read( int size )
	{
		Buffer buffer(size);
		if( int retSize = read(buffer.getData(), size) ) {
			if( retSize < size ) {
				buffer.resize(retSize);
			}
			return (buffer);
		}

		return (Buffer::null);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( const void* buffer, int size )
	{
		if( m_pushBackData == Buffer::null ) {
			m_pushBackData.set(size, buffer);
			m_pushBackOffset = 0;
		}
		else {
			int remaining = m_pushBackData.getSize() - m_pushBackOffset;
			Buffer pushBack( remaining + size );

			pushBack.writeData(buffer, size);
			pushBack.writeData(m_pushBackData.getData(m_pushBackOffset), remaining, size);
			
			m_pushBackData   = pushBack;
			m_pushBackOffset = 0;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( const Buffer& buffer )
	{
		pushBack(buffer.getData(), buffer.getSize());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( int8_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( int16_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( int32_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( int64_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( uint8_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( uint16_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( uint32_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( uint64_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( float32_t var )
	{
		pushBack(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InputStream::pushBack( float64_t var )
	{
		pushBack(&var, sizeof(var));
	}


}}	// namespaces
