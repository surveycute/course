//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/DiskFileSystem.cpp
//**

// Private Headers =========================================================================================================

// system headers
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>

// matching header
#include "DiskFileSystem.h"

#if defined(BLUE_PLATFORM_WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#else
#	error "DiskFileSystem needs an implementation for this platform."
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

namespace {

	using namespace blue;
	using namespace blue::common;


	// Determine if the path is absolute
	bool priv_isAbsolute( String path )
	{
		#if defined(BLUE_PLATFORM_WIN32)
			return (path.equalsWildCard("?:*") || path.equalsWildCard("//*"));
		#else
			return path.beginsWith("/");
		#endif
	}


	// Make sure that the path given is a valid path.
	String priv_makeValidPath( String path, String cwd )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		if( path.findPos("\\") != String::npos ) {
			path = path.replaceAll("\\", "/");
		}
		#endif

		// check for relative path
		bool relative = !priv_isAbsolute(path);

		#if defined(BLUE_PLATFORM_WIN32)
		if( relative && path.beginsWith("/") ) {
			path = (cwd.equalsWildCard("?:/*") ? cwd.left(2) : "/") + path;
			relative = false;
		}
		#endif

		if( relative ) {
			path = cwd + (path == String::null ? String::null : "/" + path);
		}
		
		// remove trailing slash
		if( path.endsWith("/") ) {
			path = path.left( path.getLength() - 1 );
		}

		// remove trailing '/.'
		if( path.endsWith("/.") ) {
			path = path.left( path.getLength() - 2 );
		}

		// check for '..' in path
		int pos;
		while( (pos = path.findPos("/..")) != String::npos ) {
			int slashPos = path.findPosR("/",  pos - 1);
			if( slashPos == String::npos ) {
				path = path.left(pos);
				break;
			}
			path = path.remove(slashPos, (pos - slashPos) + 3);
		}

		return (path);
	}


	// Helper function used only by priv_getNames.  This function
	// determines if the path given is a dot dir ("." or ".."). These
	// directory entries are not added to the directory array.
	bool priv_isDotDir( const char* name )
	{
		if( name[0] == '\0' ) {
			return (false);
		}
		if( name[0] == '.' && name[1] == '\0' ) {
			return (true);
		}
		if( name[1] == '\0' ) {
			return (false);
		}
		if( name[0] == '.' && name[1] == '.' && name[2] == '\0' ) {
			return (true);
		}

		return (false);
	}

	// Get the list of directory or file names in the given
	// directory.
	Array<String> priv_getNames( String dir, bool filesOnly )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		Array<String> names;
		dir = dir.replaceAll("/", "\\") + "\\*";

		WIN32_FIND_DATA wfd;
		HANDLE first = FindFirstFile(dir.getAsCStr(), &wfd);

		if( first != INVALID_HANDLE_VALUE ) {

			if( (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0 ) {
				if( !filesOnly ) {
					if( !priv_isDotDir(wfd.cFileName) ) {
						names.append( String(wfd.cFileName) );
					}
				}
			}
			else if( filesOnly ) {
				names.append( String(wfd.cFileName) );
			}

			while( FindNextFile(first, &wfd) != FALSE ) {
				if( (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0 ) {
					if( !filesOnly ) {
						if( !priv_isDotDir(wfd.cFileName) ) {
							names.append( String(wfd.cFileName) );
						}
					}
				}
				else if( filesOnly ) {
					names.append( String(wfd.cFileName) );
				}
			}

			FindClose(first);
		}

		return (names);
		#endif
	}

	#if defined(BLUE_PLATFORM_WIN32)

	// Converts a short filename into a long filename.
	// Some Win32 API functions return short filenames, this function
	// converts those into more readable long filenames.
	String priv_win32GetLongFilename( String filename )
	{
		if( filename.endsWith("\\") ) {
			filename = filename.left(filename.getLength() - 1);
		}

		String fullpath = filename;
		String longpath;

		int pos = fullpath.findPos("\\");
		longpath = fullpath.left(pos + 1);	// set drive letter
		while( pos = fullpath.findPos("\\", pos + 1) ) {
			if( pos == String::npos ) {
				pos = fullpath.getLength();
			}
			String partpath = fullpath.left(pos).makeUnique();
			String partname = partpath.subString(partpath.findPosR("\\") + 1);

			WIN32_FIND_DATA wfd;
			HANDLE first = FindFirstFile(partpath.getAsCStr(), &wfd);
			if( first != INVALID_HANDLE_VALUE ) {
				if( partname.equalsIgnoreCase(wfd.cAlternateFileName) || partname.equalsIgnoreCase(wfd.cFileName) ) {
					longpath += wfd.cFileName + String("\\");
				}
				else {
					while( FindNextFile(first, &wfd) != FALSE ) {
						if( partname.equalsIgnoreCase(wfd.cAlternateFileName) || partname.equalsIgnoreCase(wfd.cFileName) ) {
							longpath += wfd.cFileName + String("\\");
							break;
						}
					}
				}
				FindClose(first);
			}
			else {
				longpath += partname + "\\";
			}
			if( pos == fullpath.getLength() ) {
				break;
			}
		}

		return (longpath);
	}
	#endif

}

// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	DiskFileSystem::DiskFileSystem()
	{
		#if defined(BLUE_PLATFORM_WIN32)
		char buffer[MAX_PATH+1];
		GetCurrentDirectory( sizeof(buffer) - 1, buffer );
		String dir = priv_win32GetLongFilename(buffer);
		dirSetDefaultDirectory( dir.replaceAll("\\", "/") );
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	DiskFileSystem::~DiskFileSystem()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	DiskFileSystem* DiskFileSystem::instance()
	{
		static DiskFileSystem diskFileSystem;
		return (&diskFileSystem);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	FileSystem::filehandle_t DiskFileSystem::fileOpen( String filename, file_access_e access )
	{
		const char* accessStr;
		switch(access)
		{
		case FILE_READ:      accessStr = "rb";  break;
		case FILE_WRITE:     accessStr = "ab+"; break;
		case FILE_WRITEOVER: accessStr = "wb";  break;
		}

		if( FILE* fp = fopen( fileFormatFileNameNative(filename).makeUnique().getAsCStr(), accessStr) ) {
			return ((int32_t)fp);
		}
		else {
			return (INVALID_FILEHANDLE);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void DiskFileSystem::fileClose( filehandle_t handle )
	{
		if( handle != INVALID_FILEHANDLE ) {
			fclose( (FILE*)handle );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int DiskFileSystem::fileGetSize( filehandle_t handle )
	{
		long pos = ftell( (FILE*)handle );
		fseek( (FILE*)handle, 0, SEEK_END );
		int size = (int)ftell( (FILE*)handle );
		fseek( (FILE*)handle, pos, SEEK_SET );

		return (size);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int DiskFileSystem::fileGetPos( filehandle_t handle )
	{
		return (int)ftell( (FILE*)handle );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	util::DateTime DiskFileSystem::fileGetCreatedDateTime( String filename )
	{
		// is this portable?
		struct _stat stats;
		if( _stat(filename.makeUnique().getAsCStr(), &stats) != 0 ) {
			return util::DateTime();
		}

		tm* ftm = localtime(&stats.st_ctime);
		return util::DateTime( ftm->tm_mon + 1, ftm->tm_mday, ftm->tm_year+1900,
		                       ftm->tm_hour, ftm->tm_min, ftm->tm_sec );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	util::DateTime DiskFileSystem::fileGetModifiedDateTime( String filename )
	{
		// is this portable?
		struct _stat stats;
		if( _stat(filename.makeUnique().getAsCStr(), &stats) != 0 ) {
			return util::DateTime();
		}

		tm* ftm = localtime(&stats.st_mtime);
		return util::DateTime( ftm->tm_mon + 1, ftm->tm_mday, ftm->tm_year+1900,
		                       ftm->tm_hour, ftm->tm_min, ftm->tm_sec );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String DiskFileSystem::fileFormatFileName( String filename, format_e format ) const
	{
		String fullPath = priv_makeValidPath(filename, m_cwd);

		switch(format)
		{
		case FMT_FULL:           return fullPath;
		case FMT_RELATIVE:       return fullPath.subString( fullPath.findPosR("/") + 1 );
		case FMT_PATH:           return fullPath.subString( 0, fullPath.findPosR("/") );
		case FMT_EXT:            return fullPath.subString( fullPath.findPosR(".") + 1 );
		case FMT_RELATIVE_NOEXT:
			if( fullPath.findPosR(".") > fullPath.findPosR("/") ) {
				fullPath = fullPath.subString( fullPath.findPosR("/") + 1 );
				fullPath = fullPath.left( fullPath.findPosR(".") - 1 );
				return (fullPath);
			}
			else {
				return fullPath.subString( fullPath.findPosR("/") + 1 );
			}
		}

		return (fullPath);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String DiskFileSystem::fileFormatFileNameNative( String filename ) const
	{
		String native = priv_makeValidPath(filename, m_cwd);

		#if defined(BLUE_PLATFORM_WIN32)
		filename = filename.replaceAll("/", "\\");
		#endif

		return (filename);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::fileExists( String filename ) const
	{
		String path = fileFormatFileName(filename, FMT_PATH);
		String name = fileFormatFileName(filename, FMT_RELATIVE);
		Array<String> files = dirGetFiles(path);

		if( isCaseSensitive() ) {
			for( int i = 0; i < files.getSize(); ++i ) {
				if( files[i].equals(name) ) {
					return (true);
				}
			}
		}
		else {
			for( int i = 0; i < files.getSize(); ++i ) {
				if( files[i].equalsIgnoreCase(name) ) {
					return (true);
				}
			}
		}
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::dirExists( String dirpath ) const
	{
		String path = fileFormatFileName(dirpath, FMT_PATH);
		String name = fileFormatFileName(dirpath, FMT_RELATIVE);
		Array<String> dirs = dirGetSubDirectories(path);

		if( isCaseSensitive() ) {
			for( int i = 0; i < dirs.getSize(); ++i ) {
				if( dirs[i].equals(name) ) {
					return (true);
				}
			}
		}
		else {
			for( int i = 0; i < dirs.getSize(); ++i ) {
				if( dirs[i].equalsIgnoreCase(name) ) {
					return (true);
				}
			}
		}
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> DiskFileSystem::dirGetFiles( String dirpath ) const
	{
		String path = fileFormatFileName(dirpath, FMT_FULL);
		return priv_getNames(path, true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> DiskFileSystem::dirGetSubDirectories( String dirpath ) const
	{
		String path = fileFormatFileName(dirpath, FMT_FULL);
		return priv_getNames(path, false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String DiskFileSystem::dirGetDefaultDirectory() const
	{
		return (m_cwd);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::isCaseSensitive() const
	{
		#if !defined(BLUE_PLATFORM_WIN32)
		return (true);
		#else
		return (false);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String DiskFileSystem::getHomeDirectory() const
	{
		#if defined(BLUE_PLATFORM_WIN32)
		// SHGetSpecialFolderLocation (shlobj.h)
		// #define CSIDL_PERSONAL                  0x0005

		// Why do it this way?  To avoid linking to yet another library.
		// This is the only function needed from the shell32.dll, why
		// link to everything when it's not neccessary?

		typedef BOOL (_stdcall *SHGetSpecialFolderPath_t)(HWND, LPTSTR, int, BOOL);

		String home;
		if( HMODULE module = LoadLibrary("shell32.dll") ) {
			if( SHGetSpecialFolderPath_t func = (SHGetSpecialFolderPath_t)GetProcAddress(module, "SHGetSpecialFolderPathA") ) {
				char buffer[MAX_PATH+1];
				if( func(NULL, buffer, 0x0005, FALSE) != FALSE ) {
					home = priv_win32GetLongFilename(buffer);
				}
			}
			FreeLibrary(module);
		}

		return fileFormatFileName( home == String::null ? "/" : home, FMT_FULL);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String DiskFileSystem::getTempDirectory() const
	{
		#if defined(BLUE_PLATFORM_WIN32)
		char buffer[MAX_PATH+1];
		if( GetTempPath(sizeof(buffer)-1, buffer) != 0 ) {
			String temp = priv_win32GetLongFilename(buffer);
			return fileFormatFileName(temp, FMT_FULL);
		}

		return getHomeDirectory();
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void DiskFileSystem::fileSetPos( filehandle_t handle, int pos )
	{
		fseek( (FILE*)handle, pos, SEEK_SET );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void DiskFileSystem::fileFlush( filehandle_t handle )
	{
		fflush( (FILE*)handle );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int DiskFileSystem::fileRead( filehandle_t handle, void* buffer, int size )
	{
		return fread( buffer, 1, size, (FILE*)handle );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int DiskFileSystem::fileWrite( filehandle_t handle, const void* data, int size )
	{
		return fwrite( data, 1, size, (FILE*)handle );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::fileRemove( String filename )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		filename = fileFormatFileNameNative(filename);
		return (DeleteFile(filename.makeUnique().getAsCStr()) != FALSE);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::fileCopy( String filesrc, String filedst )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		filesrc = fileFormatFileNameNative(filesrc);
		filedst = fileFormatFileNameNative(filedst);
		return (CopyFile(filesrc.makeUnique().getAsCStr(), filedst.makeUnique().getAsCStr(), TRUE) != FALSE);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::fileMove( String filesrc, String filedst )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		filesrc = fileFormatFileNameNative(filesrc);
		filedst = fileFormatFileNameNative(filedst);
		return (MoveFile(filesrc.makeUnique().getAsCStr(), filedst.makeUnique().getAsCStr()) != FALSE);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::dirCreate( String dirpath )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		dirpath = fileFormatFileNameNative(dirpath);
		return (CreateDirectory( dirpath.makeUnique().getAsCStr(), NULL ) != FALSE);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::dirRemove( String dirpath )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		dirpath = fileFormatFileNameNative(dirpath);
		return (RemoveDirectory(dirpath.makeUnique().getAsCStr()) != FALSE);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::dirCopy( String dirsrc, String dirdst )
	{
		if( !dirExists(dirdst) ) {
			dirCreate(dirdst);
		}

		int idx;
		Array<String> files = dirGetFiles(dirsrc);
		for( idx = 0; idx < files.getSize(); ++idx ) {
			if( !fileCopy( dirsrc + "/" + files[idx], dirdst + "/" + files[idx]) ) {
				return (false);
			}
		}

		Array<String> dirs = dirGetSubDirectories(dirsrc);
		for( idx = 0; idx < dirs.getSize(); ++idx ) {
			if( !dirCopy( dirsrc + "/" + dirs[idx], dirdst + "/" + dirs[idx]) ) {
				return (false);
			}
		}
		return (true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DiskFileSystem::dirMove( String dirsrc, String dirdst )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		dirsrc = fileFormatFileNameNative(dirsrc);
		dirdst = fileFormatFileNameNative(dirdst);
		return (MoveFile(dirsrc.makeUnique().getAsCStr(), dirdst.makeUnique().getAsCStr()) != FALSE);
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void DiskFileSystem::dirSetDefaultDirectory( String dirname )
	{
		String cwd = fileFormatFileName(dirname, FMT_FULL);
		if( dirExists(cwd) ) {
			m_cwd = cwd;
		}
	}


}}	// namespaces
