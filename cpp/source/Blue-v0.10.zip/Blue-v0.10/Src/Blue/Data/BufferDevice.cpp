//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/BufferDevice.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "BufferDevice.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	BufferDevice::BufferDevice() :m_access(READ)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	BufferDevice::BufferDevice( const Buffer& data, access_e access ) :m_access(READ)
	{
		open(data, access);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	BufferDevice::BufferDevice( const BufferDevice& copy ) :m_access(copy.m_access)
	{
		m_posStack = copy.m_posStack.copy();
		m_buffer   = copy.m_buffer.copy();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	BufferDevice::~BufferDevice()
	{
		close();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void BufferDevice::open( const Buffer& data, access_e access )
	{
		close();

		m_access = access;
		m_buffer = data.copy();
		m_posStack.append(0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void BufferDevice::close()
	{
		m_access = READ;
		m_buffer.clear();
		m_posStack.clear();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool BufferDevice::isOpen() const
	{
		if( m_buffer.getSize() > 0 ) {
			return (true);
		}
		else if( (m_access & WRITE) != 0 ) {
			return (true);
		}

		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool BufferDevice::isReadable() const
	{
		return ((m_access & READ) != 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool BufferDevice::isWriteable() const
	{
		return ((m_access & WRITE) != 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool BufferDevice::isSeekable() const
	{
		return (true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool BufferDevice::canRead() const
	{
		if( !isReadable() ) {
			return (false);
		}

		return ( m_posStack[0] - m_buffer.getSize() != 0 );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool BufferDevice::canWrite() const
	{
		return isWriteable();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int BufferDevice::getSize() const
	{
		return (m_buffer.getSize());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int BufferDevice::getPos() const
	{
		return (m_posStack[0]);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	const Buffer& BufferDevice::getBuffer() const
	{
		return (m_buffer);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void BufferDevice::purge()
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot purge when not writeable"));
		}

		m_buffer.clear();
		m_posStack[0] = 0;

	}

	// ---------------------------------------------------------------------------------------------------------------------

	void BufferDevice::flush()
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot flush when not writeable"));
		}

		// nothing to do here
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int BufferDevice::read( void* buffer, int size )
	{
		if( !isReadable() ) {
			throw DeviceInvalidModeException($("Cannot read when not readable"));
		}

		int actl = min(size, m_buffer.getSize() - m_posStack[0]);
		m_posStack[0] += m_buffer.readData(buffer, actl, m_posStack[0]);
		return (actl);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int BufferDevice::write( const void* data, int size )
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot write when not writeable"));
		}

		int need = size - (m_buffer.getSize() - m_posStack[0]);
		if( need > 0 ) {
			m_buffer.resize( m_buffer.getSize() + need );
		}

		m_posStack[0] += m_buffer.writeData( data, size, m_posStack[0] );
		return (size);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void BufferDevice::setPos( int pos, seek_method_e seek )
	{
		switch(seek)
		{
		case SM_BEG: m_posStack[0]  = pos; break;
		case SM_CUR: m_posStack[0] += pos; break;
		case SM_END: m_posStack[0]  = m_buffer.getSize() - pos; break;
		}

		m_posStack[0] = clamp(m_posStack[0], 0, m_buffer.getSize());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void BufferDevice::pushPos()
	{
		m_posStack.insert(m_posStack[0], 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void BufferDevice::popPos()
	{
		if( m_posStack.getSize() != 1 ) {
			m_posStack.remove(0);
			m_posStack[0] = min(m_posStack[0], m_buffer.getSize());
		}
	}

}}	// namespaces
