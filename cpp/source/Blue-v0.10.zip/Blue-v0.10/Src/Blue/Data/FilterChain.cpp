//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/FilterChain.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "FilterChain.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	FilterChain::FilterChain() :m_locked(false)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	FilterChain::~FilterChain()
	{
		unlock();

		while( m_filters.getSize() > 0 ) {
			removeFilter(0);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int FilterChain::getFilterCount() const
	{
		return m_filters.getSize();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Filter* FilterChain::getFilter( int index )
	{
		return (m_filters[index].m_filter);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	const Filter* FilterChain::getFilter( int index ) const
	{
		return (m_filters[index].m_filter);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int FilterChain::addFilter( Filter* filter, bool autoDelete )
	{
		return insertFilter(m_filters.getSize(), filter, autoDelete);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int FilterChain::insertFilter( int before, Filter* filter, bool autoDelete )
	{
		if( m_locked ) {
			throw FilterChainLockException();
		}

		filter_entry entry;
		entry.m_filter     = filter;
		entry.m_autoDelete = autoDelete;
		entry.m_closed     = false;

		before = clamp(before, 0, m_filters.getSize());

		if( before == m_filters.getSize() ) {
			m_filters.append(entry);
		}
		else {
			m_filters.insert(entry, before);
		}

		return (before);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::removeFilter( int index )
	{
		if( m_locked ) {
			throw FilterChainLockException();
		}

		if( m_filters[index].m_autoDelete ) {
			delete m_filters[index].m_filter;
		}

		m_filters.remove(index);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::setFilterAutoDelete( int index, bool autoDelete )
	{
		m_filters[index].m_autoDelete = autoDelete;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool FilterChain::isValid() const
	{
		return (m_filters.getSize() > 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool FilterChain::canRead()
	{
		bool canRead = m_filters[m_filters.getSize() - 1].m_filter->canRead();
		
		if(!canRead) {
			while( canRead == false ) {
				bool readable = false;
				for( int i = 0; i < m_filters.getSize(); ++i ) {
					if( m_filters[i].m_filter->canRead() ) {
						readable = true;
						break;
					}
				}

				if( m_closed && !readable) {
					for( int i = 0; i < m_filters.getSize(); ++i ) {
						if( m_filters[i].m_closed == false ) {
							readable = true;
							break;
						}
					}
				}

				if( readable ) {
					processChain(0);
					canRead = m_filters[m_filters.getSize() - 1].m_filter->canRead();
				}
				else {
					break;
				}
			}
		}

		return (canRead);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::lock()
	{
		m_locked = true;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::unlock()
	{
		m_locked = false;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::write( uint8_t byte )
	{
		m_filters[0].m_filter->write(byte);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint8_t FilterChain::read()
	{
		uint8_t retVal = m_filters[m_filters.getSize() - 1].m_filter->read();

		if( m_closed && !m_filters[m_filters.getSize() - 1].m_closed ) {
			processChain(0);
		}

		return (retVal);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::streamClosed()
	{
		m_closed = true;
		processChain(0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::reset()
	{
		for( int i = 0; i < m_filters.getSize(); ++i ) {
			m_filters[i].m_filter->reset();
			m_filters[i].m_closed = false;
		}
		m_closed = false;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FilterChain::processChain( int begin )
	{
		if( m_closed ) {
			bool close = true;
			for( int i = 0; i < m_filters.getSize(); ++i ) {
				if( (i < begin && m_filters[i].m_closed == false) || m_filters[i].m_filter->canRead() ) {
					close = false;
					break;
				}
			}
			if( close && (m_filters[begin].m_closed == false && m_filters[begin].m_filter->canRead() == false) ) {
				m_filters[begin].m_filter->streamClosed();
				m_filters[begin].m_closed = true;
			}
		}

		if( begin == m_filters.getSize() - 1 ) {
			return;
		}

		while( m_filters[begin].m_filter->canRead() ) {
			if( m_filters[begin+1].m_filter->canRead() ) {
				break;
			}
			else {
				m_filters[begin+1].m_filter->write( m_filters[begin].m_filter->read() );
			}
		}

		processChain(begin + 1);
	}


}}	// namespaces
