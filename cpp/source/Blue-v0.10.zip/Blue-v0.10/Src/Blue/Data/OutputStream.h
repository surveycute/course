//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/OutputStream.h
//**

#ifndef __blue_data_OutputStream_h_included__
#define __blue_data_OutputStream_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Data/Device.h"
#include "Blue/Data/FilterChain.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class OutputStream
	 * \brief Streams data to a %Device.
	 * \ingroup Data
	 *
	 * The %OutputStream class allows for writing data to a
	 * %Device.  While a %Device can be written to directly, the
	 * %OutputStream allows for filtering of the data being wrote
	 * before it is given to the device.  See the documentation
	 * for Filter and FilterChain for more information.
	 *
	 * \sa Filter, FilterChain, Device, InputStream
	 */
	class BLUE_EXPORT OutputStream
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		OutputStream();
		/** Constructor. */
		OutputStream( Device* device, bool startWriting = false );

		/** Destructor. */
		~OutputStream();


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the Device used for writing to the OutputStream.
		 */
		Device* getWriteDevice() const;

		/**
		 * Determines if the %OutputStream can be written to.
		 */
		bool isWriting() const;

		/**
		 * Returns the FilterChain being used by this %OutputStream.
		 */
		FilterChain* getFilterChain() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Sets the %Device to read data from.  If the %OutputStream is
		 * already reading, a DeviceInvalidModeException will be thrown.
		 */
		void setWriteDevice( Device* device, bool startWriting = false );

		/**
		 * Once a %Device has been set by OutputStream::setWriteDevice,
		 * this function must be called before any writing can occur.
		 */
		void startWriting();
		/**
		 * Once writing has begun, this must be called before changing
		 * the %Device being written to.
		 */
		void stopWriting();

		/**
		 * Sets the FilterChain to be used by this %OutputStream.  This
		 * cannot be set if the stream is writing.
		 */
		void setFilterChain( FilterChain* chain );

		/**
		 * Writes data to the stream.  The return value is the actual
		 * number of bytes written.  It may or may not match the given
		 * size.  This value should be checked to determine how much of
		 * the data was written.
		 *
		 * If the write operation failed for some reason, a 
		 * DeviceWriteInterruptException is thrown.  If the stream has not
		 * been started, a DeviceInvalidModeException will be thrown.
		 */
		int write( const void* data, int size );
		/** overload */
		int write( const Buffer& data );

		
		/** Writes an 8 bit integer to the %Device. */
		void writeInt8( int8_t var );
		/** Writes a 16 bit integer to the %Device, swapping endianess if needed. */
		void writeInt16( int16_t var );
		/** Writes a 32 bit integer to the %Device, swapping endianess if needed. */
		void writeInt32( int32_t var );
		/** Writes a 64 bit integer to the %Device, swapping endianess if needed. */
		void writeInt64( int64_t var );
		/** Writes an 8 bit unsigned integer to the %Device. */
		void writeUint8( uint8_t var );
		/** Writes a 16 bit unsigned integer to the %Device, swapping endianess if needed. */
		void writeUint16( uint16_t var );
		/** Writes a 32 bit unsigned integer to the %Device, swapping endianess if needed. */
		void writeUint32( uint32_t var );
		/** Writes a 64 bit unsigned integer to the %Device, swapping endianess if needed. */
		void writeUint64( uint64_t var );
		/** Writes a 32 bit float to the %Device. */
		void writeFloat32( float32_t var );
		/** Writes a 64 bit float to the %Device. */
		void writeFloat64( float64_t var );
		/** Writes an ascii string to the %Device, but stops short of the null terminator. */
		void writeString( String var );
		/** Writes an ascii string to the %Device, including the null terminator. */
		void writeStringNull( String var );
		/**
		 * Writes an ascii string to the %Device placing a 4 byte value for the length,
		 * followed by the string data.
		 */
		void writeStringPascal( String var );

		/** Writes the value to the %Device. */
		OutputStream& operator<<( int8_t var );
		/** overload. */
		OutputStream& operator<<( int16_t var );
		/** overload. */
		OutputStream& operator<<( int32_t var );
		/** overload. */
		OutputStream& operator<<( int64_t var );
		/** overload. */
		OutputStream& operator<<( uint8_t var );
		/** overload. */
		OutputStream& operator<<( uint16_t var );
		/** overload. */
		OutputStream& operator<<( uint32_t var );
		/** overload. */
		OutputStream& operator<<( uint64_t var );
		/** overload. */
		OutputStream& operator<<( float32_t var );
		/** overload. */
		OutputStream& operator<<( float64_t var );
		/** overload. */
		OutputStream& operator<<( String var );


	private:
		/**
		 * Copy constructor. Private because OutputStreams should not be
		 * manipulated by more than one instance.
		 */
		OutputStream( const OutputStream& );
		/** Private assignment operator. See copy constructor documentation. */
		const OutputStream& operator=( const OutputStream& );

		
		Device*      m_writeDevice;
		bool         m_writing;
		FilterChain* m_writeFilter;

	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
