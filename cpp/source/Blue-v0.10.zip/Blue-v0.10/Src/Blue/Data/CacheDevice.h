//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/CacheDevice.h
//**

#ifndef __blue_data_CacheDevice_h_included__
#define __blue_data_CacheDevice_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/Array.h"
#include "Blue/Data/Device.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class CacheDevice
	 * \brief Caches reads/writes from another Device into memory.
	 * \ingroup Data
	 *
	 *  A %Device that reads from another %Device and caches those
	 *  reads into memory.  When writing, it stores the data in
	 *  memory before writing to the %Device.  Note that a %CacheDevice
	 *  can only be used for one way communication.  Even if the %Device
	 *  being cached supports reading and writing, the %CacheDevice will
	 *  only do one or the other.
	 */
	class BLUE_EXPORT CacheDevice :public Device
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/**
		 * Method of accessing the BufferDevice.
		 */
		enum access_e
		{
			READ  = 1,      //!< The %CacheDevice can be read from.
			WRITE = 2,      //!< The %CacheDevice can be written to.
		};

		/** Constructor. */
		CacheDevice();

		/** Constructor. */
		CacheDevice( Device* device, access_e access, int cacheSize );

		/** Destructor. */
		virtual ~CacheDevice();

		/**
		 * Opens the %CacheDevice for the give Device.
		 */
		virtual void open( Device* device, access_e access, int cacheSize );

		virtual void close();


		// ===========================================================
		//  query
		// ===========================================================

		virtual bool isOpen() const;
		virtual bool isReadable() const;
		virtual bool isWriteable() const;
		virtual bool isSeekable() const;

		virtual bool canRead() const;
		virtual bool canWrite() const;

		virtual int getSize() const;
		virtual int getPos() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		virtual void purge();
		virtual void flush();

		using Device::read; // allow all read functions to be called
		virtual int read( void* buffer, int size );

		using Device::write; // allow all write functions to be called
		virtual int write( const void* data, int size );

		virtual void setPos( int pos, seek_method_e seek = SM_BEG );
		virtual void pushPos();
		virtual void popPos();

	private:
		/**
		 * Copy constructor. Private because CacheDevices should not be
		 * manipulated by more than one instance.
		 */
		CacheDevice( const CacheDevice& );
		/** Private assignment operator. See copy constructor documentation. */
		const CacheDevice& operator=( const CacheDevice& );

		void readIntoBuffer();

		Device*  m_device;
		access_e m_access;

		Buffer m_buffer;
		int    m_bufferIdx;
		int    m_bufferMax;
		Buffer m_bufferNext;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
