//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/FilterByte.h
//**

#ifndef __blue_data_FilterByte_h_included__
#define __blue_data_FilterByte_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Data/Filter.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class FilterByte
	 * \brief Base class for any Filters doing per byte manipulation.
	 * \ingroup Data
	 *
	 * The purpose of the %FilterByte class is to be a base class for
	 * any Filters that wants to manipulate the data stream byte by
	 * byte as they come in.  The only function that is required by
	 * the deriving class is the FilterByte::processByte function.
	 *
	 * Here is a sample %Filter that does very simple encryption
	 * on the data stream:
	 *
	 * \code
	 * class SimpleEncryptFilter: public FilterByte
	 * {
	 * public:
	 *     SimpleEncryptFilter( const char* pass ) {
	 *         m_pass = pass;
	 *         m_idx  = 0;
	 *     }
	 *
	 *     virtual ~SimpleEncryptFilter() {
	 *     }
	 *
	 *     virtual void processByte( uint8_t& byte ) {
	 *         byte ^= m_pass[m_idx];
	 *         m_idx = (++m_idx % m_pass.getLength());
	 *     }
	 *
	 * private:
	 *     String m_pass;
	 *     int    m_idx;
	 * };
	 * \endcode
	 */
	class BLUE_EXPORT FilterByte :public Filter
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Virtual Destructor. */
		virtual ~FilterByte();


		// ===========================================================
		//  query
		// ===========================================================

		virtual bool canRead() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		virtual void write( uint8_t byte );

		virtual uint8_t read();

		virtual void streamClosed();

		virtual void reset();


	protected:
		/** Constructor. */
		FilterByte();

		/**
		 * This is the function that deriving classes need to
		 * implement.  All this function needs to do is manipulate the
		 * given byte.
		 *
		 * \param byte - The byte to manipulate.
		 */
		virtual void processByte( uint8_t& byte ) = 0;

	private:
		/**
		 * Copy constructor. Private because FilterBytes should not be
		 * manipulated by more than one instance.
		 */
		FilterByte( const FilterByte& );
		/** Private assignment operator. See copy constructor documentation. */
		const FilterByte& operator=( const FilterByte& );

		
		bool    m_read;
		uint8_t m_byte;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
