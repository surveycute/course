//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/DiskFileSystem.h
//**

#ifndef __blue_data_DiskFileSystem_h_included__
#define __blue_data_DiskFileSystem_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Data/FileSystem.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class DiskFileSystem
	 * \brief A FileSystem implementation for disk %Files and %Directories.
	 * \ingroup Data
	 *
	 * \sa FileSystem
	 */
	class BLUE_EXPORT DiskFileSystem :public FileSystem
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		virtual ~DiskFileSystem();

		/** Returns the only allowed instance of %DiskFileSystem. */
		static DiskFileSystem* instance();

		virtual filehandle_t fileOpen( String filename, file_access_e access );
		virtual void fileClose( filehandle_t handle );


		// ===========================================================
		//  query
		// ===========================================================

		virtual int fileGetSize( filehandle_t handle );
		virtual int fileGetPos( filehandle_t handle );

		virtual util::DateTime fileGetCreatedDateTime( String filename );
		virtual util::DateTime fileGetModifiedDateTime( String filename );

		virtual String fileFormatFileName( String filename, format_e format ) const;
		virtual String fileFormatFileNameNative( String filename ) const;

		virtual bool fileExists( String filename ) const;

		virtual bool dirExists( String dirpath ) const;

		virtual Array<String> dirGetFiles( String dirpath ) const;
		virtual Array<String> dirGetSubDirectories( String dirpath ) const;

		virtual String dirGetDefaultDirectory() const;

		virtual bool isCaseSensitive() const;

		/**
		 * Returns the current user's home directory.
		 * This will vary depending on the operating system.
		 */
		String getHomeDirectory() const;
		/**
		 * Returns a directory suitable for temporary files.
		 * This will vary depending on the operating system.
		 */
		String getTempDirectory() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		virtual void fileSetPos( filehandle_t handle, int pos );

		virtual void fileFlush( filehandle_t handle );
		
		virtual int fileRead( filehandle_t handle, void* buffer, int size );
		virtual int fileWrite( filehandle_t handle, const void* data, int size );

		virtual bool fileRemove( String filename );
		virtual bool fileCopy( String filesrc, String filedst );
		virtual bool fileMove( String filesrc, String filedst );

		virtual bool dirCreate( String dirpath );
		virtual bool dirRemove( String dirpath );
		virtual bool dirCopy( String dirsrc, String dirdst );
		virtual bool dirMove( String dirsrc, String dirdst );

		virtual void dirSetDefaultDirectory( String dirname );

	private:
		DiskFileSystem();
		DiskFileSystem( const DiskFileSystem& copy );

		String m_cwd;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
