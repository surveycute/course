//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/Device.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Device.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	endianess_e Device::getPlatformEndianess()
	{
		#if defined(BLUE_PLATFORM_I386)
			return (ENDIAN_LITTLE);
		#else
			#error "data::Device::getPlatformEndianess() needs an implementation for this platform."
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	endianess_e Device::getEndianess() const
	{
		return (m_endianess);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Device::read( Buffer& buffer )
	{
		return read( buffer.getData(),  buffer.getSize() );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer Device::read( int size )
	{
		Buffer buffer(size);
		if( int retSize = read(buffer.getData(), size) ) {
			if( retSize < size ) {
				buffer.resize(retSize);
			}
			return (buffer);
		}

		return (Buffer::null);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer Device::readAll()
	{
		if( isSeekable() ) {
			int size = getSize();
			return read(size);
		}
		else {
			static const int MAX_READ = 32768;
			return read(MAX_READ);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Device::write( const Buffer& buffer )
	{
		return write(buffer.getData(), buffer.getSize());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int8_t Device::readInt8()
	{
		int8_t var;
		read(&var, sizeof(var));
		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int16_t Device::readInt16()
	{
		int16_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int32_t Device::readInt32()
	{
		int32_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int64_t Device::readInt64()
	{
		int64_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint8_t Device::readUint8()
	{
		uint8_t var;
		read(&var, sizeof(var));
		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint16_t Device::readUint16()
	{
		uint16_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint32_t Device::readUint32()
	{
		uint32_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint64_t Device::readUint64()
	{
		uint64_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	float32_t Device::readFloat32()
	{
		float32_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	float64_t Device::readFloat64()
	{
		float64_t var;
		int size = 0;
		while( size != sizeof(var) ) {
			size += read( ((byte_t*)&var) + size, sizeof(var)-size );
		}

		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		return (var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeInt8( int8_t var )
	{
		write(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeInt16( int16_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeInt32( int32_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeInt64( int64_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeUint8( uint8_t var )
	{
		write(&var, sizeof(var));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeUint16( uint16_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeUint32( uint32_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeUint64( uint64_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeFloat32( float32_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::writeFloat64( float64_t var )
	{
		if( getPlatformEndianess() != getEndianess() ) {
			swapEndianess(&var, sizeof(var));
		}

		int size = 0;
		while( size != sizeof(var) ) {
			size = write( ((byte_t*)&var) + size, sizeof(var)-size );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::setEndianess( endianess_e endianess )
	{
		m_endianess = endianess;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Device::swapEndianess( void* data, int size )
	{
		byte_t* bytes = (byte_t*)data;

		for( int i = 0; i < (size / 2); ++i ) {
			swap(bytes[i], bytes[(size - i) - 1]);
		}
	}


}}	// namespaces
