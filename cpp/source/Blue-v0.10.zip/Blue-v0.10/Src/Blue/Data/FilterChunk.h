//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/FilterChunk.h
//**

#ifndef __blue_data_FilterChunk_h_included__
#define __blue_data_FilterChunk_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/Buffer.h"
#include "Blue/Data/Filter.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class FilterChunk
	 * \brief Base class for any Filters doing byte chunk manipulation.
	 * \ingroup Data
	 *
	 * Some data Filters may need to manipulate data in chunks of
	 * certain sizes.  For example, some encryption methods require
	 * chunks of data (64 bytes at a time, maybe).  The %FilterChunk
	 * class allows for chunked Filters to be created easily.  Here
	 * is an example of a Base64 encoding filter that requires bytes
	 * in chunks of 3 and writes bytes in chunks of 4:
	 *
	 * \code
	 * class Base64EncodeFilter :public FilterChunk
	 * {
	 * public:
	 *     Base64EncodeFilter() :FilterChunk(3, 4)
	 *     {}
	 *
	 *     virtual ~Base64EncodeFilter() {
	 *     }
	 *
	 *
	 * private:
	 *     virtual void processChunk( uint8_t* chunkIn, int chunkInSize, uint8_t* chunkOut, int& ) {
	 *
	 *         const char base64Values[64] = {
	 *             'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
	 *             'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
	 *             'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
	 *             'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
	 *             };
	 *
	 *         chunkOut[0] = base64Values[   (chunkIn[0] & 0xfc) >> 2 ];
	 *         chunkOut[1] = base64Values[ ( (chunkIn[0] & 0x03) << 4 ) | ( (chunkIn[1] & 0xf0) >> 4) ];
	 *         chunkOut[2] = base64Values[ ( (chunkIn[1] & 0x0f) << 2 ) | ( (chunkIn[2] & 0xc0) >> 6) ];
	 *         chunkOut[3] = base64Values[   (chunkIn[2] & 0x3f) ];
	 *
	 *         int skip = 3 - chunkInSize;
	 *         if( skip != 0 && skip != 3 ) {
	 *             if( skip >= 1 ) chunkOut[3] = '=';
	 *             if( skip >= 2 ) chunkOut[2] = '=';
	 *         }
	 *     }
	 * };
	 * \endcode
	 *
	 * Note that when the stream is closed, the processChunk function
	 * may be called with an input chunk that does not contain the
	 * required number of bytes.  This should be handled by the
	 * deriving class.
	 */
	class BLUE_EXPORT FilterChunk :public Filter
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Virtual Destructor. */
		virtual ~FilterChunk();


		// ===========================================================
		//  query
		// ===========================================================

		virtual bool canRead() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		virtual void write( uint8_t byte );

		virtual uint8_t read();

		virtual void streamClosed();

		virtual void reset();


	protected:
		/**
		 * Constructor.  The deriving classes must pass the required
		 * chunk sizes into the constructor.  These values cannot be
		 * changes after the initial creation of the object.
		 */
		FilterChunk( int chunkSizeIn, int chunkSizeOut );

		/**
		 * This is the function that deriving classes need to implement
		 * in order to manipulate the chunks of data.
		 *
		 * \param chunkIn - The data to manipulate
		 * \param chunkInSize - The actual size of the input chunk.  This
		 *  will only be less than the requested number of bytes when the
		 *  end of the stream has been reached.
		 * \param chunkOut - The manipulated data
		 * \param chunkOutSize - Set this if the actual number of bytes
		 *  to write out is less than the size given at construction time.
		 */
		virtual void processChunk( uint8_t* chunkIn, int chunkInSize, uint8_t* chunkOut, int& chunkOutSize ) = 0;

	private:
		/**
		 * Copy constructor. Private because FilterChunks should not be
		 * manipulated by more than one instance.
		 */
		FilterChunk( const FilterChunk& );
		/** Private assignment operator. See copy constructor documentation. */
		const FilterChunk& operator=( const FilterChunk& );

		
		Buffer m_chunkIn;
		int    m_chunkInIdx;
		Buffer m_chunkOut;
		int    m_chunkOutIdx;
		int    m_chunkOutMax;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
