//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/FileSystem.h
//**

#ifndef __blue_data_FileSystem_h_included__
#define __blue_data_FileSystem_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"
#include "Blue/Common/Array.h"
#include "Blue/Util/DateTime.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class FileSystem
	 * \brief Interface for Files and Directories to communicate with various
	 * file systems.
	 * \ingroup Data
	 *
	 * The %FileSystem interface is meant to only be used by the %File and
	 * %Directory classes.  Through the use of this interface, the standard
	 * %File/%Directory classes can access disk files, archived files (like
	 * files in a ZIP archive), and any other types of files that can
	 * provide a %FileSystem.  See the File and Directory documentation for
	 * more information.
	 *
	 * When implementing a %FileSystem, keep in mind that the %File and
	 * %Directory classes expect that the %FileSystem will not throw any
	 * exceptions, so design the new %FileSystem so that it catches any and
	 * all possible exceptions.
	 *
	 * In all functions that accept file or path names, if the given path
	 * isn't absolute, then the current default directory is prepended to
	 * the given path.
	 *
	 * \sa File, Directory
	 */
	class BLUE_EXPORT FileSystem
	{
	public:
		// ===========================================================
		//  enums/typedefs
		// ===========================================================

		/** Method of accessing a file. */
		enum file_access_e
		{
			FILE_READ      = 0,  //!< file can be read from.
			FILE_WRITE     = 1,  //!< file can be written to.
			FILE_WRITEOVER = 2,  //!< file can be written to and its contents are destroyed.
		};

		/** Method of formatting a filename. */
		enum format_e
		{
			FMT_FULL,           //!< Full path and file or directory name.
			FMT_RELATIVE,       //!< Relative to the file or directory's parent directory.
			FMT_PATH,           //!< The path up to the current file or directory.
			FMT_EXT,            //!< Returns the extension of the file.
			FMT_RELATIVE_NOEXT, //!< Returns the relative filename without the extension
		};

		enum {
			INVALID_FILEHANDLE = -1, //!< Represents an invalid file handle.
		};

		/** Typedef used to represent a file handle. */
		typedef int32_t filehandle_t;


		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Virtual destructor. */
		virtual ~FileSystem()
		{}

		/**
		 * Opens a file in the %FileSystem.  The handle returned will be passed
		 * to the various functions to manipulate that file.
		 *
		 * \returns the file handle to the open file, or INVALID_FILEHANDLE.
		 */
		virtual filehandle_t fileOpen( String filename, file_access_e access ) = 0;
		/**
		 * Closes the file.  Once a file handle has been closed, it is no longer
		 * valid and should be set to INVALID_FILEHANDLE.
		 */
		virtual void fileClose( filehandle_t handle ) = 0;


		// ===========================================================
		//  query
		// ===========================================================

		/** Returns the size of the file in bytes. */
		virtual int fileGetSize( filehandle_t handle ) = 0;

		/** Returns the current reading position in the file. */
		virtual int fileGetPos( filehandle_t handle ) = 0;

		/** Returns the date and time when the file was created. */
		virtual util::DateTime fileGetCreatedDateTime( String filename ) = 0;
		/** Returns the date and time when the file was modified. */
		virtual util::DateTime fileGetModifiedDateTime( String filename ) = 0;


		/**
		 * Formats the given filename in the requested format. If the
		 * requested format is FMT_FULL, and the filename given is not an
		 * absolute path, the current default directory for the
		 * filesystem is used to complete the absolute path.
		 */
		virtual String fileFormatFileName( String filename, format_e format ) const = 0;
		/**
		 * Formats the given filename according to the native filesystem format.
		 * This function returns an absolute path.
		 */
		virtual String fileFormatFileNameNative( String filename ) const = 0;

		/** Determines if the file exists in the filesystem. */
		virtual bool fileExists( String filename ) const = 0;

		/** Determines if the directory exists in the filesystem. */
		virtual bool dirExists( String dirpath ) const = 0;

		/** Returns an array of files located in the given directory. */
		virtual Array<String> dirGetFiles( String dirpath ) const = 0;
		/** Returns an array of sub directories located in the given directory. */
		virtual Array<String> dirGetSubDirectories( String dirpath ) const = 0;

		/** Returns the default directory for the filesystem. */
		virtual String dirGetDefaultDirectory() const = 0;

		/** Determines if the %FileSystem's filenames are case sensitive or not. */
		virtual bool isCaseSensitive() const = 0;

		
		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Sets the reading position in the file. */
		virtual void fileSetPos( filehandle_t handle, int pos ) = 0;

		/** Flushes any pending writes to the file system. */
		virtual void fileFlush( filehandle_t handle ) = 0;
		
		/** Reads data from the file. */
		virtual int fileRead( filehandle_t handle, void* buffer, int size ) = 0;
		/** Writes data to the file. */
		virtual int fileWrite( filehandle_t handle, const void* data, int size ) = 0;

		/** Deletes the file from the filesystem. */
		virtual bool fileRemove( String filename ) = 0;
		/**
		 * Copies the file from one location to another.  All file attributes
		 * are to be kept in the new file.
		 */
		virtual bool fileCopy( String filesrc, String filedst ) = 0;
		/**
		 * Moves the file from one location to another.  All file attributes
		 * are to be kept in the new file.
		 */
		virtual bool fileMove( String filesrc, String filedst ) = 0;

		/**
		 * Creates a new directory.  The path leading up to the directory
		 * must exist or this function will fail.
		 */
		virtual bool dirCreate( String dirpath ) = 0;
		/**
		 * Deletes the directory from the filesystem.  This directory must
		 * not have any files or sub directories or the delete will fail.
		 */
		virtual bool dirRemove( String dirpath ) = 0;
		/**
		 * Copies the directory from one location to another.  All directory
		 * attributes are to be kept in the new directory.
		 */
		virtual bool dirCopy( String dirsrc, String dirdst ) = 0;
		/**
		 * Moves the directory from one location to another.  All directory
		 * attributes are to be kept in the new directory.
		 */
		virtual bool dirMove( String dirsrc, String dirdst ) = 0;

		/**
		 * Sets the default directory for the filesystem.  This is used to
		 * determine the absolute path when only a relative path is given.
		 */
		virtual void dirSetDefaultDirectory( String dirname ) = 0;


	protected:
		/** Constructor. */
		FileSystem()
		{}

	private:
		FileSystem( const FileSystem& );
		FileSystem& operator=( const FileSystem& );

	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
