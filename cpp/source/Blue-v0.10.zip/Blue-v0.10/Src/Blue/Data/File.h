//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/File.h
//**

#ifndef __blue_data_File_h_included__
#define __blue_data_File_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Data/Device.h"
#include "Blue/Data/FileSystem.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class File
	 * \brief Disk file device.
	 * \ingroup Data
	 *
	 * The %File class is used to read and write data to and from
	 * files.  Here is a usage example:
	 *
	 * \code
	 * try {
	 *     File someFile("somefile.txt");
	 *     if( someFile.exists() ) {
	 *         someFile.open(File::READ);
	 *         Buffer fileData = someFile.readAll();
	 *         someFile.close();
	 *
	 *         // process data in fileData...
	 *     }
	 *
	 *     Buffer textData( String("This is some text data") );
	 *     someFile.open(File::WRITEOVER);	// deletes existing content
	 *     someFile.write(textData);
	 *     someFile.close();
	 * }
	 * catch( FileAccessDeniedException& e ) {
	 *     cout << "You do not have access to " << e.getFileName() << endl;
	 * }
	 * \endcode
	 *
	 * When opening a %File for write access, the position of the file
	 * is located at the end of the file.  The position cannot be
	 * changed when writing to a file.  All writing will occur at the
	 * end of the file.  In other words, existing data cannot be
	 * overwritten.
	 *
	 * An interesting feature of Files (and Directories too) is that
	 * they can use different FileSystems.  The default %FileSystem
	 * used is the %DiskFileSystem.  Other FileSystems can be created
	 * so that Files can access ZIP archives and other such FileSystems.
	 *
	 * For example, say there's a %FileSystem for ZIP archives called
	 * ZipFileSystem.  We can access a file in that %FileSystem like this:
	 *
	 * \code
	 * ZipFileSystem archive("zipfile.zip");
	 * File arcFile("/dir/subdir/file.txt", &archive);
	 * arcFile.open(File::READ);
	 * // arcFile is reading from the zipfile.zip archive file.
	 * \endcode
	 *
	 * \sa FileSystem, DiskFileSystem, Directory
	 */
	class BLUE_EXPORT File :public Device
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/**
		 * Method of accessing the File.
		 */
		enum access_e
		{
			READ      = FileSystem::FILE_READ,      //!< The %File can be read from.
			WRITE     = FileSystem::FILE_WRITE,     //!< The %File can be written to, but is not truncated.
			WRITEOVER = FileSystem::FILE_WRITEOVER, //!< The %File can be written to and the contents are deleted.
		};

		/** Constructor. */
		File( FileSystem* system = 0 );
		/**
		 * Constructor.  Sets the filename, but does not open the file.
		 */
		File( String filename, FileSystem* system = 0 );
		/**
		 * Constructor.  Sets the filename and opens the file in the given mode.
		 */
		File( String filename, access_e access, FileSystem* system = 0 );

		/** Destructor. */
		virtual ~File();

		/**
		 * Opens the file.  If the file cannot be opened, a
		 * FileAccessDeniedException is thrown.
		 */
		void open( access_e access = READ );

		virtual void close();


		// ===========================================================
		//  query
		// ===========================================================

		virtual bool isOpen() const;
		virtual bool isReadable() const;
		virtual bool isWriteable() const;
		virtual bool isSeekable() const;

		virtual bool canRead() const;
		virtual bool canWrite() const;
		
		virtual int getSize() const;
		virtual int getPos() const;

		/**
		 * Returns the filename of the file.  This does not include
		 * any directory information.
		 */
		String getFileName() const;
		/**
		 * Returns the full filename of the file.  This includes the
		 * full absolute path of the file.
		 */
		String getFullFileName() const;
		/** Returns the extension of the file. */
		String getFileExt() const;
		/** Returns the filename without the extension. */
		String getFileNameWithoutExt() const;
		/** Returns the path leading up to the file. */
		String getFilePath() const;

		/** Determines if the File contains a filename. */
		bool hasFileName() const;

		/** Returns the %FileSystem being used by the %File. */
		FileSystem* getFileSystem() const;

		/** Determines if the file exists. */
		bool exists() const;
		/**
		 * Determines if the file exists without having to create a
		 * %File instances.
		 */
		static bool exists( String filename, FileSystem* system = 0 );

		/** Returns the date and time when the file was created. */
		util::DateTime getCreatedDateTime() const;
		/** Returns the date and time when the file was modified. */
		util::DateTime getModifiedDateTime() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		virtual void purge();
		virtual void flush();

		using Device::read; // allow all read functions to be called
		virtual int read( void* buffer, int size );

		using Device::write; // allow all write functions to be called
		virtual int write( const void* data, int size );

		virtual void setPos( int pos, seek_method_e seek = SM_BEG );
		virtual void pushPos();
		virtual void popPos();

		/**
		 * Sets the filename.  The file must be closed or a
		 * DeviceInvalidModeException will be thrown.
		 */
		void setFileName( String filename );

		/**
		 * Sets the %FileSystem to be used by the %File.  The %File must
		 * be closed or a DeviceInvalidModeException will be thrown.
		 */
		void setFileSystem( FileSystem* system );

		/**
		 * Removes the %File from the %FileSystem.  The %File must
		 * be closed or a %DeviceInvalidModeException will be thrown.
		 */
		void remove();
		/**
		 * Copies the %File from one location on the %FileSystem to
		 * another.  The %File must be closed or a
		 * %DeviceInvalidModeException will be thrown.
		 * \param to - The location to copy to.
		 * \param controlNew - Should this %File instance point to the
		 * new file?
		 */
		void copy( String to, bool controlNew = false );
		/**
		 * Moves the %File from one location on the %FileSystem to
		 * another.  The %File must be closed or a
		 * %DeviceInvalidModeException will be thrown.
		 * \param to - The location to copy to.
		 * \param controlNew - Should this %File instance point to the
		 * new file?
		 */
		void move( String to, bool controlNew = false );


	private:
		/**
		 * Copy constructor. Private because Files should not be
		 * manipulated by more than one instance.
		 */
		File( const File& );
		/** Private assignment operator. See copy constructor documentation. */
		const File& operator=( const File& );

		String      m_filename;
		access_e    m_access;
		Array<int>  m_posStack;
		int         m_size;
		FileSystem* m_system;
		FileSystem::filehandle_t m_handle;
	};


	/**
	 * \class FileAccessDeniedException
	 * \brief Thrown when attempting to open a file that security prohibits or
	 * cannot be found.
	 * \ingroup DataExceptions
	 *
	 * To prevent this exception from being thrown when the file can't be
	 * found, make a call to File::exists before attempting to open the file.
	 * This exception is also thrown by the Directory class in some instances.
	 *
	 * \sa File, Directory
	 */
	class BLUE_EXPORT FileAccessDeniedException :public common::Exception
	{
	public:
		FileAccessDeniedException( String filename, String desc = "File cannot be accessed" )
			:Exception(desc), m_file(filename) {}

		virtual String getException() const {
			return ("FileAccessDeniedException");
		}

		/** Returns the name of the file/directory that access to has been denied. */
		String getFileName() const {
			return (m_file);
		}

	private:
		String m_file;
	};



}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
