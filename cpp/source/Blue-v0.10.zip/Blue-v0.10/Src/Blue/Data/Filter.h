//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/Filter.h
//**

#ifndef __blue_data_Filter_h_included__
#define __blue_data_Filter_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class Filter
	 * \brief Used to filter data streaming through streams.
	 * \ingroup Data
	 *
	 * The %Filter class is an interface that should be derived from
	 * in order to allow for filtering of data that flows through
	 * InputStreams and OutputStreams.  There are two classes derived
	 * from %Filter that can be used for easier use.  They are the
	 * %FilterByte and %FilterChunk classes.  See the documentation
	 * for these classes for more information.
	 *
	 * When using Filters, an instance of the %Filter should only be
	 * used for one %FilterChain and only once in that %FilterChain.
	 *
	 * \sa FilterChain, FilterByte, FilterChunk,
	 *     InputStream, OutputStream
	 */
	class BLUE_EXPORT Filter
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Virtual Destructor. */
		virtual ~Filter()
		{}


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Determines if the %Filter has data that can be read.  This
		 * should always return true for Filters that read byte by byte,
		 * but may not always return true for Filters that operate on
		 * chunks of data.
		 */
		virtual bool canRead() const = 0;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Writes a byte to the %Filter.  This should be stored and
		 * manipulated by the %Filter before being returned by a call
		 * to Filter::read.
		 */
		virtual void write( uint8_t byte ) = 0;

		/**
		 * Reads one byte from the %Filter.  Note that this will never
		 * be called unless a call to Filter::write has been made and
		 * a call to Filter::canRead has returned true.
		 */
		virtual uint8_t read() = 0;

		/**
		 * Called when the data stream has been closed.  No further calls
		 * to Filter::write will be made.
		 */
		virtual void streamClosed() = 0;

		/**
		 * Called when the %Filter should reset its internal state.
		 */
		virtual void reset() = 0;


	protected:
		/** Protected Constructor accessible only by derived classes. */
		Filter()
		{}


	private:
		/**
		 * Copy constructor. Private because Filters should not be
		 * manipulated by more than one instance.
		 */
		Filter( const Filter& );
		/** Private assignment operator. See copy constructor documentation. */
		const Filter& operator=( const Filter& );

	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
