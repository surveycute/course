//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/CacheDevice.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "CacheDevice.h"

// library headers
#include "Blue/Kernel/Thread.h"

// system headers
#include <memory.h>


// Private Defines/Enums/Typedefs/Etc ======================================================================================

namespace {
	const int MIN_CACHE_SIZE = 1024;
}

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	CacheDevice::CacheDevice() :m_device(0), m_bufferIdx(0), m_bufferMax(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CacheDevice::CacheDevice( Device* device, access_e access, int cacheSize ) :m_device(0), m_bufferIdx(0), m_bufferMax(0)
	{
		open(device, access, cacheSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CacheDevice::~CacheDevice()
	{
		close();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::open( Device* device, access_e access, int cacheSize )
	{
		close();

		if( !device->isOpen() ) {
			throw DeviceInvalidModeException($("Cannot cache an unopened Device"));
		}

		if( access == READ && !device->isReadable()) {
			throw DeviceInvalidModeException($("Cannot cache reads for an unreadable Device"));
		}
		if( access == WRITE && !device->isWriteable()) {
			throw DeviceInvalidModeException($("Cannot cache writes for an unwriteable Device"));
		}

		m_device = device;
		m_access = access;

		cacheSize = max(cacheSize, MIN_CACHE_SIZE);

		if( m_access == READ ) {
			if( cacheSize % 2 != 0 ) {
				// must have even number cache size
				cacheSize -= 1;
			}
			m_buffer.setSize(cacheSize / 2);
			m_bufferNext.setSize(cacheSize / 2);
		}
		else {
			m_buffer.setSize(cacheSize);
		}

		m_bufferIdx = 0;
		m_bufferMax = 0;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::close()
	{
		if( isWriteable() ) {
			flush();
		}

		if( m_device != 0 ) {
			m_device = 0;
		}

		m_bufferIdx = 0;
		m_bufferMax = 0;

		m_buffer     = Buffer::null;
		m_bufferNext = Buffer::null;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool CacheDevice::isOpen() const
	{
		if( m_device == 0 ) {
			return (false);
		}
		if( m_device->isOpen() ) {
			return (true);
		}
		if( m_bufferMax > m_bufferIdx ) {
			return (true);
		}
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool CacheDevice::isReadable() const
	{
		return (m_access == READ && m_device != 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool CacheDevice::isWriteable() const
	{
		return (m_access == WRITE && m_device != 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool CacheDevice::isSeekable() const
	{
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool CacheDevice::canRead() const
	{
		if( !isReadable() ) {
			return (false);
		}
		if( m_bufferIdx < m_bufferMax ) {
			return (true);
		}
		if( m_device->canRead() ) {
			return (true);
		}
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool CacheDevice::canWrite() const
	{
		return isWriteable();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int CacheDevice::getSize() const
	{
		throw data::DeviceInvalidModeException($("CacheDevice is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int CacheDevice::getPos() const
	{
		throw data::DeviceInvalidModeException($("CacheDevice is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::purge()
	{
		// nothing to do
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::flush()
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot flush when not writeable"));
		}

		int start = 0;
		while(m_bufferIdx > 0) {
			int wrote = m_device->write(m_buffer.getData(start), m_bufferIdx);
			if( wrote == 0 ) {
				throw data::DeviceWriteInterruptException($("Unable to flush cached data to Device"));
			}
			start       += wrote;
			m_bufferIdx -= wrote;
		}
		m_bufferIdx = 0;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int CacheDevice::read( void* buffer, int size )
	{
		if( !isReadable() ) {
			throw DeviceInvalidModeException($("Cannot read from CacheDevice when not readable"));
		}

		readIntoBuffer();

		int actlSize = min(size, m_bufferMax - m_bufferIdx);
		int buffSize = m_buffer.getSize();

		int maxFromOne = max(0, min(m_bufferMax, buffSize) - m_bufferIdx);
		int maxFromTwo = max(0, min(m_bufferMax, buffSize * 2) - m_bufferIdx) - maxFromOne;

		int bufferOne = min(actlSize, maxFromOne);
		int bufferTwo = min(actlSize - bufferOne, maxFromTwo);

		if( bufferOne > 0 ) {
			memcpy((char*)buffer, m_buffer.getData(m_bufferIdx), bufferOne);
			m_bufferIdx += bufferOne;
		}
		if( bufferTwo > 0 ) {
			memcpy(((char*)buffer) + bufferOne, m_bufferNext.getData(0), bufferTwo);
			m_bufferIdx += bufferTwo;
		}

		if( m_bufferIdx >= buffSize ) {
			swap(m_buffer, m_bufferNext);
			m_bufferIdx -= buffSize;
			m_bufferMax -= buffSize;
		}
		if( m_bufferIdx == buffSize ) {
			m_bufferIdx  = 0;
			m_bufferMax  = 0;
		}

		return (actlSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int CacheDevice::write( const void* data, int size )
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot write to CacheDevice when not writeable"));
		}

		int actlSize = size;
		const char* writeData = (const char*)data;
		while(true) {
			int writeCache = m_buffer.getSize() - m_bufferIdx;
			int writeSize = min(writeCache, size);
			int wrote = m_buffer.writeData(writeData, writeSize, m_bufferIdx);
			m_bufferIdx += wrote;

			if( writeSize < size ) {
				flush();
				size -= wrote;
				writeData += wrote;
			}
			else break;
		}

		return (actlSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::setPos( int pos, seek_method_e seek )
	{
		throw data::DeviceInvalidModeException($("CacheDevice is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::pushPos()
	{
		throw data::DeviceInvalidModeException($("CacheDevice is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::popPos()
	{
		throw data::DeviceInvalidModeException($("CacheDevice is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CacheDevice::readIntoBuffer()
	{
		int cacheSize = m_buffer.getSize() * 2;
		if( m_bufferMax != cacheSize ) {
			while(true) {
				// buffers aren't full, try to read some data
				if( m_device->canRead() ) {
					int read = 0;
					if( m_bufferMax < m_buffer.getSize() ) {
						read = m_device->read(m_buffer.getData(m_bufferMax), m_buffer.getSize() - m_bufferMax);
					}
					else if( m_bufferMax < cacheSize ) {
						read = m_device->read(m_bufferNext.getData(m_bufferMax - m_buffer.getSize()), cacheSize - m_bufferMax);
					}
					if( read != 0 ) {
						m_bufferMax += read;
						break;
					}
				}
				if( m_bufferIdx != m_bufferMax ) {
					break;
				}
				if( !m_device->isOpen() ) {
					break;
				}
				kernel::Thread::sleep(0);
			}
		}
	}


}}	// namespaces
