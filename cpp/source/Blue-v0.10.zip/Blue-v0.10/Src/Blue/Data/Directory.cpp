//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/Directory.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Directory.h"

// blue headers
#include "Blue/Data/File.h"
#include "Blue/Data/DiskFileSystem.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

namespace {
	using namespace blue;
	using namespace blue::data;


	void priv_traverseTree( Directory* dir, Signal_2<Directory*,String>& sig, String searchPattern, bool recurse )
	{
		Array<String> files = dir->getFiles(searchPattern);
		for( int idxFiles = 0; idxFiles < files.getSize(); ++idxFiles ) {
			sig.emit(dir, files[idxFiles]);
		}

		if( recurse ) {
			Array<String> dirs = dir->getSubDirectories();

			for( int idxDirs = 0; idxDirs < dirs.getSize(); ++idxDirs ) {
				Directory recurseDir( dir->getFullPathName() + "/" + dirs[idxDirs] );
				priv_traverseTree( &recurseDir, sig, searchPattern, true );
			}
		}
	}
}

// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	Directory::Directory( String pathname, FileSystem* system )
	{
		setFileSystem(system);
		setPathName(pathname);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Directory::~Directory()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Directory::create( bool createParents )
	{
		if( createParents ) {
			String fullpath = getFullPathName();
			int pos = fullpath.findPos("/");
			while( (pos = fullpath.findPos("/", pos + 1)) != String::npos ) {
				String partpath = fullpath.left(pos);
				if( !getFileSystem()->dirExists(partpath) ) {
					if( !getFileSystem()->dirCreate(partpath) ) {
						throw FileAccessDeniedException(partpath);
					}
				}
			}
		}
		if( !getFileSystem()->dirCreate(getFullPathName()) ) {
			throw FileAccessDeniedException(getFullPathName());
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Directory Directory::createSubDirectory( String subDir, bool createParents )
	{
		Directory dir( getFullPathName() + "/" + subDir );
		dir.create(createParents);
		return (dir);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String Directory::getPathName() const
	{
		return getFileSystem()->fileFormatFileName(m_pathname, FileSystem::FMT_RELATIVE);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String Directory::getFullPathName() const
	{
		return (m_pathname);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String Directory::getParentPathName() const
	{
		return getFileSystem()->fileFormatFileName(m_pathname, FileSystem::FMT_PATH);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	FileSystem* Directory::getFileSystem() const
	{
		return (m_system);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> Directory::getFiles( String searchPattern ) const
	{
		Array<String> files = getFileSystem()->dirGetFiles(m_pathname);

		if( searchPattern == String::null || searchPattern == "*" ) {
			return (files);
		}

		Array<String> ret;

		if( getFileSystem()->isCaseSensitive() ) {
			for( int i = 0; i < files.getSize(); ++i ) {
				if( files[i].equalsWildCard(searchPattern) ) {
					ret.append(files[i]);
				}
			}
		}
		else {
			for( int i = 0; i < files.getSize(); ++i ) {
				if( files[i].equalsWildCardIgnoreCase(searchPattern) ) {
					ret.append(files[i]);
				}
			}
		}

		return (ret);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> Directory::getSubDirectories() const
	{
		return getFileSystem()->dirGetSubDirectories(m_pathname);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Directory::exists() const
	{
		return exists( m_pathname, getFileSystem() );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	bool Directory::exists( String directory, FileSystem* system ) 
	{
		if( system == 0 ) {
			system = DiskFileSystem::instance();
		}

		return system->dirExists(directory);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Directory::setPathName( String pathname )
	{
		m_pathname = getFileSystem()->fileFormatFileName(pathname, FileSystem::FMT_FULL);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Directory::setFileSystem( FileSystem* system )
	{
		m_system = system;
		if( m_system == 0 ) {
			m_system = DiskFileSystem::instance();
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Directory::remove( bool force )
	{
		if( force ) {
			int idx;
			Array<String> files = getFiles();
			for( idx = 0; idx < files.getSize(); ++idx ) {
				if( getFileSystem()->fileRemove(m_pathname + "/" + files[idx]) == false ) {
					throw FileAccessDeniedException(m_pathname + "/" + files[idx]);
				}
			}
			Array<String> dirs = getSubDirectories();
			for( idx = 0; idx < dirs.getSize(); ++idx ) {
				Directory(m_pathname + "/" + dirs[idx], getFileSystem()).remove(force);
			}
		}

		if( getFileSystem()->dirRemove(m_pathname) == false ) {
			throw FileAccessDeniedException(m_pathname);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Directory::copy( String to, bool controlNew )
	{
		to = getFileSystem()->fileFormatFileName(to, FileSystem::FMT_FULL);
		if( getFileSystem()->dirCopy(m_pathname, to) ) {
			if( controlNew ) {
				setPathName(to);
			}
		}
		else {
			throw FileAccessDeniedException(to);
		}

	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Directory::move( String to, bool controlNew )
	{
		to = getFileSystem()->fileFormatFileName(to, FileSystem::FMT_FULL);
		if( getFileSystem()->dirMove(m_pathname, to) ) {
			if( controlNew ) {
				setPathName(to);
			}
		}
		else {
			throw FileAccessDeniedException(to);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Directory::traverseTree( Signal_2<Directory*,String>& signal, String searchPattern, bool recurse )
	{
		priv_traverseTree(this, signal, searchPattern, recurse);
	}


}}	// namespaces
