//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/File.cpp
//**

// Private Headers =========================================================================================================

// system headers
#include <stdio.h>

// matching header
#include "File.h"

// blue headers
#include "Blue/Common/Array.h"
#include "Blue/Data/DiskFileSystem.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	File::File( FileSystem* system )
		:m_access(READ), m_handle(FileSystem::INVALID_FILEHANDLE)
	{
		setFileSystem(system);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	File::File( String filename, FileSystem* system )
		:m_access(READ), m_handle(FileSystem::INVALID_FILEHANDLE)
	{
		setFileSystem(system);
		setFileName(filename);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	File::File( String filename, access_e access, FileSystem* system )
		:m_access(READ), m_handle(FileSystem::INVALID_FILEHANDLE)
	{
		setFileSystem(system);
		setFileName(filename);
		open(access);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	File::~File()
	{
		close();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::open( access_e access )
	{
		close();

		m_handle = getFileSystem()->fileOpen( m_filename, (FileSystem::file_access_e)access );
		
		if( m_handle != FileSystem::INVALID_FILEHANDLE ) {
			m_access = access;
			m_posStack.append(0);
			m_size = getFileSystem()->fileGetSize(m_handle);
		}
		else {
			throw FileAccessDeniedException(m_filename);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::close()
	{
		if( !isOpen() ) {
			return;
		}

		getFileSystem()->fileClose(m_handle);
		m_handle = FileSystem::INVALID_FILEHANDLE;
		m_posStack.clear();
		m_size = 0;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::isOpen() const
	{
		return (m_handle != FileSystem::INVALID_FILEHANDLE);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::isReadable() const
	{
		return (isOpen() && m_access == READ);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::isWriteable() const
	{
		return (isOpen() && m_access != READ);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::isSeekable() const
	{
		return isReadable();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::canRead() const
	{
		return (isReadable() && getPos() != getSize());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::canWrite() const
	{
		return isWriteable();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int File::getSize() const
	{
		if( !isOpen() ) {
			return (0);
		}

		return (m_size);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int File::getPos() const
	{
		if( !isOpen() ) {
			return (0);
		}

		return (m_posStack[0]);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String File::getFileName() const
	{
		return getFileSystem()->fileFormatFileName(m_filename, FileSystem::FMT_RELATIVE);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String File::getFullFileName() const
	{
		return (m_filename);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String File::getFileExt() const
	{
		return getFileSystem()->fileFormatFileName(m_filename, FileSystem::FMT_EXT);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String File::getFileNameWithoutExt() const
	{
		return getFileSystem()->fileFormatFileName(m_filename, FileSystem::FMT_RELATIVE_NOEXT);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String File::getFilePath() const
	{
		return getFileSystem()->fileFormatFileName(m_filename, FileSystem::FMT_PATH);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::hasFileName() const
	{
		return (m_filename != String::null);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	FileSystem* File::getFileSystem() const
	{
		return (m_system);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool File::exists() const
	{
		return exists( getFullFileName(), getFileSystem() );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	bool File::exists( String filename, FileSystem* system )
	{
		if( system == 0 ) {
			system = DiskFileSystem::instance();
		}

		return system->fileExists(filename);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	util::DateTime File::getCreatedDateTime() const
	{
		return getFileSystem()->fileGetCreatedDateTime(m_filename);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	util::DateTime File::getModifiedDateTime() const
	{
		return getFileSystem()->fileGetModifiedDateTime(m_filename);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::purge()
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot purge when not writeable"));
		}

		if( getSize() > 0 ) {
			close();
			open(WRITEOVER);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::flush()
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot flush when not writeable"));
		}

		getFileSystem()->fileFlush(m_handle);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int File::read( void* buffer, int size )
	{
		if( !isReadable() ) {
			throw DeviceInvalidModeException($("Cannot read when not readable"));
		}

		int retSize = getFileSystem()->fileRead(m_handle, buffer, size);
		m_posStack[0] += retSize;

		return (retSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int File::write( const void* data, int size )
	{
		if( !isWriteable() ) {
			throw DeviceInvalidModeException($("Cannot write when not writeable"));
		}

		int retSize = getFileSystem()->fileWrite(m_handle, data, size);
		m_size += retSize;

		return (retSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::setPos( int pos, seek_method_e seek )
	{
		if( !isReadable() ) {
			return;
		}

		switch(seek)
		{
		case SM_BEG: m_posStack[0]  = pos; break;
		case SM_CUR: m_posStack[0] += pos; break;
		case SM_END: m_posStack[0]  = getSize() - pos; break;
		}

		m_posStack[0] = clamp(m_posStack[0], 0, getSize());
		getFileSystem()->fileSetPos(m_handle, m_posStack[0]);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::pushPos()
	{
		m_posStack.insert(m_posStack[0], 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::popPos()
	{
		if( m_posStack.getSize() != 1 ) {
			m_posStack.remove(0);
			m_posStack[0] = min(m_posStack[0], getSize());
			setPos(m_posStack[0], SM_BEG);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::setFileName( String filename )
	{
		if( isOpen() ) {
			throw DeviceInvalidModeException($("Cannot set filename while file is open"));
		}

		if( filename != String::null ) {
			m_filename = getFileSystem()->fileFormatFileName(filename, FileSystem::FMT_FULL);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::setFileSystem( FileSystem* system )
	{
		if( isOpen() ) {
			throw DeviceInvalidModeException($("Cannot change filesystem while file is open"));
		}

		m_system = system;
		if( m_system == 0 ) {
			m_system = DiskFileSystem::instance();
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::remove()
	{
		if( isOpen() ) {
			throw DeviceInvalidModeException($("Cannot remove file while file is open"));
		}

		if( getFileSystem()->fileRemove(m_filename) == false ) {
			throw FileAccessDeniedException(m_filename);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::copy( String to, bool controlNew )
	{
		if( isOpen() ) {
			throw DeviceInvalidModeException($("Cannot copy file while file is open"));
		}

		to = getFileSystem()->fileFormatFileName(to, FileSystem::FMT_FULL);
		if( getFileSystem()->fileCopy(m_filename, to) ) {
			if( controlNew ) {
				setFileName(to);
			}
		}
		else {
			throw FileAccessDeniedException(to);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void File::move( String to, bool controlNew )
	{
		if( isOpen() ) {
			throw DeviceInvalidModeException($("Cannot move file while file is open"));
		}

		to = getFileSystem()->fileFormatFileName(to, FileSystem::FMT_FULL);
		if( getFileSystem()->fileMove(m_filename, to) ) {
			if( controlNew ) {
				setFileName(to);
			}
		}
		else {
			throw FileAccessDeniedException(to);
		}
	}


}}	// namespaces
