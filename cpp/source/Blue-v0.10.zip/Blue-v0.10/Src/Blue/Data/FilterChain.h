//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/FilterChain.h
//**

#ifndef __blue_data_FilterChain_h_included__
#define __blue_data_FilterChain_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"
#include "Blue/Common/Array.h"
#include "Blue/Data/Filter.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class FilterChain
	 * \brief Allows multiple levels of filtering on one data stream.
	 * \ingroup Data
	 *
	 * The %FilterChain allows a single data stream (input or output)
	 * to have multiple layers of filtering without the individual
	 * filters needing to know anything about each other.
	 *
	 * This is useful in cases where multiple Filters are desired to
	 * operate on one stream of data.  For instance, when a data
	 * stream should be compressed and encrypted.  Simply create the
	 * data stream, create the two filters and add them to a
	 * %FilterChain to be set to the data stream.  An example would
	 * look similar to this:
	 *
	 * \code
	 *   FilterChain chain;
	 *   chain.addFilter( new CompressionFilter(), true );
	 *   chain.addFilter( new EncryptionFilter(), true );
	 *
	 *   OutputStream output(outputDevicePtr);
	 *   output.setFilterChain(&chain);
	 *   output.startWriting();
	 *
	 *   // now all data sent to the output will first be compressed,
	 *   // then encrypted before being sent to the underlying device.
	 * \endcode
	 *
	 * There are no limits (other than memory) to the number of filters
	 * that can be added to a %FilterChain.
	 *
	 * It is important to realize that because Filters may need to
	 * store internal state information, each %Filter added to the
	 * %FilterChain should be a unique instance and a %FilterChain
	 * should only be used for one stream at a time.
	 *
	 * While there are methods to manipulate Filters in the %FilterChain,
	 * it is only possible to do this if the stream using the %Filter
	 * has not been started (or has been stopped).  If the %FilterChain
	 * is attempted to be changed while being used, a 
	 * FilterChainLockException will be thrown.
	 *
	 * \sa Filter, InputStream, OutputStream
	 */
	class BLUE_EXPORT FilterChain
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		FilterChain();

		/** Destructor. */
		~FilterChain();


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the number of filters currently in the chain.
		 */
		int getFilterCount() const;

		/**
		 * Returns the filter at the given index.
		 */
		Filter* getFilter( int index );
		/** overload. */
		const Filter* getFilter( int index ) const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Adds a %Filter to the %FilterChain.
		 *
		 * \param filter - The %Filter to add.
		 * \param autoDelete - Should the %Filter be deleted when the
		 *  chain is destroyed?
		 * \returns The index of the new %Filter.
		 */
		int addFilter( Filter* filter, bool autoDelete = false );
		/**
		 * Inserts a %Filter into the %FilterChain.
		 *
		 * \param before - The index of the %Filter to insert this one
		 *  before.
		 * \param filter - The %Filter to insert.
		 * \param autoDelete - Should the %Filter be deleted when the
		 *  chain is destroyed?
		 * \returns The index of the new %Filter.
		 */
		int insertFilter( int before, Filter* filter, bool autoDelete = false );
		/**
		 * Removes a %Filter from the %FilterChain.
		 */
		void removeFilter( int index );

		/**
		 * Sets or removes the auto delete flag from a %Filter in
		 * the %FilterChain.  If a %Filter is set to auto delete, when
		 * the FilterChain is destroyed, the %Filter will be deleted.
		 */
		void setFilterAutoDelete( int index, bool autoDelete );


	private:
		// ===========================================================
		//  internal: interface used by the data streams.
		// ===========================================================
		
		friend class InputStream;
		friend class OutputStream;

		//  query
		bool isValid() const;
		bool canRead();

		//  manipulation
		void lock();
		void unlock();

		void write( uint8_t byte );
		uint8_t read();
		void streamClosed();
		void reset();

		// nothing below here should be touched by the data streams

		/**
		 * Copy constructor. Private because FilterChains should not be
		 * manipulated by more than one instance.
		 */
		FilterChain( const FilterChain& );
		/** Private assignment operator. See copy constructor documentation. */
		const FilterChain& operator=( const FilterChain& );

		void processChain( int begin );


		struct filter_entry
		{
			Filter* m_filter;
			bool    m_autoDelete;
			bool    m_closed;
		};

		bool m_locked;
		bool m_closed;
		Array<filter_entry> m_filters;
	};



	/**
	 * \class FilterChainLockException
	 * \brief Thrown when an operation is attempted on a %FilterChain that is being used.
	 * \ingroup DataExceptions
	 */
	class BLUE_EXPORT FilterChainLockException :public common::Exception
	{
	public:
		FilterChainLockException( String desc = String("Cannot execute that operation on a locked FilterChain", String::STATIC) )
			:Exception(desc) {}

		virtual String getException() const {
			return (String("FilterChainLockException", String::STATIC));
		}
	};


}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
