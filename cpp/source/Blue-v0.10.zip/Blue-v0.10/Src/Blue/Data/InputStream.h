//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/InputStream.h
//**

#ifndef __blue_data_InputStream_h_included__
#define __blue_data_InputStream_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Data/Device.h"
#include "Blue/Data/FilterChain.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class InputStream
	 * \brief Streams data from a %Device.
	 * \ingroup Data
	 *
	 * The %InputStream class allows for reading data from a
	 * %Device.  While a %Device can be read from directly, the
	 * %InputStream allows for filtering of the data being read
	 * before it is returned to the caller.  See the documentation
	 * for Filter and FilterChain for more information.
	 *
	 * \sa Filter, FilterChain, Device, OutputStream
	 */
	class BLUE_EXPORT InputStream
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		InputStream();
		/** Constructor. */
		InputStream( Device* device, bool startReading = false );

		/** Destructor. */
		~InputStream();


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the Device used for reading from the InputStream.
		 */
		Device* getReadDevice() const;

		/**
		 * Determines if the %InputStream can be read from.
		 */
		bool isReading() const;

		/**
		 * Returns the FilterChain being used by this %InputStream.
		 */
		FilterChain* getFilterChain() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Sets the %Device to read data from.  If the %InputStream is
		 * already reading, a DeviceInvalidModeException will be thrown.
		 */
		void setReadDevice( Device* device, bool startReading = false );

		/**
		 * Once a %Device has been set by InputStream::setReadDevice,
		 * this function must be called before any reading can occur.
		 */
		void startReading();
		/**
		 * Once reading has begun, this must be called before changing
		 * the %Device being read from.
		 */
		void stopReading();

		/**
		 * Sets the FilterChain to be used by this %InputStream.  This
		 * cannot be set if the stream is reading.
		 */
		void setFilterChain( FilterChain* chain );


		/**
		 * Reads data from the stream. The return value is the actual
		 * number of bytes read.  It may or may not match the requested
		 * size.
		 *
		 * If the read operation failed for some reason, a
		 * DeviceReadInterruptException is thrown.  If the stream has not
		 * been started, a DeviceInvalidModeException will be thrown.
		 */
		int read( void* buffer, int size );
		/** overload */
		int read( Buffer& buffer );
		/** overload */
		Buffer read( int size );

		/** Reads an 8 bit integer from the %Device. */
		int8_t readInt8();
		/** Reads a 16 bit integer from the %Device, swapping endianess if needed. */
		int16_t readInt16();
		/** Reads a 32 bit integer from the %Device, swapping endianess if needed. */
		int32_t readInt32();
		/** Reads a 64 bit integer from the %Device, swapping endianess if needed. */
		int64_t readInt64();
		/** Reads an 8 bit unsigned integer from the %Device, swapping endianess if needed. */
		uint8_t readUint8();
		/** Reads a 16 bit unsigned integer from the %Device. */
		uint16_t readUint16();
		/** Reads a 32 bit unsigned integer from the %Device, swapping endianess if needed. */
		uint32_t readUint32();
		/** Reads a 64 bit unsigned integer from the %Device, swapping endianess if needed. */
		uint64_t readUint64();
		/** Reads a 32 bit float from the %Device. */
		float32_t readFloat32();
		/** Reads a 64 bit float from the %Device. */
		float64_t readFloat64();
		/** Reads an ascii string until one of the characters in the given string is found. */
		String readString( String until = " \t\r\n" );
		/** Reads an ascii string until a null character is encountered. */
		String readStringNull();
		/** Reads an ascii string stored pascal style (4 byte length, then string). */
		String readStringPascal();

		/** Reads the value from the %Device. */
		InputStream& operator>>( int8_t& var );
		/** overload. */
		InputStream& operator>>( int16_t& var );
		/** overload. */
		InputStream& operator>>( int32_t& var );
		/** overload. */
		InputStream& operator>>( int64_t& var );
		/** overload. */
		InputStream& operator>>( uint8_t& var );
		/** overload. */
		InputStream& operator>>( uint16_t& var );
		/** overload. */
		InputStream& operator>>( uint32_t& var );
		/** overload. */
		InputStream& operator>>( uint64_t& var );
		/** overload. */
		InputStream& operator>>( float32_t& var );
		/** overload. */
		InputStream& operator>>( float64_t& var );
		/** overload. */
		InputStream& operator>>( String& var );


		/**
		 * Pushes data back into the input stream.  This should ONLY be used for data
		 * that had just been read from the %InputStream.  Otherwise, the data coming
		 * from the %InputStream will be corrupt and invalid.  This function can be
		 * used multiple times prior to a read.
		 */
		void pushBack( const void* buffer, int size );
		/** overload. */
		void pushBack( const Buffer& buffer );
		/** overload. */
		void pushBack( int8_t var );
		/** overload. */
		void pushBack( int16_t var );
		/** overload. */
		void pushBack( int32_t var );
		/** overload. */
		void pushBack( int64_t var );
		/** overload. */
		void pushBack( uint8_t var );
		/** overload. */
		void pushBack( uint16_t var );
		/** overload. */
		void pushBack( uint32_t var );
		/** overload. */
		void pushBack( uint64_t var );
		/** overload. */
		void pushBack( float32_t var );
		/** overload. */
		void pushBack( float64_t var );



	private:
		/**
		 * Copy constructor. Private because InputStreams should not be
		 * manipulated by more than one instance.
		 */
		InputStream( const InputStream& );
		/** Private assignment operator. See copy constructor documentation. */
		const InputStream& operator=( const InputStream& );

		
		Device*      m_readDevice;
		bool         m_reading;
		FilterChain* m_readFilter;
		Buffer       m_pushBackData;
		int          m_pushBackOffset;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
