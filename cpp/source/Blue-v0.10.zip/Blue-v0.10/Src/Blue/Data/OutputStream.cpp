//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/OutputStream.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "OutputStream.h"

// library headers
#include "Blue/Kernel/Thread.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

namespace {
	using namespace blue;
	using namespace blue::data;

	template<typename type_t> void writeVariable( OutputStream* output, type_t var )
	{
		if( Device::getPlatformEndianess() != output->getWriteDevice()->getEndianess() ) {
			Device::swapEndianess(&var, sizeof(var));
		}

		int size = output->write( ((type_t*)&var), sizeof(var) );

		while( size != sizeof(var) ) {
			kernel::Thread::sleep(0);
			size += output->write( ((type_t*)&var) + size, sizeof(var) - size );
		}
	}
}


// Functions ===============================================================================================================

namespace blue {
namespace data {

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream::OutputStream() :m_writeDevice(0), m_writing(false), m_writeFilter(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream::OutputStream( Device* device, bool startWriting ) :m_writeDevice(0), m_writing(false), m_writeFilter(0)
	{
		setWriteDevice(device, startWriting);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream::~OutputStream()
	{
		stopWriting();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Device* OutputStream::getWriteDevice() const
	{
		return (m_writeDevice);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool OutputStream::isWriting() const
	{
		return (m_writing);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	FilterChain* OutputStream::getFilterChain() const
	{
		return (m_writeFilter);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::setWriteDevice( Device* device, bool startWriting )
	{
		if( m_writing ) {
			throw DeviceInvalidModeException($("Cannot set read device while reading"));
		}

		m_writeDevice = device;

		if( startWriting ) {
			this->startWriting();
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::startWriting()
	{
		if( m_writing ) {
			return;
		}

		if( m_writeDevice == 0 ) {
			throw DeviceInvalidModeException($("Cannot read from a null device"));
		}

		if( m_writeFilter != 0 ) {
			m_writeFilter->reset();
			m_writeFilter->lock();
		}

		m_writing = true;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::stopWriting()
	{
		if( !m_writing ) {
			return;
		}

		if( m_writeFilter != 0 ) {
			if( m_writeFilter->isValid() ) {
				m_writeFilter->streamClosed();
				while( m_writeFilter->canRead() ) {
					uint8_t byte = m_writeFilter->read();
					m_writeDevice->write(&byte, sizeof(byte));
				}
			}

			m_writeFilter->unlock();
		}

		m_writing = false;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::setFilterChain( FilterChain* chain )
	{
		if( m_writing ) {
			throw DeviceInvalidModeException($("Cannot set output stream filter while writing"));
		}

		m_writeFilter = chain;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeInt8( int8_t var )
	{
		writeVariable<int8_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeInt16( int16_t var )
	{
		writeVariable<int16_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeInt32( int32_t var )
	{
		writeVariable<int32_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeInt64( int64_t var )
	{
		writeVariable<int64_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeUint8( uint8_t var )
	{
		writeVariable<uint8_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeUint16( uint16_t var )
	{
		writeVariable<uint16_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeUint32( uint32_t var )
	{
		writeVariable<uint32_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeUint64( uint64_t var )
	{
		writeVariable<uint64_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeFloat32( float32_t var )
	{
		writeVariable<float32_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeFloat64( float64_t var )
	{
		writeVariable<float64_t>(this, var);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeString( String var )
	{
		for( int i = 0; i < var.getLength(); ++i ) {
			writeInt8(var[i]);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeStringNull( String var )
	{
		for( int i = 0; i < var.getLength(); ++i ) {
			writeInt8(var[i]);
		}

		writeInt8('\0');
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void OutputStream::writeStringPascal( String var )
	{
		writeInt32( var.getLength() );

		for( int i = 0; i < var.getLength(); ++i ) {
			writeInt8( var[i] );
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( int8_t var )
	{
		writeInt8(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( int16_t var )
	{
		writeInt16(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( int32_t var )
	{
		writeInt32(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( int64_t var )
	{
		writeInt64(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( uint8_t var )
	{
		writeUint8(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( uint16_t var )
	{
		writeUint16(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( uint32_t var )
	{
		writeUint32(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( uint64_t var )
	{
		writeUint64(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( float32_t var )
	{
		writeFloat32(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( float64_t var )
	{
		writeFloat64(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	OutputStream& OutputStream::operator<<( String var )
	{
		writeString(var);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int OutputStream::write( const void* data, int size )
	{
		if( !isWriting() ) {
			throw DeviceInvalidModeException($("Cannot write to output stream"));
		}

		if( m_writeFilter != 0 && m_writeFilter->isValid() ) {
			uint8_t* bytes = (uint8_t*)data;
			int bytesWrote = 0;

			while( bytesWrote < size && isWriting() ) {
				m_writeFilter->write(bytes[bytesWrote++]);

				while( m_writeFilter->canRead() ) {
					uint8_t byte = m_writeFilter->read();
					m_writeDevice->write(&byte, sizeof(byte));
					kernel::Thread::sleep(0);
				}
				kernel::Thread::sleep(0);
			}

			return (bytesWrote);
		}
		else {
			return m_writeDevice->write(data, size);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int OutputStream::write( const Buffer& data )
	{
		return write( data.getData(), data.getSize() );
	}

}}	// namespaces
