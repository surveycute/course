//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/Directory.h
//**

#ifndef __blue_data_Directory_h_included__
#define __blue_data_Directory_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/Array.h"
#include "Blue/Common/Signals.h"
#include "Blue/Data/FileSystem.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class Directory
	 * \brief Allows searching of the filesystem's directory structure.
	 * \ingroup Data
	 *
	 * The %Directory class allows for directories to be created, as
	 * well as searched.  A very convienient method of processing
	 * multiple files is provided by the way of Device::traverseTree.
	 *
	 * An interesting feature of Directories (and Files too) is that
	 * they can use different FileSystems.  The default %FileSystem
	 * used is the %DiskFileSystem.  Other FileSystems can be created
	 * so that Directories can access ZIP archives and other such FileSystems.
	 *
	 * For example, say there's a %FileSystem for ZIP archives called
	 * ZipFileSystem.  We can access that %FileSystem like this:
	 *
	 * \code
	 * ZipFileSystem archive("zipfile.zip");
	 * Directory arcDir("/");
	 * Array<String> arcFiles = arcDir->getFiles();
	 * // arcDir is pointing to the root directory in the zipfile.zip archive file.
	 * \endcode
	 *
	 * \sa File, FileSystem, DiskFileSystem
	 */
	class BLUE_EXPORT Directory
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		Directory( String directory = String::null, FileSystem* system = 0 );

		/** Destructor. */
		~Directory();

		/**
		 * Creates the directory if it does not exist.  If the directory
		 * cannot be created, a FileAccessDeniedException is thrown.
		 *
		 * \param createParents - If the entire directory path does
		 * not exist, create the necessary directories to complete the
		 * path.
		 */
		void create( bool createParents = false );
		/**
		 * Creates the sub directory if it does not exist.  If the directory
		 * cannot be created, a FileAccessDeniedException is thrown.
		 *
		 * \param subDir - The sub directory to create.
		 * \param createParents - If the entire directory path does
		 * not exist, create the necessary directories to complete the
		 * path.
		 * \returns The new %Directory.
		 */
		Directory createSubDirectory( String subDir, bool createParents = false );


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the path of the directory.  This is not the absolute
		 * path.
		 */
		String getPathName() const;
		/** Returns the absolute path of the directory. */
		String getFullPathName() const;
		/** Returns the absolute path of the directory's parent. */
		String getParentPathName() const;

		/** Returns the %FileSystem being used by the %Directory. */
		FileSystem* getFileSystem() const;

		/**
		 * Returns the names of the files in the directory matching the
		 * given searchPattern ("*" is default).  This function will
		 * not allow recursive searching (searching beyond the current
		 * directory).  To do that, see Directory::traverseTree.
		 */
		Array<String> getFiles( String searchPattern = String::null ) const;
		/**
		 * Returns the names of the sub directories under this directory.
		 */
		Array<String> getSubDirectories() const;

		/**
		 * Determines if the directory exists or not.
		 */
		bool exists() const;

		/**
		 * Determines if the directory exists without having to create
		 * a %Directory instance.
		 */
		static bool exists( String directory, FileSystem* system = 0 );


		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Sets the path of the %Directory. */
		void setPathName( String pathname );

		/** Sets the %FileSystem to be used by the %Directory. */
		void setFileSystem( FileSystem* system );

		/**
		 * Removes the %Directory from the %FileSystem.  If the directory
		 * is not empty a FileAccessDeniedException will be thrown unless
		 * the <i>force</i> parameter is set to true.
		 */
		void remove( bool force = false );
		/**
		 * Copies the %Directory from one location on the %FileSystem to
		 * another.
		 * \param to - The location to copy to.
		 * \param controlNew - Should this %File instance point to the
		 * new file?
		 */
		void copy( String to, bool controlNew = false );
		/**
		 * Moves the %Directory from one location on the %FileSystem to
		 * another.
		 * \param to - The location to copy to.
		 * \param controlNew - Should this %File instance point to the
		 * new file?
		 */
		void move( String to, bool controlNew = false );

		/**
		 * If an application requires that some process be performed on
		 * a series of files in a directory tree, this function should be
		 * used.  This function will search the directory (and sub
		 * directories if recursion is requested) for files that match
		 * the search pattern ("*" is default) and emit the signal for
		 * each file it finds.
		 *
		 * Here is an example that will print the name of every text file
		 * under the current directory and any sub directories.
		 *
		 * \code
		 * void displayFileNames( Directory* dir, String file ) {
		 *     cout << dir->getFullPathName() << "/" << file << endl;
		 * }
		 *
		 * void traverse() {
		 *     Directory curDir(".");
		 *     Signal_2<Directory*,String> signal;
		 *     Slot slot = signal.connect(displayFileNames);
		 *     curDir.traverseTree(signal, "*.txt", true);
		 * }
		 * \endcode
		 */
		void traverseTree( Signal_2<Directory*,String>& signal, String searchPattern = String::null, bool recurse = false );

	private:
		String m_pathname;
		FileSystem* m_system;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
