//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Data/BufferDevice.h
//**

#ifndef __blue_data_BufferDevice_h_included__
#define __blue_data_BufferDevice_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/Array.h"
#include "Blue/Data/Device.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace data {

	/**
	 * \class BufferDevice
	 * \brief A %Device that operates from memory.
	 * \ingroup Data
	 *
	 * \sa Device, common::Buffer
	 */
	class BLUE_EXPORT BufferDevice :public Device
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/**
		 * Method of accessing the BufferDevice.
		 */
		enum access_e
		{
			READ  = (1<<0),      //!< The %BufferDevice can be read from.
			WRITE = (1<<1),      //!< The %BufferDevice can be written to.
			BOTH  = READ|WRITE,  //!< The %BufferDevice has read and write access.
		};

		/** Constructor. */
		BufferDevice();
		/** Constructor. */
		BufferDevice( const Buffer& data, access_e access = READ );
		/** Copy constructor. */
		BufferDevice( const BufferDevice& copy );

		/** Destructor. */
		virtual ~BufferDevice();

		/**
		 * Opens the %BufferDevice with the given %Buffer.
		 */
		virtual void open( const Buffer& data, access_e access = READ );

		virtual void close();


		// ===========================================================
		//  query
		// ===========================================================

		virtual bool isOpen() const;
		virtual bool isReadable() const;
		virtual bool isWriteable() const;
		virtual bool isSeekable() const;

		virtual bool canRead() const;
		virtual bool canWrite() const;
		
		virtual int getSize() const;
		virtual int getPos() const;
		
		const Buffer& getBuffer() const;
		

		// ===========================================================
		//  manipulation
		// ===========================================================

		virtual void purge();
		virtual void flush();

		using Device::read; // allow all read functions to be called
		virtual int read( void* buffer, int size );

		using Device::write; // allow all write functions to be called
		virtual int write( const void* data, int size );

		virtual void setPos( int pos, seek_method_e seek = SM_BEG );
		virtual void pushPos();
		virtual void popPos();


	private:
		Buffer      m_buffer;
		Array<int>  m_posStack;
		access_e    m_access;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
