//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/Thread.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Thread.h"

// system headers
#if defined(BLUE_PLATFORM_WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#	include <process.h>
#	include <setjmp.h>
#else
#	error "Thread needs an implementation for this platform."
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

namespace blue {
namespace kernel {

#if defined(BLUE_PLATFORM_WIN32)

	struct Thread::platform_info
	{
		void start( Thread* thread )
		{
			m_handle = (HANDLE)_beginthreadex(NULL, 0, threadFunction, thread, 0, &m_id);
			if( m_handle == NULL ) {
				throw ThreadCreateException();
			}
		}

		void exit()
		{
			longjmp(m_jmpBuf, 1);
		}

		void terminate()
		{
			TerminateThread(m_handle, 0);
		}

		bool join( int32_t milli )
		{
			return (WaitForSingleObject(m_handle, (milli < 0 ? INFINITE : milli)) != WAIT_TIMEOUT);
		}

		static void sleep( int32_t milli )
		{
			Sleep(milli);
		}

		static uint32_t WINAPI threadFunction( void* data )
		{
			Thread* thread = (Thread*)data;
			Thread::platform_info* info = thread->m_platform;

			try {

				int setRet = setjmp(info->m_jmpBuf);
				if( setRet == 0 ) {
					thread->run();
					thread->threadTerminated();
				}
				else {
					thread->threadTerminated();
				}
			}
			catch(...) {
				thread->threadTerminated();
			}

			return (0);
		}


		~platform_info()
		{
			CloseHandle(m_handle);
		}


		HANDLE   m_handle;
		uint32_t m_id;
		jmp_buf  m_jmpBuf;
	};

#endif

}}	// namespaces


// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace kernel {

	// ---------------------------------------------------------------------------------------------------------------------

	Thread::Thread( exit_mode_e mode )
		:m_platform(0), m_running(false), m_shouldExit(false)
	{
		setExitMode(mode);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Thread::~Thread()
	{
		terminate();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Thread::isRunning() const
	{
		return (m_platform != 0 && m_running);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Thread::exit_mode_e Thread::getExitMode() const
	{
		return (m_exitMode);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Thread::start()
	{
		if( isRunning() ) {
			throw ThreadInvalidModeException();
		}

		preRun();
		m_platform = new platform_info();
		m_platform->start(this);
		m_running = true;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Thread::terminate()
	{
		if( !isRunning() ) {
			return;
		}

		switch(m_exitMode)
		{
			case EXIT_DISABLED: break;
			case EXIT_PREDETERMINED:
				m_shouldExit = true;
				break;

			case EXIT_IMMEDIATELY:
				m_platform->terminate();
				threadTerminated();
				break;
		};
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Thread::join()
	{
		if( !isRunning() ) {
			return;
		}

		m_platform->join(-1);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Thread::join( int32_t milli )
	{
		if( !isRunning() ) {
			return (true);;
		}

		return m_platform->join(milli);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	void Thread::sleep( int32_t milli )
	{
		platform_info::sleep(milli);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Thread::yield()
	{
		sleep(0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Thread::exit()
	{
		m_platform->exit();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Thread::setExitMode( exit_mode_e mode )
	{
		if( isRunning() ) {
			throw ThreadInvalidModeException();
		}

		m_exitMode = mode;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Thread::shouldExit() const
	{
		return (m_shouldExit);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Thread::threadTerminated()
	{
		if( m_platform != 0 ) {
			delete m_platform;
			m_platform = 0;
		}

		m_running = false;
		m_shouldExit = false;

		postRun();
	}


}}	// namespaces
