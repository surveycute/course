//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/Mutex.h
//**

#ifndef __blue_kernel_Mutex_h_included__
#define __blue_kernel_Mutex_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace kernel {

	/**
	 * \class Mutex
	 * \brief Prevents more than one %Thread from accessing code at the
	 *        same time.
	 * \ingroup Kernel
	 *
	 * In multithreaded programs, there will be occasions where two or
	 * more Threads will be accessing or manipulating the same object
	 * or data.  It is important to be able to avoid the problem where
	 * one %Thread is manipulating the data, but is stopped in the
	 * middle of the execution by the operating system in order to start
	 * another %Thread that happens to be reading the same data that
	 * the other %Thread was writing.  What happens is that the reading
	 * %Thread gets the data in a half-written state.  This is a major
	 * error and is incredibly difficult to debug.  How is this
	 * situation avoided?  Through the use of Mutexes.  A %Mutex allows
	 * a section of code to be protected.  Each %Thread attempting to
	 * access the code must lock the %Mutex.  Only one %Thread may have
	 * the %Mutex locked at any one time.  Any other %Threads
	 * attempting to lock the %Mutex will block until the %Mutex is
	 * unlocked.
	 *
	 * Using a %Mutex is fairly straightforward.  Simply create an
	 * instance of the %Mutex that is accessible to all Threads and
	 * call the Mutex::lock function to lock access, manipulate the
	 * data, then call Mutex::unlock to give other Threads access.  Here
	 * is an example of using a %Mutex (but is very bad code and should
	 * never be used in a real application).
	 *
	 * \code
	 * void myGlobalManipulatingFunction()
	 * {
	 *     static Mutex mutex; // the globally accessible mutex
	 *     mutex.lock();
	 *     g_myGlobalVariable += 1;
	 *     mutex.unlock();
	 * }
	 * \endcode
	 *
	 * \sa Thread, MutexAutoLock
	 */
	class BLUE_EXPORT Mutex
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		Mutex();

		/** Destructor. */
		~Mutex();


		// ===========================================================
		//  query
		// ===========================================================

		/** Determines if the %Mutex is currently locked. */
		bool isLocked() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Locks the %Mutex.  If the %Mutex is currently locked, the
		 * calling %Thread will sleep until the %Mutex is unlocked by
		 * the %Thread that locked it.
		 */
		void lock();

		/**
		 * Unlocks the %Mutex.  Once the %Mutex is unlocked, if a
		 * %Thread is waiting to lock the %Mutex, that %Thread gets
		 * the lock.
		 */
		void unlock();


	private:
		/**
		 * Copy constructor. Private because Mutexes should not be
		 * manipulated by more than one instance.
		 */
		Mutex( const Mutex& );
		/** Private assignment operator. See copy constructor documentation. */
		const Mutex& operator=( const Mutex& );

		
		struct platform_info;
		platform_info* m_platform;
		bool m_locked;
	};



	/**
	 * \class MutexAutoLock
	 * \brief Allows for a %Mutex to be locked and unlocked automatically.
	 * \ingroup Kernel
	 *
	 * Many functions contain several exit points, be they return calls,
	 * exceptions, whatever.  In a %Mutex protected block of code, it is
	 * of utmost importance that the Mutex::unlock function is called
	 * when the locked code is complete.  However, a misplaced return or
	 * an unexpected exception can cause major problems on these sections
	 * of code.  That is where the %MutexAutoLock class comes in.
	 *
	 * By using a %MutexAutoLock, blocks of code can be locked and
	 * unlocked regardless of how the block of code is exited.  When the
	 * MutexAutoLock is created, the %Mutex is locked and when the
	 * %MutexAutoLock object goes out of scope, the %Mutex is unlocked.
	 *
	 * Here's an example of using a %MutexAutoLock:
	 *
	 * \code
	 * void myGlobalFunction()
	 * {
	 *     static Mutex mutex; // the globally accessible mutex
	 *     MutexAutoLock lock(mutex); // note: NOT static
	 *     anotherFunctionThatCouldThrowAnException();
	 * }
	 * \endcode
	 *
	 * \sa Thread, Mutex
	 */
	class BLUE_EXPORT MutexAutoLock
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/**
		 * Constructor.  Locks the given %Mutex.
		 */
		MutexAutoLock( Mutex& mutex ) :m_mutex(mutex)
		{
			m_mutex.lock();
		}

		/**
		 * Destructor.  Unlocks the given %Mutex.
		 */
		~MutexAutoLock()
		{
			m_mutex.unlock();
		}


	private:
		/**
		 * Copy constructor. Private because MutexAutoLocks should not be
		 * manipulated by more than one instance.
		 */
		MutexAutoLock( const MutexAutoLock& );
		/** Private assignment operator. See copy constructor documentation. */
		const MutexAutoLock& operator=( const MutexAutoLock& );

		
		Mutex& m_mutex;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
