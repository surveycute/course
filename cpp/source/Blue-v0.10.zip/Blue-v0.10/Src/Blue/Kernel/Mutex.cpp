//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/Mutex.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Mutex.h"

// system headers
#if defined(BLUE_PLATFORM_WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#else
#	error "Mutex needs an implementation for this platform."
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

namespace blue {
namespace kernel {

#if defined(BLUE_PLATFORM_WIN32)

	struct Mutex::platform_info
	{
		void lock()
		{
			EnterCriticalSection(&m_crit);
		}

		void unlock()
		{
			LeaveCriticalSection(&m_crit);
		}


		platform_info()
		{
			InitializeCriticalSection(&m_crit);
		}

		~platform_info()
		{
			DeleteCriticalSection(&m_crit);
		}

		CRITICAL_SECTION m_crit;
	};

#endif

}}	// namespaces


// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace kernel {

	// ---------------------------------------------------------------------------------------------------------------------

	Mutex::Mutex() :m_locked(false)
	{
		m_platform = new platform_info();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Mutex::~Mutex()
	{
		delete m_platform;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Mutex::isLocked() const
	{
		return (m_locked);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Mutex::lock()
	{
		m_platform->lock();
		m_locked = true;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Mutex::unlock()
	{
		m_platform->unlock();
		m_locked = false;
	}

	// ---------------------------------------------------------------------------------------------------------------------


}}	// namespaces
