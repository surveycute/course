//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/SharedLibrary.h
//**

#ifndef __blue_kernel_SharedLibrary_h_included__
#define __blue_kernel_SharedLibrary_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace kernel {

	/**
	 * \class SharedLibrary
	 * \brief Allows access to shared libraries used by the platform.
	 * \ingroup Kernel
	 *
	 * Shared libraries are used by many applications in order to
	 * reduce the amount of code that is actually compiled into an
	 * executable.  If many different applications require much of
	 * the same code, this code could be separated into a shared
	 * library in order to reduce the size of each executable, while
	 * at the same time making it easy to make changes and bug fixes
	 * to each application by only recompiling and distributing the
	 * shared library rather than each executable.
	 *
	 * Due to requirements set forth by some platforms, shared
	 * libraries are required to be actual files on the filesystem.
	 *
	 * Here is some sample code demonstrating basic usage of the
	 * %SharedLibrary object:
	 *
	 * \code
	 * typedef int (*myFunction_t)( int, float );
	 *
	 * SharedLibrary library;
	 * library.setFileName("./mySharedLibrary"); // no extension needed
	 * library.load();
	 *
	 * myFunction_t func = (myFunction_t)library.getSymbol("mySharedFunction");
	 * 
	 * func(1, 2.34f);
	 *
	 * library.unload();
	 *
	 * func = 0; // func no longer points to a valid function
	 * \endcode
	 */
	class BLUE_EXPORT SharedLibrary
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		SharedLibrary();
		/** Constructor. */
		SharedLibrary( String filename, bool load = true );

		/** Destructor. */
		~SharedLibrary();


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the filename of the shared library to use (or is
		 * being used).
		 */
		String getFileName() const;

		/**
		 * Determines if the shared library has been loaded into 
		 * memory.
		 */
		bool isLoaded() const;

		/**
		 * Determines if the given symbol exists in the shared library.
		 */
		bool symbolExists( String symbol ) const;

		/**
		 * Returns the extension used by the platform to identify a
		 * shared library.  For example, under Win32, this would return
		 * "DLL".
		 */
		static String getSharedLibraryExt();


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Sets the filename of the shared library to use.  If this
		 * instance currently has a library loaded, a
		 * SharedLibraryInvalidModeException is thrown.  The filename
		 * does not have to provide an extension.  If no extension is
		 * provided, the platform's shared library extension is used.
		 */
		void setFileName( String filename );

		/**
		 * Loads the shared library using the filename previously set.
		 */
		void load();
		/**
		 * Unloads the shared library.  Any and all symbols that were
		 * loaded from the shared library are no longer valid and
		 * should not be used.
		 */
		void unload();

		/**
		 * Extracts a symbol from the shared library.  If no library
		 * is loaded, a SharedLibraryInvalidModeException will be
		 * thrown.
		 *
		 * Symbols are usually functions that reside in a shared
		 * library that can be called by external applications.
		 */
		void* getSymbol( String symbol, bool throwIfNotFound = true );


	private:
		/**
		 * Copy constructor. Private because SharedLibraries should not be
		 * manipulated by more than one instance.
		 */
		SharedLibrary( const SharedLibrary& );
		/** Private assignment operator. See copy constructor documentation. */
		const SharedLibrary& operator=( const SharedLibrary& );

		String m_fileName;

		struct platform_info;
		platform_info* m_platform;
	};



	/**
	 * \class SharedLibraryNotFoundException
	 * \brief Thrown when attempting to load a shared library that does not exist.
	 * \ingroup KernelExceptions
	 */
	class BLUE_EXPORT SharedLibraryNotFoundException :public common::Exception
	{
	public:
		SharedLibraryNotFoundException( String libName, String desc = String("Unable to locate shared library", String::STATIC) )
			:Exception(desc), m_libName(libName) {}

		virtual String getException() const {
			return (String("SharedLibraryNotFoundException", String::STATIC));
		}

		String getLibraryName() const {
			return (m_libName);
		}

	private:
		String m_libName;
	};



	/**
	 * \class SharedLibraryInvalidFileException
	 * \brief Thrown when an attempting to load a file that is not a shared library.
	 * \ingroup KernelExceptions
	 */
	class BLUE_EXPORT SharedLibraryInvalidFileException :public common::Exception
	{
	public:
		SharedLibraryInvalidFileException( String fileName, String desc = String("Invalid mode for that operation", String::STATIC) )
			:Exception(desc), m_fileName(fileName) {}

		virtual String getException() const {
			return (String("SharedLibraryInvalidFileException", String::STATIC));
		}

		String getFileName() const {
			return (m_fileName);
		}

	private:
		String m_fileName;
	};



	/**
	 * \class SharedLibraryInvalidModeException
	 * \brief Thrown when an operation is attempted on a %SharedLibrary that cannot be performed.
	 * \ingroup KernelExceptions
	 */
	class BLUE_EXPORT SharedLibraryInvalidModeException :public common::Exception
	{
	public:
		SharedLibraryInvalidModeException( String desc = String("Invalid mode for that operation", String::STATIC) )
			:Exception(desc){}

		virtual String getException() const {
			return (String("SharedLibraryInvalidModeException", String::STATIC));
		}

		String getLibraryName() const {
			return (m_libName);
		}

	private:
		String m_libName;
	};



	/**
	 * \class SharedLibraryInvalidSymbolException
	 * \brief Thrown when attempting to load a symbol from a shared library that does not exist.
	 * \ingroup KernelExceptions
	 */
	class BLUE_EXPORT SharedLibraryInvalidSymbolException :public common::Exception
	{
	public:
		SharedLibraryInvalidSymbolException( String symbolName, String desc = String("Symbol does not exist in library", String::STATIC) )
			:Exception(desc), m_symbolName(symbolName) {}

		virtual String getException() const {
			return (String("SharedLibraryInvalidSymbolException", String::STATIC));
		}

		String getSymbolName() const {
			return (m_symbolName);
		}

	private:
		String m_symbolName;
	};


}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
