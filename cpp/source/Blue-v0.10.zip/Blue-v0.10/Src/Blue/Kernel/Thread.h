//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/Thread.h
//**

#ifndef __blue_kernel_Thread_h_included__
#define __blue_kernel_Thread_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace kernel {

	/**
	 * \class Thread
	 * \brief Represents an executable thread.
	 * \ingroup Kernel
	 *
	 * Threads allow applications to perform multiple operations at
	 * the same time.  If two Threads are created and started, they
	 * will execute parallel to each other.  This means that the
	 * operating system will decide when each %Thread gets time to
	 * execute.  The application does not have to handle the task of
	 * splitting execution time between the code.
	 *
	 * It must be realized that while Threads are very powerful and
	 * this class makes them easy to use, they make it easy to make
	 * mistakes and they are not easy to debug.  Use Threads
	 * sparingly and only when absolutely neccessary.
	 *
	 * \sa Mutex
	 */
	class BLUE_EXPORT Thread
	{
	public:

		/** Determines how the %Thread can be exited. */
		enum exit_mode_e
		{
			EXIT_DISABLED,       //!< The %Thread cannot be externally terminated.
			EXIT_PREDETERMINED,  //!< The %Thread is notified to terminate when convenient.
			EXIT_IMMEDIATELY,    //!< The %Thread is terminated immediately and without notification.
		};


		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Destructor. */
		virtual ~Thread();


		// ===========================================================
		//  query
		// ===========================================================

		/** Determines if the %Thread is currently running. */
		bool isRunning() const;

		/**
		 * Returns the current exit mode of the %Thread.  The
		 * exit mode determines what happens to the %Thread when an
		 * outside class calls Thread::terminate.
		 */
		exit_mode_e getExitMode() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Starts the %Thread.
		 */
		void start();

		/**
		 * Terminates the %Thread.  This does not neccessarily have to
		 * end the %Thread.  Depending on the exit mode, the %Thread
		 * may be flagged for termination, or it may be terminated
		 * immediately without notification, or it may ignore the
		 * termination request altogether.
		 */
		void terminate();

		/**
		 * Halts execution of the calling %Thread until this %Thread
		 * instance has finished execution.
		 */
		void join();
		/**
		 * Halts execution of the calling %Thread until either this %Thread
		 * instance has finished execution, or the given number of
		 * milliseconds have passed.
		 *
		 * \returns Whether this %Thread instance has finished execution
		 *          (true) or not (false).
		 */
		bool join( int32_t milli );

		/**
		 * Halts execution of the calling %Thread until the given number
		 * of milliseconds have passed.  This is useful for giving the
		 * operating system a signal that the calling %Thread is yielding
		 * some of its execution time.  This basically improves the
		 * processor usage of the computer.
		 */
		static void sleep( int32_t milli );


	protected:
		/** Constructor. */
		Thread( exit_mode_e mode = EXIT_IMMEDIATELY );

		/**
		 * This is the function that deriving Threads must implement.
		 * This function is called when the %Thread is started.  When this
		 * function exits, the %Thread has finished execution.
		 */
		virtual void run() = 0;
		/**
		 * This function is called immediately before the run function is
		 * run.  It allows Threads to do any neccessary initialization.
		 */
		virtual void preRun() {}
		/**
		 * This function is called immediately after the run function exits
		 * or the %Thread exits or is terminated.  In self-deleting Threads,
		 * this is where the %Thread should delete itself (delete this).
		 */
		virtual void postRun() {}

		/**
		 * Temporarily yields execution time to the operating system.  This
		 * should be called in Threads that use any sort of continual loops.
		 */
		void yield();
		/**
		 * Exits the %Thread.  This must only be called by the %Thread itself.
		 * This is the equivalent of returning from the Thread::run function.
		 */
		void exit();
		/**
		 * Tells the %Thread internals how it should react when
		 * Thread::terminate is called.
		 */
		void setExitMode( exit_mode_e mode );
		/**
		 * If the exit mode is set to EXIT_PREDETERMINED, this function
		 * should be called to determine whether the %Thread should
		 * terminate or not.
		 */
		bool shouldExit() const;


	private:
		/**
		 * Copy constructor. Private because Threads should not be
		 * manipulated by more than one instance.
		 */
		Thread( const Thread& );
		/** Private assignment operator. See copy constructor documentation. */
		const Thread& operator=( const Thread& );

		// Called internally
		void threadTerminated();


		struct platform_info;
		friend struct platform_info;
		platform_info* m_platform;

		exit_mode_e m_exitMode;
		bool        m_running;
		bool        m_shouldExit;
	};



	/**
	 * \class ThreadInvalidModeException
	 * \brief Thrown when an operation is attempted on a %Thread that cannot be performed.
	 * \ingroup KernelExceptions
	 */
	class BLUE_EXPORT ThreadInvalidModeException :public common::Exception
	{
	public:
		ThreadInvalidModeException( String desc = String("Invalid mode for that operation", String::STATIC) )
			:Exception(desc) {}

		virtual String getException() const {
			return (String("ThreadInvalidModeException", String::STATIC));
		}
	};



	/**
	 * \class ThreadCreateException
	 * \brief Thrown when an attempt to create a new %Thread failed.
	 * \ingroup KernelExceptions
	 */
	class BLUE_EXPORT ThreadCreateException :public common::Exception
	{
	public:
		ThreadCreateException( String desc = String("Unable to create thread", String::STATIC) )
			:Exception(desc) {}

		virtual String getException() const {
			return (String("ThreadCreateException", String::STATIC));
		}
	};





}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
