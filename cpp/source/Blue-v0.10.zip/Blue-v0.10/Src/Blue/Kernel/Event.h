//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/Event.h
//**

#ifndef __blue_kernel_Event_h_included__
#define __blue_kernel_Event_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace kernel {

	/**
	 * \class Event
	 * \brief A triggerable event.
	 * \ingroup Kernel
	 *
	 * An %Event can be used to allow one or more Threads to sleep
	 * until another %Thread indicates that execution should
	 * continue.
	 * 
	 * For example, if an application is creating multiple Threads
	 * that need to start their processing at the exact same time, an
	 * %Event can be used to trigger their start.  To wait on the
	 * %Event, the Threads only need to have access to the %Event
	 * object and call its <code>wait</code> function.  To allow all
	 * Threads waiting on the %Event to begin processing again, a
	 * different %Thread must call the %Event's <code>signal</code>
	 * function.
	 *
	 * Once an %Event has been signaled, it must be reset or any
	 * further attempts to wait on the %Event will return immediately.
	 *
	 * Here's a simple example of how an %Event might be used to
	 * coordinate the start of a %Thread:
	 *
	 * \code
	 * class MyThread: public Thread
	 * {
	 * public:
	 *     MyThread( Event* event ) :m_event(event) {}
	 *     virtual ~MyThread() {}
	 *
	 * private:
	 *     virtual void run() {
	 *         m_event->wait();
	 *
	 *         // do some processing here
	 *         // ...
	 *     }
	 *
	 *     Event* m_event;
	 * };
	 *
	 * void doMyThread()
	 * {
	 *     Event event;
	 *     MyThread thread(&event);
	 *
	 *     thread.start();
	 *     Thread::sleep(2000); // 2 seconds to let thread startup
	 *
	 *     event.signal(); // thread will now continue execution
	 *
	 *     thread.join(); // wait until thread is complete
	 * }
	 * \endcode
	 * \sa Thread
	 */
	class BLUE_EXPORT Event
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		Event();

		/** Destructor. */
		~Event();


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Determines if the %Event has been signaled and if it needs
		 * reset.
		 */
		bool hasBeenSignaled() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Signals the %Event.  All Threads waiting for the %Event will
		 * continue execution.
		 */
		void signal();
		/**
		 * Resets the %Event.  This will cause all Threads that wait on
		 * this %Event to block until it is signaled again.
		 */
		void reset();

		/**
		 * Blocks execution of the calling %Thread until another %Thread
		 * signals this %Event.
		 */
		void wait();
		/**
		 * Blocks execution of the calling %Thread until another %Thread
		 * signals this %Event or the timeout value is reached.
		 *
		 * \returns Whether the event was signaled (true) or not (false).
		 */
		bool wait( uint32_t milli );


	private:
		/**
		 * Copy constructor. Private because Events should not be
		 * manipulated by more than one instance.
		 */
		Event( const Event& );
		/** Private assignment operator. See copy constructor documentation. */
		const Event& operator=( const Event& );


		struct platform_info;
		platform_info* m_platform;
		bool m_signaled;	
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
