//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/SharedLibrary.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "SharedLibrary.h"

// library headers
#include "Blue/Data/File.h"

// system headers
#if defined(BLUE_PLATFORM_WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#else
#	error "SharedLibrary needs an implementation for this platform."
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

using namespace blue;
using namespace blue::common;
using namespace blue::data;

// Private Classes/Structs =================================================================================================

namespace blue {
namespace kernel {

#if defined(BLUE_PLATFORM_WIN32)

	struct SharedLibrary::platform_info
	{
		bool load( String filename )
		{
			m_module = LoadLibrary( filename.makeUnique().getAsCStr() );
			return (m_module != NULL);
		}


		void unload()
		{
			FreeLibrary(m_module);
		}


		void* getSymbol( String symbol ) const
		{
			return GetProcAddress( m_module, symbol.makeUnique().getAsCStr() );
		}


		static const char* const SHARED_EXT;

	private:
		HMODULE m_module;

	};

	const char* const SharedLibrary::platform_info::SHARED_EXT = "DLL";

#endif

}}	// namespaces


// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace kernel {

	// ---------------------------------------------------------------------------------------------------------------------

	SharedLibrary::SharedLibrary() :m_platform(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	SharedLibrary::SharedLibrary( String filename, bool load ) :m_platform(0)
	{
		setFileName(filename);
		
		if( load ) {
			this->load();
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	SharedLibrary::~SharedLibrary()
	{
		if( isLoaded() ) {
			unload();
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String SharedLibrary::getFileName() const
	{
		return (m_fileName);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool SharedLibrary::isLoaded() const
	{
		return (m_platform != 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool SharedLibrary::symbolExists( String symbol ) const
	{
		return (isLoaded() && m_platform->getSymbol(symbol) != 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	String SharedLibrary::getSharedLibraryExt()
	{
		return String(platform_info::SHARED_EXT);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SharedLibrary::setFileName( String filename )
	{
		if( isLoaded() ) {
			throw SharedLibraryInvalidModeException();
		}

		m_fileName = filename;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SharedLibrary::load()
	{
		if( isLoaded() ) {
			return;
		}

		String filename = m_fileName;

		if( !File::exists(filename) ) {
			filename += "." + getSharedLibraryExt();

			if( !File::exists(filename) ) {
				throw SharedLibraryNotFoundException(m_fileName);
			}
		}

		m_platform = new platform_info();
		if( !m_platform->load(filename) ) {
			delete m_platform;
			m_platform = 0;
			throw SharedLibraryInvalidFileException(filename);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SharedLibrary::unload()
	{
		if( !isLoaded() ) {
			return;
		}

		m_platform->unload();
		delete m_platform;
		m_platform = 0;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void* SharedLibrary::getSymbol( String symbol, bool throwIfNotFound )
	{
		if( !isLoaded() ) {
			throw SharedLibraryInvalidModeException();
		}

		void* sym = m_platform->getSymbol(symbol);

		if( sym == 0 && throwIfNotFound ) {
			throw SharedLibraryInvalidSymbolException(symbol);
		}

		return (sym);
	}


}}	// namespaces
