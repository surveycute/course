//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Kernel/Event.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Event.h"

// system headers
#if defined(BLUE_PLATFORM_WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#else
#	error "Event needs an implementation for this platform."
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

namespace blue {
namespace kernel {

#if defined(BLUE_PLATFORM_WIN32)

	struct Event::platform_info
	{
		void signal()
		{
			SetEvent(m_handle);
		}

		void reset()
		{
			ResetEvent(m_handle);
		}

		bool wait( int32_t milli )
		{
			return (WaitForSingleObject(m_handle, (milli < 0 ? INFINITE : milli)) != WAIT_TIMEOUT);
		}


		platform_info()
		{
			m_handle = CreateEvent(NULL, TRUE, FALSE, NULL);
		}

		~platform_info()
		{
			CloseHandle(m_handle);
		}

		HANDLE m_handle;
	};

#endif

}}	// namespaces


// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace kernel {

	// ---------------------------------------------------------------------------------------------------------------------

	Event::Event() :m_signaled(false)
	{
		m_platform = new platform_info();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Event::~Event()
	{
		delete m_platform;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Event::hasBeenSignaled() const
	{
		return (m_signaled);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Event::signal()
	{
		m_platform->signal();
		m_signaled = true;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Event::reset()
	{
		m_platform->reset();
		m_signaled = false;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Event::wait()
	{
		m_platform->wait(-1);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Event::wait( uint32_t milli )
	{
		return m_platform->wait(milli);
	}


}}	// namespaces
