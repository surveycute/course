//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Config.h [win32/msvc]
//**

#ifndef __blue_Config_h_included__
#define __blue_Config_h_included__

// Public Headers ==========================================================================================================

// Public Defines/Enums/Typedefs/Etc. ======================================================================================


// ===================================================================
//  Platforms
// ===================================================================

// Define this if your platform is Win32
#define BLUE_PLATFORM_WIN32


// Define this if your platform is i386
#define BLUE_PLATFORM_I386



// ===================================================================
//  Compilers / Compiling
// ===================================================================

// Define this if your compiler is MSVC++
#define BLUE_COMPILER_MSVC

// Define this if you want all warnings to be enabled
//#define BLUE_ENABLE_WARNINGS



// ===================================================================
//  Memory Tracking
// ===================================================================

// Define this to disable any memory tracking in debug builds.
//#define BLUE_MEMTRACK_DISABLED

// Define this to enable memory tracking in release builds (this
// is enabled by default in debug builds).
//#define BLUE_MEMTRACK

// Define this to enable the logging of individual allocations
// and deallocations (for extreme debugging only!)
//#define BLUE_MEMTRACK_EXTENSIVE


// Public Classes/Structs ==================================================================================================

// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
