//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/Exception.h
//**

#ifndef __blue_common_Exception_h_included__
#define __blue_common_Exception_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/String.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace common {

	/**
	 * \class Exception
	 * \brief Thrown when exceptions occur.
	 * \ingroup Common
	 *
	 * An %Exception is thrown when an error occurs in the library
	 * that the library cannot recover from.  All exceptions thrown
	 * by the library (or extensions to the library) should be
	 * derived from %Exception.
	 */
	class BLUE_EXPORT Exception
	{
	public:
		/** Constructor. */
		Exception( String desc = String::null );
		/** Copy constructor. */
		Exception( const Exception& copy );

		/** Virtual destructor. */
		virtual ~Exception();


		/**
		 * Returns the name of the exception.  This should be
		 * overloaded by deriving classes.
		 */
		virtual String getException() const;

		/** Returns the description of the exception. */
		virtual String getDescription() const;

		/**
		 * Returns a full description of the exception,
		 * including the name of the exception.
		 */
		virtual String toString() const;


	private:
		String m_desc;
	};

}}	// namespaces

// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
