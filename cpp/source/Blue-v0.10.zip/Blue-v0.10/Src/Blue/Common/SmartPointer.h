//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/SmartPointer.h
//**

#ifndef __blue_common_SmartPointer_h_included__
#define __blue_common_SmartPointer_h_included__

// Public Headers ==========================================================================================================

// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace common {


	/**
	 * \class Null
	 * \ingroup Common
	 * \brief Used by the smartpointer system to represent an invalid or empty value.
	 *
	 * \sa blue::common::null
	 */
	class BLUE_EXPORT Null
	{};

	const Null null;	//!< Used by the smartpointer system to represent an invalid or empty value.

	
	// internal.  please do not reference in code.
	struct smartpointer_refcnt
	{
		int m_ref;
		int m_weak;

		smartpointer_refcnt() :m_ref(0), m_weak(0) {}
	};


	/**
	 * \class SmartPointer
	 * \brief Template pointer class.
	 * \ingroup Common
	 *
	 * A %SmartPointer keeps a reference to an object until all instances of
	 * %SmartPointers referencing that object goes out of scope, when it then
	 * deletes the object.
	 *
	 * It is very important to know that once a %SmartPointer points to
	 * an object, that object will be deleted by the %SmartPointer when all
	 * references go out of scope.  It's also not a good idea to mix
	 * %SmartPointers and regular pointers in the same code.  It may cause
	 * confusion.
	 *
	 * \sa WeakPointer
	 */
	template<typename type_t> class SmartPointer
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		SmartPointer() :m_ref(0), m_inst(0)
		{}

		/** Constructor. */
		SmartPointer( type_t* inst ) :m_ref(0), m_inst(inst)
		{ refInc(); }

		/** Constructor. */
		template<typename other_t> SmartPointer( const SmartPointer<other_t>& ptr ) :m_ref(ptr.m_ref), m_inst(ptr.m_inst)
		{ refInc(); }

		/** Constructor. */
		SmartPointer( const Null& ) :m_ref(0), m_inst(0)
		{}

		/*  Constructor. */
		SmartPointer( smartpointer_refcnt* ref, type_t* inst ) :m_ref(ref), m_inst(inst)
		{ refInc(); }

		/** Copy constructor. */
		SmartPointer( const SmartPointer<type_t>& ptr ) :m_ref(ptr.m_ref), m_inst(ptr.m_inst)
		{ refInc(); }

		/** Destructor. */
		~SmartPointer()
		{ refDec(); }


		// ===========================================================
		//  assignment
		// ===========================================================

		/** Assignment operator.  Point to a base class. */
		template<typename other_t> SmartPointer<type_t>& operator=( const SmartPointer<other_t>& ptr )
		{
			refDec();
			m_ref  = ptr.m_ref;
			m_inst = ptr.m_inst;
			refInc();
			return (*this);
		}

		/** Assignment operator.  Point to another %SmartPointer. */
		SmartPointer<type_t>& operator=( const SmartPointer<type_t>& ptr )
		{
			refDec();
			m_ref  = ptr.m_ref;
			m_inst = ptr.m_inst;
			refInc();
			return (*this);
		}

		/** Assignment operator.  Point to a new object. */
		SmartPointer<type_t>& operator=( type_t* ptr )
		{
			refDec();
			m_ref  = 0;
			m_inst = ptr;
			refInc();
			return (*this);
		}

		/** Assignment operator.  Point to nothing. */
		SmartPointer<type_t>& operator=( const Null& )
		{
			refDec();
			return (*this);
		}


		// ===========================================================
		//  equality
		// ===========================================================

		/** Determine if the two pointers point to the same object. */
		bool operator==( const type_t* ptr ) const
		{ return (m_inst == ptr); }

		/** Determine if the two pointers point to the same object. */
		template<typename other_t> bool operator==( const SmartPointer<other_t>& ptr ) const
		{ return (m_ref == ptr.m_ref); }

		/** Determine if the two pointers point to the same object. */
		bool operator==( const SmartPointer<type_t>& ptr ) const
		{ return (m_ref == ptr.m_ref); }

		/** Determine if the pointer is null. */
		bool operator==( const Null& ) const
		{ return isNull(); }

		/** Determine if the two pointers do not point to the same object. */
		bool operator!=( const type_t* ptr ) const
		{ return (m_inst != ptr); }

		/** Determine if the two pointers do not point to the same object. */
		template<typename other_t> bool operator!=( const SmartPointer<other_t>& ptr ) const
		{ return (m_ref != ptr.m_ref); }

		/** Determine if the two pointers do not point to the same object. */
		bool operator!=( const SmartPointer<type_t>& ptr ) const
		{ return (m_ref != ptr.m_ref); }

		/** Determine if the pointer is not null. */
		bool operator!=( const Null& ) const
		{ return !isNull(); }


		/** Determine if the pointer is pointing to a valid object. */
		bool isNull() const
		{ return (m_ref == 0 || m_ref->m_ref == 0); }

		/** Determine if the pointer is pointing to a valid object. */
		operator bool() const
		{ return !isNull(); }


		// ===========================================================
		//  access
		// ===========================================================

		/** Access to the underlining object */
		type_t* operator->()
		{ return (m_inst); }

		/** Const access to the underlining object. */
		const type_t* operator->() const
		{ return (m_inst); }

		/** Access to the underlining object */
		type_t& operator*()
		{ return (*m_inst); }

		/** Const access to the underlining object. */
		const type_t& operator*() const
		{ return (*m_inst); }


		/** Access to the underlining object */
		type_t* getInst()
		{ return (m_inst); }

		/** Const access to the underlining object. */
		const type_t* getInst() const
		{ return (m_inst); }

		/** Access to the reference counting structure. */
		const smartpointer_refcnt* getRefCnt() const
		{ return (m_ref); }



	private:
		void refInc()
		{
			if( m_inst == 0 ) return;
			if( m_ref  == 0 ) m_ref = new smartpointer_refcnt();
			++m_ref->m_ref;
		}

		void refDec()
		{
			if( m_inst == 0 ) return;

			if( m_ref != 0 && --m_ref->m_ref == 0 ) {
				if( m_ref->m_weak == 0 ) {
					delete m_ref;
				}
				delete m_inst;
			}

			m_ref = 0;
			m_inst = 0;
		}


	public:	// pretend this is private!
		smartpointer_refcnt* m_ref;
		type_t*  m_inst;
	};



	/**
	 * \class WeakPointer
	 * \brief Template pointer class.
	 * \ingroup Common
	 *
	 * A %WeakPointer points to object, but does not allow access to the object,
	 * nor does it keep the object in scope.  What it does is work hand in hand
	 * with the SmartPointer class to allow whatever may need access to the
	 * object to know if the object has been deleted.
	 *
	 * The only way to access the object in a %WeakPointer to to change it into
	 * a SmartPointer.  This is done by the WeakPointer::reference function.
	 * If there is still a SmartPointer somewhere that has a reference to the
	 * object, it will be returned.  If all SmartPointers have lost scope and
	 * the object is gone, the WeakPointer::reference function will return
	 * null.
	 *
	 * By using a %WeakPointer, any neccessary circular links can be made without
	 * the normal problems associated with smart pointers.
	 */
	template<typename type_t> class WeakPointer
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		WeakPointer() :m_ref(0), m_inst(0)
		{}

		/** Constructor. */
		template<typename other_t> WeakPointer( const WeakPointer<other_t>& ptr ) :m_ref(ptr.m_ref), m_inst(ptr.m_inst)
		{ refInc(); }

		/** Constructor. */
		template<typename other_t> WeakPointer( const SmartPointer<other_t>& ptr ) :m_ref(ptr.m_ref), m_inst(ptr.m_inst)
		{ refInc(); }

		/** Constructor. */
		WeakPointer( const Null& ) :m_ref(0), m_inst(0)
		{}

		/** Constructor. */
		WeakPointer( const SmartPointer<type_t>& ptr ) :m_ref(ptr.m_ref), m_inst(ptr.m_inst)
		{ refInc(); }

		/** Copy constructor. */
		WeakPointer( const WeakPointer<type_t>& ptr ) :m_ref(ptr.m_ref), m_inst(ptr.m_inst)
		{ refInc(); }

		/** Destructor. */
		~WeakPointer()
		{ refDec(); }


		// ===========================================================
		//  assignment
		// ===========================================================

		/** Assignment operator.  Point to a base class. */
		template<typename other_t> WeakPointer<type_t>& operator=( const WeakPointer<other_t>& ptr )
		{
			refDec();
			m_ref  = ptr.m_ref;
			m_inst = ptr.m_inst;
			refInc();
			return (*this);
		}

		/** Assignment operator.  Point to another %WeakPointer. */
		WeakPointer<type_t>& operator=( const WeakPointer<type_t>& ptr )
		{
			refDec();
			m_ref  = ptr.m_ref;
			m_inst = ptr.m_inst;
			refInc();
			return (*this);
		}

		/** Assignment operator.  Point to a base class. */
		template<typename other_t> WeakPointer<type_t>& operator=( const SmartPointer<other_t>& ptr )
		{
			refDec();
			m_ref  = ptr.m_ref;
			m_inst = ptr.m_inst;
			refInc();
			return (*this);
		}

		/** Assignment operator.  Point to a SmartPointer. */
		WeakPointer<type_t>& operator=( const SmartPointer<type_t>& ptr )
		{
			refDec();
			m_ref  = ptr.m_ref;
			m_inst = ptr.m_inst;
			refInc();
			return (*this);
		}


		// ===========================================================
		//  equality
		// ===========================================================

		/** Determine if the two pointers point to the same object. */
		template<typename other_t> bool operator==( const WeakPointer<other_t>& ptr ) const
		{ return (m_ref == ptr.m_ref); }

		/** Determine if the two pointers point to the same object. */
		bool operator==( const WeakPointer<type_t>& ptr ) const
		{ return (m_ref == ptr.m_ref); }

		/** Determine if the two pointers point to the same object. */
		template<typename other_t> bool operator==( const SmartPointer<other_t>& ptr ) const
		{ return (m_ref == ptr.m_ref); }

		/** Determine if the two pointers point to the same object. */
		bool operator==( const SmartPointer<type_t>& ptr ) const
		{ return (m_ref == ptr.m_ref); }

		/** Determine if the pointer is null. */
		bool operator==( const Null& ) const
		{ return isNull(); }

		/** Determine if the two pointers do not point to the same object. */
		bool operator!=( const type_t* ptr ) const
		{ return (m_inst != ptr); }

		/** Determine if the two pointers do not point to the same object. */
		template<typename other_t> bool operator!=( const WeakPointer<other_t>& ptr ) const
		{ return (m_ref != ptr.m_ref); }

		/** Determine if the two pointers do not point to the same object. */
		bool operator!=( const WeakPointer<type_t>& ptr ) const
		{ return (m_ref != ptr.m_ref); }

		/** Determine if the two pointers do not point to the same object. */
		template<typename other_t> bool operator!=( const SmartPointer<other_t>& ptr ) const
		{ return (m_ref != ptr.m_ref); }

		/** Determine if the two pointers do not point to the same object. */
		bool operator!=( const SmartPointer<type_t>& ptr ) const
		{ return (m_ref != ptr.m_ref); }

		/** Determine if the pointer is not null. */
		bool operator!=( const Null& ) const
		{ return !isNull(); }


		/** Determine if the pointer is pointing to a valid object. */
		bool isNull() const
		{ return (m_ref == 0 || m_ref->m_ref == 0); }

		/** Determine if the pointer is pointing to a valid object. */
		operator bool() const
		{ return !isNull(); }


		// ===========================================================
		//  access
		// ===========================================================

		/** Return a SmartPointer to the object so that it can be operated on. */
		SmartPointer<type_t> reference()
		{
			if( !isNull() ) {
				return SmartPointer<type_t>(m_ref, m_inst);
			}
			else return (null);
		}


	private:
		void refInc()
		{
			if( m_inst == 0 ) return;
			++m_ref->m_weak;
		}

		void refDec()
		{
			if( m_inst == 0 ) return;

			if( m_ref != 0 && --m_ref->m_weak == 0 ) {
				if( m_ref->m_ref == 0 ) {
					delete m_ref;
				}
			}

			m_ref = 0;
			m_inst = 0;
		}


	public:	// pretend this is private!
		smartpointer_refcnt* m_ref;
		type_t*  m_inst;
	};



}}	// namespaces

// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
