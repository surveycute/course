//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/MemoryManager.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "MemoryManager.h"
#undef new

// system headers
#include <malloc.h>
#include <new>
#include <stdio.h>
#include <string.h>


// Private Defines/Enums/Typedefs/Etc ======================================================================================

#if defined(BLUE_DEBUG)
#	if !defined(BLUE_MEMTRACK_DISABLED)
#		define BLUE_MEMTRACK
#	endif
#endif

#if defined(BLUE_PLATFORM_WIN32)
#	define LF      "\r\n"
#	define SEPSTR  "\\"
#	define SEPCHR  '\\'
#else
#	define LF      "\n"
#	define SEPSTR  "/"
#	define SEPCHR  '/'
#endif


#define MEM_DUMPFILE     "blue.memdump.log"
#define MEM_DUMPFILE_EXT "blue.memdump.ext.log"


// Private Classes/Structs =================================================================================================

namespace blue {
namespace common {

#if !defined(BLUE_MEMTRACK)
	
	struct MemoryManager::internal
	{};

#else

	struct MemoryManager::internal
	{
		struct alloc
		{
			uint32_t    m_id;        
			size_t      m_size;
			const char* m_file;
			int         m_line;

			alloc* m_next;
			alloc* m_prev;
		};

		static alloc m_head;

		static uint32_t m_allocAmtTotal;
		static uint32_t m_allocAmtPeak;
		static uint32_t m_allocAmtCurrent;

		static uint32_t m_allocCntTotal;
		static uint32_t m_allocCntPeak;
		static uint32_t m_allocCntCurrent;

		static bool m_shuttingDown;


		internal();
		~internal();

		static void  dumpMemoryInfo();
		static char* formatNumber( uint32_t num, char* buffer );

		static MemoryManager::internal m_internal;
	};


	MemoryManager::internal::alloc MemoryManager::internal::m_head = {0,0,0,0,0,0};

	uint32_t MemoryManager::internal::m_allocAmtTotal   = 0;
	uint32_t MemoryManager::internal::m_allocAmtPeak    = 0;
	uint32_t MemoryManager::internal::m_allocAmtCurrent = 0;

	uint32_t MemoryManager::internal::m_allocCntTotal   = 0;
	uint32_t MemoryManager::internal::m_allocCntPeak    = 0;
	uint32_t MemoryManager::internal::m_allocCntCurrent = 0;

	bool     MemoryManager::internal::m_shuttingDown    = false;

	MemoryManager::internal MemoryManager::internal::m_internal;


#endif // memtrack

}}	// namespaces


// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

namespace blue {
namespace common {

#if defined(BLUE_MEMTRACK)

	// ---------------------------------------------------------------------------------------------------------------------

	MemoryManager::internal::internal()
	{
	#if defined(BLUE_MEMTRACK_EXTENSIVE)
		if( FILE* fp = fopen(MEM_DUMPFILE_EXT, "wb") ) {
			fprintf( fp, "Type    Alloc ID     Alloc Addr     Alloc Size                      Alloc File/Line"LF );
			fprintf( fp, "----  ----------     ----------     ----------     --------------------------------"LF );
			fclose(fp);
		}
	#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	MemoryManager::internal::~internal()
	{
		m_shuttingDown = true;
		dumpMemoryInfo();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	// static
	void MemoryManager::internal::dumpMemoryInfo()
	{
		if( FILE* fp = fopen(MEM_DUMPFILE, "wb") ) {
			char buffer[64];

			fprintf( fp, "-----------------------------------------------------------------------------"LF );
			fprintf( fp, "                             Blue Memory Report                              "LF );
			fprintf( fp, "-----------------------------------------------------------------------------"LF );
			fprintf( fp, LF LF );

			fprintf( fp, "-----------------------------------------------------------------------------"LF );
			fprintf( fp, "  Totals                                                                     "LF );
			fprintf( fp, "-----------------------------------------------------------------------------"LF );
			fprintf( fp, "       Allocation Count: %15s"LF, formatNumber(m_allocCntTotal, buffer) );
			fprintf( fp, "      Allocation Amount: %15s bytes ", formatNumber(m_allocAmtTotal, buffer) );
			fprintf( fp, "(%s K)"LF, formatNumber(m_allocAmtTotal / 1024, buffer) );
			fprintf( fp, LF LF );

			fprintf( fp, "-----------------------------------------------------------------------------"LF );
			fprintf( fp, "  Peaks                                                                      "LF );
			fprintf( fp, "-----------------------------------------------------------------------------"LF );
			fprintf( fp, "       Allocation Count: %15s"LF, formatNumber(m_allocCntPeak, buffer) );
			fprintf( fp, "      Allocation Amount: %15s bytes ", formatNumber(m_allocAmtPeak, buffer) );
			fprintf( fp, "(%s K)"LF, formatNumber(m_allocAmtPeak / 1024, buffer) );
			fprintf( fp, LF LF );

			fprintf( fp, "-----------------------------------------------------------------------------"LF );
			fprintf( fp, "  Memory Leaks                                                               "LF );
			fprintf( fp, "-----------------------------------------------------------------------------"LF );

			if( m_allocCntCurrent <= 0 ) {
				fprintf( fp, "      No leaks detected!"LF );
			}
			else {
				uint32_t leakSize = 0;

				fprintf( fp, "                  Leaks:   %s"LF, formatNumber(m_allocCntCurrent, buffer) );
				fprintf( fp, LF LF );

				fprintf( fp, "  Alloc ID     Alloc Addr     Alloc Size                      Alloc File/Line"LF );
				fprintf( fp, "----------     ----------     ----------     --------------------------------"LF );

				alloc* cur = m_head.m_next;
				while( cur != 0 ) {
					leakSize += cur->m_size;

					fprintf( fp, "%10u     0x%08x     %10u     %25s (%4d)"LF,
									cur->m_id,
									cur + 1,
									cur->m_size,
									strrchr( cur->m_file, SEPCHR ) + 1,
									cur->m_line );

					cur = cur->m_next;
				}

				fprintf( fp, LF );
				fprintf( fp, "        Total Leak Size: %15s bytes ", formatNumber(leakSize, buffer) );
				fprintf( fp, "(%s K)"LF, formatNumber(leakSize / 1024, buffer) );
			}

			fclose(fp);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	// static
	char* MemoryManager::internal::formatNumber( uint32_t num, char* buffer )
	{
		int bil = num / 1000000000;
		int mil = (num - (bil * 1000000000)) / 1000000;
		int tho = (num - (bil * 1000000000) - (mil * 1000000)) / 1000;
		int hun = (num - (bil * 1000000000) - (mil * 1000000) - (tho * 1000));

		if( bil > 0 ) sprintf(buffer, "%d,%03d,%03d,%03d", bil, mil, tho, hun); else
		if( mil > 0 ) sprintf(buffer, "%d,%03d,%03d", mil, tho, hun); else
		if( tho > 0 ) sprintf(buffer, "%d,%03d", tho, hun); else
		              sprintf(buffer, "%d", hun);

		return (buffer);
	}

#endif	// memtrack

}}	// namespaces


// Functions ===============================================================================================================

namespace blue {
namespace common {

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	void* MemoryManager::malloc( size_t size )
	{
		return malloc(size, SEPSTR"[untracked]", 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	void* MemoryManager::malloc( size_t size, const char* file, int line )
	{
	#if !defined(BLUE_MEMTRACK)

		if( void* alloc = ::malloc(size) ) {
			return (alloc);
		}

		throw std::bad_alloc();

	#else

		if( internal::alloc* alloc = (internal::alloc*) ::malloc( sizeof(internal::alloc) + size ) ) {
			alloc->m_id   = internal::m_allocCntTotal++;
			alloc->m_size = size;
			alloc->m_file = file;
			alloc->m_line = line;
			alloc->m_next = 0;
			alloc->m_prev = 0;

			if( internal::m_allocCntPeak < ++internal::m_allocCntCurrent ) {
				internal::m_allocCntPeak = internal::m_allocCntCurrent;
			}

			internal::m_allocAmtTotal   += size;
			internal::m_allocAmtCurrent += size;
			if( internal::m_allocAmtPeak < internal::m_allocAmtCurrent ) {
				internal::m_allocAmtPeak = internal::m_allocAmtCurrent;
			}

			if( internal::m_head.m_next != 0 ) {
				alloc->m_next = internal::m_head.m_next;
				alloc->m_next->m_prev = alloc;
			}

			alloc->m_prev = &internal::m_head;
			internal::m_head.m_next = alloc;

			#if defined(BLUE_MEMTRACK_EXTENSIVE)
			if( FILE* fp = fopen(MEM_DUMPFILE_EXT, "ab+") ) {
				fprintf( fp, "[A]   %10u     0x%08x     %10d     %25s (%4d)"LF, 
								alloc->m_id,
								alloc + 1,
								alloc->m_size,
								strrchr( alloc->m_file, SEPCHR ) + 1,
								alloc->m_line );
				fclose(fp);
			}
			#endif

			return (alloc + 1);
		}

		throw std::bad_alloc();

	#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	void MemoryManager::free( void* mem )
	{
	#if !defined(BLUE_MEMTRACK)

		::free(mem);

	#else

		internal::alloc* alloc = ((internal::alloc*)(mem)) - 1;

		if( alloc->m_prev ) { alloc->m_prev->m_next = alloc->m_next; }
		if( alloc->m_next ) { alloc->m_next->m_prev = alloc->m_prev; }

		internal::m_allocAmtCurrent -= alloc->m_size;
		internal::m_allocCntCurrent -= 1;

		#if defined(BLUE_MEMTRACK_EXTENSIVE)
		if( FILE* fp = fopen(MEM_DUMPFILE_EXT, "ab+") ) {
			fprintf( fp, "[D]   %10u     0x%08x     %10d     %25s (%4d)"LF, 
							alloc->m_id,
							alloc + 1,
							alloc->m_size,
							strrchr( alloc->m_file, SEPCHR ) + 1,
							alloc->m_line );
			fclose(fp);
		}
		#endif

		if( internal::m_shuttingDown ) {
			// shutting down, make sure all after-exit deallocs aren't recorded as leaks
			internal::dumpMemoryInfo();
		}

		::free(alloc);

	#endif
	}


}}	// namespaces
