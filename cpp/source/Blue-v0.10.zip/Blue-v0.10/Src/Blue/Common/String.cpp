//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/String.cpp
//**

// Private Headers =========================================================================================================

#if defined(BLUE_DLL) || defined(BLUE_LIB)
#	include "Blue/Blue.h"
#else
	// matching header
#	include "String.h"
#endif


// system headers
#include <string.h> // for strlen, strcpy, strncpy and strstr
#include <stdio.h>  // for sprintf
#include <ctype.h>  // for isspace
#include <stdlib.h> // for toupper, tolower, strtol, strtod
#include <stdarg.h> // for va_args

#if defined(_MSC_VER)
#define strnicmp  _strnicmp
#define vsnprintf _vsnprintf
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

namespace blue {
namespace common {

	const String String::null;

}}	// namespaces

// Private Functions =======================================================================================================

namespace {

	using namespace blue;
	using namespace blue::common;

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline int priv_findPos( const char* src, int srcLen, const char* sch, int schLen, int start, cmpfunc_t cmpfunc )
	{
		if( srcLen == 0 || schLen == 0 || start > srcLen - 1) {
			return (String::npos);
		}

		start = (start < 0 ? 0 : start);

		for( int i = start; i < srcLen - (schLen-1); ++i ) {
			if( cmpfunc(src + i, sch, schLen) == 0 ) {
				return (i);
			}
		}

		return (String::npos);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline int priv_findPosR( const char* src, int srcLen, const char* sch, int schLen, int start, cmpfunc_t cmpfunc )
	{
		if( srcLen == 0 || schLen == 0 ) {
			return (String::npos);
		}

		if( start == String::npos ) {
			start = srcLen;
		}
		else {
			start = (start < 0 ? 0 : start > srcLen ? srcLen : start);
		}

		const char* pos = (src + start) - schLen;

		while( pos >= src ) {
			if( cmpfunc(pos, sch, schLen) == 0 ) {
				return (pos - src);
			}
			--pos;
		}

		return (String::npos);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline int priv_count( const char* src, int srcLen, const char* sch, int schLen, cmpfunc_t cmpfunc )
	{
		if( schLen == 0 ) {
			return (0);
		}

		int pos = 0;
		int cnt = 0;

		while( (pos = priv_findPos(src, srcLen, sch, schLen, pos, cmpfunc)) != String::npos ) {
			++cnt;
			pos += schLen;
		}

		return (cnt);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline bool priv_equals( const char* src, int srcLen, const char* tst, int tstLen, cmpfunc_t cmpfunc )
	{
		if( srcLen != tstLen ) {
			return (false);
		}

		if( src == tst ) {
			return (true);
		}

		return (cmpfunc(src, tst, tstLen) == 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	inline bool priv_cmpchar ( char one, char two ) { return one == two; }
	inline bool priv_cmpichar( char one, char two ) { return toupper(one) == toupper(two); }

	template<typename cmpfunc_t>
	inline bool priv_equalsWildCard( const char* src, int srcLen, const char* tst, int tstLen, cmpfunc_t cmpfunc )
	{
		if( srcLen == 0 || tstLen == 0 ) {
			return (false);
		}

		const char* srcEnd = src + srcLen;
		const char* tstEnd = tst + tstLen;
		const char* mp = 0;
		const char* cp = 0;

		while( (src < srcEnd) && (*tst != '*') ) {
			if( !cmpfunc( *src, *tst ) && (*tst != '?') ) {
				return (false);
			}
			++src;
			++tst;
		}

		while( src < srcEnd ) {
			if( *tst == '*' ) {
				if( ++tst >= tstEnd ) {
					return (true);
				}

				mp = tst;
				cp = src + 1;
			}
			else if( cmpfunc(*src, *tst) || (*tst == '?') ) {
				++src;
				++tst;
			}
			else {
				tst = mp;
				src = cp++;
			}
		}

		while( *tst == '*' ) {
			++tst;
		}

		return (tst == tstEnd);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline bool priv_beginsWith( const char* src, int srcLen, const char* tst, int tstLen, cmpfunc_t cmpfunc )
	{
		if( srcLen == 0 || tstLen == 0 || tstLen > srcLen ) {
			return (tstLen == 0 ? true : false);
		}

		return (cmpfunc(src, tst, tstLen) == 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline bool priv_endsWith( const char* src, int srcLen, const char* tst, int tstLen, cmpfunc_t cmpfunc )
	{
		if( srcLen == 0 || tstLen == 0 || tstLen > srcLen ) {
			return (tstLen == 0 ? true : false);
		}

		return (cmpfunc(src + (srcLen - tstLen), tst, tstLen) == 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline int priv_compare( const char* src, int srcLen, const char* tst, int tstLen, cmpfunc_t cmpfunc )
	{
		int minLen = (srcLen < tstLen ? srcLen : tstLen);

		int cmp = cmpfunc(src, tst, minLen);
		if( cmp != 0 ) {
			return (cmp);
		}

		if( srcLen < tstLen ) {
			return (-1);
		}
		if( tstLen < srcLen ) {
			return (1);
		}

		return (0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	inline char* priv_insert( const char* src, int srcLen, const char* ins, int insLen, int before )
	{
		int len = srcLen + insLen;
		char* ptr = new char[len + 1];

		int i, cur = 0;
		for( i = 0; i < before; ++i ) {
			ptr[i] = src[cur++];
		}

		for( i = cur; i < cur + (len - srcLen); ++i ) {
			ptr[i] = ins[i - cur];
		}

		for( i = cur + (len - srcLen); i < len; ++i ) {
			ptr[i] = src[cur++];
		}

		ptr[len] = 0;

		return (ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline char* priv_removeAll( const char* src, int srcLen, const char* rem, int remLen, cmpfunc_t cmpfunc )
	{
		if( srcLen == 0 || remLen == 0 ) {
			return (0);
		}

		int count = priv_count(src, srcLen, rem, remLen, cmpfunc);
		if( count <= 0 ) {
			char* ptr = new char[srcLen + 1];
			strncpy(ptr, src, srcLen);
			ptr[srcLen] = 0;
			return (ptr);
		}

		int lenremTot = count * remLen;
		int lenNew = srcLen - lenremTot;

		char* ptr = new char[lenNew + 1];

		int cur = 0;
		int lst = 0, pos = 0;
		while( (pos = priv_findPos(src, srcLen, rem, remLen, pos, cmpfunc)) != String::npos ) {
			for( int i = lst; i < pos; ++i ) {
				ptr[cur++] = src[i];
			}
			lst = pos + remLen;
			pos = lst;
		}
		if( cur != lenNew ) {
			for( int i = lst; i < srcLen; ++i ) {
				ptr[cur++] = src[i];
			}
		}

		ptr[lenNew] = 0;
		return (ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	template<typename cmpfunc_t>
	inline char* priv_replaceAll( const char* src, int srcLen, const char* rep, int repLen, const char* with, int withLen, cmpfunc_t cmpfunc )
	{
		if( srcLen == 0 || repLen == 0 ) {
			return (0);
		}

		int count = priv_count(src, srcLen, rep, repLen, cmpfunc);
		if( count <= 0 ) {
			char* ptr = new char[srcLen + 1];
			strncpy(ptr, src, srcLen);
			ptr[srcLen] = 0;
			return (ptr);
		}

		int lenNew = (srcLen - (repLen * count)) + (withLen * count);

		char* ptr = new char[lenNew + 1];

		int cur = 0;
		int lst = 0, pos = 0;
		while( (pos = priv_findPos(src, srcLen, rep, repLen, pos, cmpfunc)) != String::npos ) {
			for( int i = lst; i < pos; ++i ) {
				ptr[cur++] = src[i];
			}
			for( int j = 0; j < withLen; ++j ) {
				ptr[cur++] = with[j];
			}

			lst = pos + repLen;
			pos = lst;
		}
		if( cur != lenNew ) {
			for( int i = lst; i < srcLen; ++i ) {
				ptr[cur++] = src[i];
			}
		}

		ptr[lenNew] = 0;
		return (ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	inline String priv_arg( const String& src, const char* arg, int argLen )
	{
		int pos = src.findPos("{");
		if( pos == String::npos ) {
			return (src + arg);
		}

		int lowest = 2000000000;
		while( pos != String::npos ) {
			if( src.subString(pos, 2) != "{{" ) {
				int end = src.findPos("}", pos);
				if( end != String::npos ) {
					String sub = src.subString(pos + 1, end-(pos + 1));
					if( sub.isValidInt() ) {
						int subInt = sub.getAsInt();
						if( subInt > 0 && subInt < lowest ) {
							lowest = subInt;
						}
					}
					pos = end;
				}
			}
			else {
				pos += 2;
			}
			pos = src.findPos("{", pos);
		}

		return src.replaceAll("{" + String(lowest) + "}", String(arg, argLen, String::STATIC));
	}

}	// namespace

// Functions ===============================================================================================================

namespace blue {
namespace common {

	// ---------------------------------------------------------------------------------------------------------------------

	String::String()
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( const String& copy )
		:m_refCnt(copy.m_refCnt), m_refBuf(copy.m_refBuf), m_refLen(copy.m_refLen), m_start(copy.m_start), m_len(copy.m_len)
	{
		refInc();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( const char* str, create_e create )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		if( create == NORMAL ) {
			refCreate( strlen(str) );
			if( m_refBuf != 0 ) {
				strcpy(m_refBuf, str);
			}
		}
		else if( create == STATIC ) {
			m_start = str;
			m_len = strlen(str);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( const char* str, int len, create_e create )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		if( create == NORMAL ) {
			refCreate( len );
			if( m_refBuf != 0 ) {
				strncpy(m_refBuf, str, len);
			}
		}
		else if( create == STATIC ) {
			m_start = str;
			m_len = len;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( char ch )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		refCreate(1);
		if( m_refBuf != 0 ) {
			m_refBuf[0] = ch;
			m_refBuf[1] = 0;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( int num )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		char buffer[13];  // 12 == strlen("-2147483648")
		sprintf(buffer, "%d", num);
		refCreate(buffer, false);  
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( float num )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		char buffer[16];  // 15 == strlen("-d.dddddd e-ddd")
		sprintf(buffer, "%.6e", num);
		refCreate(buffer, false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( double num )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		char buffer[16];  // 15 == strlen("-d.dddddd e-ddd")
		sprintf(buffer, "%.6e", num);
		refCreate(buffer, false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( unsigned int num )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		char buffer[12];  // 11 == strlen("4294967296")
		sprintf(buffer, "%u", num);
		refCreate(buffer, false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::String( bool own, char* str )
		:m_refCnt(0), m_refBuf(0), m_refLen(0), m_start(0), m_len(0)
	{
		refCreate(str, own);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String::~String()
	{
		refDec();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPos( const char* search, int start ) const
	{
		return priv_findPos(m_start, m_len, search, strlen(search), start, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPos( const String& search, int start ) const
	{
		return priv_findPos(m_start, m_len, search.m_start, search.m_len, start, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPosIgnoreCase( const char* search, int start ) const
	{
		return priv_findPos(m_start, m_len, search, strlen(search), start, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPosIgnoreCase( const String& search, int start ) const
	{
		return priv_findPos(m_start, m_len, search.m_start, search.m_len, start, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPosR( const char* search, int start ) const
	{
		return priv_findPosR(m_start, m_len, search, strlen(search), start, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPosR( const String& search, int start ) const
	{
		return priv_findPosR(m_start, m_len, search.m_start, search.m_len, start, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPosRIgnoreCase( const char* search, int start ) const
	{
		return priv_findPosR(m_start, m_len, search, strlen(search), start, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::findPosRIgnoreCase( const String& search, int start ) const
	{
		return priv_findPosR(m_start, m_len, search.m_start, search.m_len, start, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::count( const char* search ) const
	{
		return priv_count(m_start, m_len, search, strlen(search), strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::count( const String& search ) const
	{
		return priv_count(m_start, m_len, search.m_start, search.m_len, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::countIgnoreCase( const char* search ) const
	{
		return priv_count(m_start, m_len, search, strlen(search), strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::countIgnoreCase( const String& search ) const
	{
		return priv_count(m_start, m_len, search.m_start, search.m_len, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::getLength() const
	{
		return (m_len);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equals( const char* str ) const
	{
		return priv_equals(m_start, m_len, str, strlen(str), strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equals( const String& str ) const
	{
		return priv_equals(m_start, m_len, str.m_start, str.m_len, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equalsIgnoreCase( const char* str ) const
	{
		return priv_equals(m_start, m_len, str, strlen(str), strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equalsIgnoreCase( const String& str ) const
	{
		return priv_equals(m_start, m_len, str.m_start, str.m_len, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equalsWildCard( const char* str ) const
	{
		return priv_equalsWildCard(m_start, m_len, str, strlen(str), priv_cmpchar);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equalsWildCard( const String& str ) const
	{
		return priv_equalsWildCard(m_start, m_len, str.m_start, str.m_len, priv_cmpchar);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equalsWildCardIgnoreCase( const char* str ) const
	{
		return priv_equalsWildCard(m_start, m_len, str, strlen(str), priv_cmpichar);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::equalsWildCardIgnoreCase( const String& str ) const
	{
		return priv_equalsWildCard(m_start, m_len, str.m_start, str.m_len, priv_cmpichar);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::beginsWith( const char* str ) const
	{
		return priv_beginsWith(m_start, m_len, str, strlen(str), strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::beginsWith( const String& str ) const
	{
		return priv_beginsWith(m_start, m_len, str.m_start, str.m_len, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::beginsWithIgnoreCase( const char* str ) const
	{
		return priv_beginsWith(m_start, m_len, str, strlen(str), strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::beginsWithIgnoreCase( const String& str ) const
	{
		return priv_beginsWith(m_start, m_len, str.m_start, str.m_len, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::endsWith( const char* str ) const
	{
		return priv_endsWith(m_start, m_len, str, strlen(str), strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::endsWith( const String& str ) const
	{
		return priv_endsWith(m_start, m_len, str.m_start, str.m_len, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::endsWithIgnoreCase( const char* str ) const
	{
		return priv_endsWith(m_start, m_len, str, strlen(str), strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::endsWithIgnoreCase( const String& str ) const
	{
		return priv_endsWith(m_start, m_len, str.m_start, str.m_len, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::compare( const char* str ) const
	{
		return priv_compare(m_start, m_len, str, strlen(str), strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::compare( const String& str ) const
	{
		return priv_compare(m_start, m_len, str.m_start, str.m_len, strncmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::compareIgnoreCase( const char* str ) const
	{
		return priv_compare(m_start, m_len, str, strlen(str), strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::compareIgnoreCase( const String& str ) const
	{
		return priv_compare(m_start, m_len, str.m_start, str.m_len, strnicmp);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::isEmpty() const
	{
		return (m_refCnt == 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::insert( const char* str, int before ) const
	{
		return String(true, priv_insert(m_start, m_len, str, strlen(str), before));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::insert( const String& str, int before ) const
	{
		return String(true, priv_insert(m_start, m_len, str.m_start, str.m_len, before));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::remove( int start, int chars ) const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		start = (start < 0 ? 0 : start > m_len - 1 ? m_len - 1 : start);
		chars = (chars < 0 ? 0 : chars > m_len - start ? m_len - start : chars);

		if( chars == 0 ) {
			return (*this);
		}

		char* ptr = new char[(m_len - chars) + 1];

		int i, cur = 0;
		for( i = 0; i < start; ++i ) {
			ptr[cur++] = m_start[i];
		}

		for( i = (start + chars); i < m_len; ++i ) {
			ptr[cur++] = m_start[i];
		}

		ptr[m_len - chars] = 0;

		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::removeAll( const char* str ) const
	{
		return String(true, priv_removeAll(m_start, m_len, str, strlen(str), strncmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::removeAll( const String& str ) const
	{
		return String(true, priv_removeAll(m_start, m_len, str.m_start, str.m_len, strncmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::removeAllIgnoreCase( const char* str ) const
	{
		return String(true, priv_removeAll(m_start, m_len, str, strlen(str), strnicmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::removeAllIgnoreCase( const String& str ) const
	{
		return String(true, priv_removeAll(m_start, m_len, str.m_start, str.m_len, strnicmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::replaceAll( const char* str, const char* with ) const
	{
		return String(true, priv_replaceAll(m_start, m_len, str, strlen(str), with, strlen(with), strncmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::replaceAll( const String& str, const String& with ) const
	{
		return String(true, priv_replaceAll(m_start, m_len, str.m_start, str.m_len, with.m_start, with.m_len, strncmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::replaceAllIgnoreCase( const char* str, const char* with ) const
	{
		return String(true, priv_replaceAll(m_start, m_len, str, strlen(str), with, strlen(with), strnicmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::replaceAllIgnoreCase( const String& str, const String& with ) const
	{
		return String(true, priv_replaceAll(m_start, m_len, str.m_start, str.m_len, with.m_start, with.m_len, strnicmp));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	String String::format( const char* str, ... )
	{
		char buffer[512];
		va_list args;
		va_start(args, str);
		vsnprintf(buffer, sizeof(buffer) - 1, str, args);	// no buffer overflows allowed!
		va_end(args);
		return String(false, buffer);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	String String::format( const String& str, ... )
	{
		char buffer[512];
		va_list args;
		String fmt = str.makeUnique();
		const char* fmtPtr = fmt.getAsCStr();
		va_start(args, fmtPtr);
		vsnprintf(buffer, sizeof(buffer) - 1, fmt.getAsCStr(), args);	// no buffer overflows allowed!
		va_end(args);
		return String(false, buffer);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	String String::format( int maxSize, const char* str, ... )
	{
		char* buffer = new char[maxSize + 1];
		memset(buffer, 0, maxSize + 1);
		va_list args;
		va_start(args, str);
		vsnprintf( buffer, maxSize, str, args );	// no buffer overflows allowed!
		va_end(args);
		String ret(false, buffer);
		delete [] buffer;

		return (ret);		
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	String String::format( int maxSize, const String& str, ... )
	{
		char* buffer = new char[maxSize + 1];
		memset(buffer, 0, maxSize + 1);
		va_list args;
		String fmt = str.makeUnique();
		const char* fmtPtr = fmt.getAsCStr();
		va_start(args, fmtPtr);
		vsnprintf( buffer, maxSize, fmtPtr, args );	// no buffer overflows allowed!
		va_end(args);
		String ret(false, buffer);
		delete [] buffer;

		return (ret);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	String String::fill( int len, char ch )
	{
		if( len <= 0 ) {
			return (String::null);
		}

		char* ptr = new char[len + 1];
		for( int i = 0; i < len; ++i ) {
			ptr[i] = ch;
		}
		ptr[len] = 0;

		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::trim() const
	{
		return trimLeft().trimRight();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::trimLeft() const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		const char* start = m_start;
		if( start != 0 ) {
			while( isspace(*start) && (start - m_start) < m_len ) {
				++start;
			}

			String copy(*this);

			int dif = start - m_start;
			copy.m_start = start;
			copy.m_len   = m_len - dif;
			return (copy);
		}
		return (String::null);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::trimRight() const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		const char* start = m_start;
		if( start != 0 ) {
			start += m_len - 1;
			int len = m_len;
			while( isspace(*start) && (start - m_start) >= 0 ) {
				--start;
				--len;
			}

			String copy(*this);
			copy.m_len = len;
			return (copy);
		}
		return (String::null);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::padLeft( int len, char ch ) const
	{
		int dif = len - m_len;
		if( dif <= 0 ) {
			return (*this);
		}

		String filled = fill(dif, ch);
		return (filled + *this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::padRight( int len, char ch ) const
	{
		int dif = len - m_len;
		if( dif <= 0 ) {
			return (*this);
		}

		String filled = fill(dif, ch);
		return (*this + filled);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::arg( const char* arg ) const
	{
		return priv_arg(*this, arg, strlen(arg));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::arg( String arg ) const
	{
		return priv_arg(*this, arg.m_start, arg.m_len);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::makeUnique() const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		char* ptr = new char[m_len + 1];
		strncpy(ptr, m_start, m_len);
		ptr[m_len] = 0;

		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::left( int chars ) const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		chars = (chars < 0 ? 0 : chars > m_len ? m_len : chars);
		if( chars == 0 ) {
			return (String::null);
		}

		String copy(*this);
		copy.m_len = chars;
		return (copy);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::right( int chars ) const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		chars = (chars < 0 ? 0 : chars > m_len ? m_len : chars);
		if( chars == 0 ) {
			return (String::null);
		}

		String copy(*this);
		copy.m_start += m_len - chars;
		copy.m_len = chars;
		return (copy);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::subString( int start, int chars ) const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		start = (start < 0 ? 0 : start > m_len ? m_len : start);

		if( chars == npos ) {
			chars = m_len - start;
		}
		else {
			chars = (chars < 0 ? 0 : chars > (m_len - start) ? (m_len - start) : chars);
		}

		if( chars == 0 ) {
			return (String::null);
		}

		String copy(*this);
		copy.m_start += start;
		copy.m_len = chars;
		return (copy);
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	String String::stripFromLeft( int characters ) const
	{
		return subString(characters);
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	String String::stripFromRight( int characters ) const
	{
		return left(getLength() - characters);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::reverse() const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		char* ptr = new char[m_len + 1];
		for( int i = 0; i < m_len; ++i ) {
			ptr[ (m_len - i) - 1 ] = m_start[i];
		}
		ptr[m_len] = 0;
		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::toUpper() const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		char* ptr = new char[m_len + 1];
		for( int i = 0; i < m_len; ++i ) {
			ptr[i] = toupper(m_start[i]);
		}
		ptr[m_len] = 0;

		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::toLower() const
	{
		if( m_len == 0 ) {
			return (String::null);
		}

		char* ptr = new char[m_len + 1];
		for( int i = 0; i < m_len; ++i ) {
			ptr[i] = tolower(m_start[i]);
		}
		ptr[m_len] = 0;

		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::isValidInt( int base ) const
	{
		if( m_len == 0 ) {
			return (false);
		}

		char buf[129];
		int len = (sizeof(buf) < m_len ? sizeof(buf) : m_len);
		strncpy(buf, m_start, len);
		buf[len] = '\0';
		char* end;
		strtol(buf, &end, base);
		if( end != buf + m_len ) {
			return (false);
		}

		return (true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::isValidFloat() const
	{
		return isValidDouble();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool String::isValidDouble() const
	{
		if( m_len == 0 ) {
			return (false);
		}

		char buf[129];
		int len = (sizeof(buf) < m_len ? sizeof(buf) : m_len);
		strncpy(buf, m_start, len);
		buf[len] = '\0';
		char* end;
		strtod(buf, &end);
		if( end != buf + m_len ) {
			return (false);
		}

		return (true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int String::getAsInt( int base ) const
	{
		if( m_start != 0 ) {
			char buf[129];
			int len = (sizeof(buf) < m_len ? sizeof(buf) : m_len);
			strncpy(buf, m_start, len);
			buf[len] = '\0';
			char* dummy;
			return strtol(buf, &dummy, base);
		}
		return (0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	float String::getAsFloat() const
	{
		if( m_start != 0 ) {
			char buf[129];
			int len = (sizeof(buf) < m_len ? sizeof(buf) : m_len);
			strncpy(buf, m_start, len);
			buf[len] = '\0';
			char* dummy;
			return static_cast<float>( strtod(buf, &dummy) );
		}
		return (0.0f);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	double String::getAsDouble() const
	{
		if( m_start != 0 ) {
			char buf[129];
			int len = (sizeof(buf) < m_len ? sizeof(buf) : m_len);
			strncpy(buf, m_start, len);
			buf[len] = '\0';
			char* dummy;
			return strtod(buf, &dummy);
		}
		return (0.0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	const char* String::getAsCStr() const
	{
		return (m_start);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	const char& String::operator[]( int index ) const
	{
		return (m_start[index]);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String& String::operator=( const char* str )
	{
		refDec();
		refCreate(str, false);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String& String::operator=( const String& str )
	{
		refDec();
		refCreate(str);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::operator+( const char* str )
	{
		if( m_len == 0 ) {
			return String(str);
		}

		int strLen = strlen(str);
		int newLen = m_len + strLen;
		char* ptr = new char[newLen + 1];

		strncpy(ptr, m_start, m_len);
		strncpy(ptr + m_len, str, strLen);
		ptr[newLen] = 0;

		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String String::operator+( const String& str )
	{
		if( m_len == 0 ) {
			return (str);
		}

		int strLen = str.m_len;
		int newLen = m_len + strLen;
		char* ptr = new char[newLen + 1];

		strncpy(ptr, m_start, m_len);
		strncpy(ptr + m_len, str.m_start, strLen);
		ptr[newLen] = 0;

		return String(true, ptr);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String& String::operator+=( const char* str )
	{
		*this = *this + str;
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String& String::operator+=( const String& str )
	{
		*this = *this + str;
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void String::refInc()
	{
		if( m_refCnt != 0 ) {
			++*m_refCnt;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void String::refDec()
	{
		if( m_refCnt != 0 ) {
			if( --*m_refCnt == 0 ) {
				delete m_refCnt;
				delete m_refLen;
				delete [] m_refBuf;
			}
		}

		m_refCnt = 0;
		m_refBuf = 0;
		m_refLen = 0;
		m_start  = 0;
		m_len    = 0;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void String::refCreate( int len )
	{
		if( m_refCnt != 0 ) {
			refDec();
		}
		if( len <= 0 ) {
			return;
		}

		m_refCnt = new int;
		m_refBuf = new char[len + 1];
		m_refLen = new int;

		*m_refCnt = 1;
		*m_refLen = len;

		m_start  = m_refBuf;
		m_len    = len;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void String::refCreate( const String& str )
	{
		m_refBuf = str.m_refBuf;
		m_refCnt = str.m_refCnt;
		m_refLen = str.m_refLen;
		m_start  = str.m_start;
		m_len    = str.m_len;
		refInc();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void String::refCreate( const char* str, bool own )
	{
		int len;
		if( str == 0 || (len = strlen(str)) == 0 ) {
			return;
		}

		if( own ) {
			m_refBuf = (char*)str;
			m_refCnt = new int;
			m_refLen = new int;

			*m_refCnt = 1;
			*m_refLen = strlen(str);

			m_start = m_refBuf;
			m_len   = *m_refLen;
		}
		else {
			refCreate(strlen(str));
			if( m_refBuf ) {
				strcpy(m_refBuf, str);
			}
		}
	}


}}	// namespaces
