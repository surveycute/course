//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/MemoryManager.h
//**

#ifndef __blue_common_MemoryManager_h_included__
#define __blue_common_MemoryManager_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace common {

	/**
	 * \class MemoryManager
	 * \brief Memory management.
	 * \ingroup Common
	 *
	 * The memory manager is great debugging aid.  It keeps track of all
	 * allocations and deallocations and  writes a file at the end of the
	 * applications execution that contains information on how much memory
	 * was dynamically allocated as well as any memory leaks.
	 *
	 * It is also capable of logging every allocation made by the library
	 * and application and will report the file and line where the allocation
	 * was made.  This functionality is turned off by default and must be
	 * enabled by defining <code> BLUE_MEMTRACK_EXTENSIVE</code> before
	 * compiling the Blue library.  Note that this feature will greatly slow
	 * down the execution of the application as every allocation and 
	 * deallocation will be doing file io.
	 *
	 * The memory tracking is turned on by default in debug builds and turned
	 * off by default in release builds.  This behavior can be changed by
	 * defining <code>BLUE_MEMTRACK_DISABLED</code> in debug builds and by
	 * defining <code>BLUE_MEMTRACK</code> in release builds.
	 *
	 * The files that the memory manager write are located wherever the current
	 * directory happens to be and are named:
	 * <pre>
	 * blue.memtrack.log     - This is the standard log.
	 * blue.memtrack.ext.log - This is the extensive, detailed log.
	 * </pre>
	 * When using the memory manager compiling problems may arrise.  In order
	 * to log the file and line of every allocation, the global new operator
	 * has to be overriden to accept the two parameters.  For applications to
	 * take advantage of the allocation tracking, allocations would have to be
	 * coded like this:
	 *
	 * \code
	 * SomeClass myClass = new(__FILE__, __LINE__) SomeClass();
	 * \endcode
	 *
	 * Needless to say, this is unacceptable.  Not only is it ugly to look at,
	 * it's also very easy to forget that it is needed.  In order to prevent
	 * the developer from having to remember this, there is a define that
	 * defines the word 'new'.  What this does is replace every instance of
	 * 'new' in the application to 'new(__FILE__, __LINE__)'.  This solves the
	 * last problem, but introduces it's own problems.  The major problem
	 * comes when overriding the operator new elsewhere.  In instances where
	 * the new operator is being overriden, the defined new must either be
	 * undef'd or it must not be defined before the overriding function.  There
	 * are a couple ways this can be achieved.  Here is an example of using
	 * the memory manager with the STL which overrides the operator new many
	 * times.
	 *
	 * \code
	 * // place offending headers above Blue headers
	 * #include <iostream>
	 *
	 * // include Blue headers here...
	 *
	 * // ... rest of file ...
	 * \endcode
	 *
	 * This can also be done before the function itself:
	 *
	 * \code
	 * #undef new
	 * void* operator new( size_t size, param_t myParm )
	 * { 
	 *     // whatever
	 * }
	 * #define new BLUE_NEW
	 * \endcode
	 *
	 * Also, when calling a different operator new, the #undef/#define pair
	 * is neccessary.
	 *
	 * The entire memory management operation can be disabled by defining
	 * <code>BLUE_MEMTRACK_DISABLED</code> when compiling the Blue library.
	 */
	class BLUE_EXPORT MemoryManager
	{
	public:
		/**
		 * Allocates memory.
		 */
		static void* malloc( size_t size );
		/**
		 * Allocates memory.  If memory tracking is enabled (compile time
		 * flag), the file and line where the allocation is taking place
		 * is recorded.
		 */
		static void* malloc( size_t size, const char* file, int line );

		/**
		 * Frees memory allocated by MemoryManager::malloc.
		 */
		static void free( void* mem );

	private:
		struct internal; friend struct internal;

		MemoryManager();
		~MemoryManager();
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#if !defined(BLUE_MEMTRACK_DISABLED)

	inline void* operator new( size_t size ) {
		return ::blue::common::MemoryManager::malloc(size);
	}

	inline void* operator new[]( size_t size ) {
		return ::blue::common::MemoryManager::malloc(size);
	}

	inline void* operator new( size_t size, const char* file, int line ) {
		return ::blue::common::MemoryManager::malloc(size, file, line);
	}

	inline void* operator new[]( size_t size, const char* file, int line ) {
		return ::blue::common::MemoryManager::malloc(size, file, line);
	}

	inline void operator delete( void* mem ) {
		::blue::common::MemoryManager::free(mem);
	}

	inline void operator delete[]( void* mem ) {
		::blue::common::MemoryManager::free(mem);
	}


	#define BLUE_NEW new(__FILE__, __LINE__)

#else

	#define BLUE_NEW new

#endif



#if !defined(BLUE_NEW_NODEF) && defined(BLUE_NEW)
#	define new BLUE_NEW
#endif


#endif // include guard
