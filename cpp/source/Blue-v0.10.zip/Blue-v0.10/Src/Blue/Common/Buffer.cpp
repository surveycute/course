//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/Buffer.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Buffer.h"

#if !defined(BLUE_DLL) || !defined(BLUE_LIB)
	typedef unsigned char byte_t;
#endif

// system headers
#include <memory.h>


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

namespace blue {
namespace common {

	const Buffer Buffer::null;

}}	// namespaces


// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace common {

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer::Buffer() :m_refCnt(0), m_refData(0), m_refSize(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer::Buffer( int size, const void* data ) :m_refCnt(0), m_refData(0), m_refSize(0)
	{
		set(size, data);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer::Buffer( const String& string ) :m_refCnt(0), m_refData(0), m_refSize(0)
	{
		set(string.getLength(), string.getAsCStr());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer::Buffer( const Buffer& copy ) :m_refCnt(copy.m_refCnt), m_refData(copy.m_refData), m_refSize(copy.m_refSize)
	{
		refInc();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer::~Buffer()
	{
		clear();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Buffer::getSize() const
	{
		return (m_refSize == 0 ? 0 : *m_refSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void* Buffer::getData( int offset )
	{
		return (((byte_t*)m_refData) + offset);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	const void* Buffer::getData( int offset ) const
	{
		return (((byte_t*)m_refData) + offset);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Buffer::isEmpty() const
	{
		return (m_refData == 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Buffer::readData( void* buffer, int bufSize, int offset ) const
	{
		byte_t* bytesDst = (byte_t*)buffer;
		byte_t* bytesSrc = (byte_t*)m_refData;

		if( bytesSrc == 0 || bytesDst == 0 ) {
			return (0);
		}

		if( offset + bufSize > *m_refSize ) {
			bufSize = *m_refSize - offset;
		}

		memcpy(bytesDst, bytesSrc + offset, bufSize);

		return (bufSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer Buffer::subBuffer( int start, int span ) const
	{
		int len = getSize();
		if( len <= 0 ) {
			return (Buffer::null);
		}

		start = (start < 0 ? 0 : start > len ? len : start);

		if( len < 0 ) {
			span = len - start;
		}
		else {
			span = (span < 0 ? 0 : span > (len - start) ? (len - start) : span);
		}

		if( span == 0 ) {
			return (Buffer::null);
		}

		return Buffer(span, getData(start));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String Buffer::toString() const
	{
		if( getSize() <= 0 ) {
			return (String::null);
		}

		return String( (char*)getData(), getSize());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Buffer::operator==( const Buffer& other ) const
	{
		return (m_refData == other.m_refData);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Buffer::operator!=( const Buffer& other ) const
	{
		return (m_refData != other.m_refData);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::clear()
	{
		refDec();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::setSize( int size )
	{
		refCreate(size);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::setData( const void* data )
	{
		if( data != 0 ) {
			memcpy(m_refData, data, *m_refSize);
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::resize( int size )
	{
		if( getSize() <= 0 ) {
			setSize(size);
			return;
		}

		int oldLen = *m_refSize;
		void* copy = new byte_t[oldLen];
		memcpy(copy, m_refData, oldLen);

		setSize(size);
		writeData(copy, oldLen);

		delete [] copy;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::set( int size, const void* data )
	{
		setSize(size);
		setData(data);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Buffer::writeData( const void* data, int dataSize, int offset )
	{
		byte_t* bytesSrc = (byte_t*)data;
		byte_t* bytesDst = (byte_t*)m_refData;

		if( bytesSrc == 0 || bytesDst == 0 ) {
			return (0);
		}

		if( offset + dataSize > *m_refSize ) {
			dataSize = *m_refSize - offset;
		}

		memcpy(bytesDst + offset, bytesSrc, dataSize);

		return (dataSize);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer Buffer::copy() const
	{
		Buffer copy;
		copy.setSize(getSize());
		copy.setData(getData());
		return (copy);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::append( const Buffer& other )
	{
		if( other.getSize() <= 0 ) {
			return;
		}
		if( &other == this ) {
			append( other.copy() );
			return;
		}

		int oldLen = getSize();
		resize(getSize() + other.getSize());
		writeData(other.getData(), other.getSize(), oldLen);

	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer& Buffer::operator=( const Buffer& other )
	{
		if( &other == this ) {
			return (*this);
		}

		refDec();
		m_refCnt = other.m_refCnt;
		m_refData = other.m_refData;
		m_refSize = other.m_refSize;
		refInc();

		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer& Buffer::operator+=( const Buffer& other )
	{
		append(other);
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer Buffer::operator+( const Buffer& other )
	{
		Buffer clone( copy() );
		clone += other;
		return (clone);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::refInc()
	{
		if( m_refCnt != 0 ) {
			++*m_refCnt;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::refDec()
	{
		if( m_refCnt != 0 ) {
			if( --*m_refCnt == 0 ) {
				delete m_refCnt;
				delete m_refSize;
				delete [] m_refData;
			}
		}

		m_refCnt = 0;
		m_refData = 0;
		m_refSize = 0;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Buffer::refCreate( int size )
	{
		if( m_refCnt != 0 ) {
			refDec();
		}
		if( size <= 0 ) {
			return;
		}

		m_refCnt = new int;
		m_refData = new byte_t[size];
		m_refSize = new int;

		*m_refCnt = 1;
		*m_refSize = size;
	}


}}	// namespaces
