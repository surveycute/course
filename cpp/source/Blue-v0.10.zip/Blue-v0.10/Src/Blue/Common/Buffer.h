//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/Buffer.h
//**

#ifndef __blue_common_Buffer_h_included__
#define __blue_common_Buffer_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"
#include "Blue/Common/String.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace common {

	/**
	 * \class Buffer
	 * \brief Holds a chunk of raw memory.
	 * \ingroup Common
	 *
	 * Buffers are chunks of raw memory.  Buffers are referenced counted
	 * and copy on resize.  What that means is as long as the %Buffer isn't
	 * resized, all Buffers referencing the same memory will see any
	 * changes made to the memory.  However, once the size of the %Buffer
	 * changes, the %Buffer that was changed gets its own memory.
	 */
	class BLUE_EXPORT Buffer
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		Buffer();
		/** Constructor. */
		Buffer( int size, const void* data = 0 );
		/** Constructor. */
		Buffer( const String& string );
		/** Copy constructor. */
		Buffer( const Buffer& copy );

		/** Destructor. */
		~Buffer();


		// ===========================================================
		//  query
		// ===========================================================

		/** Returns the size of the memory in bytes. */
		int getSize() const;

		/** Returns a pointer to the beginning of the memory. */
		void* getData( int offset = 0 );
		/** overload */
		const void* getData( int offset = 0 ) const;

		/** Determines if the %Buffer contains data. */
		bool isEmpty() const;

		/**
		 * Reads data from the %Buffer and copies it into the given
		 * buffer.
		 *
		 * \param buffer - the buffer to receive the data.
		 * \param bufSize - the maximum number of bytes to copy into the buffer.
		 * \param offset - the offset into the memory to start reading.
		 * \returns the number of bytes actually read.
		 */
		int readData( void* buffer, int bufSize, int offset = 0 ) const;

		/** Returns a new %Buffer that contains a portion of this %Buffer. */
		Buffer subBuffer( int start, int span = -1 ) const;

		/** Converts the %Buffer to a String. */
		String toString() const;

		/**
		 * Should be used when testing for empty buffers (or use
		 * Buffer::isEmpty()) and when assigning empty buffers.
		 */
		static const Buffer null;

		/** Determines if the two %Buffers are equal. */
		bool operator==( const Buffer& other ) const;
		/** Determines if the two %Buffers are not equal. */
		bool operator!=( const Buffer& other ) const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Nulls out this instance.  Note that if other %Buffers exist
		 * that point to the same memory, the memory is not deleted.
		 * The call affects this instance only.
		 */
		void clear();

		/**
		 * Sets the size of this data.  Calls Buffer::clear before
		 * allocating the new memory.
		 */
		void setSize( int size );
		/**
		 * Copies the data given into the allocated memory.  It is assumed
		 * that the memory given and the allocated memory are the same size.
		 */
		void setData( const void* data );

		/**
		 * Similiar to Buffer::setSize, but the data currently in the memory
		 * is copied into the new memory.  If the new memory cannot hold all
		 * of the old memory, then the data is simply cut off.  If the new
		 * memory is larger than the old, the difference contains unknown
		 * information and should be writen to using Buffer::writeData.
		 */
		void resize( int size );

		/**
		 * Combines Buffer::setSize and Buffer::setData into one call.
		 */
		void set( int size, const void* data );

		/**
		 * Writes data to the buffer at the given offset.
		 *
		 * \param data - the data to write.
		 * \param dataSize - the size of the data.
		 * \param offset - the offset into the memory to start writing.
		 * \returns the number of bytes actually written.
		 */
		int writeData( const void* data, int dataSize, int offset = 0 );

		/**
		 * Creates a new %Buffer that points to new memory, but contains
		 * the same data that is contained in this %Buffer.
		 */
		Buffer copy() const;

		/** Resizes this %Buffer and appends the other %Buffer's data. */
		void append( const Buffer& other );

		/** Points this %Buffer to the memory of the other %Buffer. */
		Buffer& operator=( const Buffer& other );
		/** Resizes this %Buffer and appends the other %Buffer's data. */
		Buffer& operator+=( const Buffer& other );
		/** Creates a new %Buffer that is the result of this %Buffer and the other %Buffer. */
		Buffer  operator+( const Buffer& other );

	private:
		void refInc();
		void refDec();
		void refCreate( int size );

		int*  m_refCnt;  // The number of buffers referencing this memory
		void* m_refData; // The shared memory
		int*  m_refSize; // The size of the memory buffer
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
