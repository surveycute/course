//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/Signals.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Signals.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace common {

	// ---------------------------------------------------------------------------------------------------------------------

	SlotBase::SlotBase( Signal* signal ) :m_signal(signal)
	{}

	// ---------------------------------------------------------------------------------------------------------------------

	SlotBase::~SlotBase()
	{
		disconnect();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SlotBase::disconnect()
	{
		if( m_signal ) {
			m_signal->removeSlot(this);
			m_signal = 0;
		}
	}



	// ---------------------------------------------------------------------------------------------------------------------
	//  Slot
	// ---------------------------------------------------------------------------------------------------------------------

	Slot::Slot() :m_base(0), m_refCnt(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Slot::Slot( SlotBase* base ) :m_base(base), m_refCnt(new int)
	{
		*m_refCnt = 1;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Slot::Slot( const Slot& slot ) :m_base(slot.m_base), m_refCnt(slot.m_refCnt)
	{
		if( m_refCnt ) {
			++*m_refCnt;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Slot::~Slot()
	{
		disconnect();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Slot::disconnect()
	{
		if( m_refCnt && --*m_refCnt == 0 ) {
			if( m_base != 0 ) {
				m_base->disconnect();
				delete m_base;
			}
			delete m_refCnt;
		}
		m_base = 0;
		m_refCnt = 0;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Slot& Slot::operator=( const Slot& slot )
	{
		disconnect();
		m_base   = slot.m_base;
		m_refCnt = slot.m_refCnt;
		if( m_refCnt ) {
			++*m_refCnt;
		}
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Slot::operator==( const Slot& slot )
	{
		return (m_base == slot.m_base);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Slot::operator!=( const Slot& slot )
	{
		return (m_base != slot.m_base);
	}


	// ---------------------------------------------------------------------------------------------------------------------
	//  SlotContainer
	// ---------------------------------------------------------------------------------------------------------------------

	SlotContainer::SlotContainer()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	SlotContainer::~SlotContainer()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SlotContainer::addSlot( Slot slot, String name )
	{
		container item;
		item.m_slot = slot;
		item.m_name = name;
		m_slots.append(item);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SlotContainer::removeSlot( Slot slot )
	{
		for( int i = 0; i < m_slots.getSize(); ++i ) {
			if( m_slots[i].m_slot == slot ) {
				m_slots.remove(i);
				break;
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SlotContainer::removeSlot( String name )
	{
		for( int i = 0; i < m_slots.getSize(); ++i ) {
			if( m_slots[i].m_name == name ) {
				m_slots.remove(i);
				break;
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Slot SlotContainer::getSlot( String name )
	{
		for( int i = 0; i < m_slots.getSize(); ++i ) {
			if( m_slots[i].m_name == name ) {
				return (m_slots[i].m_slot);
			}
		}

		return Slot();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void SlotContainer::operator+=( Slot slot )
	{
		addSlot(slot);
	}


}}	// namespaces
