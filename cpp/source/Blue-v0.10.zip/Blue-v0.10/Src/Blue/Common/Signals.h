//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Common/Signals.h
//**

#ifndef __blue_common_Signals_h_included__
#define __blue_common_Signals_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/Array.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace common {

	// forward declaration
	class Signal;


	// internal. do not reference in code.
	class BLUE_EXPORT SlotBase
	{
	public:
		SlotBase( Signal* signal );
		virtual ~SlotBase();

		void disconnect();

	public:
		Signal* m_signal;
	};



	/**
	 * \class Slot
	 * \brief A handle to a %Slot registered with a %Signal.
	 * \ingroup Common
	 *
	 * See Signal for more information on the %Signal/%Slot process.
	 *
	 * A %Slot instance is what keeps the function that was registered
	 * with a %Signal as a valid slot.  As long as the %Slot generated
	 * by the %Signal's connect method remains in scope, the %Signal will
	 * call the %Slot's function.  Once the %Slot is destroyed, either
	 * by going out of scope, or by calling Slot::disconnect, the %Slot
	 * will be unregistered with the %Signal and will not be called.
	 *
	 * \sa Signal, SlotContainer
	 */
	class BLUE_EXPORT Slot
	{
	public:
		/** Constructor. */
		Slot();
		/** Constructor. */
		Slot( SlotBase* base );
		/** Copy constructor. */
		Slot( const Slot& slot );

		/** Destructor. */
		~Slot();

		/** Disconnects the %Slot from the Signal it is connected to. */
		void disconnect();

		/** Assignment operator.  Point to a different %Slot. */
		Slot& operator=( const Slot& slot );
		/** Determines if the two Slots are identical. */
		bool operator==( const Slot& slot );
		/** Determines if the two Slots are not identical. */
		bool operator!=( const Slot& slot );

	private:
		SlotBase* m_base;
		int*      m_refCnt;
	};



	/**
	 * \class Signal
	 * \brief Used by objects that have signals that are emitted.
	 * \ingroup Common
	 *
	 * Signals and Slots are proven to be a very effective and popular way
	 * for C++ objects to communicate.  Many existing toolkits use this method
	 * of communications (especially for GUI development) and it's worked very
	 * well.  It is a very intuitive way for objects to communicate.  Other
	 * methods, such as event passing, work well, but can be complicated.
	 * Signals and Slots are very easy to learn and to use.
	 *
	 * The basic idea behind the %Signal and %Slot process is that objects have
	 * Signals that can be connected to.  A %Signal is basically something that
	 * has happened to the object, such as a state change.  For good example of
	 * this, think of a GUI button widget.  A signal that might be found for
	 * this object may be a 'clicked' signal.  Whenever a button receives a
	 * click from the user, it emits its 'clicked' signal.  Whatever objects
	 * have a %Slot registered with a button's 'clicked' signal will be notified
	 * of the click.  That brings us to the %Slot part of the process.
	 *
	 * The Slots are the functions that are called in response to a %Signal.
	 * It's that simple.  An important thing to know about is the %Slot object.
	 * Basically, when a function is registered with a %Signal, a %Slot is
	 * created.  This %Slot object keeps the function registered with the
	 * %Signal.  See the Slot object documentation for more information on this.
	 *
	 * The following is an example of how the %Signal/%Slot process might be used
	 * with a GUI library.
	 *
	 * \code
	 * class MyDialog :public Dialog
	 * {
	 * public:
	 *     MyDialog() {
	 *         PushButton* push = new PushButton("Push Me");
	 *         m_slotPush = push->sigClicked().connect(this, &MyDialog::onPushMeClicked);
	 *     }
	 *
	 * private:
	 *     void onPushMeClicked() {
	 *         MessageBox::information("Push Me button was clicked!");
	 *     }
	 *
	 *     Slot m_slotPush;
	 * };
	 * \endcode
	 *
	 * This does exactly what you think it would.  First, the new PushButton is
	 * created.  After that is done, the clicked %Signal is retrieved via the
	 * sigClicked function.  When connecting to the %Signal, because the function
	 * that is to be called is a member function, a pointer to the instance of the
	 * class, as well as the member function to call needs to be passed to the
	 * signal.  Note that the slot is being saved to the member variable <code>
	 * m_slotPush</code>.  This is necessary as it keeps the connection to the
	 * %Signal alive.  When this dialog is destroyed, the member variable will
	 * go out of scope which disconnects it from the %Signal.  This can also be
	 * done manually by calling the Slot::disconnect function.
	 *
	 * The current implementation of the %Signal/%Slot process allows for %Signals
	 * that return nothing (void) and have up to 6 parameters.  Slots can be either
	 * normal functions or class member functions.  The code to connect to a normal
	 * function looks like this:
	 *
	 * \code
	 *   Slot slot = push->sigClicked().connect( someStandardFunction );
	 * \endcode
	 *
	 * When connecting to a %Signal that passes parameters, make sure that the
	 * parameters of the %Slot matches the parameters of the %Signal or compilation
	 * errors will occur.
	 *
	 * When creating Signals for an object, simply create a %Signal variable,
	 * making sure that the parameters are in the template declaration.  An accessor
	 * function should also be made (<code>Signal_2<int, String>& sigMySignal()</code>)
	 * for consistancy.  The %Signal object will take care of the connecting Slots.
	 * In order to emit the %Signal, there is a member function,
	 * <code>Signal_X::emit(...)</code> that will emit the %Signal.  One very 
	 * important thing to remember is that Signals cannot be copied.  When creating
	 * copy constructors and assignment operators, this must be taken into account.
	 * Here is a sample	application that uses Signals.
	 *
	 * \code
	 * class SignalTest
	 * {
	 * public:
	 *     Signal_0&             sigSignal_0() { return (m_signal0); }
	 *     Signal_1<String>&     sigSignal_1() { return (m_signal1); }
	 *     Signal_2<int,String>& sigSignal_2() { return (m_signal2); }
	 *
	 *     void emitSignal0()                        { m_signal0.emit(); }
	 *     void emitSignal1(String parm1)            { m_signal1.emit(parm1); }
	 *     void emitSignal2(int parm1, String parm2) { m_signal2.emit(parm1, parm2); }
	 *
	 * private:
	 *     Signal_0              m_signal0;
	 *     Signal_1<String>      m_signal1;
	 *     Signal_2<int, String> m_signal2;
	 * };
	 *
	 * void slot_0() {
	 *     cout << "slot_0 was called." << endl;
	 * }
	 * void slot_1( String parm1 ) {
	 *     cout << "slot_1 was called: " << parm1.makeUnique().getAsCStr() << endl;
	 * }
	 * void slot_2( int parm1, String parm2 ) {
	 *     cout << "slot_2 was called: " << parm1 << ", " << parm2.makeUnique().getAsCStr() << endl;
	 * }
	 *
	 *
	 * class SlotTest
	 * {
	 * public:
	 *     void slot_0() {
	 *         cout << "SlotTest::slot_0 was called." << endl;
	 *     }
	 *     void slot_1( String parm1 ) {
	 *         cout << "SlotTest::slot_1 was called: " << parm1.makeUnique().getAsCStr() << endl;
	 *     }
	 *     void slot_2( int parm1, String parm2 ) {
	 *         cout << "SlotTest::slot_2 was called: " << parm1 << ", " << parm2.makeUnique().getAsCStr() << endl;
	 *     }
	 *
	 * };
	 *
	 * int main( int argc, char** argv ) {
	 *     SignalTest signal;
	 *     SlotTest   slot;
	 *
	 *     Slot slot1 = signal.sigSignal_0().connect( slot_0 );
	 *     Slot slot2 = signal.sigSignal_1().connect( slot_1 );
	 *     Slot slot3 = signal.sigSignal_2().connect( slot_2 );
	 *
	 *     Slot slot4 = signal.sigSignal_0().connect( &slot, &SlotTest::slot_0 );
	 *     Slot slot5 = signal.sigSignal_1().connect( &slot, &SlotTest::slot_1 );
	 *     Slot slot6 = signal.sigSignal_2().connect( &slot, &SlotTest::slot_2 );
	 *
	 *     signal.emitSignal0();
	 *     signal.emitSignal1("Hello World!");
	 *     signal.emitSignal2(42, "Hello Again!");
	 *
	 *     return (0);
	 * }
	 * \endcode
	 *
	 * The output of this application looks like this:
	 *
	 * <pre>
	 * SlotTest::slot_0 was called.
	 * slot_0 was called.
	 * SlotTest::slot_1 was called: Hello World!
	 * slot_1 was called: Hello World!
	 * SlotTest::slot_2 was called: 42, Hello Again!
	 * slot_2 was called: 42, Hello Again!
	 * </pre>
	 *
	 * \sa Slot, SlotContainer
	 */
	class BLUE_EXPORT Signal
	{
	public:
		virtual ~Signal()
		{}

		virtual void removeSlot( SlotBase* slot ) = 0;
	};



	/**
	 * \class SlotContainer
	 * \brief Manages multiple %Slots.
	 * \ingroup Common
	 *
	 * The %SlotContainer class keeps track of multiple %Slot handles.  If a large
	 * number of %Slots need to be kept, it is much easier to store them in a
	 * %SlotContainer than to keep track of each %Slot individually.  If there's a
	 * possiblity that a %Slot may need to be accessed (perhaps to disconnect it
	 * before the others), a name can be given to the %Slot.  The %Slot can then
	 * be accessed using the SlotContainer::getSlot function.
	 *
	 * \sa Slot, Signal
	 */
	class BLUE_EXPORT SlotContainer
	{
	public:
		/** Constructor. */
		SlotContainer();

		/** Destructor. */
		~SlotContainer();

		/** Adds a %Slot to be managed. */
		void addSlot( Slot slot, String name = String::null );

		/** Removes a %Slot from the managed list. */
		void removeSlot( Slot slot );
		/** Removes a %Slot from the managed list. */
		void removeSlot( String name );

		/** Return a %Slot that has the given name. */
		Slot getSlot( String name );

		/** Identical to SlotContainer::addSlot. */
		void operator+=( Slot slot );


	private:
		struct container
		{
			Slot   m_slot;
			String m_name;
		};

		Array<container> m_slots;
	};





	// ===============================================================
	// Actual implementation follows.  This is pretty ugly...
	// I hate duplicating code. *sigh*
	// ===============================================================





	// ===============================================================
	//  Zero Parameters
	// ===============================================================

	class BLUE_EXPORT Slot_0_Base :public SlotBase
	{
	public:
		Slot_0_Base( Signal* signal )
			:SlotBase(signal)
		{}

		virtual void call() = 0;
	};

	// ----------------------

	class BLUE_EXPORT Slot_0_Func :public Slot_0_Base
	{
	public:
		typedef void (*func_t)();

		Slot_0_Func( Signal* signal, func_t func )
			:Slot_0_Base(signal), m_func(func)
		{}

		virtual void call() {
			if( m_func ) m_func();
		}

	private:
		func_t m_func;
	};

	// ----------------------

	template<typename class_t>
	class BLUE_EXPORT Slot_0_MemFunc :public Slot_0_Base
	{
	public:
		typedef void (class_t::*func_t)();

		Slot_0_MemFunc( Signal* signal, class_t* who, func_t func )
			:Slot_0_Base(signal), m_who(who), m_func(func)
		{}

		virtual void call() {
			if( m_who && m_func ) (m_who->*m_func)();
		}

	private:
		class_t* m_who;
		func_t   m_func;
	};

	// ----------------------

	class BLUE_EXPORT Signal_0 :public Signal
	{
	public:
		Signal_0()
		{}

		~Signal_0()
		{
			Array<Slot_0_Base*> slots = m_slots;
			m_slots.clear();

			for( int i = 0; i < slots.getSize(); ++i ) {
				slots[i]->disconnect();
			}
		}

		void removeSlot( SlotBase* slot )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				if( m_slots[i] == slot ) {
					m_slots.remove(i);
					break;
				}
			}
		}

		void emit()
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				m_slots[i]->call();
			}
		}


		Slot connect( Slot_0_Base* slot )
		{
			m_slots.insert(slot, 0);
			return Slot(slot);
		}

		Slot connect( void (*func)() ) {
			return connect( new Slot_0_Func(this, func) );
		}

		template<typename class_t> Slot connect( class_t* self, void (class_t::*func)() ) {
			return connect( new Slot_0_MemFunc<class_t>(this, self, func) );
		}

	private:
		Array<Slot_0_Base*> m_slots;

		Signal_0( const Signal_0& );
		Signal_0& operator=( const Signal_0& );
	};




	
	// ===============================================================
	//  One Parameter
	// ===============================================================

	template<typename parm1_t>
	class BLUE_EXPORT Slot_1_Base :public SlotBase
	{
	public:
		Slot_1_Base( Signal* signal )
			:SlotBase(signal)
		{}

		virtual void call(parm1_t) = 0;
	};

	// ----------------------

	template<typename parm1_t>
	class BLUE_EXPORT Slot_1_Func :public Slot_1_Base<parm1_t>
	{
	public:
		typedef void (*func_t)(parm1_t);

		Slot_1_Func( Signal* signal, func_t func )
			:Slot_1_Base<parm1_t>(signal), m_func(func)
		{}

		virtual void call(parm1_t parm1) {
			if( m_func ) m_func(parm1);
		}

	private:
		func_t m_func;
	};

	// ----------------------

	template<typename class_t, typename parm1_t>
	class BLUE_EXPORT Slot_1_MemFunc :public Slot_1_Base<parm1_t>
	{
	public:
		typedef void (class_t::*func_t)(parm1_t);

		Slot_1_MemFunc( Signal* signal, class_t* who, func_t func )
			:Slot_1_Base<parm1_t>(signal), m_who(who), m_func(func)
		{}

		virtual void call(parm1_t parm1) {
			if( m_who && m_func ) (m_who->*m_func)(parm1);
		}

	private:
		class_t* m_who;
		func_t   m_func;
	};

	// ----------------------

	template<typename parm1_t>
	class BLUE_EXPORT Signal_1 :public Signal
	{
	public:
		Signal_1()
		{}

		~Signal_1()
		{
			Array<Slot_1_Base<parm1_t>*> slots = m_slots;
			m_slots.clear();

			for( int i = 0; i < slots.getSize(); ++i ) {
				slots[i]->disconnect();
			}
		}

		void removeSlot( SlotBase* slot )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				if( m_slots[i] == slot ) {
					m_slots.remove(i);
					break;
				}
			}
		}

		void emit( parm1_t parm1 )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				m_slots[i]->call(parm1);
			}
		}


		Slot connect( Slot_1_Base<parm1_t>* slot )
		{
			m_slots.insert(slot, 0);
			return Slot(slot);
		}

		Slot connect( void (*func)(parm1_t) ) {
			return connect( new Slot_1_Func<parm1_t>(this, func) );
		}

		template<typename class_t> Slot connect( class_t* self, void (class_t::*func)(parm1_t) ) {
			return connect( new Slot_1_MemFunc<class_t,parm1_t>(this, self, func) );
		}

	private:
		Array<Slot_1_Base<parm1_t>*> m_slots;

		Signal_1( const Signal_1& );
		Signal_1& operator=( const Signal_1& );
	};





	// ===============================================================
	//  Two Parameters
	// ===============================================================

	template<typename parm1_t, typename parm2_t>
	class BLUE_EXPORT Slot_2_Base :public SlotBase
	{
	public:
		Slot_2_Base( Signal* signal )
			:SlotBase(signal)
		{}

		virtual void call(parm1_t, parm2_t) = 0;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t>
	class BLUE_EXPORT Slot_2_Func :public Slot_2_Base<parm1_t, parm2_t>
	{
	public:
		typedef void (*func_t)(parm1_t, parm2_t);

		Slot_2_Func( Signal* signal, func_t func )
			:Slot_2_Base<parm1_t, parm2_t>(signal), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2) {
			if( m_func ) m_func(parm1, parm2);
		}

	private:
		func_t m_func;
	};

	// ----------------------

	template<typename class_t, typename parm1_t, typename parm2_t>
	class BLUE_EXPORT Slot_2_MemFunc :public Slot_2_Base<parm1_t, parm2_t>
	{
	public:
		typedef void (class_t::*func_t)(parm1_t, parm2_t);

		Slot_2_MemFunc( Signal* signal, class_t* who, func_t func )
			:Slot_2_Base<parm1_t, parm2_t>(signal), m_who(who), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2) {
			if( m_who && m_func ) (m_who->*m_func)(parm1, parm2);
		}

	private:
		class_t* m_who;
		func_t   m_func;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t>
	class BLUE_EXPORT Signal_2 :public Signal
	{
	public:
		Signal_2()
		{}

		~Signal_2()
		{
			Array<Slot_2_Base<parm1_t, parm2_t>*> slots = m_slots;
			m_slots.clear();

			for( int i = 0; i < slots.getSize(); ++i ) {
				slots[i]->disconnect();
			}
		}

		void removeSlot( SlotBase* slot )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				if( m_slots[i] == slot ) {
					m_slots.remove(i);
					break;
				}
			}
		}

		void emit( parm1_t parm1, parm2_t parm2 )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				m_slots[i]->call(parm1, parm2);
			}
		}


		Slot connect( Slot_2_Base<parm1_t,parm2_t>* slot )
		{
			m_slots.insert(slot, 0);
			return Slot(slot);
		}

		Slot connect( void (*func)(parm1_t, parm2_t) ) {
			return connect( new Slot_2_Func<parm1_t, parm2_t>(this, func) );
		}

		template<typename class_t> Slot connect( class_t* self, void (class_t::*func)(parm1_t, parm2_t) ) {
			return connect( new Slot_2_MemFunc<class_t,parm1_t, parm2_t>(this, self, func) );
		}

	private:
		Array<Slot_2_Base<parm1_t, parm2_t>*> m_slots;

		Signal_2( const Signal_2& );
		Signal_2& operator=( const Signal_2& );
	};





	// ===============================================================
	//  Three Parameters
	// ===============================================================
	
	template<typename parm1_t, typename parm2_t, typename parm3_t>
	class BLUE_EXPORT Slot_3_Base :public SlotBase
	{
	public:
		Slot_3_Base( Signal* signal )
			:SlotBase(signal)
		{}

		virtual void call(parm1_t, parm2_t, parm3_t) = 0;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t>
	class BLUE_EXPORT Slot_3_Func :public Slot_3_Base<parm1_t, parm2_t, parm3_t>
	{
	public:
		typedef void (*func_t)(parm1_t, parm2_t, parm3_t);

		Slot_3_Func( Signal* signal, func_t func )
			:Slot_3_Base<parm1_t, parm2_t, parm3_t>(signal), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3) {
			if( m_func ) m_func(parm1, parm2, parm3);
		}

	private:
		func_t m_func;
	};

	// ----------------------

	template<typename class_t, typename parm1_t, typename parm2_t, typename parm3_t>
	class BLUE_EXPORT Slot_3_MemFunc :public Slot_3_Base<parm1_t, parm2_t, parm3_t>
	{
	public:
		typedef void (class_t::*func_t)(parm1_t, parm2_t, parm3_t);

		Slot_3_MemFunc( Signal* signal, class_t* who, func_t func )
			:Slot_3_Base<parm1_t, parm2_t, parm3_t>(signal), m_who(who), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3) {
			if( m_who && m_func ) (m_who->*m_func)(parm1, parm2, parm3);
		}

	private:
		class_t* m_who;
		func_t   m_func;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t>
	class BLUE_EXPORT Signal_3 :public Signal
	{
	public:
		Signal_3()
		{}

		~Signal_3()
		{
			Array<Slot_3_Base<parm1_t, parm2_t, parm3_t>*> slots = m_slots;
			m_slots.clear();

			for( int i = 0; i < slots.getSize(); ++i ) {
				slots[i]->disconnect();
			}
		}

		void removeSlot( SlotBase* slot )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				if( m_slots[i] == slot ) {
					m_slots.remove(i);
					break;
				}
			}
		}

		void emit( parm1_t parm1, parm2_t parm2, parm3_t parm3 )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				m_slots[i]->call(parm1, parm2, parm3);
			}
		}


		Slot connect( Slot_3_Base<parm1_t, parm2_t, parm3_t>* slot )
		{
			m_slots.insert(slot, 0);
			return Slot(slot);
		}

		Slot connect( void (*func)(parm1_t, parm2_t, parm3_t) ) {
			return connect( new Slot_3_Func<parm1_t, parm2_t, parm3_t>(this, func) );
		}

		template<typename class_t> Slot connect( class_t* self, void (class_t::*func)(parm1_t, parm2_t, parm3_t) ) {
			return connect( new Slot_3_MemFunc<class_t, parm1_t, parm2_t, parm3_t>(this, self, func) );
		}

	private:
		Array<Slot_3_Base<parm1_t, parm2_t, parm3_t>*> m_slots;

		Signal_3( const Signal_3& );
		Signal_3& operator=( const Signal_3& );
	};





	// ===============================================================
	//  Four Parameters
	// ===============================================================

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t>
	class BLUE_EXPORT Slot_4_Base :public SlotBase
	{
	public:
		Slot_4_Base( Signal* signal )
			:SlotBase(signal)
		{}

		virtual void call(parm1_t, parm2_t, parm3_t, parm4_t) = 0;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t>
	class BLUE_EXPORT Slot_4_Func :public Slot_4_Base<parm1_t, parm2_t, parm3_t, parm4_t>
	{
	public:
		typedef void (*func_t)(parm1_t, parm2_t, parm3_t, parm4_t);

		Slot_4_Func( Signal* signal, func_t func )
			:Slot_4_Base< parm1_t, parm2_t, parm3_t, parm4_t>(signal), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4)
		{ if( m_func ) m_func(parm1, parm2, parm3, parm4); }

	private:
		func_t m_func;
	};

	// ----------------------

	template<typename class_t, typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t>
	class BLUE_EXPORT Slot_4_MemFunc :public Slot_4_Base<parm1_t, parm2_t, parm3_t, parm4_t>
	{
	public:
		typedef void (class_t::*func_t)(parm1_t, parm2_t, parm3_t, parm4_t);

		Slot_4_MemFunc( Signal* signal, class_t* who, func_t func )
			:Slot_4_Base<parm1_t, parm2_t, parm3_t, parm4_t>(signal), m_who(who), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4)
		{ if( m_who && m_func ) (m_who->*m_func)(parm1, parm2, parm3, parm4); }

	private:
		class_t* m_who;
		func_t   m_func;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t>
	class BLUE_EXPORT Signal_4 :public Signal
	{
	public:
		Signal_4()
		{}

		~Signal_4()
		{
			Array<Slot_4_Base<parm1_t, parm2_t, parm3_t, parm4_t>*> slots = m_slots;
			m_slots.clear();

			for( int i = 0; i < slots.getSize(); ++i ) {
				slots[i]->disconnect();
			}
		}

		void removeSlot( SlotBase* slot )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				if( m_slots[i] == slot ) {
					m_slots.remove(i);
					break;
				}
			}
		}

		void emit( parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4 )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				m_slots[i]->call(parm1, parm2, parm3, parm4);
			}
		}


		Slot connect( Slot_4_Base<parm1_t, parm2_t, parm3_t, parm4_t>* slot )
		{
			m_slots.insert(slot, 0);
			return Slot(slot);
		}

		Slot connect( void (*func)(parm1_t, parm2_t, parm3_t, parm4_t) ) {
			return connect( new Slot_4_Func<parm1_t, parm2_t, parm3_t, parm4_t>(this, func) );
		}

		template<typename class_t> Slot connect( class_t* self, void (class_t::*func)(parm1_t, parm2_t, parm3_t, parm4_t) ) {
			return connect( new Slot_4_MemFunc<class_t, parm1_t, parm2_t, parm3_t, parm4_t>(this, self, func) );
		}

	private:
		Array<Slot_4_Base<parm1_t, parm2_t, parm3_t, parm4_t>*> m_slots;

		Signal_4( const Signal_4& );
		Signal_4& operator=( const Signal_4& );
	};





	// ===============================================================
	//  Five Parameters
	// ===============================================================

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t>
	class BLUE_EXPORT Slot_5_Base :public SlotBase
	{
	public:
		Slot_5_Base( Signal* signal )
			:SlotBase(signal)
		{}

		virtual void call(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t) = 0;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t>
	class BLUE_EXPORT Slot_5_Func :public Slot_5_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>
	{
	public:
		typedef void (*func_t)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t);

		Slot_5_Func( Signal* signal, func_t func )
			:Slot_5_Base< parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>(signal), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4, parm5_t parm5)
		{ if( m_func ) m_func(parm1, parm2, parm3, parm4, parm5); }

	private:
		func_t m_func;
	};

	// ----------------------

	template<typename class_t, typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t>
	class BLUE_EXPORT Slot_5_MemFunc :public Slot_5_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>
	{
	public:
		typedef void (class_t::*func_t)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t);

		Slot_5_MemFunc( Signal* signal, class_t* who, func_t func )
			:Slot_5_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>(signal), m_who(who), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4, parm5_t parm5)
		{ if( m_who && m_func ) (m_who->*m_func)(parm1, parm2, parm3, parm4, parm5); }

	private:
		class_t* m_who;
		func_t   m_func;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t>
	class BLUE_EXPORT Signal_5 :public Signal
	{
	public:
		Signal_5()
		{}

		~Signal_5()
		{
			Array<Slot_5_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>*> slots = m_slots;
			m_slots.clear();

			for( int i = 0; i < slots.getSize(); ++i ) {
				slots[i]->disconnect();
			}
		}

		void removeSlot( SlotBase* slot )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				if( m_slots[i] == slot ) {
					m_slots.remove(i);
					break;
				}
			}
		}

		void emit( parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4, parm5_t parm5 )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				m_slots[i]->call(parm1, parm2, parm3, parm4, parm5);
			}
		}


		Slot connect( Slot_5_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>* slot )
		{
			m_slots.insert(slot, 0);
			return Slot(slot);
		}

		Slot connect( void (*func)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t) ) {
			return connect( new Slot_5_Func<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>(this, func) );
		}

		template<typename class_t> Slot connect( class_t* self, void (class_t::*func)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t) ) {
			return connect( new Slot_5_MemFunc<class_t, parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>(this, self, func) );
		}

	private:
		Array<Slot_5_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t>*> m_slots;

		Signal_5( const Signal_5& );
		Signal_5& operator=( const Signal_5& );
	};





	// ===============================================================
	//  Six Parameters
	// ===============================================================

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t, typename parm6_t>
	class BLUE_EXPORT Slot_6_Base :public SlotBase
	{
	public:
		Slot_6_Base( Signal* signal )
			:SlotBase(signal)
		{}

		virtual void call(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t) = 0;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t, typename parm6_t>
	class BLUE_EXPORT Slot_6_Func :public Slot_6_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>
	{
	public:
		typedef void (*func_t)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t);

		Slot_6_Func( Signal* signal, func_t func )
			:Slot_6_Base< parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>(signal), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4, parm5_t parm5, parm6_t parm6)
		{ if( m_func ) m_func(parm1, parm2, parm3, parm4, parm5, parm6); }

	private:
		func_t m_func;
	};

	// ----------------------

	template<typename class_t, typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t, typename parm6_t>
	class BLUE_EXPORT Slot_6_MemFunc :public Slot_6_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>
	{
	public:
		typedef void (class_t::*func_t)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t);

		Slot_6_MemFunc( Signal* signal, class_t* who, func_t func )
			:Slot_6_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>(signal), m_who(who), m_func(func)
		{}

		virtual void call(parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4, parm5_t parm5, parm6_t parm6)
		{ if( m_who && m_func ) (m_who->*m_func)(parm1, parm2, parm3, parm4, parm5, parm6); }

	private:
		class_t* m_who;
		func_t   m_func;
	};

	// ----------------------

	template<typename parm1_t, typename parm2_t, typename parm3_t, typename parm4_t, typename parm5_t, typename parm6_t>
	class BLUE_EXPORT Signal_6 :public Signal
	{
	public:
		Signal_6()
		{}

		~Signal_6()
		{
			Array<Slot_6_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>*> slots = m_slots;
			m_slots.clear();

			for( int i = 0; i < slots.getSize(); ++i ) {
				slots[i]->disconnect();
			}
		}

		void removeSlot( SlotBase* slot )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				if( m_slots[i] == slot ) {
					m_slots.remove(i);
					break;
				}
			}
		}

		void emit( parm1_t parm1, parm2_t parm2, parm3_t parm3, parm4_t parm4, parm5_t parm5, parm6_t parm6 )
		{
			for( int i = 0; i < m_slots.getSize(); ++i ) {
				m_slots[i]->call(parm1, parm2, parm3, parm4, parm5, parm6);
			}
		}


		Slot connect( Slot_6_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>* slot )
		{
			m_slots.insert(slot, 0);
			return Slot(slot);
		}

		Slot connect( void (*func)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t) ) {
			return connect( new Slot_6_Func<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>(this, func) );
		}

		template<typename class_t> Slot connect( class_t* self, void (class_t::*func)(parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t) ) {
			return connect( new Slot_6_MemFunc<class_t, parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>(this, self, func) );
		}

	private:
		Array<Slot_6_Base<parm1_t, parm2_t, parm3_t, parm4_t, parm5_t, parm6_t>*> m_slots;

		Signal_6( const Signal_6& );
		Signal_6& operator=( const Signal_6& );
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
