//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/Date.cpp
//**

// Private Headers =========================================================================================================

// system headers
#include <time.h>

// matching header
#include "Date.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace util {

	// ---------------------------------------------------------------------------------------------------------------------

	Date::Date( int month, int day, int year )
	{
		m_julian = convertToJulian(month, day, year);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Date::Date( uint32_t julian ) :m_julian(julian)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Date::Date( const Date& copy ) :m_julian(copy.m_julian)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Date::~Date()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	Date Date::getToday()
	{
		time_t today = time(0);
		tm* curtime = localtime(&today);
		return Date( curtime->tm_mon + 1, curtime->tm_mday, curtime->tm_year + 1900 );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::getMonth() const
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);
		return (m);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::getDay() const
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);
		return (d);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::getYear() const
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);
		return (y);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::getWeekday() const
	{
		return int32_t( (((float32_t(m_julian) / 7.0) - int32_t(float32_t(m_julian) / 7.0)) * 7 + 0.000000000317) + 1);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint32_t Date::getJulian() const
	{
		return (m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::diffInMonths( const Date& other ) const
	{
		int m1, d1, y1;
		int m2, d2, y2;

		convertFromJulian(m_julian, m1, d1, y1);
		convertFromJulian(other.m_julian, m2, d2, y2);

		int difYears = y2 - y1;
		int difMonths = m1 - m2;

		return ((difYears * 12) - difMonths);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::diffInDays( const Date& other ) const
	{
		return (other.m_julian - m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::diffInYears( const Date& other ) const
	{
		return (diffInMonths(other) / 12);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Date::isLeapYear() const
	{
		return isLeapYear( getYear() );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	bool Date::isLeapYear( int year )
	{
		if( year %   4 ) return (false);
		if( year % 100 ) return (true);
		if( year % 400 ) return (false);

		return (true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Date::daysInMonth() const
	{
		return daysInMonth( getMonth(), getYear() );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	int Date::daysInMonth( int month, int year )
	{
		month = clamp(month, 1, 12);

		static const int days[] = {
			0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
		};

		if( month == FEB ) {
			return (days[month] + (isLeapYear(year) ? 1 : 0));
		}

		return (days[month]);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Date::operator==( const Date& other ) const
	{
		return (m_julian == other.m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Date::operator!=( const Date& other ) const
	{
		return (m_julian != other.m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Date::operator<( const Date& other ) const
	{
		return (m_julian < other.m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Date::operator<=( const Date& other ) const
	{
		return (m_julian <= other.m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Date::operator>( const Date& other ) const
	{
		return (m_julian > other.m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Date::operator>=( const Date& other ) const
	{
		return (m_julian >= other.m_julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::setMonth( int month )
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);
		month = clamp(month, 1, 12);
		m_julian = convertToJulian(month, d, y);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::setDay( int day )
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);
		day = clamp(day, 1, daysInMonth(m, y));
		m_julian = convertToJulian(m, day, y);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::setYear( int year )
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);
		m_julian = convertToJulian(m, d, year);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::set( int month, int day, int year )
	{
		m_julian = convertToJulian(month, day, year);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::setJulian( uint32_t julian )
	{
		m_julian = julian;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::addMonths( int months )
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);

		m += months;
		while( m - 12 >= 1 ) {
			++y;
			m -= 12;
		}

		m_julian = convertToJulian(m, d, y);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::addDays( int days )
	{
		m_julian += days;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Date::addYears( int years )
	{
		int m, d, y;
		convertFromJulian(m_julian, m, d, y);
		m_julian = convertToJulian(m, d, y + years);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Date& Date::operator=( const Date& copy )
	{
		m_julian = copy.m_julian;
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	uint32_t Date::convertToJulian( int month, int day, int year )
	{
		uint32_t julian =
			( 1461 * (year + 4800 + (month - 14) / 12) ) / 4 + 
			( 367 * (month - 2 - 12 * ( (month - 14) / 12) ) ) / 12 -
			( 3 * ( (year + 4900 + (month - 14) / 12 ) / 100 ) ) / 4 + 
			day - 32075;

		return (julian);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	void Date::convertFromJulian( uint32_t julian, int& month, int& day, int& year )
	{
		int l = julian + 68569;
		int n = ( 4 * l ) / 146097;
		l = l - ( 146097 * n + 3 ) / 4;
		int i = ( 4000 * ( l + 1 ) ) / 1461001;
		l = l - ( 1461 * i ) / 4 + 31;
		int j = ( 80 * l ) / 2447;
		
		day = l - ( 2447 * j ) / 80;
		l = j / 11;
		month = j + 2 - ( 12 * l );
		year = 100 * ( n - 49 ) + i + l;
	}


}}	// namespaces
