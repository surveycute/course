//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/Time.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Time.h"

// system headers
#include <time.h>

#if defined(BLUE_PLATFORM_WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

namespace {
	const ::blue::int32_t MAX_MILLISECONDS = (1000 * 60 * 60 * 24);
	const ::blue::int32_t MAX_SECONDS      = (60 * 60 * 24);
	const ::blue::int32_t MAX_MINUTES      = (60 * 24);
	const ::blue::int32_t MAX_HOURS        = (24);
}

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace util {

	// ---------------------------------------------------------------------------------------------------------------------

	Time::Time( int hour, int minute, int second, int milli )
	{
		m_milliseconds = convertToMilliseconds(hour, minute, second, milli);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Time::Time( const Time& copy ) :m_milliseconds(copy.m_milliseconds)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Time::~Time()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	Time Time::getNow()
	{
	#if defined(BLUE_PLATFORM_WIN32)
		SYSTEMTIME curTime;
		GetLocalTime(&curTime);
		return Time(curTime.wHour, curTime.wMinute, curTime.wSecond, curTime.wMilliseconds);
	#else
		time_t today = time(0);
		tm* curTime = localtime(&today);
		return Time(curTime->tm_hour, curTime->tm_min, curTime->tm_sec);
	#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::getHour() const
	{
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		return (h);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::getMinute() const
	{
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		return (m);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::getSecond() const
	{
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		return (s);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::getMillisecond() const
	{
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		return (mi);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::diffInHours( const Time& other ) const
	{
		return (diffInMinutes(other) / 60);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::diffInMinutes( const Time& other ) const
	{
		return (diffInSeconds(other) / 60);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::diffInSeconds( const Time& other ) const
	{
		return (diffInMilliseconds(other) / 1000);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Time::diffInMilliseconds( const Time& other ) const
	{
		return (other.m_milliseconds - m_milliseconds);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Time::operator==( const Time& other ) const
	{
		return (m_milliseconds == other.m_milliseconds);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Time::operator!=( const Time& other ) const
	{
		return (m_milliseconds != other.m_milliseconds);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Time::operator<( const Time& other ) const
	{
		return (m_milliseconds < other.m_milliseconds);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Time::operator<=( const Time& other ) const
	{
		return (m_milliseconds <= other.m_milliseconds);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Time::operator>( const Time& other ) const
	{
		return (m_milliseconds > other.m_milliseconds);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Time::operator>=( const Time& other ) const
	{
		return (m_milliseconds >= other.m_milliseconds);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::setHour( int hour )
	{
		hour = clamp(hour, 0, 23);
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		m_milliseconds = convertToMilliseconds(hour, m, s, mi);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::setMinute( int minute )
	{
		minute = clamp(minute, 0, 59);
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		m_milliseconds = convertToMilliseconds(h, minute, s, mi);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::setSecond( int second )
	{
		second = clamp(second, 0, 59);
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		m_milliseconds = convertToMilliseconds(h, m, second, mi);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::setMillisecond( int milli )
	{
		milli = clamp(milli, 0, 999);
		int h, m, s, mi;
		convertFromMilliseconds(m_milliseconds, h, m, s, mi);
		m_milliseconds = convertToMilliseconds(h, m, s, milli);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::set( int hour, int minute, int second, int milli )
	{
		hour = clamp(hour, 0, 23);
		minute = clamp(minute, 0, 59);
		second = clamp(second, 0, 59);
		milli = clamp(milli, 0, 999);
		m_milliseconds = convertToMilliseconds(hour, minute, second, milli);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::addHours( int hours )
	{
		while( hours >= MAX_HOURS ) {
			hourRollover(1);
			hours -= MAX_HOURS;
		}

		while( hours <= -MAX_HOURS ) {
			hourRollover(-1);
			hours += MAX_HOURS;
		}

		addMinutes( hours * 60 );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::addMinutes( int minutes )
	{
		while( minutes >= MAX_MINUTES ) {
			hourRollover(1);
			minutes -= MAX_MINUTES;
		}

		while( minutes <= -MAX_MINUTES ) {
			hourRollover(-1);
			minutes += MAX_MINUTES;
		}

		addSeconds( minutes * 60 );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::addSeconds( int seconds )
	{
		while( seconds >= MAX_SECONDS ) {
			hourRollover(1);
			seconds -= MAX_SECONDS;
		}

		while( seconds <= -MAX_SECONDS ) {
			hourRollover(-1);
			seconds += MAX_SECONDS;
		}

		addMilliseconds( seconds * 1000 );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::addMilliseconds( int milli )
	{
		while( milli >= MAX_MILLISECONDS ) {
			hourRollover(1);
			milli -= MAX_MILLISECONDS;
		}

		while( milli <= -MAX_MILLISECONDS ) {
			hourRollover(-1);
			milli += MAX_MILLISECONDS;
		}

		if( milli < 0 && m_milliseconds < (uint32_t)abs(milli) ) {
			hourRollover(-1);
			m_milliseconds += (MAX_MILLISECONDS - abs(milli));
		}
		else {
			m_milliseconds += milli;
			if( m_milliseconds >= MAX_MILLISECONDS ) {
				hourRollover(1);
				m_milliseconds -= MAX_MILLISECONDS;
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Time& Time::operator=( const Time& copy )
	{
		m_milliseconds = copy.m_milliseconds;
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Time::hourRollover( int dayDir )
	{
		// virtual function meant to be used by DateTime class.
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint32_t Time::getMaxMilliseconds() const
	{
		return (MAX_MILLISECONDS);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	uint32_t Time::convertToMilliseconds( int hour, int minute, int second, int milli )
	{
		int miHour = hour * (1000 * 60 * 60);
		int miMinute = minute * (1000 * 60);
		int miSecond = second * (1000);

		return (miHour + miMinute + miSecond + milli);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	void Time::convertFromMilliseconds( uint32_t milliseconds, int& hour, int& minute, int& second, int& milli )
	{
		hour = milliseconds / (1000 * 60 * 60);
		milliseconds -= hour * (1000 * 60 * 60);

		minute = milliseconds / (1000 * 60);
		milliseconds -= minute * (1000 * 60);

		second = milliseconds / (1000);
		milliseconds -= second * (1000);

		milli = milliseconds;
	}

}}	// namespaces
