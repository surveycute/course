//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/Time.h
//**

#ifndef __blue_util_Time_h_included__
#define __blue_util_Time_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace util {

	/**
	 * \class Time
	 * \brief %Time manipulation.
	 * \ingroup Util
	 *
	 * Allows %Time manipulation.
	 */
	class BLUE_EXPORT Time
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		Time( int hour = 0, int minute = 0, int second = 0, int milli = 0 );
		/** Copy constructor. */
		Time( const Time& copy );

		/** Destructor. */
		~Time();

		/** Returns a %Time with the system's current time. */
		static Time getNow();


		// ===========================================================
		//  query
		// ===========================================================

		/** Returns the hour.  This is a number between 0 and 23. */
		int getHour() const;
		/** Returns the minute.  This is a number between 0 and 59. */
		int getMinute() const;
		/** Returns the second.  This is a number between 0 and 59. */
		int getSecond() const;
		/** Returns the millisecond.  This is a number between 0 and 999. */
		int getMillisecond() const;

		/**
		 * Returns the difference in time between the two Times in hours.
		 * This is actually the difference in minutes divided by 60, not
		 * subtracting the results returned by Time::getHour.
		 * If the value returned is negative, then the %Date given is earlier
		 * than the instance calling the function.
		 */
		int diffInHours( const Time& other ) const;
		/**
		 * Returns the difference in time between the two Times in minutes.
		 * If the value returned is negative, then the %Date given is earlier
		 * than the instance calling the function.
		 */
		int diffInMinutes( const Time& other ) const;
		/**
		 * Returns the difference in time between the two Times in seconds.
		 * If the value returned is negative, then the %Date given is earlier
		 * than the instance calling the function.
		 */
		int diffInSeconds( const Time& other ) const;
		/**
		 * Returns the difference in time between the two Times in milliseconds.
		 * If the value returned is negative, then the %Date given is earlier
		 * than the instance calling the function.
		 */
		int diffInMilliseconds( const Time& other ) const;

		/** Determines if the two Times are the same. */
		bool operator==( const Time& other ) const;
		/** Determines if the two Times are not the same. */
		bool operator!=( const Time& other ) const;
		/** Determines if this %Time is earlier than the other. */
		bool operator<( const Time& other ) const;
		/** Determines if this %Time is earlier or equal to the other. */
		bool operator<=( const Time& other ) const;
		/** Determines if this %Time is later than the other. */
		bool operator>( const Time& other ) const;
		/** Determines if this %Time is later or equal to the other. */
		bool operator>=( const Time& other ) const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Sets the hour. */
		void setHour( int hour );
		/** Sets the minute. */
		void setMinute( int minute );
		/** Sets the second. */
		void setSecond( int second );
		/** Sets the millisecond. */
		void setMillisecond( int milli );

		/** Combines calls to setHour, setMinute, setSecond and setMillisecond. */
		void set( int hour, int minute, int second, int milli = 0 );

		/**
		 * Adds the given number of hours to the current time.
		 * The hours roll over if they would exceed the 24 hour limit (0 - 23).
		 */
		void addHours( int hours );
		/**
		 * Adds the given number of minutes to the current time.
		 * The minutes roll over if they would exceed the 60 minute limit (0 - 59).
		 */
		void addMinutes( int minutes );
		/**
		 * Adds the given number of seconds to the current time.
		 * The seconds roll over if they would exceed the 60 second limit (0 - 59).
		 */
		void addSeconds( int seconds );
		/**
		 * Adds the given number of milliseconds to the current time.
		 * The seconds roll over if they would exceed the 1000 millisecond limit (0 - 999).
		 */
		void addMilliseconds( int milli );

		/** Assignment operator. */
		Time& operator=( const Time& copy );


	protected:
		// called when adding Hours causes the hour to rollover.
		virtual void hourRollover( int dayDir );

		uint32_t getMaxMilliseconds() const;


	private:
		// converts the given hour/minute/second/milli to milliseconds
		static uint32_t convertToMilliseconds( int hour, int minute, int second, int milli );
		// converts the given milliseconds to a hour/minute/second/milli.
		static void convertFromMilliseconds( uint32_t milliseconds, int& hour, int& minute, int& second, int& milli );

		uint32_t m_milliseconds;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
