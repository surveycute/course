//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/DateTime.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "DateTime.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace util {

	// ---------------------------------------------------------------------------------------------------------------------

	DateTime::DateTime()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	DateTime::DateTime( const Date& date, const Time& time )
		:Date(date), Time(time)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	DateTime::DateTime( int month, int day, int year, int hour, int minute, int second, int milli )
		:Date(month, day, year), Time(hour, minute, second, milli)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	DateTime::DateTime( const DateTime& copy )
	{
		setDate( copy.getDate() );
		setTime( copy.getTime() );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	DateTime::~DateTime()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	DateTime DateTime::getCurrent()
	{
		return DateTime( Date::getToday(), Time::getNow() );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Date DateTime::getDate() const
	{
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Time DateTime::getTime() const
	{
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	int DateTime::diffInHours( const DateTime& other ) const
	{
		int diff = diffInDays(other) * (getMaxMilliseconds() / (1000 * 60 * 60));
		return (diff + Time::diffInHours(other));
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	int DateTime::diffInMinutes( const DateTime& other ) const
	{
		int diff = diffInDays(other) * (getMaxMilliseconds() / (1000 * 60));
		return (diff + Time::diffInMinutes(other));
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	int DateTime::diffInSeconds( const DateTime& other ) const
	{
		int diff = diffInDays(other) * (getMaxMilliseconds() / 1000);
		return (diff + Time::diffInSeconds(other));
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	int DateTime::diffInMilliseconds( const DateTime& other ) const
	{
		int diff = diffInDays(other) * getMaxMilliseconds();
		return (diff + Time::diffInMilliseconds(other));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void DateTime::setDate( const Date& date )
	{
		Date::operator=(date);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void DateTime::setTime( const Time& time )
	{
		Time::operator=(time);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	DateTime& DateTime::operator=( const DateTime& copy )
	{
		setDate( copy.getDate() );
		setTime( copy.getTime() );

		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void DateTime::hourRollover( int dayDir )
	{
		Date::addDays(dayDir);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DateTime::operator==( const DateTime& other ) const
	{
		return (getDate() == other.getDate() && getTime() == other.getTime());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DateTime::operator!=( const DateTime& other ) const
	{
		return !(*this == other);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DateTime::operator<( const DateTime& other ) const
	{
		if( getDate() == other.getDate() ) {
			return (getTime() < other.getTime());
		}
		
		return (getDate() < other.getDate());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DateTime::operator<=( const DateTime& other ) const
	{
		if( getDate() == other.getDate() ) {
			return (getTime() <= other.getTime());
		}
		
		return (getDate() <= other.getDate());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DateTime::operator>( const DateTime& other ) const
	{
		if( getDate() == other.getDate() ) {
			return (getTime() > other.getTime());
		}
		
		return (getDate() > other.getDate());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool DateTime::operator>=( const DateTime& other ) const
	{
		if( getDate() == other.getDate() ) {
			return (getTime() >= other.getTime());
		}
		
		return (getDate() >= other.getDate());
	}


}}	// namespaces
