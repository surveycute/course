//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/Date.h
//**

#ifndef __blue_util_Date_h_included__
#define __blue_util_Date_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace util {

	/**
	 * \class Date
	 * \brief %Date manipulation.
	 * \ingroup Util
	 *
	 * Allows %Date manipulation.  Internally, the %Date class stores the
	 * date as a julian date.  For more information on julian dates see the
	 * following website: <code>
	 * http://serendipity.magnet.ch/hermetic/cal_stud/jdn.htm</code>
	 *
	 * \sa Time, DateTime
	 */
	class BLUE_EXPORT Date
	{
	public:

		/** Values that can be used when working with months. */
		enum month_e
		{
			JAN =  1,  //!< January
			FEB =  2,  //!< February
			MAR =  3,  //!< March
			APR =  4,  //!< April
			MAY =  5,  //!< May
			JUN =  6,  //!< June
			JUL =  7,  //!< July
			AUG =  8,  //!< August
			SEP =  9,  //!< September
			OCT = 10,  //!< October
			NOV = 11,  //!< November
			DEC = 12,  //!< December
		};

		/** Values that can be used when working with weekdays. */
		enum weekday_e
		{
			MON = 1,  //!< Monday
			TUE = 2,  //!< Tuesday
			WED = 3,  //!< Wednesday
			THU = 4,  //!< Thursday
			FRI = 5,  //!< Friday
			SAT = 6,  //!< Saturday
			SUN = 7,  //!< Sunday
		};

		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		Date( int month = JAN, int day = 1, int year = 1900 );
		/** Constructor. */
		Date( uint32_t julian );
		/** Copy constructor. */
		Date( const Date& copy );

		/** Destructor. */
		~Date();

		/** Returns a %Date with the system's current date. */
		static Date getToday();


		// ===========================================================
		//  query
		// ===========================================================

		/** Returns the month.  This is a number between 1 and 12. */
		int getMonth() const;
		/** Returns the day of the month. */
		int getDay() const;
		/** Returns the year. */
		int getYear() const;
		/** Returns the weekday. */
		int getWeekday() const;

		/** Returns the Julian value of the %Date. */
		uint32_t getJulian() const;

		/**
		 * Returns the difference in time between the two Dates in months.
		 * If the value returned is negative, then the %Date given is earlier
		 * than the instance calling the function.
		 */
		int diffInMonths( const Date& other ) const;
		/**
		 * Returns the difference in time between the two Dates in days.
		 * If the value returned is negative, then the %Date given is earlier
		 * than the instance calling the function.
		 */
		int diffInDays( const Date& other ) const;
		/**
		 * Returns the difference in time between the two Dates in years.
		 * If the value returned is negative, then the %Date given is earlier
		 * than the instance calling the function.
		 */
		int diffInYears( const Date& other ) const;

		/** Determines if the %Date's year is a leap year. */
		bool isLeapYear() const;
		/** Determines if the given year is a leap year. */
		static bool isLeapYear( int year );

		/** Returns the number of days in the %Date's month. */
		int daysInMonth() const;
		/** Returns the number of days in the given month. */
		static int daysInMonth( int month, int year );

		/** Determines if the two Dates are the same. */
		bool operator==( const Date& other ) const;
		/** Determines if the two Dates are not the same. */
		bool operator!=( const Date& other ) const;
		/** Determines if this %Date is earlier than the other. */
		bool operator<( const Date& other ) const;
		/** Determines if this %Date is earlier or equal to the other. */
		bool operator<=( const Date& other ) const;
		/** Determines if this %Date is later than the other. */
		bool operator>( const Date& other ) const;
		/** Determines if this %Date is later or equal to the other. */
		bool operator>=( const Date& other ) const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Sets the month. */
		void setMonth( int month );
		/**
		 * Sets the day of the month.  If the given day exceeds the number of
		 * days in the current month, the day is clamped to the last day of
		 * the month.
		 */
		void setDay( int day );
		/** Sets the year. */
		void setYear( int year );
		/** Combines calls to setMonth, setDay and setYear. */
		void set( int month, int day, int year );

		/** Sets this %Date using a julian value. */
		void setJulian( uint32_t julian );

		/**
		 * Adds the given number of months to the current date.
		 * If the month/day combination isn't valid, the month rolls over.
		 * For example, adding 1 month to Jan 30 on a non leap year will
		 * result in the date Mar 2.
		 */
		void addMonths( int months );
		/**
		 * Adds the given number of days to the current date.  If the month/day
		 * combination isn't valid, the month rolls over.
		 */
		void addDays( int days );
		/**
		 * Adds the given number of years to the current date.  If the 
		 * month/day/year combination isn't valid, the month/day rolls over.
		 */
		void addYears( int years );

		/** Assignment operator. */
		Date& operator=( const Date& copy );


		// ===========================================================
		//  julian date functions
		// ===========================================================

		/** Converts the given month/day/year to a julian date. */
		static uint32_t convertToJulian( int month, int day, int year );
		/** Converts the given julian date to a month/day/year. */
		static void convertFromJulian( uint32_t julian, int& month, int& day, int& year );

	private:
		uint32_t m_julian;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
