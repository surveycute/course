//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/CommandLineArgs.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "CommandLineArgs.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace util {

	// ---------------------------------------------------------------------------------------------------------------------

	CommandLineArgs::CommandLineArgs()
	{
		reset(true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CommandLineArgs::CommandLineArgs( int argc, char** argv )
	{
		reset(true);
		setCommandArgs(argc, argv);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CommandLineArgs::CommandLineArgs( Array<String> args )
	{
		reset(true);
		setCommandArgs(args);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CommandLineArgs::CommandLineArgs( String args )
	{
		reset(true);
		setCommandArgs(args);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CommandLineArgs::CommandLineArgs( const CommandLineArgs& copy )
	{
		reset(true);
		m_args      = copy.m_args.copy();
		m_options   = copy.m_options.copy();
		m_trailing  = copy.m_trailing.copy();
		m_usageLine = copy.m_usageLine;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CommandLineArgs::~CommandLineArgs()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> CommandLineArgs::getArgs() const
	{
		return (m_args);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> CommandLineArgs::getOptions() const
	{
		Array<String> options( m_options.getSize() );
		
		for( int i = 0; i < options.getSize(); ++i ) {
			options[i] = m_options[i].m_name;
		}

		return (options);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool CommandLineArgs::isOptionSet( String name ) const
	{
		for( int i = 0; i < m_options.getSize(); ++i ) {
			if( m_options[i].m_name == name ) {
				return (m_options[i].m_set);
			}
		}

		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String CommandLineArgs::getOptionParm( String name )
	{
		for( int i = 0; i < m_options.getSize(); ++i ) {
			if( m_options[i].m_name == name ) {
				return (m_options[i].m_parm);
			}
		}

		return (String::null);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> CommandLineArgs::getTrailingArgs() const
	{
		return (m_trailing);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::addOption( String name, String brief, String full, bool hasParm, String desc )
	{
		option opt;
		opt.m_name    = name;
		opt.m_brief   = brief;
		opt.m_full    = full;
		opt.m_hasParm = hasParm;
		opt.m_desc    = desc;
		opt.m_set     = false;

		m_options.append(opt);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::remOption( String name )
	{
		for( int i = 0; i < m_options.getSize(); ++i ) {
			if( m_options[i].m_name == name ) {
				m_options.remove(i);
				break;
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::setUsageLine( String usageLine )
	{
		m_usageLine = usageLine;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String CommandLineArgs::displayUsage( String endLine )
	{
		String out;

		if( !m_usageLine.isEmpty() ) {
			out += m_usageLine + endLine + endLine;
		}

		for( int i = 0; i < m_options.getSize(); ++i ) {
			String brief = String("-" + m_options[i].m_brief.left(3)).padLeft(3, ' ');
			String full  = "--" + m_options[i].m_full.left(17).padRight(17, ' ');

			String line  = brief + ", " + full + ": " + m_options[i].m_desc;
			out += line + endLine;
		}

		return (out);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::setCommandArgs( int argc, char** argv )
	{
		Array<String> args(argc);
		for( int i = 0; i < argc; ++i ) {
			args[i] = argv[i];
		}

		setCommandArgs(args);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::setCommandArgs( Array<String> args )
	{
		m_args = args;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::setCommandArgs( String args )
	{
		Array<String> argArray;

		int argLen = 0;
		bool inQuote = false;
		while(args.getLength() > 0) {
			String check = args.subString(argLen++, 1).trim();

			if( inQuote ) {
				if( check == "\"" ) {
					inQuote = false;
				}
			}
			else {
				if( check == "\"" ) {
					inQuote = true;
				}
				else if( check.isEmpty() ) {
					String value = args.subString(0, argLen - 1).trim();
					if( (value.beginsWith("\"") && value.endsWith("\"")) || value.beginsWith("\'") && value.endsWith("\'") ) {
						value = value.subString( 1, value.getLength() - 2 );
					}
					if( !value.isEmpty() ) {
						argArray.append( value );
						args = args.subString( argLen );
						argLen = 0;
					}
				}
			}
		}

		setCommandArgs(argArray);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::processArgs()
	{
		try {
			int  lastOptIdx = -1;
			bool lastWasOpt = false;

			for( int i = 1; i < m_args.getSize(); ++i ) {

				enum opt_val_e { NO_OP, BRIEF, FULL };
				opt_val_e optVal = NO_OP;

				if( m_args[i].beginsWith("--") ) {
					optVal = FULL;
				}
				else if( m_args[i].beginsWith("-") ) {
					optVal = BRIEF;
				}
				else {
					optVal = NO_OP;
				}


				if( lastWasOpt ) {
					if( optVal != NO_OP ) {
						throw CommandLineArgsInvalidException();
					}

					m_options[lastOptIdx].m_parm = m_args[i];

					lastWasOpt = false;
					lastOptIdx = -1;
				}
				else {
					if( optVal == NO_OP ) {
						m_trailing.append( m_args[i] );
					}
					else {
						bool found = false;
						String option = m_args[i].subString( optVal == BRIEF ? 1 : 2 );
						for( int idx = 0; idx < m_options.getSize(); ++idx ) {
							String compare = (optVal == BRIEF ? m_options[idx].m_brief : m_options[idx].m_full);
							if( option == compare ) {
								if( m_options[idx].m_set == true ) {
									throw CommandLineArgsInvalidException();
								}

								found = true;
								m_options[idx].m_set = true;

								if( m_options[idx].m_hasParm ) {
									lastWasOpt = true;
									lastOptIdx = idx;
								}
							}
						}

						if( !found ) {
							throw CommandLineArgsInvalidException();
						}
					}
				}
			}

			if( lastWasOpt ) {
				// last argument was an option that required a parameter!
				throw CommandLineArgsInvalidException();
			}
		}
		catch(...) {
			reset();	// don't leave the object in a half processed state
			throw;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void CommandLineArgs::reset( bool removeOptions )
	{
		m_args.clear();
		m_trailing.clear();

		if( removeOptions ) {
			m_options.clear();
			m_usageLine = String::null;
		}
		else {
			for( int i = 0; i < m_options.getSize(); ++i ) {
				m_options[i].m_set  = false;
				m_options[i].m_parm = String::null;
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	CommandLineArgs& CommandLineArgs::operator=( const CommandLineArgs& copy )
	{
		reset(true);
		m_args      = copy.m_args.copy();
		m_options   = copy.m_options.copy();
		m_trailing  = copy.m_trailing.copy();
		m_usageLine = copy.m_usageLine;

		return (*this);
	}

}}	// namespaces
