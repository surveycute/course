//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/DateTime.h
//**

#ifndef __blue_util_DateTime_h_included__
#define __blue_util_DateTime_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Util/Date.h"
#include "Blue/Util/Time.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace util {

	/**
	 * \class DateTime
	 * \brief %Date and %Time manipulation.
	 * \ingroup Util
	 */
	class BLUE_EXPORT DateTime : public Date, public Time
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		DateTime();
		/** Constructor. */
		DateTime( const Date& date, const Time& time );
		/** Constructor. */
		DateTime( int month, int day, int year, int hour, int minute, int second, int milli = 0 );
		/** Copy constructor. */
		DateTime( const DateTime& copy );

		/** Destructor. */
		~DateTime();

		/** Gets the current date and time. */
		static DateTime getCurrent();


		// ===========================================================
		//  query
		// ===========================================================

		/** Get the %Date portion of the %DateTime. */
		Date getDate() const;
		/** Get the %Time portion of the %DateTime. */
		Time getTime() const;

		/**
		 * Returns the difference in time between the two DateTimes in hours.
		 * This is actually the difference in minutes divided by 60, not
		 * subtracting the results returned by DateTime::getHour.
		 * If the value returned is negative, then the %DateTime given is earlier
		 * than the instance calling the function.  Please note that this function
		 * will fail miserably if the two dates are very far apart.
		 */
		int diffInHours( const DateTime& other ) const;
		/**
		 * Returns the difference in time between the two DateTimes in minutes.
		 * If the value returned is negative, then the %DateTime given is earlier
		 * than the instance calling the function.  Please note that this function
		 * will fail miserably if the two dates are very far apart.
		 */
		int diffInMinutes( const DateTime& other ) const;
		/**
		 * Returns the difference in time between the two DateTimes in seconds.
		 * If the value returned is negative, then the %DateTime given is earlier
		 * than the instance calling the function.  Please note that this function
		 * will fail miserably if the two dates are very far apart.
		 */
		int diffInSeconds( const DateTime& other ) const;
		/**
		 * Returns the difference in time between the two DateTimes in milliseconds.
		 * If the value returned is negative, then the %DateTime given is earlier
		 * than the instance calling the function.  Please note that this function
		 * will fail miserably if the two dates are very far apart.
		 */
		int diffInMilliseconds( const DateTime& other ) const;


		/** Determines if the two DateTimes are the same. */
		bool operator==( const DateTime& other ) const;
		/** Determines if the two DateTimes are not the same. */
		bool operator!=( const DateTime& other ) const;
		/** Determines if this %DateTime is earlier than the other. */
		bool operator<( const DateTime& other ) const;
		/** Determines if this %DateTime is earlier or equal to the other. */
		bool operator<=( const DateTime& other ) const;
		/** Determines if this %DateTime is later than the other. */
		bool operator>( const DateTime& other ) const;
		/** Determines if this %DateTime is later or equal to the other. */
		bool operator>=( const DateTime& other ) const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Set the %Date portion of the %DateTime. */
		void setDate( const Date& date );
		/** Set the %Time portion of the %DateTime. */
		void setTime( const Time& time );

		/** Assignment operator. */
		DateTime& operator=( const DateTime& copy );


	private:
		virtual void hourRollover( int dayDir );
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
