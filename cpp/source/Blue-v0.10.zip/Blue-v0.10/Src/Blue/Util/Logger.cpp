//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/Logger.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Logger.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

namespace {
	using namespace blue;
	using namespace blue::kernel;

	class LoggerAutoLock
	{
	public:
		LoggerAutoLock( bool threadSafe, Mutex* mutex )
			:m_threadSafe(threadSafe), m_mutex(mutex)
		{
			if( m_threadSafe ) {
				m_mutex->lock();
			}
		}

		~LoggerAutoLock()
		{
			if( m_threadSafe ) {
				m_mutex->unlock();
			}
		}

	private:
		bool   m_threadSafe;
		Mutex* m_mutex;
	};

}


// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace util {

	// ---------------------------------------------------------------------------------------------------------------------

	Logger::Logger() :m_level(INFO), m_threadSafe(false), m_mutex(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Logger::~Logger()
	{
		for( int i = 0; i < m_handlers.getSize(); ++i ) {
			if( m_handlers[i].m_autoDelete ) {
				delete m_handlers[i].m_handler;
			}
		}
		if( m_mutex != 0 ) {
			delete m_mutex;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Logger::level_e Logger::getLevel() const
	{
		return (m_level);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<Logger::Handler*> Logger::getHandlers()
	{
		LoggerAutoLock lock(m_threadSafe, m_mutex);

		Array<Handler*> handlers(m_handlers.getSize());
		for( int i = 0; i < m_handlers.getSize(); ++i ) {
			handlers[i] = m_handlers[i].m_handler;
		}
		return (handlers);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	const Array<Logger::Handler*> Logger::getHandlers() const
	{
		return ((Logger*)this)->getHandlers();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Logger::isThreadSafe() const
	{
		return (m_threadSafe);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::setLevel( level_e level )
	{
		m_level = level;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::addHandler( Handler* handler, bool autoDelete )
	{
		LoggerAutoLock lock(m_threadSafe, m_mutex);

		handler_info info = {handler, autoDelete};
		m_handlers.append(info);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::removeHandler( Handler* handler )
	{
		LoggerAutoLock lock(m_threadSafe, m_mutex);

		for( int i = 0; i < m_handlers.getSize(); ++i ) {
			if( m_handlers[i].m_handler == handler ) {
				if( m_handlers[i].m_autoDelete ) {
					delete m_handlers[i].m_handler;
				}
				m_handlers.remove(i);
				break;
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::setThreadSafe( bool threadSafe )
	{
		if( !threadSafe ) {
			if( m_mutex != 0 ) {
				delete m_mutex;
				m_mutex = 0;
			}
			m_threadSafe = false;
		}
		else {
			if( m_mutex == 0 ) {
				m_mutex = new Mutex();
			}
			m_threadSafe = true;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::log( level_e level, String message )
	{
		LoggerAutoLock lock(m_threadSafe, m_mutex);

		if( m_level >= level ) {
			DateTime dt = DateTime::getCurrent();

			for( int i = 0; i < m_handlers.getSize(); ++i ) {
				m_handlers[i].m_handler->write(dt, message);
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::log( level_e level, const Exception& e )
	{
		log(level, e.getException() + ": " + e.getDescription());
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::urgent( String message )
	{
		log(URGENT, message);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::urgent( const Exception& e )
	{
		log(URGENT, e);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::warning( String message )
	{
		log(WARNING, message);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::warning( const Exception& e )
	{
		log(WARNING, e);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::info( String message )
	{
		log(INFO, message);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::info( const Exception& e )
	{
		log(INFO, e);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::verbose( String message )
	{
		log(VERBOSE, message);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Logger::verbose( const Exception& e )
	{
		log(VERBOSE, e);
	}



	// ---------------------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------------------------

	FileLogHandler::FileLogHandler( String filename, data::File::access_e access, bool logMilliseconds )
		:m_file(filename, access), m_logMilliseconds(logMilliseconds)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	FileLogHandler::~FileLogHandler()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void FileLogHandler::write( const DateTime& dt, String message )
	{
		String dtFormat = String::format("%04d/%02d/%02d %02d:%02d:%02d{1}: ",
		                                  dt.getYear(), dt.getMonth(), dt.getDay(),
		                                  dt.getHour(), dt.getMinute(), dt.getSecond())
										  .arg(m_logMilliseconds ? String::format(".%03d", dt.getMillisecond()) : String::null);
		m_file.write(dtFormat);
		m_file.write(message);
		m_file.write(String("\n", String::STATIC));
		m_file.flush();
	}

}}	// namespaces
