//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/Logger.h
//**

#ifndef __blue_util_Logger_h_included__
#define __blue_util_Logger_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Common/Array.h"
#include "Blue/Data/File.h"
#include "Blue/Kernel/Mutex.h"
#include "Blue/Util/DateTime.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace util {

	/**
	 * \class Logger
	 * \brief Used to keep logs of application activity.
	 * \ingroup Util
	 *
	 * The %Logger class is provided as a way to keep track of what
	 * happens during the execution of an application.  By using
	 * the Logger::Handler class, extreme flexibility is given as to
	 * how the log messages are actually logged.
	 *
	 * \sa Logger::Handler
	 */
	class BLUE_EXPORT Logger
	{
	public:

		/**
		 * \class Handler
		 * \brief Used by a Logger to actually record the log message.
		 * \ingroup Util
		 */
		class BLUE_EXPORT Handler
		{
		public:
			/** Destructor. */
			virtual ~Handler()
			{}

			/** Write the message. */
			virtual void write( const DateTime& dt, String message ) = 0;

		protected:
			Handler()
			{}
		};


		/** Level of logging. */
		enum level_e
		{
			URGENT  = 1,  //!< Log urgent messages
			WARNING = 2,  //!< Log warning messages and everything above
			INFO    = 3,  //!< Log info messages and everything above
			VERBOSE = 4,  //!< Log verbose messages and everything above
		};


		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		Logger();

		/** Destructor. */
		~Logger();


		// ===========================================================
		//  query
		// ===========================================================

		/** Gets the current level of logging being used. */
		level_e getLevel() const;

		/** Gets the LogHandlers for this %Logger. */
		Array<Handler*> getHandlers();
		/** overload */
		const Array<Handler*> getHandlers() const;

		/** Determines if the %Logger is in thread-safe mode. */
		bool isThreadSafe() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Sets the level of logging to use. */
		void setLevel( level_e level );

		/** Adds a LogHandler to this %Logger. */
		void addHandler( Handler* handler, bool autoDelete = false );
		/** Removes a LogHandler from this %Logger. */
		void removeHandler( Handler* handler );

		/** Tells the %Logger to enter or exit thread-safe mode. */
		void setThreadSafe( bool threadSafe );

		/**
		 * Logs the given message at the given level.  If the level
		 * being used by this %Logger is higher than the given level,
		 * the message is ignored.  For example, if the current level
		 * of Logger is set to WARNING, any messages using the level
		 * of VERBOSE will not be written to the log.
		 */
		void log( level_e level, String message );
		/** overload */
		void log( level_e level, const Exception& e );

		/** Logs an URGENT message. */
		void urgent( String message );
		/** overload */
		void urgent( const Exception& e );

		/** Logs a WARNING message. */
		void warning( String message );
		/** overload */
		void warning( const Exception& e );

		/** Logs an INFO message. */
		void info( String message );
		/** overload */
		void info( const Exception& e );

		/** Logs a VERBOSE message. */
		void verbose( String message );
		/** overload */
		void verbose( const Exception& e );


	private:
		struct handler_info
		{
			Handler* m_handler;
			bool     m_autoDelete;
		};

		level_e m_level;
		bool m_threadSafe;
		kernel::Mutex* m_mutex;
		Array<handler_info> m_handlers;

	};



	/**
	 * \class FileLogHandler
	 * \brief Logs to a file on disk.
	 * \ingroup Util
	 */
	class BLUE_EXPORT FileLogHandler :public Logger::Handler
	{
	public:
		/** Constructor. */
		FileLogHandler( String filename, data::File::access_e access = data::File::WRITEOVER, bool logMilliseconds = false);

		/** Destructor. */
		virtual ~FileLogHandler();

		/** Overload of Logger::Handler::write(). */
		virtual void write( const DateTime& dt, String message );

	private:
		data::File m_file;
		bool m_logMilliseconds;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
