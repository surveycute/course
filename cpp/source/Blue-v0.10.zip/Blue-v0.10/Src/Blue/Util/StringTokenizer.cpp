//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Util/StringTokenizer.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "StringTokenizer.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace util {

	// ---------------------------------------------------------------------------------------------------------------------

	StringTokenizer::StringTokenizer()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	StringTokenizer::StringTokenizer( const StringTokenizer& copy )
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	StringTokenizer::~StringTokenizer()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Array<String> StringTokenizer::tokenize( String str, String delimiters, flags32_t flags )
	{
		Array<String> results;
		Array<container*> contains(5);
		int containIdx = -1;
		int lastDelimit = 0;

		for( int i = 0; i < str.getLength(); ++i ) {
			bool skipContainers = false;

			if( containIdx >= 0 ) {
				String containEnd = contains[containIdx]->m_end;
				if( str.subString(i, containEnd.getLength()) == containEnd ) {
					--containIdx;
					skipContainers = true;
				}
				else {
					skipContainers = (contains[containIdx]->m_type == EXCLUSIVE);
				}
			}

			if( containIdx < 0 ) {
				char ch = str[i];
				for( int iD = 0; iD < delimiters.getLength(); ++iD ) {
					if( ch == delimiters[iD] ) {
						if( lastDelimit != i ) {
							String token = str.subString(lastDelimit, i - lastDelimit);
							if( !(flags & NO_WHITESPACE) || token.trim().getLength() > 0 ) {
								results.append( (flags & TRIM_RESULTS ? token.trim() : token) );
							}
						}

						if( flags & KEEP_DELIMITERS ) {
							results.append(str.subString(i, 1));
						}
						lastDelimit = i + 1;
						break;
					}
				}
			}

			if( !skipContainers ) {
				for( int iC = 0; iC < m_containers.getSize(); ++iC ) {
					String beg = m_containers[iC].m_beg;
					if( str.subString(i, beg.getLength()) == beg ) {
						if( contains.getSize() == containIdx + 1 ) {
							contains.resize(contains.getSize() * 2);
						}

						contains[++containIdx] = &m_containers[iC];
						break;
					}
				}
			}
		}

		if( lastDelimit < str.getLength() ) {
			String token = str.subString(lastDelimit);
			if( !(flags & NO_WHITESPACE) || token.trim().getLength() > 0 ) {
				results.append( (flags & TRIM_RESULTS ? token.trim() : token) );
			}
		}

		return (results);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void StringTokenizer::addContainer( String begin, String end, container_type_e type )
	{
		container contain;
		contain.m_beg  = begin;
		contain.m_end  = end;
		contain.m_type = type;

		m_containers.append(contain);
	}


}}	// namespaces
