//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/InetAddress.h
//**

#ifndef __blue_network_InetAddress_h_included__
#define __blue_network_InetAddress_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace network {

	/**
	 * \class InetAddress
	 * \brief Represents an IP address.
	 * \ingroup Network
	 *
	 * The %InetAddress class simply stores an internet address and
	 * can convert to and from string representation of the numeric
	 * version of the IP address.  This class has no methods for
	 * name resolution.  If a string is passed into this class that
	 * does not contain a valid IP address ("127.0.0.1"), an
	 * InvalidInetAddressException will be thrown.
	 *
	 * To resolve names, use the Dns class.
	 *
	 * \sa Dns
	 */
	class BLUE_EXPORT InetAddress
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		InetAddress();
		/** Constructor. */
		InetAddress( uint32_t address );
		/** Constructor. */
		InetAddress( String address );
		/** Copy constructor. */
		InetAddress( const InetAddress& copy );

		/** Destructor. */
		~InetAddress();


		// ===========================================================
		//  query
		// ===========================================================

		/** Returns the IP address. */
		uint32_t getAddress() const;

		/** Returns the IP address in string format ("127.0.0.1"). */
		String toString() const;

		/** Determines if the two addresses are equal. */
		bool operator==( const InetAddress& other ) const;
		/** Determines if the two addresses are not equal. */
		bool operator!=( const InetAddress& other ) const;

		/**
		 * Builds up an IP address.
		 *
		 * \code
		 * InetAddress addr = InetAddress::build(127,0,0,1);
		 * \endcode
		 */
		static uint32_t build( uint8_t a1, uint8_t a2, uint8_t a3, uint8_t a4 );

		/**
		 * Decomposes an IP address into its individual components.
		 */
		static void decompose( uint32_t addr, uint8_t& a1, uint8_t& a2, uint8_t& a3, uint8_t& a4 );
		/** overload */
		static void decompose( uint32_t addr, uint8_t a[4] );

		/** Determines if the string contains a valid IP address. */
		static bool isValid( String address );


		// ===========================================================
		//  manipulation
		// ===========================================================

		/** Sets the address. */
		void setAddress( uint32_t address );
		/**
		 * Sets the address from the address that is contained in the
		 * string.  The address must be formatted with the standard
		 * dot notation ("127.0.0.1") or an InvalidInetAddressException
		 * will be thrown.
		 */
		void setAddress( String address );

		/** Reassigns this %InetAddress. */
		InetAddress& operator=( const InetAddress& other );
		/** overload */
		InetAddress& operator=( uint32_t address );


	private:
		uint32_t m_address;

	};


	/**
	 * \class InvalidInetAddressException
	 * \brief Thrown when a string is passed to InetAddress that does
	 *  not contain a valid IP address.
	 * \ingroup NetworkExceptions
	 */
	class BLUE_EXPORT InvalidInetAddressException :public common::Exception
	{
	public:
		InvalidInetAddressException( String address, String desc = String("The address is not a valid IP address", String::STATIC) )
			:Exception(desc), m_address(address) {}


		virtual String getException() const {
			return (String("InvalidInetAddressException", String::STATIC));
		}

		String getInetAddress() const {
			return (m_address);
		}

	private:
		String m_address;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
