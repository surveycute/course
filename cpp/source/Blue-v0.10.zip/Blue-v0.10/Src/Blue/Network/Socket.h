//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/Socket.h
//**

#ifndef __blue_network_Socket_h_included__
#define __blue_network_Socket_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Data/Device.h"

#if defined(BLUE_PLATFORM_WIN32)
#	include <winsock2.h>
#else
#	error "Socket needs an implementation for this platform."
#endif


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace network {

	/**
	 * \class Socket
	 * \brief Base class for socket manipulation.
	 * \ingroup Network
	 *
	 * The %Socket class is not meant to be used by applications, it
	 * is a convenient base class for the more specialized socket
	 * manipulating classes (such as TcpSocket and UdpSocket).
	 */
	class BLUE_EXPORT Socket :public data::Device
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Destructor. */
		virtual ~Socket();

		virtual void close();


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the SOCKET for this %Socket.  This should be used
		 * with caution.
		 */
		SOCKET getSocket() const;

		virtual bool isOpen() const;
		virtual bool isReadable() const;
		virtual bool isWriteable() const;
		virtual bool isSeekable() const;

		virtual bool canRead() const;
		virtual bool canWrite() const;

		virtual int getSize() const;   // not supported
		virtual int getPos() const;    // not supported


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Sets the SOCKET for this %Socket.  This should be used with
		 * caution.
		 */
		void setSocket( SOCKET socket );

		virtual void purge();
		virtual void flush();

		using Device::read; // allow all read functions to be called
		virtual int read( void* buffer, int size );

		using Device::write; // allow all write functions to be called
		virtual int write( const void* data, int size );

		// The pos functions are not supported because
		// sockets are not seekable.  See data::Device documentation.
		virtual void setPos( int, data::seek_method_e );
		virtual void pushPos();
		virtual void popPos();


	protected:
		/** Constructor. */
		Socket();

		SOCKET m_socket;	//!< The socket object.


	private:
		/**
		 * Copy constructor. Private because Sockets should not be
		 * manipulated by more than one instance.
		 */
		Socket( const Socket& );
		/** Private assignment operator. See copy constructor documentation. */
		const Socket& operator=( const Socket& );
	};



	/**
	 * \class SocketException
	 * \brief Base class for all Socket exceptions.
	 * \ingroup NetworkExceptions
	 */
	class BLUE_EXPORT SocketException :public common::Exception
	{
	public:
		SocketException( String desc = String("A socket error has occurred", String::STATIC) )
			:Exception(desc) {}

		virtual String getException() const {
			return (String("SocketException", String::STATIC));
		}
	};


	/**
	 * \class SocketCreateException
	 * \brief Thrown when a Socket cannot be created.
	 * \ingroup NetworkExceptions
	 */
	class BLUE_EXPORT SocketCreateException :public SocketException
	{
	public:
		SocketCreateException( String desc = String("Cannot create socket", String::STATIC) )
			:SocketException(desc) {}

		virtual String getException() const {
			return (String("SocketCreateException", String::STATIC));
		}
	};


}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
