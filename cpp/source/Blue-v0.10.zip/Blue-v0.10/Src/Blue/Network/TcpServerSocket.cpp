//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/TcpServerSocket.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "TcpServerSocket.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace network {

	// ---------------------------------------------------------------------------------------------------------------------

	TcpServerSocket::TcpServerSocket() :m_port(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	TcpServerSocket::TcpServerSocket( uint16_t port ) :m_port(0)
	{
		setPort(port);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	TcpServerSocket::~TcpServerSocket()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void TcpServerSocket::listen()
	{
		if( isOpen() ) {
			return;
		}

		try {
			m_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
			if( m_socket == INVALID_SOCKET ) {
				throw SocketCreateException();
			}

			sockaddr_in addr;
			memset(&addr, 0, sizeof(addr));

			addr.sin_family      = AF_INET;
			addr.sin_addr.s_addr = INADDR_ANY;
			addr.sin_port        = htons(m_port);

			if( bind(m_socket, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR ) {
				throw TcpServerSocketListenException();
			}

			if( ::listen(m_socket, SOMAXCONN) == SOCKET_ERROR ) {
				throw TcpServerSocketListenException();
			}
		}
		catch(...) {
			close();
			throw;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool TcpServerSocket::isReadable() const
	{
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool TcpServerSocket::isWriteable() const
	{
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint16_t TcpServerSocket::getPort() const
	{
		return (m_port);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void TcpServerSocket::setPort( uint16_t port )
	{
		if( isOpen() ) {
			throw data::DeviceInvalidModeException($("Cannot set TCP listening port while server socket is listening"));
		}

		m_port = port;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void TcpServerSocket::accept( TcpSocket& client )
	{
		accept(client, -1); // -1 indicates no timeout
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool TcpServerSocket::accept( TcpSocket& client, int32_t timeout )
	{
		if( m_socket == INVALID_SOCKET ) {
			throw data::DeviceInvalidModeException($("Cannot accept a TCP connection when server socket is not listening"));
		}

		SOCKET socket = INVALID_SOCKET;
		bool doAccept = true;

		if( timeout >= 0 ) {
			fd_set fds;
			timeval tv = { timeout / 1000, timeout % 1000 };

			FD_ZERO(&fds);
			FD_SET(m_socket, &fds);
			select(m_socket, &fds, 0, 0, &tv);

			if( !FD_ISSET(m_socket, &fds) ) {
				doAccept = false;
			}
		}

		if( doAccept ) {
			socket = ::accept(m_socket, 0, 0);
		}

		client.setSocket(socket);
		
		return (doAccept);
	}

}}	// namespaces
