//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/Socket.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Socket.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

#if defined(BLUE_PLATFORM_WIN32)
void win32_initWinsock();

#define ioctl ioctlsocket
#endif


// Functions ===============================================================================================================

namespace blue {
namespace network {

	// ---------------------------------------------------------------------------------------------------------------------

	Socket::Socket() :m_socket(INVALID_SOCKET)
	{
		#if defined(BLUE_PLATFORM_WIN32)
		win32_initWinsock();
		#endif
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Socket::~Socket()
	{
		close();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Socket::close()
	{
		if( m_socket != INVALID_SOCKET ) {
			shutdown(m_socket, SD_BOTH);
			#if defined(BLUE_PLATFORM_WIN32)
			closesocket(m_socket);
			#else
			close(m_socket);
			#endif
			m_socket = INVALID_SOCKET;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	SOCKET Socket::getSocket() const
	{
		return (m_socket);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Socket::isOpen() const
	{
		if( m_socket == INVALID_SOCKET ) {
			return (false);
		}

		timeval tv = {0,0};
		fd_set  fds;

		FD_ZERO(&fds);
		FD_SET(m_socket, &fds);
		select(m_socket, &fds, 0, 0, &tv);

		if( FD_ISSET(m_socket, &fds) ) {
			unsigned long waiting = -1;
			if( ioctl(m_socket, FIONREAD, &waiting) == 0 ) {
				return (waiting != 0);
			}
		}
		return (true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Socket::isReadable() const
	{
		return isOpen();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Socket::isWriteable() const
	{
		return isOpen();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Socket::isSeekable() const
	{
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Socket::canRead() const
	{
		if( m_socket == INVALID_SOCKET || !isReadable() ) {
			return (false);
		}

		timeval tv = {0,0};
		fd_set  fds;

		FD_ZERO(&fds);
		FD_SET(m_socket, &fds);
		select(m_socket, &fds, 0, 0, &tv);

		if( FD_ISSET(m_socket, &fds) ) {
			unsigned long waiting = -1;
			if( ioctl(m_socket, FIONREAD, &waiting) == 0 ) {
				return (waiting != 0);
			}
		}
		
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool Socket::canWrite() const
	{
		if( m_socket == INVALID_SOCKET || !isWriteable() ) {
			return (false);
		}

		timeval tv = {0,0};
		fd_set  fds;

		FD_ZERO(&fds);
		FD_SET(m_socket, &fds);
		select(m_socket, 0, &fds, 0, &tv);

		if( FD_ISSET(m_socket, &fds) ) {
			return (true);
		}
		
		return (false);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Socket::getSize() const
	{
		throw data::DeviceInvalidModeException($("Socket is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Socket::getPos() const
	{
		throw data::DeviceInvalidModeException($("Socket is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	void Socket::setSocket( SOCKET socket )
	{
		close();
		m_socket = socket;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Socket::purge()
	{
		// nothing to do.
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Socket::flush()
	{
		// nothing to do.
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Socket::read( void* buffer, int size )
	{
		if( !isReadable() ) {
			throw data::DeviceInvalidModeException($("Cannot read when not readable"));
		}

		if( size == 0 ) {
			return (0);
		}

		int recved = recv(m_socket, (char*)buffer, size, 0);
		if( recved == 0 ) {
			// socket has been closed
			close();
			return (0);
		}
		if( recved == SOCKET_ERROR ) {
			throw data::DeviceReadInterruptException();
		}

		return (recved);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int Socket::write( const void* data, int size )
	{
		if( !isWriteable() ) {
			throw data::DeviceInvalidModeException($("Cannot write when not writeable"));
		}

		int sent = send(m_socket, (char*)data, size, 0);
		if( sent == SOCKET_ERROR ) {
			throw data::DeviceWriteInterruptException();
		}

		return (sent);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Socket::setPos( int, data::seek_method_e )
	{
		throw data::DeviceInvalidModeException($("Socket is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Socket::pushPos()
	{
		throw data::DeviceInvalidModeException($("Socket is not seekable"));
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void Socket::popPos()
	{
		throw data::DeviceInvalidModeException($("Socket is not seekable"));
	}


}}	// namespaces
