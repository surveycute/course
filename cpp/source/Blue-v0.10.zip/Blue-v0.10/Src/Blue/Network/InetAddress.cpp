//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/InetAddress.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "InetAddress.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

#if defined(BLUE_PLATFORM_WIN32)
	void win32_initWinsock();
#endif

// Functions ===============================================================================================================

namespace blue {
namespace network {

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress::InetAddress() :m_address(0)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress::InetAddress( uint32_t address )
	{
		setAddress(address);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress::InetAddress( String address )
	{
		setAddress(address);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress::InetAddress( const InetAddress& copy ) :m_address(copy.m_address)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress::~InetAddress()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint32_t InetAddress::getAddress() const
	{
		return (m_address);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	String InetAddress::toString() const
	{
		return String::format("%d.%d.%d.%d", (m_address >> 24) & 0xff,
		                                     (m_address >> 16) & 0xff,
		                                     (m_address >>  8) & 0xff,
		                                     (m_address      ) & 0xff );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool InetAddress::operator==( const InetAddress& other ) const
	{
		return(m_address == other.m_address);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool InetAddress::operator!=( const InetAddress& other ) const
	{
		return(m_address != other.m_address);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	uint32_t InetAddress::build( uint8_t a1, uint8_t a2, uint8_t a3, uint8_t a4 )
	{
		return ((a1 * 16777216) + (a2 * 65536) + (a3 * 256) + a4);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	void InetAddress::decompose( uint32_t addr, uint8_t& a1, uint8_t& a2, uint8_t& a3, uint8_t& a4 )
	{
		a1 = (addr >> 24) & 0xff;
		a2 = (addr >> 16) & 0xff;
		a3 = (addr >>  8) & 0xff;
		a4 = (addr      ) & 0xff;
	}

	// ---------------------------------------------------------------------------------------------------------------------
	
	//static
	void InetAddress::decompose( uint32_t addr, uint8_t a[4] )
	{
		decompose(addr, a[0], a[1], a[2], a[3]);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	bool InetAddress::isValid( String address )
	{
		try {
			// I realize this is a hack, but I prefer this
			// simple hack over parsing the string in more than
			// one place.
			InetAddress valid(address);
		}
		catch(...) {
			return (false);
		}

		return (true);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InetAddress::setAddress( uint32_t address )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		win32_initWinsock();
		#endif

		m_address = address;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void InetAddress::setAddress( String address )
	{
		if( address.count(".") != 3 || address.equalsWildCard("?*.?*.?*.?*") == false ) {
			throw InvalidInetAddressException(address);
		}

		uint8_t sections[4] = {0};
		int lstPos = 0, curPos = 0, curSec = 0;

		while(true) {
			if( curPos == address.getLength() ) {
				break;
			}

			curPos = address.findPos(".", lstPos);
			if( curPos == String::npos ) {
				curPos = address.getLength();
			}

			String section = address.subString(lstPos, curPos - lstPos);
			if( !section.isValidInt() ) {
				throw InvalidInetAddressException(address);
			}

			int value = section.getAsInt();
			if( value < 0 || value > 255 ) {
				throw InvalidInetAddressException(address);
			}

			sections[curSec++] = value;
			lstPos = curPos + 1;
		}

		setAddress( build(sections[0], sections[1], sections[2], sections[3]) );
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress& InetAddress::operator=( const InetAddress& other )
	{
		m_address = other.m_address;
		return (*this);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress& InetAddress::operator=( uint32_t address )
	{
		m_address = address;
		return (*this);
	}


}}	// namespaces
