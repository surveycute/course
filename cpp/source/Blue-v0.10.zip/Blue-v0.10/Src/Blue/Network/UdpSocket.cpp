//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/UdpSocket.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "UdpSocket.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace network {

	// ---------------------------------------------------------------------------------------------------------------------

	UdpSocket::UdpSocket() :m_port(0), m_bind(NONE)
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	UdpSocket::UdpSocket( uint16_t port ) :m_port(0), m_bind(NONE)
	{
		setPort(port);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	UdpSocket::UdpSocket( uint16_t port, InetAddress dest ) :m_port(0), m_bind(NONE)
	{
		setPort(port);
		setDestination(dest);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	UdpSocket::~UdpSocket()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void UdpSocket::close()
	{
		Socket::close();
		m_bind = NONE;
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool UdpSocket::isReadable() const
	{
		return (m_bind == RECVER);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	bool UdpSocket::isWriteable() const
	{
		return (m_bind == SENDER);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint16_t UdpSocket::getPort() const
	{
		return (m_port);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress UdpSocket::getDestination() const
	{
		return (m_dest);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	UdpSocket::bind_as_e UdpSocket::getBoundAs() const
	{
		return (m_bind);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void UdpSocket::setPort( uint16_t port )
	{
		if( m_bind != NONE ) {
			throw data::DeviceInvalidModeException($("Cannot change UDP port when the socket is bound"));
		}

		m_port = port;
		m_destAddr.sin_port = htons(m_port);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void UdpSocket::setDestination( InetAddress address )
	{
		m_dest = address;
		m_destAddr.sin_family      = AF_INET;
		m_destAddr.sin_addr.s_addr = htonl(m_dest.getAddress());
		m_destAddr.sin_port        = htons(m_port);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void UdpSocket::bind( bind_as_e bindAs )
	{
		if( m_bind != NONE ) {
			throw data::DeviceInvalidModeException($("Cannot bind an already bound UDP socket"));
		}

		if( bindAs == NONE ) {
			throw SocketException($("Cannot bind a UdpSocket to NONE"));
		}

		try {
			m_socket = socket(AF_INET, SOCK_DGRAM, 0);
			if( m_socket == INVALID_SOCKET ) {
				throw SocketCreateException();
			}

			sockaddr_in addr;
			memset(&addr, 0, sizeof(addr));
			
			addr.sin_family      = AF_INET;
			addr.sin_addr.s_addr = htonl(INADDR_ANY);
			addr.sin_port        = htons(bindAs == SENDER ? 0 : m_port);

			int32_t broadcast = (bindAs == SENDER ? 1 : 0);
			setsockopt(m_socket, SOL_SOCKET, SO_BROADCAST, (char*)&broadcast, sizeof(broadcast));

			if( ::bind(m_socket, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR ) {
				throw UdpSocketBindException();
			}

			m_bind = bindAs;
		}
		catch(...) {
			close();
			m_bind = NONE;
			throw;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int UdpSocket::read( void* buffer, int size )
	{
		InetAddress who;
		return readFrom(buffer, size, who);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int UdpSocket::readFrom( void* buffer, int size, InetAddress& who )
	{
		if( !isReadable() ) {
			throw data::DeviceInvalidModeException($("Cannot read when not readable"));
		}

		if( size == 0 ) {
			return (0);
		}

		sockaddr_in addr;
		int addrLen = sizeof(addr);

		int recved = recvfrom(m_socket, (char*)buffer, size, 0, (sockaddr*)&addr, &addrLen);
		if( recved == 0 ) {
			// socket has been closed
			close();
			return (0);
		}
		if( recved == SOCKET_ERROR ) {
			throw data::DeviceReadInterruptException();
		}

		who.setAddress( ntohl(addr.sin_addr.s_addr) );

		return (recved);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int UdpSocket::readFrom( Buffer& buffer, InetAddress& who )
	{
		return readFrom(buffer.getData(), buffer.getSize(), who);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer UdpSocket::readFrom( int size, InetAddress& who )
	{
		Buffer buffer(size);
		if( int retSize = readFrom(buffer.getData(), size, who) ) {
			if( retSize < size ) {
				buffer.resize(retSize);
			}
			return (buffer);
		}

		return (Buffer::null);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	Buffer UdpSocket::readAllFrom( InetAddress& who )
	{
		const int MAX_READ = 32768;
		return readFrom(MAX_READ, who);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int UdpSocket::write( const void* data, int size )
	{
		if( !isWriteable() ) {
			throw data::DeviceInvalidModeException($("Cannot write when not writeable"));
		}

		int sent = sendto(m_socket, (char*)data, size, 0, (sockaddr*)&m_destAddr, sizeof(m_destAddr));
		if( sent == SOCKET_ERROR ) {
			throw data::DeviceWriteInterruptException();
		}

		return (sent);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int UdpSocket::writeTo( const void* data, int size, const InetAddress& who )
	{
		if( !isWriteable() ) {
			throw data::DeviceInvalidModeException($("Cannot write when not writeable"));
		}

		sockaddr_in addr;
		addr.sin_family      = AF_INET;
		addr.sin_addr.s_addr = htonl(who.getAddress());
		addr.sin_port        = htons(m_port);

		int sent = sendto(m_socket, (char*)data, size, 0, (sockaddr*)&addr, sizeof(addr));
		if( sent == SOCKET_ERROR ) {
			throw data::DeviceWriteInterruptException();
		}

		return (sent);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	int UdpSocket::writeTo( const Buffer& buffer, InetAddress& who )
	{
		return writeTo(buffer.getData(), buffer.getSize(), who);
	}


}}	// namespaces
