//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/TcpServerSocket.h
//**

#ifndef __blue_network_TcpServerSocket_h_included__
#define __blue_network_TcpServerSocket_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Network/TcpSocket.h"

// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace network {

	/**
	 * \class TcpServerSocket
	 * \brief %Socket for a TCP server.
	 * \ingroup Network
	 *
	 * The %TcpServerSocket allows for an application to act as
	 * the server part of a TCP client-server connection.  The
	 * %TcpServerSocket is given a port to listen on and told to
	 * start listening and then returns TcpSockets for any
	 * incoming connections.  See TcpSocket for more information
	 * about these connections.
	 *
	 * Here is some sample code showing how the TcpServerSocket
	 * can be used:
	 *
	 * \code
	 * TcpServerSocket server;
	 *
	 * server.setPort(12345);
	 * server.listen();
	 *
	 * while(true) {
	 *     TcpSocket client;
	 *     if( !server.accept(client, 30000) ) { // 30 second timeout
	 *         break; // server timed out
	 *     }
	 *
	 *     String data = "Hello there, " + client.getRemoteAddress().toString();
	 *     client.write(data);
	 *     client.close(); // also done in destructor
	 * }
	 *
	 * server.close(); // close manually, but would be done in destructor
	 * \endcode
	 */
	class BLUE_EXPORT TcpServerSocket :public Socket
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		TcpServerSocket();
		/** Constructor. */
		TcpServerSocket( uint16_t port );

		/** Destructor. */
		virtual ~TcpServerSocket();

		/**
		 * Places the server socket into listen mode, where calls to
		 * accept will return connected sockets.  The port to listen
		 * on must be set before this function is called.  To stop
		 * listening for connections, call TcpServerSocket::close().
		 *
		 * If the socket cannot listen to the port, a
		 * TcpServerSocketListenException will be thrown.
		 *
		 * To determine if a %TcpServerSocket is currently listening,
		 * call TcpServerSocket::isOpen.
		 */
		void listen();


		// ===========================================================
		//  query
		// ===========================================================

		/****
		 * These functions are being overridden to always return
		 * false.  Why?  Because the TcpServerSocket is not meant
		 * to be read from or written to.
		 */
		virtual bool isReadable() const;
		virtual bool isWriteable() const;

		/** Returns the port to listen on. */
		uint16_t getPort() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Sets the port to listen on.  If this is called while the
		 * server socket is listening, a DeviceInvalidModeException
		 * will be thrown.
		 */
		void setPort( uint16_t port );

		/**
		 * Waits indefinately for an incoming TCP connection.  The
		 * TcpSocket passed in becomes a connected socket ready for
		 * communication.  If the device is not currently listening,
		 * a data::DeviceInvalidModeException will be thrown.
		 */
		void accept( TcpSocket& client );
		/**
		 * Waits the given number of milliseconds for an incoming TCP
		 * connection.  If the timeout was exceeded, the function
		 * will return false.  If a connection was made, it will
		 * return true.   If the device is not currently listening,
		 * a data::DeviceInvalidModeException will be thrown.
		 */
		bool accept( TcpSocket& client, int32_t timeout );

	
	private:
		/**
		 * Copy constructor. Private because TcpServerSockets should not be
		 * manipulated by more than one instance.
		 */
		TcpServerSocket( const TcpServerSocket& );
		/** Private assignment operator. See copy constructor documentation. */
		const TcpServerSocket& operator=( const TcpServerSocket& );


		uint16_t m_port;
	};



	/**
	 * \class TcpServerSocketListenException
	 * \brief Thrown when a TcpServerSocket is unable to listen to its
	 *  given port.
	 * \ingroup NetworkExceptions
	 */
	class BLUE_EXPORT TcpServerSocketListenException: public SocketException
	{
	public:
		TcpServerSocketListenException(String desc = String("TCP server socket cannot listen on the requested port", String::STATIC))
			:SocketException(desc) {}

		virtual String getException() const {
			return (String("TcpServerSocketListenException", String::STATIC));
		}
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
