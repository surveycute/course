//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/UdpSocket.h
//**

#ifndef __blue_network_UdpSocket_h_included__
#define __blue_network_UdpSocket_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Network/Socket.h"
#include "Blue/Network/InetAddress.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace network {

	/**
	 * \class UdpSocket
	 * \brief %Socket for UDP communication.
	 * \ingroup Network
	 *
	 * The %UdpSocket allows for quick and easy UDP communication.
	 * UDP communication consists of a computer listening for
	 * UDP packets and a computer sending UDP packets.  Unlike
	 * TCP, a computer does not have to make a connection in order
	 * to send a UDP packet.  The computer sending the data simply
	 * provides the IP address (or broadcast address) and the data
	 * and the packet is sent.  Also unlike TCP, UDP packets are
	 * not guaranteed to be received in the order that they are
	 * sent, nor are they guaranteed to arrive at all.  Because of
	 * this, UDP should be used only when speed is vital (UDP is
	 * faster than TCP) or when broadcast messages are required.
	 *
	 * Here is some code showing how to be a UDP receiver:
	 *
	 * \code
	 * UdpSocket udp(12345); // listen on port 12345
	 * udp.bind(UdpSocket::RECVER); // bind as a receiver
	 *
	 * while( udp.isOpen() ) {
	 *     if( udp.canRead() ) {
	 *         InetAddress who;
	 *         Buffer packet = udp.readAllFrom(who);
	 *         // we can identify where the packet came from by the
	 *         // IP address in 'who'.
	 *     }
	 *     // do something here while waiting for data... a sleep would be good.
	 *     // this loop will never end unless code here closes the socket
	 * }
	 * \endcode
	 *
	 * Here is some code showing how to talk to the code above by
	 * sending a UDP packet to it.
	 *
	 * \code
	 * UdpSocket udp(12345); // send to port 12345
	 * udp.bind(UdpSocket::SENDER); // bind as a sender
	 *
	 * // udp can send to a single computer:
	 * udp.setDestination( InetAddress("127.0.0.1") );
	 * // or it can send to an entire subnet:
	 * udp.setDestination( InetAddress("255.255.255.255") ); // old value overwrote
	 *
	 * udp.write( String("This is a UDP packet!") );
	 * udp.close();
	 * \endcode
	 */
	class BLUE_EXPORT UdpSocket :public Socket
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		UdpSocket();
		/** Constructor. */
		UdpSocket( uint16_t port );
		/** Constructor. */
		UdpSocket( uint16_t port, InetAddress dest );

		/** Destructor. */
		virtual ~UdpSocket();


		/** How is the UDP socket bound, as a sender or a reciever? */
		enum bind_as_e
		{
			NONE,   //!< The socket has not been bound
			SENDER, //!< The socket can send data
			RECVER, //!< The socket can receive data
		};

		virtual void close();


		// ===========================================================
		//  query
		// ===========================================================

		virtual bool isReadable() const;
		virtual bool isWriteable() const;

		/**
		 * Returns the port that this socket is bound to.
		 */
		uint16_t getPort() const;

		/**
		 * Returns the default address to send to when the normal
		 * write functions are called.  This is not used when
		 * writeTo is used.
		 */
		InetAddress getDestination() const;

		/** Returns how the socket is bound. */
		bind_as_e getBoundAs() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

		/**
		 * Sets the port to bind the socket to.  The socket must be
		 * closed prior to this function call, otherwise a
		 * DeviceInvalidModeException will be thrown.
		 */
		void setPort( uint16_t port );

		/**
		 * Sets the destination address to send data to.
		 */
		void setDestination( InetAddress address );

		/**
		 * Binds the socket to the port given through a previous call
		 * to UdpSocket::setPort.  If the socket cannot be bound, a
		 * UdpSocketBindException is thrown.
		 */
		void bind( bind_as_e bindAs );

		using Socket::read; // allow all read functions to be called
		/**
		 * Reads data waiting on the socket, but does not identify
		 * where the data came from.  See the documentation for
		 * data::Device::read for more information about this function.
		 *
		 * \sa readFrom, data::Device::read
		 */
		int read( void* buffer, int size );

		/**
		 * Reads data from the socket and returns the %InetAddress of
		 * the computer that the data came from.
		 *
		 * \sa InetAddress
		 */
		int readFrom( void* buffer, int size, InetAddress& who );
		/** overload */
		int readFrom( Buffer& buffer, InetAddress& who );
		/** overload */
		Buffer readFrom( int size, InetAddress& who );
		/** overload */
		Buffer readAllFrom( InetAddress& who );

		using Socket::write; // allow all write functions to be called
		/**
		 * Writes data to the default destination set by a prior call
		 * to UdpSocket::setDestination.  See the documentation for
		 * data::Device::write for more information about this function.
		 *
		 * \sa writeTo, data::Device::write
		 */
		int write( const void* data, int size );

		/**
		 * Writes data directly to the given destination.
		 *
		 * \sa write
		 */
		int writeTo( const void* data, int size, const InetAddress& who );
		/** overload */
		int writeTo( const Buffer& buffer, InetAddress& who );


	private:
		/**
		 * Copy constructor. Private because UdpSockets should not be
		 * manipulated by more than one instance.
		 */
		UdpSocket( const UdpSocket& );
		/** Private assignment operator. See copy constructor documentation. */
		const UdpSocket& operator=( const UdpSocket& );

		uint16_t    m_port;
		InetAddress m_dest;
		sockaddr_in m_destAddr;
		bind_as_e   m_bind;
	};



	/**
	 * \class UdpSocketBindException
	 * \brief Thrown when a UdpSocket cannot be bound.
	 * \ingroup NetworkExceptions
	 */
	class BLUE_EXPORT UdpSocketBindException :public SocketException
	{
	public:
		UdpSocketBindException( String desc = String("The UDP socket cannot be bound", String::STATIC))
			:SocketException(desc) {}

		virtual String getException() const {
			return (String("UdpSocketBindException", String::STATIC));
		}
	};


}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
