//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/Dns.h
//**

#ifndef __blue_network_Dns_h_included__
#define __blue_network_Dns_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Blue.h"
#include "Blue/Common/Array.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace network {

	/**
	 * \class Dns
	 * \brief Resolves a host name into a %InetAddress.
	 * \ingroup Network
	 *
	 * The %Dns class allows IP addresses to be obtained from
	 * provided host names.  For example, a %Dns lookup on the
	 * host name sourceforge.net would return an IP address of
	 * 216.136.171.196.  Here's the code to do that:
	 *
	 * \code
	 * InetAddress addr = Dns::lookup("sourceforge.net");
	 * \endcode
	 *
	 * Some hosts may have more than one IP address associated
	 * with them.  To receive all the IP addresses available,
	 * use the Dns::lookupMulti function:
	 *
	 * \code
	 * Array<uint32_t> addresses = Dns::lookupMulti("sourceforge.net");
	 * for( int i = 0; i < addresses.getSize(); ++i ) {
	 *     InetAddress addr = addresses[i];
	 *     // use address here...
	 * }
	 * \endcode
	 *
	 * \sa InetAddress
	 */
	class BLUE_EXPORT Dns
	{
	public:
		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the IP address of the given hostname.  If the host
		 * cannot be found, a HostNotFoundException is thrown.
		 */
		static uint32_t lookup( String hostname );

		/**
		 * Returns all of the IP addresses for the given hostname.  If
		 * the host cannot be found, a HostNotFoundException is thrown.
		 */
		static Array<uint32_t> lookupMulti( String hostname );


		/**
		 * Does a reverse lookup on the IP address and returns the
		 * hostname.  If the host cannot be found, a HostNotFoundException
		 * is thrown.
		 */
		static String lookupHostName( uint32_t ip );
	};



	/**
	 * \class HostNotFoundException
	 * \brief Thrown when a Dns lookup cannot find an IP address for the
	 *  given host.
	 * \ingroup NetworkExceptions
	 *
	 * \sa Dns
	 */
	class BLUE_EXPORT HostNotFoundException :public common::Exception
	{
	public:
		HostNotFoundException( String host, String desc = String("Dns lookup on hostname failed", String::STATIC) )
			:Exception(desc), m_host(host) {}

		virtual String getException() const {
			return (String("HostNotFoundException", String::STATIC));
		}

		String getHostName() const {
			return (m_host);
		}

	private:
		String m_host;
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
