//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/Dns.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "Dns.h"

// blue headers
#include "Blue/Network/InetAddress.h"

// system headers
#if defined(BLUE_PLATFORM_WIN32)
#include <winsock2.h>
#	if defined(BLUE_COMPILER_MSVC)
#		pragma comment(lib, "ws2_32.lib")
#	endif
#endif


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

#if defined(BLUE_PLATFORM_WIN32)

	void win32_initWinsock()
	{
		struct winsock
		{
			winsock()
			{
				using namespace blue;
				using namespace blue::common;

				WORD wsVer = MAKEWORD(2,0);
				WSADATA wsaData;

				switch( WSAStartup(wsVer, &wsaData) )
				{
					case 0:
						break; // success!

					case WSASYSNOTREADY:
						throw Exception($("Network subsystem is not ready for network communication"));

					case WSAVERNOTSUPPORTED:
						throw Exception($("Winsock 2.0 is not installed"));

					case WSAEINPROGRESS:
						throw Exception($("A blocking Winsock 1.1 operation is in progress"));

					case WSAEPROCLIM:
						throw Exception($("The maximum number of Winsock tasks has been reached"));

					case WSAEFAULT:
					default: BLUE_ASSERT(false); // should never get here
				}
			}

			~winsock()
			{
				WSACleanup();
			}
		};

		static winsock init;
		return;
	}

#endif


// Functions ===============================================================================================================

namespace blue {
namespace network {

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	uint32_t Dns::lookup( String hostname )
	{
		Array<uint32_t> addresses = lookupMulti(hostname);
		return (addresses.getSize() > 0 ? addresses[0] : 0);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	Array<uint32_t> Dns::lookupMulti( String hostname )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		win32_initWinsock();
		#endif

		// According to msdn, there is one hostent per thread, so this is threadsafe.
		// under Win32.   But is it threadsafe under other platforms?

		if( hostent* host = gethostbyname( hostname.makeUnique().getAsCStr() ) ) {
			int idx = 0;
			Array<uint32_t> ips;
			while(true) {
				char* ptr  = host->h_addr_list[idx++];
				if( ptr == 0 ) break;

				ips.append( ntohl(*(int32_t*)ptr) );
			}
			return (ips);
		}
		else throw HostNotFoundException(hostname);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	//static
	String Dns::lookupHostName( uint32_t ip )
	{
		#if defined(BLUE_PLATFORM_WIN32)
		win32_initWinsock();
		#endif

		// According to msdn, there is one hostent per thread, so this is threadsafe.
		// under Win32.   But is it threadsafe under other platforms?

		uint32_t nip = htonl(ip);
		if( hostent* host = gethostbyaddr( (char*)&nip, 4, AF_INET ) ) {
			return (host->h_name);
		}
		else throw HostNotFoundException( InetAddress(ip).toString() );
	}


}}	// namespaces
