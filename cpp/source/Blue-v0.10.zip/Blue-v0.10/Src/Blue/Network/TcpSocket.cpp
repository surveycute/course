//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/TcpSocket.cpp
//**

// Private Headers =========================================================================================================

// matching header
#include "TcpSocket.h"


// Private Defines/Enums/Typedefs/Etc ======================================================================================

// Private Classes/Structs =================================================================================================

// Private Global Variables ================================================================================================

// External Global Variables ===============================================================================================

// Private Functions =======================================================================================================

// Functions ===============================================================================================================

namespace blue {
namespace network {

	// ---------------------------------------------------------------------------------------------------------------------

	TcpSocket::TcpSocket()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	TcpSocket::TcpSocket( InetAddress address, uint16_t port )
	{
		connect(address, port);
	}

	// ---------------------------------------------------------------------------------------------------------------------

	TcpSocket::~TcpSocket()
	{
	}

	// ---------------------------------------------------------------------------------------------------------------------

	void TcpSocket::connect( InetAddress address, uint16_t port )
	{
		if( isOpen() ) {
			throw data::DeviceInvalidModeException($("Cannot connect an already connected socket"));
		}

		try {
			m_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
			if( m_socket == INVALID_SOCKET ) {
				throw SocketCreateException();
			}

			uint32_t ip = address.getAddress();

			sockaddr_in addr;
			memset(&addr, 0, sizeof(addr));

			addr.sin_family      = AF_INET;
			addr.sin_addr.s_addr = htonl(ip);
			addr.sin_port        = htons(port);

			if( ::connect(m_socket, (sockaddr*)&addr, sizeof(sockaddr)) == SOCKET_ERROR ) {
				throw TcpSocketConnectException();
			}
		}
		catch(...) {
			close();
			throw;
		}
	}

	// ---------------------------------------------------------------------------------------------------------------------

	InetAddress TcpSocket::getRemoteAddress() const
	{
		sockaddr_in addr;
		int addrLen = sizeof(addr);
		if( getpeername(m_socket, (sockaddr*)&addr, &addrLen) != SOCKET_ERROR ) {
			return InetAddress( ntohl(addr.sin_addr.s_addr) );
		}

		return InetAddress();
	}

	// ---------------------------------------------------------------------------------------------------------------------

	uint16_t TcpSocket::getRemotePort() const
	{
		sockaddr_in addr;
		int addrLen = sizeof(addr);
		if( getpeername(m_socket, (sockaddr*)&addr, &addrLen) != SOCKET_ERROR ) {
			return ntohs(addr.sin_port);
		}

		return (0);		
	}


}}	// namespaces
