//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Network/TcpSocket.h
//**

#ifndef __blue_network_TcpSocket_h_included__
#define __blue_network_TcpSocket_h_included__

// Public Headers ==========================================================================================================

#include "Blue/Network/Socket.h"
#include "Blue/Network/InetAddress.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

// Public Classes/Structs ==================================================================================================

namespace blue {
namespace network {

	/**
	 * \class TcpSocket
	 * \brief %Socket for a TCP connection.
	 * \ingroup Network
	 *
	 * The %TcpSocket allows for quick and easy TCP communication.
	 * TCP communication consists of one computer (the server) waiting 
	 * for a connection and another computer (the client) trying to
	 * connect to the server, knowing the IP address of the server ahead
	 * of time. Here is an example of how the TcpSocket can be used to
	 * download a webpage from a remote webserver:
	 *
	 * \code
	 * String website = "bluelib.sourceforge.net";
	 * InetAddress address = Dns::lookup(website); // find the IP address of the server
	 *
	 * String request = "GET / HTTP/1.1\r\n"
	 *                  "Host: " + website + ":80\r\n"
	 *                  "Connection: Close\r\n"
	 *                  "\r\n";
	 *
	 * TcpSocket tcp(address, 80);	// HTTP is over port 80
	 *
	 * tcp.write(request); // assume all data was transferred
	 *
	 * Buffer data;
	 * while( tcp.isOpen() ) {
	 *     // checking TcpSocket::canRead prevents the read from blocking!
	 *     if( tcp.canRead() ) {
	 *        data += tcp.readAll();
	 *     }
	 *     // do something here while waiting for data... a sleep would be good.
	 * }
	 *
	 * tcp.close();
	 * \endcode
	 *
	 * \sa InetAddress, Dns, UdpSocket
	 */
	class BLUE_EXPORT TcpSocket :public Socket
	{
	public:
		// ===========================================================
		//  creation/destruction
		// ===========================================================

		/** Constructor. */
		TcpSocket();
		/** Constructor. */
		TcpSocket( InetAddress address, uint16_t port );

		/** Destructor. */
		virtual ~TcpSocket();

		/**
		 * Initiates a TCP connection to the destination.  If the
		 * socket cannot connect, a TcpSocketConnectException will
		 * be thrown.
		 */
		void connect( InetAddress address, uint16_t port );


		// ===========================================================
		//  query
		// ===========================================================

		/**
		 * Returns the address of the computer connected to.  The
		 * isOpen function should be called prior to processing the
		 * results of this function.
		 */
		InetAddress getRemoteAddress() const;
		/**
		 * Returns the port of the computer connected to.  The
		 * isOpen function should be called prior to processing the
		 * results of this function.
		 */
		uint16_t getRemotePort() const;


		// ===========================================================
		//  manipulation
		// ===========================================================

	
	private:
		/**
		 * Copy constructor. Private because Sockets should not be
		 * manipulated by more than one instance.
		 */
		TcpSocket( const TcpSocket& );
		/** Private assignment operator. See copy constructor documentation. */
		const TcpSocket& operator=( const TcpSocket& );
	};


	/**
	 * \class TcpSocketConnectException
	 * \brief Thrown when a TCP connection cannot be established.
	 * \ingroup NetworkExceptions
	 */
	class BLUE_EXPORT TcpSocketConnectException :public SocketException
	{
	public:
		TcpSocketConnectException( String desc = String("Could not establish TCP connection with destination", String::STATIC) )
			:SocketException(desc) {}

		virtual String getException() const {
			return (String("TcpSocketConnectException", String::STATIC));
		}
	};

}}	// namespaces


// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
