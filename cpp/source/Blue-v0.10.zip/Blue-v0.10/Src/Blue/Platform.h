//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Platform.h
//**

#ifndef __blue_Platform_h_included__
#define __blue_Platform_h_included__

// Public Headers ==========================================================================================================

#include "Config.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

#define BLUE_ASSERT(EXPR)

#if defined(BLUE_PLATFORM_WIN32)

#	if !defined(BLUE_PLATFORM_I386)
#		define BLUE_PLATFORM_I386
#	endif

#	if defined(BLUE_COMPILER_MSVC)

#		if defined(_DEBUG)
#			include <assert.h>
#			undef  BLUE_ASSERT
#			define BLUE_ASSERT(EXPR) assert( (EXPR) )
#			define BLUE_DEBUG
#		endif

#		if !defined(BLUE_ENABLE_WARNINGS)
			// disable some warnings
#			pragma warning(disable:4291)   // no matching operator delete found
#			pragma warning(disable:4251)   // 'member var' needs to have dll-interface to be used by clients of class

#		endif

#		if defined(BLUE_DLL)
			// compiling blue DLL
#			define BLUE_EXPORT        __declspec(dllexport)

#		elif defined(BLUE_LIB)
			// compiling blue static lib
#			define BLUE_EXPORT

#		elif defined(BLUE_APP_USING_DLL)
			// compiling app using blue as a DLL
#			define BLUE_OBJECT_EXPORT __declspec(dllexport)
#			define BLUE_OBJECT_IMPORT __declspec(dllimport)
#			define BLUE_EXPORT        BLUE_OBJECT_IMPORT

#		elif defined(BLUE_APP_USING_LIB)
			// compiling app using blue as a static library
#			define BLUE_OBJECT_EXPORT
#			define BLUE_OBJECT_IMPORT
#			define BLUE_EXPORT

#		elif defined(BLUE_DLL_USING_DLL)
			// compiling dll using blue as a DLL (plugin)
#			define BLUE_OBJECT_EXPORT __declspec(dllexport)
#			define BLUE_OBJECT_IMPORT __declspec(dllimport)
#			define BLUE_EXPORT        BLUE_OBJECT_IMPORT

#		else
			// one of the above must be defined when using the blue library
#			error("See documentation.  One of the following must be defined: BLUE_APP_USING_DLL, BLUE_APP_USING_LIB, BLUE_DLL_USING_DLL")
#		endif

		// standard datatypes
		namespace blue {

			typedef char	          int8_t;		//!<  8 bit integer for the current platform.
			typedef short	          int16_t;		//!< 16 bit integer for the current platform.
			typedef int               int32_t;		//!< 32 bit integer for the current platform.
			typedef __int64           int64_t;		//!< 64 bit integer for the current platform.
			typedef unsigned char     uint8_t;		//!<  8 bit unsigned integer for the current platform.
			typedef unsigned short    uint16_t;		//!< 16 bit unsigned integer for the current platform.
			typedef unsigned int      uint32_t;		//!< 32 bit unsigned integer for the current platform.
			typedef unsigned __int64  uint64_t;		//!< 64 bit unsigned integer for the current platform.

			typedef float             float32_t;    //!< 32 bit float for the current platform.
			typedef double            float64_t;    //!< 64 bit float for the current platform.

			typedef double            real_t;		//!< real numbers

			typedef uint8_t           byte_t;		//!< machine byte
			typedef uint16_t          word_t;		//!< machine word
			typedef uint32_t          dword_t;		//!< machine dword
			typedef uint64_t          qword_t;		//!< machine qword

			typedef uint16_t          flags16_t;	//!< 16 bit flag variable
			typedef uint32_t          flags32_t;	//!< 32 bit flag variable
			typedef uint64_t          flags64_t;	//!< 64 bit flag variable
		}

#	else	// end msvc
#		error("Blue is not configured for this compiler")

#	endif	// end compiler

#else	// end win32
#	error("Blue is not configuring for this platform")

#endif	// end platform


// Public Classes/Structs ==================================================================================================

// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

#endif // include guard
