//************************************************************************************************************************** 
//* Blue - General Purpose C++ Library
//* Copyright (c) 2002-2004 Josh Harler
//* 
//* This software is provided 'as-is', without any express or implied warranty. In no event
//* will the authors be held liable for any damages arising from the use of this software.
//* 
//* Permission is granted to anyone to use this software for any purpose, including commercial
//* applications, and to alter it and redistribute it freely, subject to the following restrictions:
//* 
//* 	1. The origin of this software must not be misrepresented; you must not claim that you
//* 	wrote the original software. If you use this software in a product, an acknowledgment in the
//* 	product documentation would be appreciated but is not required.
//* 
//* 	2. Altered source versions must be plainly marked as such, and must not be misrepresented as
//* 	being the original software.
//* 
//* 	3. This notice may not be removed or altered from any source distribution.
//*
//*
//* file   Blue.h
//**

#ifndef __blue_Blue_h_included__
#define __blue_Blue_h_included__

// Public Headers ==========================================================================================================

#include "Platform.h"


// Public Defines/Enums/Typedefs/Etc. ======================================================================================

namespace blue {
	namespace common{
	}

	// internal classes don't need to prepend common:: to common classes.
	using namespace ::blue::common;
}


// Public Classes/Structs ==================================================================================================

// Public External Variables ===============================================================================================

// Public Function Prototypes ==============================================================================================

// Public Inline Functions =================================================================================================

namespace blue {

	/** Returns the absolute value of the value given */
	template<typename type_t> inline type_t abs( const type_t& val )
	{
		return (val < 0 ? -val : val);
	}


	/** Returns the smallest of the two values */
	template<typename type_t> inline type_t min( const type_t& one, const type_t& two )
	{
		return (one < two ? one : two);
	}


	/** Returns the largest of the two values */
	template<typename type_t> inline type_t max( const type_t& one, const type_t& two )
	{
		return (one > two ? one : two);
	}


	/** Clamps the given value between the given range */
	template<typename type_t> inline type_t clamp( const type_t& val, const type_t& minVal, const type_t& maxVal )
	{
		return max( min(val, maxVal), minVal );
	}


	/** Swaps the values of the two given variables */
	template<typename type_t> inline void swap( type_t& one, type_t& two )
	{
		type_t tmp = one;
		one = two;
		two = tmp;
	}
}

#include "Common/MemoryManager.h"
#include "Common/Exception.h"

#endif // include guard
